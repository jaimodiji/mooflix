import { BLOG_POSTS } from "../../services/blogData";

const BASE_URL = "https://mooflix.online";
const TMDB_API_KEY = process.env.TMDB_API_KEY || "f4c3361d4917e9f25f79f339356eb8d9";
const DEFAULT_UA =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36";

const CORS_HEADERS: Record<string, string> = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
};

function jsonResponse(data: unknown, status = 200, extraHeaders: Record<string, string> = {}): Response {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      "Content-Type": "application/json; charset=utf-8",
      ...CORS_HEADERS,
      ...extraHeaders,
    },
  });
}

function htmlResponse(html: string, status = 200, extraHeaders: Record<string, string> = {}): Response {
  return new Response(html, {
    status,
    headers: {
      "Content-Type": "text/html; charset=utf-8",
      "Cache-Control": "no-cache, no-store, must-revalidate",
      "Referrer-Policy": "no-referrer-when-downgrade",
      ...CORS_HEADERS,
      ...extraHeaders,
    },
  });
}

async function fetchWithTimeout(url: string, init: RequestInit = {}, timeoutMs = 3500): Promise<Response> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(url, { ...init, signal: controller.signal });
  } finally {
    clearTimeout(timer);
  }
}

function escapeXml(str: string): string {
  return str
    .replace(/&/g, "&amp;")
    .replace(/'/g, "&apos;")
    .replace(/"/g, "&quot;")
    .replace(/>/g, "&gt;")
    .replace(/</g, "&lt;");
}

function normalizeRoutePath(pathname: string): string {
  if (pathname.startsWith("/.netlify/functions/api")) {
    const stripped = pathname.slice("/.netlify/functions/api".length);
    return stripped.startsWith("/") ? stripped : `/${stripped}`;
  }
  return pathname;
}

// 1. Multi-Server Availability Resolver (Server 1 -> Server 2 -> Server 3 -> Server 4)
async function handlePlayerResolve(url: URL): Promise<Response> {
  const rawType = (url.searchParams.get("type") || "movie").toLowerCase();
  const isTv = rawType === "tv" || rawType === "series" || rawType === "shows";
  let tmdbId = (url.searchParams.get("tmdbId") || "").trim();
  let imdbId = (url.searchParams.get("imdbId") || "").trim();
  const season = Math.max(1, Number(url.searchParams.get("s") || url.searchParams.get("season")) || 1);
  const episode = Math.max(1, Number(url.searchParams.get("e") || url.searchParams.get("episode")) || 1);

  if (tmdbId.startsWith("tt") && !imdbId) {
    imdbId = tmdbId;
    tmdbId = "";
  }

  try {
    if (!tmdbId && imdbId.startsWith("tt")) {
      const findRes = await fetchWithTimeout(
        `https://api.themoviedb.org/3/find/${encodeURIComponent(imdbId)}?api_key=${TMDB_API_KEY}&external_source=imdb_id`,
        {},
        3000
      );
      if (findRes.ok) {
        const findData: any = await findRes.json();
        const match = isTv
          ? findData.tv_results?.[0] || findData.movie_results?.[0]
          : findData.movie_results?.[0] || findData.tv_results?.[0];
        if (match?.id) tmdbId = String(match.id);
      }
    }

    if (tmdbId && (!imdbId || !imdbId.startsWith("tt"))) {
      const extRes = await fetchWithTimeout(
        `https://api.themoviedb.org/3/${isTv ? "tv" : "movie"}/${encodeURIComponent(tmdbId)}/external_ids?api_key=${TMDB_API_KEY}`,
        {},
        3000
      );
      if (extRes.ok) {
        const extData: any = await extRes.json();
        if (extData?.imdb_id && String(extData.imdb_id).startsWith("tt")) {
          imdbId = String(extData.imdb_id);
        }
      }
    }
  } catch {
    // Non-blocking ID cross-resolution fallback
  }

  const browserHeaders = {
    "User-Agent": DEFAULT_UA,
    Accept: "text/html,application/json,*/*;q=0.8",
  };

  const checkServer1 = async (): Promise<boolean | "unknown"> => {
    if (!tmdbId) return false;
    try {
      if (isTv) {
        const s1Url = `https://raw.githubusercontent.com/Watchout2025/api/refs/heads/main/hls/tv/${encodeURIComponent(tmdbId)}/S${season}.json`;
        const r = await fetchWithTimeout(s1Url, { headers: browserHeaders }, 2500);
        if (r.status === 404) return false;
        if (!r.ok) return "unknown";
        const json: any = await r.json();
        return Boolean(json && json[String(episode)]);
      } else {
        const s1Url = `https://raw.githubusercontent.com/Watchout2025/api/refs/heads/main/hls/movie/${encodeURIComponent(tmdbId)}`;
        const r = await fetchWithTimeout(s1Url, { headers: browserHeaders }, 2500);
        if (r.status === 404) return false;
        if (!r.ok) return "unknown";
        const txt = (await r.text()).trim();
        return txt.length > 0 && !txt.toLowerCase().includes("not found");
      }
    } catch {
      return "unknown";
    }
  };

  const checkServer2 = async (): Promise<boolean | "unknown"> => {
    if (!imdbId || !imdbId.startsWith("tt")) return false;
    const sPad = String(season).padStart(2, "0");
    const ePad = String(episode).padStart(2, "0");
    const play4uUrl = isTv
      ? `https://play4u.org/series/${encodeURIComponent(imdbId)}/s-${sPad}/ep-${ePad}`
      : `https://play4u.org/${encodeURIComponent(imdbId)}`;
    try {
      const r = await fetchWithTimeout(
        play4uUrl,
        { headers: { ...browserHeaders, Referer: "https://mooflix.online/" } },
        2800
      );
      if (r.status === 404 || r.status >= 500) return false;
      if (!r.ok) return "unknown";
      const html = await r.text();
      if (/<title>\s*Not found\s*<\/title>/i.test(html) || /Video not found\./i.test(html)) {
        return false;
      }
      return true;
    } catch {
      return "unknown";
    }
  };

  const checkServer4 = async (): Promise<boolean | "unknown"> => {
    if (!tmdbId) return false;
    const nxshaUrl = isTv
      ? `https://nxsha.space/embed/tv/${encodeURIComponent(tmdbId)}/${season}/${episode}?disable_ad=true&disable_ads=true&ads=0&no_ads=1`
      : `https://nxsha.space/embed/movie/${encodeURIComponent(tmdbId)}?disable_ad=true&disable_ads=true&ads=0&no_ads=1`;
    try {
      const r = await fetchWithTimeout(nxshaUrl, { headers: browserHeaders }, 2800);
      if (r.status === 404 || !r.ok) return false;
      const html = await r.text();
      if (html.includes("__next_error__") || /not\s*found/i.test(html.slice(0, 1200))) {
        return false;
      }
      return true;
    } catch {
      return "unknown";
    }
  };

  const [s1, s2, s4] = await Promise.all([checkServer1(), checkServer2(), checkServer4()]);

  let recommendedServer: "1" | "2" | "3" | "4" = "1";
  if (s1 === true) {
    recommendedServer = "1";
  } else if (s1 === false) {
    if (s2 === true || s2 === "unknown") recommendedServer = "2";
    else recommendedServer = "3";
  } else {
    recommendedServer = "1";
  }

  return jsonResponse(
    {
      resolvedTmdbId: tmdbId || "",
      resolvedImdbId: imdbId || "",
      availability: {
        "1": s1,
        "2": s2,
        "3": "unknown" as const,
        "4": s4,
      },
      recommendedServer,
    },
    200,
    {
      "Cache-Control": "public, max-age=300, s-maxage=300, stale-while-revalidate=600",
    }
  );
}

// 2. Server 1 Clean Ad-Free Proxy (vidout.pages.dev) with Auto-Failover Hook
async function handlePlayerProxy(req: Request, url: URL): Promise<Response> {
  const type = (url.searchParams.get("type") || "movie").toLowerCase();
  const isTv = type === "tv" || type === "series";
  const tmdbId = (url.searchParams.get("tmdbId") || url.searchParams.get("id") || "").trim();
  const season = Math.max(1, Number(url.searchParams.get("s") || url.searchParams.get("season")) || 1);
  const episode = Math.max(1, Number(url.searchParams.get("e") || url.searchParams.get("episode")) || 1);

  const sendFailoverNoticeHtml = (reason: string) =>
    htmlResponse(`<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>Switching Server...</title></head>
<body style="background:#000;color:#fff;font-family:sans-serif;display:flex;align-items:center;justify-content:center;height:100vh;margin:0;">
  <div style="text-align:center;opacity:0.85;font-size:14px;">Stream unavailable on Server 1. Switching to Server 2...</div>
  <script>
    try { window.parent.postMessage({ type: 'MOOFLIX_PLAYER_NOT_FOUND', server: '1', reason: ${JSON.stringify(reason)} }, '*'); } catch(e){}
  </script>
</body></html>`);

  if (!tmdbId) {
    return sendFailoverNoticeHtml("missing_tmdb_id");
  }

  const upstreamUrl = isTv
    ? `https://vidout.pages.dev/tv/${encodeURIComponent(tmdbId)}/S${season}/E${episode}`
    : `https://vidout.pages.dev/movie/${encodeURIComponent(tmdbId)}`;

  try {
    const upstreamRes = await fetchWithTimeout(
      upstreamUrl,
      {
        headers: {
          "User-Agent": req.headers.get("user-agent") || DEFAULT_UA,
          Referer: "https://vidout.pages.dev/",
          Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        },
      },
      5000
    );

    if (!upstreamRes.ok) {
      return sendFailoverNoticeHtml(`http_${upstreamRes.status}`);
    }

    let html = await upstreamRes.text();
    html = html.replace(/window\.location\.replace\(\s*["']https:\/\/www\.google\.com\/?["']\s*\)/gi, "void 0");
    html = html.replace(/location\.replace\(\s*["']https:\/\/www\.google\.com\/?["']\s*\)/gi, "void 0");
    html = html.replace(
      /<script[^>]*src=["'](?:https?:)?\/\/[^"']*(?:wpadmngr|magsrv|ariososhands|popads|hilltopads|onclicka|acscdn|adsterra|monetag|quge5|capitalhospitals|optimserve|auctionr|heiressnicholasfitful|highperformanceformat|effectivecpmnetwork)[^"']*["'][^>]*?>\s*<\/script>/gi,
      "<!-- ad-removed -->"
    );

    const injectedHead = `
<base href="https://vidout.pages.dev/">
<meta name="referrer" content="no-referrer">
<script>
  (function() {
    var notified = false;
    function notifyFailover(reason) {
      if (notified) return;
      notified = true;
      try {
        window.parent.postMessage({ type: 'MOOFLIX_PLAYER_NOT_FOUND', server: '1', reason: reason || 'not_found' }, '*');
      } catch(e) {}
    }

    window.aclib = { runPop: function(){}, runAutoTag: function(){} };
    window.open = function() {
      return { close: function(){}, closed: true, focus: function(){}, blur: function(){}, postMessage: function(){}, location: { href: 'about:blank' } };
    };
    window.alert = function() { return null; };
    window.confirm = function() { return true; };

    var wrapFn = function(name) {
      return function() {
        notifyFailover(name);
        return undefined;
      };
    };

    try {
      Object.defineProperty(window, 'showFallbackPlayer', {
        configurable: true,
        set: function() {},
        get: function() { return wrapFn('fallback_triggered'); }
      });
    } catch(e) {}

    window.addEventListener('DOMContentLoaded', function() {
      var checkDomError = function() {
        var text = (document.body && document.body.innerText ? document.body.innerText : '').toLowerCase();
        if (/(not found|video unavailable|no stream|no sources|media not found|failed to load video|episode not found|404 error)/.test(text)) {
          notifyFailover('dom_error_text');
        }
        var frames = document.querySelectorAll('iframe');
        for (var i = 0; i < frames.length; i++) {
          var s = (frames[i].getAttribute('src') || '').toLowerCase();
          if (s.includes('vidy.st')) {
            frames[i].removeAttribute('src');
            notifyFailover('vidy_fallback_blocked');
          }
        }
      };
      var obs = new MutationObserver(checkDomError);
      if (document.body) obs.observe(document.body, { childList: true, subtree: true, characterData: true });
      setTimeout(checkDomError, 1500);
      setTimeout(checkDomError, 4000);
    });
  })();
</script>
`;

    if (html.includes("<head>")) {
      html = html.replace("<head>", `<head>${injectedHead}`);
    } else if (html.includes("<html>")) {
      html = html.replace("<html>", `<html><head>${injectedHead}</head>`);
    } else {
      html = `<head>${injectedHead}</head>${html}`;
    }

    return htmlResponse(html);
  } catch {
    return sendFailoverNoticeHtml("upstream_timeout");
  }
}

// 3. Play4U Verifier & Redirect
async function handlePlay4u(url: URL): Promise<Response> {
  const imdbId = url.searchParams.get("imdbId") || "";
  const tmdbId = url.searchParams.get("tmdbId") || "";
  const rawType = url.searchParams.get("type") || "";
  const type = rawType === "series" || rawType === "tv" ? "tv" : "movie";
  const season = Math.max(1, Number(url.searchParams.get("s") || url.searchParams.get("season")) || 1);
  const episode = Math.max(1, Number(url.searchParams.get("e") || url.searchParams.get("episode")) || 1);

  const fallbackUrl =
    type === "movie"
      ? `https://rozgarlelo.modiplay.xyz/embed/tmdb/movie?id=${tmdbId || imdbId}`
      : `https://rozgarlelo.modiplay.xyz/embed/tmdb/tv?id=${tmdbId || imdbId}&s=${season}&e=${episode}`;

  if (!imdbId || !imdbId.startsWith("tt")) {
    return Response.redirect(fallbackUrl, 302);
  }

  const sPad = String(season).padStart(2, "0");
  const ePad = String(episode).padStart(2, "0");
  const play4uTarget =
    type === "movie"
      ? `https://play4u.org/${imdbId}`
      : `https://play4u.org/series/${imdbId}/s-${sPad}/ep-${ePad}`;

  try {
    const checkRes = await fetchWithTimeout(
      play4uTarget,
      { headers: { "User-Agent": DEFAULT_UA, Referer: "https://mooflix.online/" } },
      2500
    );
    const body = checkRes.ok ? await checkRes.text() : "";
    const isValid =
      checkRes.status === 200 &&
      !/<title>\s*Not found\s*<\/title>/i.test(body) &&
      !/Video not found\./i.test(body);
    return Response.redirect(isValid ? play4uTarget : fallbackUrl, 302);
  } catch {
    return Response.redirect(fallbackUrl, 302);
  }
}

// 4. Live Sports Streams (ondemand.st + fallback to static sports_streams.json on origin)
async function buildStaticSportsFallback(origin: string) {
  try {
    const res = await fetchWithTimeout(`${origin}/data/sports_streams.json`, {}, 2500);
    if (!res.ok) return null;
    const staticData: any = await res.json();
    const categoriesMap = new Map<string, any[]>();
    const allEvents = [...(staticData["Live Events"] || []), ...(staticData["Upcoming Events"] || [])];

    allEvents.forEach((ev: any, idx: number) => {
      const cat = ev.category || "Sports";
      if (!categoriesMap.has(cat)) categoriesMap.set(cat, []);
      categoriesMap.get(cat)!.push({
        id: ev.id || `ev-${idx}`,
        name: ev.name,
        poster: ev.poster || "https://images.unsplash.com/photo-1540747913346-19e32dc3e97e?w=800",
        starts_at: ev.status === "live" ? Math.floor(Date.now() / 1000) - 1800 : Math.floor(Date.now() / 1000) + 7200,
        ends_at: Math.floor(Date.now() / 1000) + 14400,
        category_name: cat,
        status: ev.status === "live" ? "live" : "upcoming",
        league: cat,
        viewers: 15000 + ((idx * 211) % 25000),
        always_live: ev.status === "live" ? 1 : 0,
        sources: (ev.streams || []).map((s: any, sIdx: number) => ({
          source: s.name || `Server ${sIdx + 1}`,
          id: `${ev.id || idx}-s${sIdx + 1}`,
          name: s.name || `Server ${sIdx + 1}`,
          embed: s.url || "",
          hd: 1,
        })),
        iframe: ev.streams?.[0]?.url || "",
      });
    });

    const streams = Array.from(categoriesMap.entries()).map(([category, sList], i) => ({
      id: i + 1,
      category,
      streams: sList,
    }));

    return { success: true, timestamp: Math.floor(Date.now() / 1000), streams };
  } catch {
    return null;
  }
}

async function handleOndemandStreams(url: URL): Promise<Response> {
  try {
    const upstreamRes = await fetchWithTimeout(
      "https://ondemand.st/papi/api/streams",
      {
        headers: {
          "User-Agent": DEFAULT_UA,
          Accept: "application/json",
        },
      },
      4500
    );

    if (upstreamRes.ok) {
      const data: any = await upstreamRes.json();
      if (data && Array.isArray(data.streams) && data.streams.length > 0) {
        return jsonResponse(data, 200, {
          "Cache-Control": "public, max-age=60, s-maxage=60, stale-while-revalidate=300",
        });
      }
    }
  } catch {
    // Handled by fallback below
  }

  const fallback = await buildStaticSportsFallback(url.origin);
  if (fallback) {
    return jsonResponse(fallback, 200, {
      "Cache-Control": "public, max-age=60, s-maxage=60, stale-while-revalidate=300",
    });
  }

  return jsonResponse({ success: true, streams: [] }, 200, {
    "Cache-Control": "no-cache",
  });
}

// 5. Clean Sports Embed Proxy
async function handleCleanStream(req: Request, url: URL): Promise<Response> {
  const embedUrl = url.searchParams.get("url") || "";
  if (!embedUrl || !embedUrl.startsWith("http")) {
    return new Response("Invalid stream embed URL", { status: 400, headers: CORS_HEADERS });
  }

  const sendAutoFailoverPage = (reason: string) =>
    htmlResponse(`<!DOCTYPE html><html><head><meta charset="utf-8"><style>html,body{margin:0;height:100%;background:#000;color:#ccc;font-family:system-ui,sans-serif;display:flex;align-items:center;justify-content:center;text-align:center;font-size:13px}</style></head><body><div>Switching to next working server...</div><script>try{window.parent.postMessage({type:'MOOFLIX_SPORTS_ERROR',reason:${JSON.stringify(reason)}},'*');}catch(e){}</script></body></html>`);

  try {
    const targetUrl = new URL(embedUrl);
    const isDamitv = targetUrl.hostname.includes("damitv.st");

    const upstreamRes = await fetchWithTimeout(
      embedUrl,
      {
        headers: {
          "User-Agent": req.headers.get("user-agent") || DEFAULT_UA,
          Referer: isDamitv ? "https://ondemand.st/" : `${targetUrl.origin}/`,
          Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        },
      },
      5500
    );

    if (!upstreamRes.ok) {
      return sendAutoFailoverPage(`upstream_http_${upstreamRes.status}`);
    }

    let html = await upstreamRes.text();

    if (
      /Worker threw exception|cf-error-details|<title>\s*(403 Forbidden|502 Bad Gateway|500 Internal Server Error)/i.test(
        html
      )
    ) {
      return sendAutoFailoverPage("upstream_cf_error");
    }

    if (embedUrl.includes("bintv-sources.pages.dev")) {
      const idParam = targetUrl.searchParams.get("id") || "";
      if (idParam) {
        try {
          const decodedUrl = Buffer.from(idParam, "base64").toString("utf8");
          if (decodedUrl.startsWith("http")) {
            const probeRes = await fetchWithTimeout(
              decodedUrl,
              { headers: { "User-Agent": DEFAULT_UA, Referer: "https://bintv-sources.pages.dev/" } },
              2500
            );
            if (!probeRes.ok) {
              return sendAutoFailoverPage(`bintv_worker_${probeRes.status}`);
            }
          }
        } catch {
          return sendAutoFailoverPage("bintv_worker_unreachable");
        }
        html = html.replace(/var encoded\s*=\s*[^;]+;/g, `var encoded = "${idParam}";`);
      }
      html = html.replace(
        /<script[^>]*src=["'](?:https?:)?\/\/[^"']*(?:acscdn|capitalhospitals|optimserve|quge5|adsterra|monetag)[^"']*["'][^>]*?>\s*<\/script>/gi,
        "<!-- ad-script-neutralized -->"
      );
      html = html.replace(/<script[^>]*>[\s\S]*?aclib\.runPop[\s\S]*?<\/script>/gi, "<!-- aclib-neutralized -->");
    }

    html = html.replace(/isSandboxed\(\)\s*\{return this\.#pe\}/g, "isSandboxed(){return false}");
    html = html.replace(/this\.#s\.isSandboxed\(\)/g, "false");
    html = html.replace(/showSandboxWarningOverlay\(\)\s*\{/g, "showSandboxWarningOverlay(){return;");
    html = html.replace(
      /#be\(\)\s*\{const e=document\.createElement\("div"\);e\.id="sbxwo"/g,
      '#be(){return;const e=document.createElement("div");e.id="sbxwo"'
    );
    html = html.replace(
      /var a=location\.protocol\+["'\s]*\+?["']\/\/["']\s*\+?\s*location\.host/g,
      `var a="${targetUrl.origin}"`
    );
    html = html.replace(
      /var a=location\.protocol\+"(\/\/)"\+location\.host/g,
      `var a="${targetUrl.origin}"`
    );

    html = html.replace(/<script[^>]*>\s*aclib\.runPop[\s\S]*?<\/script>/gi, "<!-- aclib-neutralized -->");
    html = html.replace(
      /<script[^>]*src=["'](?:https?:)?\/\/[^"']*(?:wpadmngr|magsrv|ariososhands|popads|hilltopads|onclicka|acscdn|capitalhospitals|optimserve|quge5|auctionr|heiressnicholasfitful|highperformanceformat|adsterra|monetag|effectivecpmnetwork|llvpn|doubleclick|googlesyndication)[^"']*["'][^>]*?>\s*<\/script>/gi,
      "<!-- ad-script-neutralized -->"
    );
    html = html.replace(
      /<script[^>]*>[\s\S]*?(?:ariososhands|wpadmngr|magsrv|atOptions|popads|hilltopads|onclicka)[\s\S]*?<\/script>/gi,
      "<!-- ad-inline-neutralized -->"
    );
    html = html.replace(/<iframe[^>]*?(?:visibility:\s*hidden|display:\s*none)[^>]*?>[\s\S]*?<\/iframe>/gi, "");

    const antiAdShield = `
<base href="${targetUrl.origin}/">
<meta name="referrer" content="no-referrer-when-downgrade">
<style>
  #sbxwo, [id*="sbx"], .sandbox-warning, div[style*="z-index: 10000"], div[style*="zIndex: 1e4"], div[style*="z-index: 2147483647"], div[style*="z-index: 999999"] {
    display: none !important;
    opacity: 0 !important;
    pointer-events: none !important;
    visibility: hidden !important;
    height: 0 !important;
    width: 0 !important;
  }
</style>
<script>
  (function() {
    window.aclib = { runPop: function() {}, runAutoTag: function() {} };
    window.open = function() {
      return { close: function() {}, closed: true, focus: function() {}, blur: function() {}, postMessage: function() {}, location: { href: 'about:blank' } };
    };
    window.alert = function() { return null; };
    window.confirm = function() { return true; };
    try {
      Object.defineProperty(window, 'onbeforeunload', { configurable: false, writable: false, value: null });
    } catch(e) {}

    var reportedSportsErr = false;
    function notifySportsFail(reason) {
      if (reportedSportsErr) return;
      reportedSportsErr = true;
      try {
        window.parent.postMessage({ type: 'MOOFLIX_SPORTS_ERROR', reason: reason || 'stream_error' }, '*');
      } catch(e) {}
    }

    window.addEventListener('DOMContentLoaded', function() {
      var checkStreamHealth = function() {
        var text = (document.body && document.body.innerText ? document.body.innerText : '').toLowerCase();
        var vid = document.querySelector('video');
        var hasPlayingVideo = Boolean(vid && vid.readyState >= 2 && !vid.error);
        if (!hasPlayingVideo && /(stream unavailable|not found|channel offline|stream offline|no stream|404 error|media could not be loaded)/.test(text)) {
          notifySportsFail('offline_or_not_found');
        }
      };
      var obs = new MutationObserver(checkStreamHealth);
      if (document.body) obs.observe(document.body, { childList: true, subtree: true });
      setTimeout(checkStreamHealth, 3500);
    });
  })();
</script>
`;

    if (html.includes("<head>")) {
      html = html.replace("<head>", "<head>" + antiAdShield);
    } else if (html.includes("<html>")) {
      html = html.replace("<html>", "<html><head>" + antiAdShield + "</head>");
    } else {
      html = "<head>" + antiAdShield + "</head>" + html;
    }

    return htmlResponse(html);
  } catch {
    return sendAutoFailoverPage("clean_stream_timeout");
  }
}

// 6. Red-Themed Download Proxy
async function handleDownloadProxy(url: URL): Promise<Response> {
  const targetUrl = url.searchParams.get("url") || "";
  if (!targetUrl || !targetUrl.startsWith("http")) {
    return new Response("Invalid target URL", { status: 400, headers: CORS_HEADERS });
  }

  try {
    const upstreamRes = await fetchWithTimeout(
      targetUrl,
      {
        headers: {
          "User-Agent": DEFAULT_UA,
          Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        },
      },
      5500
    );

    if (!upstreamRes.ok) {
      return Response.redirect(targetUrl, 302);
    }

    let html = await upstreamRes.text();
    const baseTag = `<base href="${targetUrl}">`;
    const redThemeOverrides = `
<style id="mooflix-red-download-theme">
  :root {
    --primary: #e50914 !important;
    --primary-rgb: 229, 9, 20 !important;
    --primary-color: #e50914 !important;
    --accent: #ff2a38 !important;
    --yellow-400: #e50914 !important;
    --yellow-500: #e50914 !important;
    --amber-400: #e50914 !important;
    --amber-500: #e50914 !important;
  }
  a[href*="download"], a[download], button, .btn, [role="button"], [class*="download"] {
    background: linear-gradient(to right, #e50914, #b81d24) !important;
    color: #ffffff !important;
    border-color: #ff3844 !important;
    box-shadow: 0 4px 18px rgba(229, 9, 20, 0.4) !important;
  }
</style>`;

    if (html.includes("<head>")) {
      html = html.replace("<head>", `<head>${baseTag}${redThemeOverrides}`);
    } else {
      html = `<head>${baseTag}${redThemeOverrides}</head>` + html;
    }

    return htmlResponse(html);
  } catch {
    return Response.redirect(targetUrl, 302);
  }
}

// 7. Real-Time Dynamic Live RSS & Live TMDB Sitemap Endpoints (Auto-Updating on Netlify CDN)
async function handleLiveRss(): Promise<Response> {
  const nowRfc = new Date().toUTCString();
  const today = new Date().toISOString().split("T")[0];

  const itemsXml = BLOG_POSTS.slice(0, 60)
    .map((p) => {
      const pubDate = new Date(p.publishedDate || today).toUTCString();
      const imageTag = p.coverImage
        ? `<enclosure url="${escapeXml(p.coverImage)}" type="image/jpeg" length="120000" />`
        : "";
      return `
    <item>
      <title><![CDATA[${p.title}]]></title>
      <link>${BASE_URL}/blog/${p.slug}</link>
      <guid isPermaLink="true">${BASE_URL}/blog/${p.slug}</guid>
      <category><![CDATA[${p.category}]]></category>
      <author>editorial@mooflix.online (${escapeXml(p.author)})</author>
      <description><![CDATA[${p.excerpt}]]></description>
      <pubDate>${pubDate}</pubDate>
      ${imageTag}
    </item>`;
    })
    .join("");

  const xml = `<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0" xmlns:atom="http://www.w3.org/2005/Atom">
  <channel>
    <title>MooFlix Cinema Magazine &amp; Streaming Guides</title>
    <link>${BASE_URL}</link>
    <description>Latest movie releases, TV series, live sports streams, anime watch guides, and 4K streaming tutorials on mooflix.online</description>
    <language>en-us</language>
    <lastBuildDate>${nowRfc}</lastBuildDate>
    <ttl>60</ttl>
    <atom:link href="${BASE_URL}/api/rss.xml" rel="self" type="application/rss+xml"/>
${itemsXml}
  </channel>
</rss>`;

  return new Response(xml, {
    status: 200,
    headers: {
      "Content-Type": "application/rss+xml; charset=utf-8",
      "Cache-Control": "public, max-age=3600, s-maxage=3600, stale-while-revalidate=7200",
      ...CORS_HEADERS,
    },
  });
}

async function handleLiveSitemap(): Promise<Response> {
  const today = new Date().toISOString().split("T")[0];
  const urls: Array<{ loc: string; lastmod: string; changefreq: string; priority: string }> = [
    { loc: `${BASE_URL}/`, lastmod: today, changefreq: "daily", priority: "1.00" },
    { loc: `${BASE_URL}/movies`, lastmod: today, changefreq: "daily", priority: "0.95" },
    { loc: `${BASE_URL}/series`, lastmod: today, changefreq: "daily", priority: "0.95" },
    { loc: `${BASE_URL}/anime`, lastmod: today, changefreq: "daily", priority: "0.90" },
    { loc: `${BASE_URL}/sports`, lastmod: today, changefreq: "always", priority: "0.95" },
    { loc: `${BASE_URL}/blogs`, lastmod: today, changefreq: "daily", priority: "0.95" },
  ];

  for (const post of BLOG_POSTS) {
    urls.push({
      loc: `${BASE_URL}/blog/${post.slug}`,
      lastmod: post.publishedDate || today,
      changefreq: "weekly",
      priority: "0.88",
    });
  }

  // Pull live trending & now-playing TMDB titles so newly released films appear immediately without waiting for redeploy
  const tmdbEndpoints = [
    `/trending/movie/day?api_key=${TMDB_API_KEY}`,
    `/trending/tv/day?api_key=${TMDB_API_KEY}`,
    `/movie/now_playing?api_key=${TMDB_API_KEY}`,
    `/tv/on_the_air?api_key=${TMDB_API_KEY}`,
  ];

  const seen = new Set<string>();
  const results = await Promise.allSettled(
    tmdbEndpoints.map((ep) =>
      fetchWithTimeout(`https://api.themoviedb.org/3${ep}`, {}, 2500).then((r) => (r.ok ? r.json() : null))
    )
  );

  results.forEach((res, idx) => {
    if (res.status !== "fulfilled" || !res.value?.results) return;
    const isTv = idx === 1 || idx === 3;
    for (const item of res.value.results) {
      if (!item?.id || item.adult) continue;
      const key = `${isTv ? "series" : "movie"}-${item.id}`;
      if (seen.has(key)) continue;
      seen.add(key);
      urls.push({
        loc: `${BASE_URL}/${isTv ? "series" : "movie"}/${item.id}`,
        lastmod: today,
        changefreq: "daily",
        priority: "0.85",
      });
    }
  });

  const body = urls
    .map(
      (u) => `  <url>
    <loc>${escapeXml(u.loc)}</loc>
    <lastmod>${u.lastmod}</lastmod>
    <changefreq>${u.changefreq}</changefreq>
    <priority>${u.priority}</priority>
  </url>`
    )
    .join("\n");

  const xml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${body}
</urlset>`;

  return new Response(xml, {
    status: 200,
    headers: {
      "Content-Type": "application/xml; charset=utf-8",
      "Cache-Control": "public, max-age=3600, s-maxage=3600, stale-while-revalidate=7200",
      ...CORS_HEADERS,
    },
  });
}

// 8. Moonflix & Streamed Legacy Proxies (for compatibility)
async function handleMoonflixProxy(req: Request, subpath: string): Promise<Response> {
  if (subpath === "/main.js") {
    const r = await fetchWithTimeout("https://player.moonflix.website/main.js?v=4", {}, 4000);
    let code = await r.text();
    code = code.replace("from './components/player-shell.js'", "from '/api/moonflix-player/components/player-shell.js'");
    code = code.replace("`/player/${file}?v=19`", "`/api/moonflix-player/player/${file}?v=19`");
    return new Response(code, {
      status: 200,
      headers: { "Content-Type": "application/javascript; charset=utf-8", "Cache-Control": "public, max-age=3600" },
    });
  }
  if (subpath === "/components/player-shell.js") {
    const r = await fetchWithTimeout("https://player.moonflix.website/components/player-shell.js", {}, 4000);
    return new Response(await r.text(), {
      status: 200,
      headers: { "Content-Type": "application/javascript; charset=utf-8", "Cache-Control": "public, max-age=3600" },
    });
  }
  if (subpath.startsWith("/player/")) {
    const file = subpath.replace("/player/", "");
    const r = await fetchWithTimeout(`https://player.moonflix.website/player/${file}?v=19`, {}, 4000);
    let code = await r.text();
    if (file === "servers.js") {
      code = code.replace(
        /url:\s*`https:\/\/nxsha\.space\/embed\/movie\/\$\{media\.id\}`/g,
        "url: `https://nxsha.space/embed/movie/${media.id}?server=MbPly&sub=hi&disable_dl_button=true&color=netflix&lang=en&disable_app_ad=true&disable_app_ads=true&disable_ad=true&disable_ads=true&ads=0&no_ads=1&auto_start=true`"
      );
      code = code.replace(
        /url:\s*`https:\/\/nxsha\.space\/embed\/tv\/\$\{media\.id\}\/\$\{media\.season\}\/\$\{media\.episode\}`/g,
        "url: `https://nxsha.space/embed/tv/${media.id}/${media.season}/${media.episode}?server=MbPly&sub=hi&disable_dl_button=true&color=netflix&lang=en&disable_app_ad=true&disable_app_ads=true&disable_ad=true&disable_ads=true&ads=0&no_ads=1&auto_start=true`"
      );
    }
    return new Response(code, {
      status: 200,
      headers: { "Content-Type": "application/javascript; charset=utf-8", "Cache-Control": "public, max-age=3600" },
    });
  }

  const upstreamRes = await fetchWithTimeout(
    `https://player.moonflix.website${subpath}`,
    {
      headers: {
        "User-Agent": req.headers.get("user-agent") || DEFAULT_UA,
        Referer: "https://player.moonflix.website/",
      },
    },
    5000
  );
  if (!upstreamRes.ok) {
    return new Response(`Failed to load player (${upstreamRes.status})`, { status: upstreamRes.status });
  }
  let html = await upstreamRes.text();
  html = html.replace(/<script[^>]*ariososhands[^>]*>[\s\S]*?<\/script>/gi, "<!-- ad-removed -->");
  html = html.replace(/\/main\.js\?v=\d+/gi, "/api/moonflix-player/main.js");
  html = html.replace(/\/styles\.css\?v=\d+/gi, "https://player.moonflix.website/styles.css?v=7");
  return htmlResponse(html);
}

export default async function handler(req: Request): Promise<Response> {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: CORS_HEADERS });
  }

  const url = new URL(req.url);
  const path = normalizeRoutePath(url.pathname);

  // Health & Ping
  if (path === "/api/health" || path === "/api/ping" || path === "/health") {
    return jsonResponse({
      status: "ok",
      platform: "netlify",
      healthy: true,
      timestamp: Date.now(),
    });
  }

  // Ad-free API stubs
  if (path === "/api/vast-ad" || path === "/api/media-preroll") {
    return jsonResponse({ hasAd: false }, 200, { "Cache-Control": "no-cache" });
  }
  if (path === "/api/media-ad-stream" || path === "/api/vast-beacon") {
    return new Response(null, { status: 204, headers: CORS_HEADERS });
  }

  // Player Multi-Server Resolver, Server 1 Proxy, Play4U Redirect
  if (path === "/api/player/resolve") {
    return handlePlayerResolve(url);
  }
  if (path === "/api/player/proxy") {
    return handlePlayerProxy(req, url);
  }
  if (path === "/api/player/play4u" || path === "/api/play4u") {
    return handlePlay4u(url);
  }

  // Live Sports Streams & Ping
  if (path === "/api/ondemand/streams" || path === "/api/sports/streams" || path === "/api/ppv/streams") {
    return handleOndemandStreams(url);
  }
  if (path === "/api/ondemand/ping" || path === "/api/sports/ping") {
    try {
      const r = await fetchWithTimeout(
        "https://ondemand.st/papi/api/ping",
        { headers: { "User-Agent": DEFAULT_UA, Accept: "application/json" } },
        3000
      );
      if (r.ok) return jsonResponse(await r.json(), 200, { "Cache-Control": "public, max-age=60" });
    } catch {}
    return jsonResponse({ success: true, timestamp: Math.floor(Date.now() / 1000) });
  }

  // PPV VODs
  if (path === "/api/ppv/vods") {
    try {
      const r = await fetchWithTimeout(
        "https://api.ppv.st/api/vods",
        { headers: { "User-Agent": DEFAULT_UA, Accept: "application/json" } },
        4000
      );
      if (r.ok) return jsonResponse(await r.json(), 200, { "Cache-Control": "public, max-age=60, s-maxage=60" });
      return jsonResponse({ error: "Failed to fetch VODs" }, r.status);
    } catch {
      return jsonResponse({ error: "PPV VODs unreachable" }, 502);
    }
  }
  if (path.startsWith("/api/ppv/vods/")) {
    const vodId = path.replace("/api/ppv/vods/", "");
    try {
      const r = await fetchWithTimeout(
        `https://api.ppv.st/api/vods/${encodeURIComponent(vodId)}`,
        { headers: { "User-Agent": DEFAULT_UA, Accept: "application/json" } },
        4000
      );
      return jsonResponse(await r.json(), r.status);
    } catch {
      return jsonResponse({ error: "Failed to fetch VOD details" }, 502);
    }
  }

  // Static Sports Channels API
  if (path === "/api/sports-channels") {
    try {
      const r = await fetchWithTimeout(`${url.origin}/data/sports_streams.json`, {}, 3000);
      if (!r.ok) return jsonResponse({ error: "Sports data not found" }, 404);
      const data = await r.json();
      return jsonResponse(data, 200, { "Cache-Control": "public, max-age=60, s-maxage=60" });
    } catch {
      return jsonResponse({ error: "Failed to load sports channels" }, 500);
    }
  }

  // Streamed.pk Proxy
  if (path.startsWith("/api/sports-stream/")) {
    const rawSubpath = path.replace("/api/sports-stream/", "");
    const targetUrl = `https://streamed.pk/api/${rawSubpath}${url.search}`;
    try {
      const r = await fetchWithTimeout(
        targetUrl,
        { headers: { "User-Agent": DEFAULT_UA, Referer: "https://streamed.pk/" } },
        4500
      );
      const body = await r.arrayBuffer();
      return new Response(body, {
        status: r.status,
        headers: {
          "Content-Type": r.headers.get("content-type") || "application/json",
          "Cache-Control": "public, max-age=60",
          ...CORS_HEADERS,
        },
      });
    } catch {
      return jsonResponse({ error: "Stream API temporarily unavailable" }, 502);
    }
  }

  // Clean Sports Embed Proxy & Red Download Proxy
  if (path === "/api/clean-stream" || path === "/api/sports-embed") {
    return handleCleanStream(req, url);
  }
  if (path === "/api/download-proxy") {
    return handleDownloadProxy(url);
  }

  // Moonflix Player Proxy
  if (path.startsWith("/api/moonflix-player/")) {
    const subpath = path.replace("/api/moonflix-player", "");
    return handleMoonflixProxy(req, subpath);
  }

  // Dynamic Live SEO RSS & Live Sitemap
  if (path === "/api/rss.xml") {
    return handleLiveRss();
  }
  if (path === "/api/sitemap-live.xml" || path === "/sitemap-live.xml") {
    return handleLiveSitemap();
  }

  // Upstream Player Sub-Assets (HLS/JW bundles)
  if (path === "/js/bundle-jw.js" || path === "/js/bundle.js") {
    try {
      const r = await fetchWithTimeout(
        `https://taifood-blog.asia${path}`,
        { headers: { "User-Agent": DEFAULT_UA, Referer: "https://taifood-blog.asia/" } },
        4000
      );
      if (!r.ok) return new Response("/* Not found */", { status: 404 });
      return new Response(await r.text(), {
        status: 200,
        headers: { "Content-Type": "application/javascript; charset=utf-8", "Cache-Control": "public, max-age=86400" },
      });
    } catch {
      return new Response("/* Bundle proxy error */", { status: 502 });
    }
  }

  if (path === "/js/xk7m9p2.js" || path === "/js/adgeo.js" || path.startsWith("/player/")) {
    try {
      const r = await fetchWithTimeout(
        `https://damitv.st${path}${url.search}`,
        { headers: { "User-Agent": DEFAULT_UA, Referer: "https://damitv.st/" } },
        4000
      );
      const buf = await r.arrayBuffer();
      return new Response(buf, {
        status: r.status,
        headers: {
          "Content-Type": r.headers.get("content-type") || "application/javascript",
          "Cache-Control": "public, max-age=86400",
        },
      });
    } catch {
      return new Response("/* Player asset error */", { status: 502 });
    }
  }

  return jsonResponse({ error: "API route not found", path }, 404);
}
