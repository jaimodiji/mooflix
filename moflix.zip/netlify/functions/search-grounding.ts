import { GoogleGenAI } from "@google/genai";

export default async (req: Request) => {
  if (req.method !== "POST") {
    return new Response(JSON.stringify({ error: "Method not allowed" }), {
      status: 405,
      headers: { "Content-Type": "application/json" },
    });
  }

  try {
    const body = await req.json().catch(() => ({}));
    const { query, category } = body || {};

    if (!query || typeof query !== "string" || query.trim().length < 2) {
      return new Response(JSON.stringify({ summary: null, sources: [], entity: null }), {
        status: 200,
        headers: { "Content-Type": "application/json" },
      });
    }

    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      return new Response(JSON.stringify({ summary: null, sources: [], entity: null }), {
        status: 200,
        headers: { "Content-Type": "application/json" },
      });
    }

    const ai = new GoogleGenAI({ apiKey });
    const cleanQuery = query.trim();

    // 1. Identify exact entity
    let entity: any = null;
    try {
      const entityRes = await ai.models.generateContent({
        model: "gemini-3.1-flash-lite",
        contents: `Search query: "${cleanQuery}" (category: ${category || 'all'}).
Identify the primary movie, TV/web series, or celebrity/star.
Respond with JSON only:
{
  "exactTitle": "exact title or official name",
  "year": "4-digit release year if movie/series or null",
  "type": "movie" | "series" | "star",
  "directorOrStar": "director or lead star if known or null"
}`,
        config: {
          responseMimeType: "application/json",
        },
      });

      const parsed = JSON.parse(entityRes.text || '{}');
      if (parsed && parsed.exactTitle) {
        entity = {
          exactTitle: String(parsed.exactTitle).trim(),
          year: parsed.year ? String(parsed.year).trim() : null,
          type: parsed.type || (category === 'movie' ? 'movie' : category === 'series' ? 'series' : null),
          directorOrStar: parsed.directorOrStar || null,
        };
      }
    } catch {
      const yearMatch = cleanQuery.match(/\b(19\d\d|20\d\d)\b/);
      if (yearMatch) {
        entity = {
          exactTitle: cleanQuery.replace(yearMatch[0], '').replace(/\s+/g, ' ').trim(),
          year: yearMatch[1],
          type: category === 'series' ? 'series' : 'movie',
        };
      }
    }

    // 2. Google Search Grounding for real-time overview
    let summary: string | null = null;
    let webSources: { title: string; url: string }[] = [];

    try {
      const response = await ai.models.generateContent({
        model: "gemini-3.8-flash",
        contents: `Provide a quick, concise 2-sentence real-time factual overview of "${cleanQuery}". Mention release year/status, lead stars/director or notable works, and key premise. Keep it direct and factual without conversational filler.`,
        config: {
          tools: [{ googleSearch: {} }],
        },
      });

      summary = response.text?.trim() || null;
      const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
      for (const chunk of chunks as any[]) {
        if (chunk?.web?.uri) {
          webSources.push({
            title: chunk.web.title || "Google Search Source",
            url: chunk.web.uri,
          });
        }
      }
    } catch {
      try {
        const fallback = await ai.models.generateContent({
          model: "gemini-3.1-flash-lite",
          contents: `Provide a quick, concise 2-sentence factual overview of "${cleanQuery}".`,
        });
        summary = fallback.text?.trim() || null;
      } catch {
        // Safe fallback
      }
    }

    if (webSources.length === 0) {
      const targetTitle = entity?.exactTitle || cleanQuery;
      const targetYear = entity?.year ? ` ${entity.year}` : '';
      const searchParam = encodeURIComponent(`${targetTitle}${targetYear} ${category === 'star' ? 'actor star' : 'movie series'}`);
      webSources = [
        {
          title: `Google: "${targetTitle}${targetYear}"`,
          url: `https://www.google.com/search?q=${searchParam}`,
        },
        {
          title: `IMDb: "${targetTitle}"`,
          url: `https://www.imdb.com/find/?q=${encodeURIComponent(targetTitle)}`,
        },
      ];
    }

    return new Response(
      JSON.stringify({
        summary,
        sources: webSources.slice(0, 4),
        entity,
      }),
      {
        status: 200,
        headers: { "Content-Type": "application/json" },
      }
    );
  } catch (err: any) {
    return new Response(JSON.stringify({ error: err.message || "Failed" }), {
      status: 500,
      headers: { "Content-Type": "application/json" },
    });
  }
};
