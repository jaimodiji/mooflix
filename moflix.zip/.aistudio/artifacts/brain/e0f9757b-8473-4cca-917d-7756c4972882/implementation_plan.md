# Live Sports: India vs New Zealand Card Fix

## Problem
After deploying to Netlify / static hosts, the India vs New Zealand match card was not showing up because:
1. In `public/data/sports_streams.json`, the match was only categorized under `"Upcoming Events"` and absent from `"Live Events"`. On static deployments, the live tab only displayed items from `"Live Events"`.
2. In `services/sportsStaticData.ts`, `STATIC_LIVE_EVENTS` did not have the India vs New Zealand match (it was only in `STATIC_UPCOMING_EVENTS`), so fallback data did not show it on the Live tab.
3. On the Home page, the live sports row was previously not rendered.

## Solution & Implementation
1. **`public/data/sports_streams.json`**:
   - Added `India vs New Zealand - Live Cricket Match (IND vs NZ)` and `New Zealand vs India - 1st ODI International (NZ vs IND)` right at index 0 and 1 of `"Live Events"` with active live status and Willow Cricket HD, Star Sports 1 Hindi HD, and Sky Sports streams.
2. **`services/sportsStaticData.ts`**:
   - Added both India vs New Zealand live events to `STATIC_LIVE_EVENTS` at index 0 and 1 so they are guaranteed to load immediately in bundled static/offline mode on any deployment.
3. **`services/sportsService.ts`**:
   - Updated `fetchMatches` sort logic so marquee matches (India vs New Zealand / NZ vs IND) are automatically prioritized at the very top.
4. **`App.tsx`**:
   - Added `LiveSportsRow` directly on the Home page above the dynamic movie rows with a quick "See All" button that links to the full Sports Arena.
5. **Code Cleanup**:
   - Removed any remaining `triggerSmartlink` calls from `SportMatchCard.tsx` and `SportsView.tsx`.
