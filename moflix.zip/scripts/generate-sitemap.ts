import fs from 'node:fs';
import path from 'node:path';
import { BLOG_POSTS } from '../services/blogData';

const BASE_URL = 'https://mooflix.online';
const API_KEY = process.env.TMDB_API_KEY || 'f4c3361d4917e9f25f79f339356eb8d9';
const TMDB_BASE = 'https://api.themoviedb.org/3';

export interface SitemapEntry {
  loc: string;
  lastmod: string;
  changefreq: 'always' | 'hourly' | 'daily' | 'weekly' | 'monthly' | 'yearly';
  priority: number;
  image?: string;
  title?: string;
}

const today = new Date().toISOString().split('T')[0];

const CORE_PAGES: SitemapEntry[] = [
  { loc: `${BASE_URL}/`, lastmod: today, changefreq: 'daily', priority: 1.0 },
  { loc: `${BASE_URL}/movies`, lastmod: today, changefreq: 'daily', priority: 0.95 },
  { loc: `${BASE_URL}/series`, lastmod: today, changefreq: 'daily', priority: 0.95 },
  { loc: `${BASE_URL}/anime`, lastmod: today, changefreq: 'daily', priority: 0.90 },
  { loc: `${BASE_URL}/sports`, lastmod: today, changefreq: 'always', priority: 0.95 },
  { loc: `${BASE_URL}/blogs`, lastmod: today, changefreq: 'daily', priority: 0.95 },
  { loc: `${BASE_URL}/sitemap`, lastmod: today, changefreq: 'daily', priority: 0.90 },
  { loc: `${BASE_URL}/watchlist`, lastmod: today, changefreq: 'weekly', priority: 0.70 },
  { loc: `${BASE_URL}/about`, lastmod: today, changefreq: 'monthly', priority: 0.70 },
  { loc: `${BASE_URL}/dmca`, lastmod: today, changefreq: 'monthly', priority: 0.70 },
  { loc: `${BASE_URL}/privacy`, lastmod: today, changefreq: 'monthly', priority: 0.70 },
  { loc: `${BASE_URL}/terms`, lastmod: today, changefreq: 'monthly', priority: 0.70 },
  { loc: `${BASE_URL}/contact`, lastmod: today, changefreq: 'monthly', priority: 0.70 },
];

async function fetchTmdbJson(endpoint: string): Promise<any> {
  try {
    const res = await fetch(`${TMDB_BASE}${endpoint}&api_key=${API_KEY}&language=en-US`);
    if (!res.ok) return null;
    return await res.json();
  } catch (err) {
    console.error(`Failed to fetch ${endpoint}:`, err);
    return null;
  }
}

function sanitizeXml(str: string): string {
  return str
    .replace(/&/g, '&amp;')
    .replace(/'/g, '&apos;')
    .replace(/"/g, '&quot;')
    .replace(/>/g, '&gt;')
    .replace(/</g, '&lt;');
}

function isValidW3CDate(d: string | undefined): boolean {
  if (!d) return false;
  return /^\d{4}-\d{2}-\d{2}$/.test(d);
}

function buildXmlUrlSet(entries: SitemapEntry[], includeImages = false): string {
  const lines: string[] = [
    '<?xml version="1.0" encoding="UTF-8"?>',
    includeImages
      ? '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:image="http://www.google.com/schemas/sitemap-image/1.1">'
      : '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">',
  ];

  for (const entry of entries) {
    const cleanDate = isValidW3CDate(entry.lastmod) ? entry.lastmod : today;
    lines.push('  <url>');
    lines.push(`    <loc>${sanitizeXml(entry.loc)}</loc>`);
    lines.push(`    <lastmod>${cleanDate}</lastmod>`);
    lines.push(`    <changefreq>${entry.changefreq}</changefreq>`);
    lines.push(`    <priority>${entry.priority.toFixed(2)}</priority>`);
    if (includeImages && entry.image) {
      lines.push('    <image:image>');
      lines.push(`      <image:loc>${sanitizeXml(entry.image)}</image:loc>`);
      if (entry.title) {
        lines.push(`      <image:title>${sanitizeXml(entry.title)}</image:title>`);
      }
      lines.push('    </image:image>');
    }
    lines.push('  </url>');
  }

  lines.push('</urlset>');
  return lines.join('\n');
}

function buildSitemapIndex(sitemaps: { loc: string; lastmod: string }[]): string {
  const lines: string[] = [
    '<?xml version="1.0" encoding="UTF-8"?>',
    '<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">',
  ];

  for (const s of sitemaps) {
    lines.push('  <sitemap>');
    lines.push(`    <loc>${sanitizeXml(s.loc)}</loc>`);
    lines.push(`    <lastmod>${s.lastmod}</lastmod>`);
    lines.push('  </sitemap>');
  }

  lines.push('</sitemapindex>');
  return lines.join('\n');
}

function writeXmlFile(filename: string, content: string) {
  const publicDir = path.resolve(process.cwd(), 'public');
  if (!fs.existsSync(publicDir)) {
    fs.mkdirSync(publicDir, { recursive: true });
  }
  fs.writeFileSync(path.join(publicDir, filename), content, 'utf-8');

  const distDir = path.resolve(process.cwd(), 'dist');
  if (fs.existsSync(distDir)) {
    fs.writeFileSync(path.join(distDir, filename), content, 'utf-8');
  }
}

async function generateAllSitemaps() {
  console.log('🚀 Generating Multi-Section Clean Google Sitemaps, RSS & Atom Feeds...');

  const seenIds = new Set<string>();

  // 1. Pages
  const pagesEntries: SitemapEntry[] = [...CORE_PAGES];

  // 2. Blogs (Sorted newest first, with <image:image> tags)
  const sortedBlogs = [...BLOG_POSTS].sort((a, b) =>
    (b.publishedDate || '').localeCompare(a.publishedDate || '')
  );

  const blogEntries: SitemapEntry[] = sortedBlogs.map((blog) => ({
    loc: `${BASE_URL}/blog/${blog.slug}`,
    lastmod: isValidW3CDate(blog.publishedDate) ? blog.publishedDate : today,
    changefreq: 'weekly',
    priority: 0.90,
    image: blog.coverImage,
    title: blog.title,
  }));

  // 3. Movies
  const movieEntries: SitemapEntry[] = [];
  const seoCatalog: {
    movies: Record<string, { title: string; overview: string; year: string; poster: string; rating: number }>;
    series: Record<string, { title: string; overview: string; year: string; poster: string; rating: number }>;
  } = {
    movies: {},
    series: {},
  };

  const movieEndpoints = [
    '/trending/movie/week?page=1',
    '/trending/movie/week?page=2',
    '/trending/movie/week?page=3',
    '/movie/popular?page=1',
    '/movie/popular?page=2',
    '/movie/popular?page=3',
    '/movie/now_playing?page=1',
    '/movie/upcoming?page=1',
    '/movie/upcoming?page=2',
    '/movie/top_rated?page=1',
    '/movie/top_rated?page=2',
  ];

  for (const endpoint of movieEndpoints) {
    const data = await fetchTmdbJson(endpoint);
    if (data && Array.isArray(data.results)) {
      for (const item of data.results) {
        if (!item.id || item.adult) continue;
        const key = `movie-${item.id}`;
        if (seenIds.has(key)) continue;
        seenIds.add(key);

        const year = item.release_date ? item.release_date.split('-')[0] : '2026';
        const posterUrl = item.poster_path ? `https://image.tmdb.org/t/p/w780${item.poster_path}` : '';
        seoCatalog.movies[String(item.id)] = {
          title: item.title || item.original_title || 'Blockbuster Movie',
          overview: item.overview || 'Stream full movie in Ultra HD 4K on MooFlix with zero buffering and multiple servers.',
          year,
          poster: posterUrl,
          rating: item.vote_average ? Math.round(item.vote_average * 10) / 10 : 7.8,
        };

        movieEntries.push({
          loc: `${BASE_URL}/movie/${item.id}`,
          lastmod: today,
          changefreq: 'weekly',
          priority: 0.85,
          image: posterUrl || undefined,
          title: item.title || item.original_title || undefined,
        });
      }
    }
  }

  // 4. TV Series
  const tvEntries: SitemapEntry[] = [];
  const tvEndpoints = [
    '/trending/tv/week?page=1',
    '/trending/tv/week?page=2',
    '/trending/tv/week?page=3',
    '/tv/popular?page=1',
    '/tv/popular?page=2',
    '/tv/popular?page=3',
    '/tv/on_the_air?page=1',
    '/tv/on_the_air?page=2',
    '/tv/top_rated?page=1',
    '/tv/top_rated?page=2',
  ];

  for (const endpoint of tvEndpoints) {
    const data = await fetchTmdbJson(endpoint);
    if (data && Array.isArray(data.results)) {
      for (const item of data.results) {
        if (!item.id || item.adult) continue;
        const key = `tv-${item.id}`;
        if (seenIds.has(key)) continue;
        seenIds.add(key);

        const year = item.first_air_date ? item.first_air_date.split('-')[0] : '2026';
        const posterUrl = item.poster_path ? `https://image.tmdb.org/t/p/w780${item.poster_path}` : '';
        seoCatalog.series[String(item.id)] = {
          title: item.name || item.original_name || 'Popular Web Series',
          overview: item.overview || 'Stream all seasons and episodes in Ultra HD on MooFlix with zero buffering.',
          year,
          poster: posterUrl,
          rating: item.vote_average ? Math.round(item.vote_average * 10) / 10 : 8.1,
        };

        tvEntries.push({
          loc: `${BASE_URL}/series/${item.id}`,
          lastmod: today,
          changefreq: 'weekly',
          priority: 0.85,
          image: posterUrl || undefined,
          title: item.name || item.original_name || undefined,
        });
      }
    }
  }

  // Save SEO Catalog JSON for fast server prerendering
  const publicDir = path.resolve(process.cwd(), 'public');
  const distDir = path.resolve(process.cwd(), 'dist');
  const catalogJson = JSON.stringify(seoCatalog, null, 2);
  fs.writeFileSync(path.join(publicDir, 'seo-catalog.json'), catalogJson, 'utf-8');
  if (fs.existsSync(distDir)) {
    fs.writeFileSync(path.join(distDir, 'seo-catalog.json'), catalogJson, 'utf-8');
  }
  console.log(`✅ Saved seo-catalog.json (${Object.keys(seoCatalog.movies).length} movies, ${Object.keys(seoCatalog.series).length} series)`);

  // Master combined list for default sitemap.xml
  const allEntries: SitemapEntry[] = [
    ...pagesEntries,
    ...blogEntries,
    ...movieEntries,
    ...tvEntries,
  ];

  // A. Master sitemap.xml
  writeXmlFile('sitemap.xml', buildXmlUrlSet(allEntries, false));
  console.log(`✅ Saved master sitemap.xml (${allEntries.length} URLs indexed)`);

  // B. Modular Section Sitemaps (Blogs & Media include Google Image sitemap tags)
  writeXmlFile('sitemap-pages.xml', buildXmlUrlSet(pagesEntries, false));
  console.log(`✅ Saved sitemap-pages.xml (${pagesEntries.length} URLs)`);

  writeXmlFile('sitemap-blogs.xml', buildXmlUrlSet(blogEntries, true));
  console.log(`✅ Saved sitemap-blogs.xml (${blogEntries.length} URLs with images)`);

  writeXmlFile('sitemap-movies.xml', buildXmlUrlSet(movieEntries, false));
  console.log(`✅ Saved sitemap-movies.xml (${movieEntries.length} URLs)`);

  writeXmlFile('sitemap-series.xml', buildXmlUrlSet(tvEntries, false));
  console.log(`✅ Saved sitemap-series.xml (${tvEntries.length} URLs)`);

  // C. sitemap-index.xml pointing to section sitemaps + dynamic live sitemap
  const indexXml = buildSitemapIndex([
    { loc: `${BASE_URL}/sitemap-pages.xml`, lastmod: today },
    { loc: `${BASE_URL}/sitemap-blogs.xml`, lastmod: today },
    { loc: `${BASE_URL}/sitemap-movies.xml`, lastmod: today },
    { loc: `${BASE_URL}/sitemap-series.xml`, lastmod: today },
    { loc: `${BASE_URL}/sitemap-live.xml`, lastmod: today },
  ]);
  writeXmlFile('sitemap-index.xml', indexXml);
  console.log('✅ Saved sitemap-index.xml pointing to all section + live sitemaps');

  // D. Official RSS 2.0 Feed (rss.xml & feed.xml) - Expanded to 60 richest recent articles
  const recentFeedPosts = sortedBlogs.slice(0, 60);
  const nowUtc = new Date().toUTCString();
  const nowIso = new Date().toISOString();

  const rssItems = recentFeedPosts.map((p) => {
    const pubDate = new Date(p.publishedDate || today).toUTCString();
    const enclosure = p.coverImage
      ? `\n      <enclosure url="${sanitizeXml(p.coverImage)}" type="image/jpeg" length="120000" />`
      : '';
    return `
    <item>
      <title><![CDATA[${p.title}]]></title>
      <link>${BASE_URL}/blog/${p.slug}</link>
      <guid isPermaLink="true">${BASE_URL}/blog/${p.slug}</guid>
      <category><![CDATA[${p.category}]]></category>
      <author>editorial@mooflix.online (${sanitizeXml(p.author)})</author>
      <description><![CDATA[${p.excerpt}]]></description>
      <pubDate>${pubDate}</pubDate>${enclosure}
    </item>`;
  }).join('');

  const rssXml = `<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0" xmlns:atom="http://www.w3.org/2005/Atom">
  <channel>
    <title>MooFlix Cinema Magazine &amp; Streaming Guides</title>
    <link>${BASE_URL}</link>
    <description>Latest movie releases, cinema reviews, live sports streams, anime guides, and 4K streaming tutorials on mooflix.online</description>
    <language>en-us</language>
    <lastBuildDate>${nowUtc}</lastBuildDate>
    <ttl>60</ttl>
    <atom:link href="${BASE_URL}/rss.xml" rel="self" type="application/rss+xml"/>
${rssItems}
  </channel>
</rss>`;

  writeXmlFile('rss.xml', rssXml);
  writeXmlFile('feed.xml', rssXml);
  console.log(`✅ Saved RSS 2.0 Feeds (rss.xml & feed.xml with ${recentFeedPosts.length} articles)`);

  // E. Official Atom 1.0 Feed (atom.xml) for Google Discover, Feedly & Crawlers
  const atomEntries = recentFeedPosts.map((p) => {
    const updatedIso = `${isValidW3CDate(p.publishedDate) ? p.publishedDate : today}T12:00:00Z`;
    return `
  <entry>
    <title type="text">${sanitizeXml(p.title)}</title>
    <link href="${BASE_URL}/blog/${p.slug}" rel="alternate" type="text/html" />
    <id>${BASE_URL}/blog/${p.slug}</id>
    <published>${updatedIso}</published>
    <updated>${updatedIso}</updated>
    <category term="${sanitizeXml(p.category)}" />
    <author><name>${sanitizeXml(p.author)}</name></author>
    <summary type="text">${sanitizeXml(p.excerpt)}</summary>
  </entry>`;
  }).join('');

  const atomXml = `<?xml version="1.0" encoding="UTF-8"?>
<feed xmlns="http://www.w3.org/2005/Atom">
  <title>MooFlix Cinema Magazine &amp; Live Streaming Guides</title>
  <subtitle>Ad-free 4K movies, web series, anime &amp; live sports guides on mooflix.online</subtitle>
  <link href="${BASE_URL}/atom.xml" rel="self" type="application/atom+xml" />
  <link href="${BASE_URL}/" rel="alternate" type="text/html" />
  <id>${BASE_URL}/</id>
  <updated>${nowIso}</updated>
${atomEntries}
</feed>`;

  writeXmlFile('atom.xml', atomXml);
  console.log(`✅ Saved official Atom 1.0 Feed (atom.xml with ${recentFeedPosts.length} entries)`);
}

generateAllSitemaps().catch((err) => {
  console.error('Sitemap generation error:', err);
  process.exit(1);
});
