const fs = require('fs');

async function test() {
  const url = "https://embed.st/embed/ingest/streamedtampabayrays/1";
  const res = await fetch(url);
  const html = await res.text();
  const scriptRegex = /<script\b[^>]*>([\s\S]*?)<\/script>/gi;
  let m = scriptRegex.exec(html);
  const scriptContent = m[1];

  fs.writeFileSync('scripts/script1.js', scriptContent);
  console.log("Saved script1.js, length:", scriptContent.length);

  // Search for userAgent in script1
  const uIndex = scriptContent.indexOf('userAgent');
  console.log("Found userAgent at:", uIndex);
  if (uIndex !== -1) {
    console.log(scriptContent.substring(uIndex - 100, uIndex + 200));
  }
}
test();
