import fs from 'node:fs';
import path from 'node:path';
import sharp from 'sharp';

async function generatePwaIcons() {
  const publicDir = path.join(process.cwd(), 'public');
  const svgPath = path.join(publicDir, 'favicon.svg');
  
  if (!fs.existsSync(svgPath)) {
    console.error('favicon.svg not found in public/');
    return;
  }

  const svgBuffer = fs.readFileSync(svgPath);

  console.log('Generating PWA Icons from favicon.svg...');

  // 192x192 PNG
  await sharp(svgBuffer)
    .resize(192, 192)
    .png()
    .toFile(path.join(publicDir, 'pwa-192x192.png'));
  console.log('✅ Generated pwa-192x192.png');

  // 512x512 PNG
  await sharp(svgBuffer)
    .resize(512, 512)
    .png()
    .toFile(path.join(publicDir, 'pwa-512x512.png'));
  console.log('✅ Generated pwa-512x512.png');

  // Apple Touch Icon (180x180)
  await sharp(svgBuffer)
    .resize(180, 180)
    .png()
    .toFile(path.join(publicDir, 'apple-touch-icon.png'));
  console.log('✅ Generated apple-touch-icon.png');

  // Maskable 512x512 PNG with 12% safe zone padding
  const innerIcon = await sharp(svgBuffer)
    .resize(384, 384)
    .toBuffer();

  await sharp({
    create: {
      width: 512,
      height: 512,
      channels: 4,
      background: { r: 8, g: 8, b: 10, alpha: 1 }
    }
  })
    .composite([{ input: innerIcon, gravity: 'center' }])
    .png()
    .toFile(path.join(publicDir, 'pwa-maskable-512x512.png'));
  console.log('✅ Generated pwa-maskable-512x512.png (with safe-zone padding)');

  console.log('🎉 All PWA icon assets generated successfully!');
}

generatePwaIcons().catch(console.error);
