package com.mooflix.app.data.model

import com.google.gson.annotations.SerializedName

data class MovieItem(
    @SerializedName("id") val id: Int,
    @SerializedName("title") val title: String? = null,
    @SerializedName("name") val name: String? = null,
    @SerializedName("overview") val overview: String? = null,
    @SerializedName("poster_path") val posterPath: String? = null,
    @SerializedName("backdrop_path") val backdropPath: String? = null,
    @SerializedName("vote_average") val voteAverage: Double? = 0.0,
    @SerializedName("release_date") val releaseDate: String? = null,
    @SerializedName("first_air_date") val firstAirDate: String? = null,
    @SerializedName("media_type") var mediaType: String? = null,
    @SerializedName("genre_ids") val genreIds: List<Int>? = emptyList(),
    @SerializedName("logo_path") var logoPath: String? = null
) {
    val displayTitle: String
        get() = title ?: name ?: "Untitled"

    val year: String
        get() {
            val date = releaseDate ?: firstAirDate ?: return ""
            return if (date.length >= 4) date.substring(0, 4) else ""
        }

    val posterUrl: String
        get() = if (!posterPath.isNullOrEmpty()) "https://image.tmdb.org/t/p/w500$posterPath" else ""

    val backdropUrl: String
        get() = if (!backdropPath.isNullOrEmpty()) "https://image.tmdb.org/t/p/original$backdropPath" else ""

    val resolvedMediaType: String
        get() = mediaType ?: if (!firstAirDate.isNullOrEmpty() || !name.isNullOrEmpty()) "tv" else "movie"
}
