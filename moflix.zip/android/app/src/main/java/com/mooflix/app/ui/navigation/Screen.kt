package com.mooflix.app.ui.navigation

sealed class Screen(val route: String, val title: String) {
    object Home : Screen("home", "Home")
    object Movies : Screen("movies", "Movies")
    object Series : Screen("series", "Series")
    object Anime : Screen("anime", "Anime")
    object Sports : Screen("sports", "Sports")
    object Watchlist : Screen("watchlist", "My List")
    object Search : Screen("search", "Search")
    object Player : Screen("player/{mediaType}/{id}/{season}/{episode}/{title}", "Player") {
        fun createRoute(mediaType: String, id: Int, season: Int = 1, episode: Int = 1, title: String = ""): String {
            val encodedTitle = java.net.URLEncoder.encode(title, "UTF-8")
            return "player/$mediaType/$id/$season/$episode/$encodedTitle"
        }
    }
}
