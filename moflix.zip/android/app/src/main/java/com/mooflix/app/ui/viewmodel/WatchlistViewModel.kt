package com.mooflix.app.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mooflix.app.data.local.WatchlistEntity
import com.mooflix.app.data.model.MovieItem
import com.mooflix.app.data.repository.MovieRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class WatchlistViewModel(private val repository: MovieRepository) : ViewModel() {

    val watchlistItems: StateFlow<List<MovieItem>> = repository.getWatchlist()
        .map { list -> list.map { it.toMovieItem() } }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    fun removeItem(id: Int) {
        viewModelScope.launch {
            repository.removeFromWatchlist(id)
        }
    }
}
