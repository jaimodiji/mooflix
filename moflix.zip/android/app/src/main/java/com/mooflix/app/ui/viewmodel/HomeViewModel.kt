package com.mooflix.app.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mooflix.app.data.local.ContinueWatchingEntity
import com.mooflix.app.data.model.MovieItem
import com.mooflix.app.data.repository.MovieRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class HomeUiState(
    val isLoading: Boolean = true,
    val heroItem: MovieItem? = null,
    val trendingDaily: List<MovieItem> = emptyList(),
    val trendingWeekly: List<MovieItem> = emptyList(),
    val topRated: List<MovieItem> = emptyList(),
    val latestMovies: List<MovieItem> = emptyList(),
    val tvSeries: List<MovieItem> = emptyList(),
    val anime: List<MovieItem> = emptyList()
)

class HomeViewModel(private val repository: MovieRepository) : ViewModel() {

    private val _uiState = MutableStateFlow(HomeUiState())
    val uiState: StateFlow<HomeUiState> = _uiState.asStateFlow()

    val continueWatching: StateFlow<List<ContinueWatchingEntity>> = repository.getContinueWatching()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    init {
        loadHomeData()
    }

    fun loadHomeData() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true)

            try {
                val daily = repository.getTrendingDaily()
                val weekly = repository.getTrendingWeekly()
                val top = repository.getTopRated()
                val movies = repository.getMovies(1)
                val tv = repository.getTvSeries(1)
                val anime = repository.getAnime(1)

                val hero = daily.firstOrNull() ?: weekly.firstOrNull()

                _uiState.value = HomeUiState(
                    isLoading = false,
                    heroItem = hero,
                    trendingDaily = daily,
                    trendingWeekly = weekly,
                    topRated = top,
                    latestMovies = movies,
                    tvSeries = tv,
                    anime = anime
                )
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(isLoading = false)
            }
        }
    }

    fun saveProgress(item: MovieItem, season: Int = 1, episode: Int = 1) {
        viewModelScope.launch {
            repository.saveContinueWatching(item, season, episode)
        }
    }

    fun removeContinueWatching(id: Int) {
        viewModelScope.launch {
            repository.removeFromContinueWatching(id)
        }
    }

    fun toggleWatchlist(item: MovieItem, isCurrentlyWatchlisted: Boolean) {
        viewModelScope.launch {
            if (isCurrentlyWatchlisted) {
                repository.removeFromWatchlist(item.id)
            } else {
                repository.addToWatchlist(item)
            }
        }
    }
}
