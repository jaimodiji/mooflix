package com.mooflix.app.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.mooflix.app.data.model.MovieItem

@Entity(tableName = "watchlist")
data class WatchlistEntity(
    @PrimaryKey val id: Int,
    val title: String,
    val overview: String?,
    val posterPath: String?,
    val backdropPath: String?,
    val voteAverage: Double?,
    val releaseDate: String?,
    val mediaType: String,
    val addedAt: Long = System.currentTimeMillis()
) {
    fun toMovieItem(): MovieItem {
        return MovieItem(
            id = id,
            title = if (mediaType == "movie") title else null,
            name = if (mediaType == "tv") title else null,
            overview = overview,
            posterPath = posterPath,
            backdropPath = backdropPath,
            voteAverage = voteAverage,
            releaseDate = if (mediaType == "movie") releaseDate else null,
            firstAirDate = if (mediaType == "tv") releaseDate else null,
            mediaType = mediaType
        )
    }

    companion object {
        fun fromMovieItem(item: MovieItem): WatchlistEntity {
            return WatchlistEntity(
                id = item.id,
                title = item.displayTitle,
                overview = item.overview,
                posterPath = item.posterPath,
                backdropPath = item.backdropPath,
                voteAverage = item.voteAverage,
                releaseDate = item.releaseDate ?: item.firstAirDate,
                mediaType = item.resolvedMediaType
            )
        }
    }
}
