package com.mooflix.app.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mooflix.app.data.model.MovieItem
import com.mooflix.app.data.repository.MovieRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

enum class BrowseType {
    MOVIES, SERIES, ANIME
}

data class BrowseUiState(
    val isLoading: Boolean = false,
    val isFetchingMore: Boolean = false,
    val items: List<MovieItem> = emptyList(),
    val currentPage: Int = 1,
    val selectedGenre: String = "all",
    val canLoadMore: Boolean = true
)

class BrowseViewModel(
    private val repository: MovieRepository,
    private val type: BrowseType
) : ViewModel() {

    private val _uiState = MutableStateFlow(BrowseUiState())
    val uiState: StateFlow<BrowseUiState> = _uiState.asStateFlow()

    init {
        loadData(page = 1, genre = "all", isInitial = true)
    }

    fun onGenreSelected(genreId: String) {
        if (_uiState.value.selectedGenre == genreId) return
        _uiState.value = _uiState.value.copy(selectedGenre = genreId, items = emptyList(), currentPage = 1)
        loadData(page = 1, genre = genreId, isInitial = true)
    }

    fun loadNextPage() {
        val current = _uiState.value
        if (current.isLoading || current.isFetchingMore || !current.canLoadMore) return
        val nextPage = current.currentPage + 1
        loadData(page = nextPage, genre = current.selectedGenre, isInitial = false)
    }

    private fun loadData(page: Int, genre: String, isInitial: Boolean) {
        viewModelScope.launch {
            if (isInitial) {
                _uiState.value = _uiState.value.copy(isLoading = true)
            } else {
                _uiState.value = _uiState.value.copy(isFetchingMore = true)
            }

            val newItems = when (type) {
                BrowseType.MOVIES -> repository.getMovies(page = page, genreId = genre)
                BrowseType.SERIES -> repository.getTvSeries(page = page, genreId = genre)
                BrowseType.ANIME -> repository.getAnime(page = page, genreId = genre)
            }

            val updatedList = if (page == 1) newItems else _uiState.value.items + newItems

            _uiState.value = _uiState.value.copy(
                isLoading = false,
                isFetchingMore = false,
                items = updatedList,
                currentPage = page,
                canLoadMore = newItems.isNotEmpty()
            )
        }
    }
}
