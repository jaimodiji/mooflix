package com.mooflix.app.ui.theme

import androidx.compose.ui.graphics.Color

val BlackBg = Color(0xFF0A0A0A)
val SurfaceDark = Color(0xFF141414)
val SurfaceElevated = Color(0xFF1F1F1F)
val BorderDark = Color(0x1AFFFFFF)
val RedAccent = Color(0xFFE50914)
val AmberAccent = Color(0xFFF59E0B)
val TextPrimary = Color(0xFFFFFFFF)
val TextSecondary = Color(0xFFA3A3A3)
val TextMuted = Color(0xFF737373)
