package com.mooflix.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.navigation.compose.rememberNavController
import com.mooflix.app.ui.navigation.MooflixNavGraph
import com.mooflix.app.ui.theme.MooflixTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val app = application as MooflixApplication
        val repository = app.repository

        setContent {
            MooflixTheme {
                val navController = rememberNavController()
                MooflixNavGraph(
                    navController = navController,
                    repository = repository
                )
            }
        }
    }
}
