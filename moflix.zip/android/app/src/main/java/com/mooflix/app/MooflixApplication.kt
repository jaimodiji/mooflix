package com.mooflix.app

import android.app.Application
import com.mooflix.app.data.local.AppDatabase
import com.mooflix.app.data.repository.MovieRepository

class MooflixApplication : Application() {

    val database: AppDatabase by lazy {
        AppDatabase.getDatabase(this)
    }

    val repository: MovieRepository by lazy {
        MovieRepository(database.watchlistDao(), database.continueWatchingDao())
    }

    override fun onCreate() {
        super.onCreate()
    }
}
