package com.mooflix.app.ui.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.navArgument
import com.mooflix.app.data.model.MovieItem
import com.mooflix.app.data.repository.MovieRepository
import com.mooflix.app.ui.components.MooflixBottomBar
import com.mooflix.app.ui.components.MooflixTopBar
import com.mooflix.app.ui.screens.*
import com.mooflix.app.ui.viewmodel.BrowseType
import com.mooflix.app.ui.viewmodel.BrowseViewModel
import com.mooflix.app.ui.viewmodel.HomeViewModel
import com.mooflix.app.ui.viewmodel.SearchViewModel
import com.mooflix.app.ui.viewmodel.WatchlistViewModel

@Composable
fun MooflixNavGraph(
    navController: NavHostController,
    repository: MovieRepository
) {
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route
    val isPlayerScreen = currentRoute?.startsWith("player/") == true

    Scaffold(
        topBar = {
            if (!isPlayerScreen && currentRoute != Screen.Search.route) {
                MooflixTopBar(
                    onNavigateWatchlist = { navController.navigate(Screen.Watchlist.route) },
                    onNavigateSearch = { navController.navigate(Screen.Search.route) }
                )
            }
        },
        bottomBar = {
            if (!isPlayerScreen) {
                MooflixBottomBar(
                    currentRoute = currentRoute,
                    onNavigate = { route ->
                        navController.navigate(route) {
                            popUpTo(Screen.Home.route) { saveState = true }
                            launchSingleTop = true
                            restoreState = true
                        }
                    }
                )
            }
        }
    ) { paddingValues ->
        NavHost(
            navController = navController,
            startDestination = Screen.Home.route,
            modifier = Modifier.padding(if (isPlayerScreen) androidx.compose.foundation.layout.PaddingValues() else paddingValues)
        ) {
            // Home Screen
            composable(Screen.Home.route) {
                val homeViewModel = androidx.lifecycle.viewmodel.compose.viewModel {
                    HomeViewModel(repository)
                }
                HomeScreen(
                    viewModel = homeViewModel,
                    onMovieClick = { item ->
                        navController.navigate(
                            Screen.Player.createRoute(
                                mediaType = item.resolvedMediaType,
                                id = item.id,
                                title = item.displayTitle
                            )
                        )
                    },
                    onPlayClick = { item ->
                        navController.navigate(
                            Screen.Player.createRoute(
                                mediaType = item.resolvedMediaType,
                                id = item.id,
                                title = item.displayTitle
                            )
                        )
                    }
                )
            }

            // Movies Screen
            composable(Screen.Movies.route) {
                val moviesViewModel = androidx.lifecycle.viewmodel.compose.viewModel {
                    BrowseViewModel(repository, BrowseType.MOVIES)
                }
                BrowseScreen(
                    title = "Movies",
                    viewModel = moviesViewModel,
                    onItemClick = { item ->
                        navController.navigate(
                            Screen.Player.createRoute("movie", item.id, title = item.displayTitle)
                        )
                    }
                )
            }

            // Series Screen
            composable(Screen.Series.route) {
                val seriesViewModel = androidx.lifecycle.viewmodel.compose.viewModel {
                    BrowseViewModel(repository, BrowseType.SERIES)
                }
                BrowseScreen(
                    title = "TV Series",
                    viewModel = seriesViewModel,
                    onItemClick = { item ->
                        navController.navigate(
                            Screen.Player.createRoute("tv", item.id, title = item.displayTitle)
                        )
                    }
                )
            }

            // Anime Screen
            composable(Screen.Anime.route) {
                val animeViewModel = androidx.lifecycle.viewmodel.compose.viewModel {
                    BrowseViewModel(repository, BrowseType.ANIME)
                }
                BrowseScreen(
                    title = "Anime & Cartoons",
                    viewModel = animeViewModel,
                    onItemClick = { item ->
                        navController.navigate(
                            Screen.Player.createRoute(
                                mediaType = item.resolvedMediaType,
                                id = item.id,
                                title = item.displayTitle
                            )
                        )
                    }
                )
            }

            // Sports Screen (Coming Soon)
            composable(Screen.Sports.route) {
                SportsScreen(
                    onBackToHome = { navController.navigate(Screen.Home.route) }
                )
            }

            // Watchlist Screen
            composable(Screen.Watchlist.route) {
                val watchlistViewModel = androidx.lifecycle.viewmodel.compose.viewModel {
                    WatchlistViewModel(repository)
                }
                WatchlistScreen(
                    viewModel = watchlistViewModel,
                    onItemClick = { item ->
                        navController.navigate(
                            Screen.Player.createRoute(
                                mediaType = item.resolvedMediaType,
                                id = item.id,
                                title = item.displayTitle
                            )
                        )
                    }
                )
            }

            // Search Screen
            composable(Screen.Search.route) {
                val searchViewModel = androidx.lifecycle.viewmodel.compose.viewModel {
                    SearchViewModel(repository)
                }
                SearchScreen(
                    viewModel = searchViewModel,
                    onItemClick = { item ->
                        navController.navigate(
                            Screen.Player.createRoute(
                                mediaType = item.resolvedMediaType,
                                id = item.id,
                                title = item.displayTitle
                            )
                        )
                    }
                )
            }

            // Player Screen
            composable(
                route = Screen.Player.route,
                arguments = listOf(
                    navArgument("mediaType") { type = NavType.StringType },
                    navArgument("id") { type = NavType.IntType },
                    navArgument("season") { type = NavType.IntType; defaultValue = 1 },
                    navArgument("episode") { type = NavType.IntType; defaultValue = 1 },
                    navArgument("title") { type = NavType.StringType; defaultValue = "" }
                )
            ) { backStackEntry ->
                val mediaType = backStackEntry.arguments?.getString("mediaType") ?: "movie"
                val id = backStackEntry.arguments?.getInt("id") ?: 0
                val season = backStackEntry.arguments?.getInt("season") ?: 1
                val episode = backStackEntry.arguments?.getInt("episode") ?: 1
                val rawTitle = backStackEntry.arguments?.getString("title") ?: ""
                val title = java.net.URLDecoder.decode(rawTitle, "UTF-8")

                PlayerScreen(
                    mediaType = mediaType,
                    id = id,
                    season = season,
                    episode = episode,
                    title = title,
                    onBack = { navController.popBackStack() }
                )
            }
        }
    }
}
