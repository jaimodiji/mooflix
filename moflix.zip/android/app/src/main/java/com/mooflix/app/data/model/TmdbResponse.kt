package com.mooflix.app.data.model

import com.google.gson.annotations.SerializedName

data class TmdbResponse(
    @SerializedName("page") val page: Int = 1,
    @SerializedName("results") val results: List<MovieItem> = emptyList(),
    @SerializedName("total_pages") val totalPages: Int = 1,
    @SerializedName("total_results") val totalResults: Int = 0
)

data class ExternalIdsResponse(
    @SerializedName("imdb_id") val imdbId: String? = null
)

data class ImagesResponse(
    @SerializedName("logos") val logos: List<LogoItem> = emptyList()
)

data class LogoItem(
    @SerializedName("file_path") val filePath: String? = null,
    @SerializedName("iso_639_1") val lang: String? = null
)

data class SeasonDetailsResponse(
    @SerializedName("season_number") val seasonNumber: Int,
    @SerializedName("episodes") val episodes: List<EpisodeItem> = emptyList()
)

data class EpisodeItem(
    @SerializedName("id") val id: Int,
    @SerializedName("name") val name: String? = null,
    @SerializedName("overview") val overview: String? = null,
    @SerializedName("episode_number") val episodeNumber: Int,
    @SerializedName("season_number") val seasonNumber: Int,
    @SerializedName("still_path") val stillPath: String? = null,
    @SerializedName("vote_average") val voteAverage: Double? = 0.0
) {
    val stillUrl: String
        get() = if (!stillPath.isNullOrEmpty()) "https://image.tmdb.org/t/p/w500$stillPath" else ""
}

data class TvDetailsResponse(
    @SerializedName("id") val id: Int,
    @SerializedName("name") val name: String? = null,
    @SerializedName("number_of_seasons") val numberOfSeasons: Int = 1,
    @SerializedName("number_of_episodes") val numberOfEpisodes: Int = 1,
    @SerializedName("seasons") val seasons: List<SeasonBriefItem> = emptyList()
)

data class SeasonBriefItem(
    @SerializedName("id") val id: Int,
    @SerializedName("name") val name: String? = null,
    @SerializedName("season_number") val seasonNumber: Int,
    @SerializedName("episode_count") val episodeCount: Int = 0
)

data class PlayConfig(
    val id: Int,
    val mediaType: String,
    val title: String,
    val season: Int = 1,
    val episode: Int = 1,
    val server: String = "nxsha"
) {
    fun getStreamUrl(): String {
        return if (mediaType == "tv") {
            "https://nxsha.xyz/embed/tv/$id/$season/$episode"
        } else {
            "https://nxsha.xyz/embed/movie/$id"
        }
    }
}
