package com.mooflix.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.mooflix.app.data.local.ContinueWatchingEntity
import com.mooflix.app.data.model.MovieItem
import com.mooflix.app.ui.components.HeroBanner
import com.mooflix.app.ui.components.MovieCard
import com.mooflix.app.ui.theme.*
import com.mooflix.app.ui.viewmodel.HomeViewModel

@Composable
fun HomeScreen(
    viewModel: HomeViewModel,
    onMovieClick: (MovieItem) -> Unit,
    onPlayClick: (MovieItem) -> Unit,
    onPlayContinueWatching: (ContinueWatchingEntity) -> Unit = { entity ->
        onPlayClick(entity.toMovieItem())
    }
) {
    val uiState by viewModel.uiState.collectAsState()
    val continueWatchingList by viewModel.continueWatching.collectAsState()

    if (uiState.isLoading) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(BlackBg),
            contentAlignment = Alignment.Center
        ) {
            CircularProgressIndicator(color = RedAccent)
        }
        return
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(BlackBg)
    ) {
        // Hero Section
        item {
            HeroBanner(
                item = uiState.heroItem,
                onPlayClick = {
                    viewModel.saveProgress(it)
                    onPlayClick(it)
                },
                onWatchlistToggle = { viewModel.toggleWatchlist(it, false) }
            )
        }

        // Continue Watching Section (Appears when user has played content)
        if (continueWatchingList.isNotEmpty()) {
            item {
                ContinueWatchingSection(
                    items = continueWatchingList,
                    onPlay = { cw ->
                        onPlayContinueWatching(cw)
                    },
                    onRemove = { id ->
                        viewModel.removeContinueWatching(id)
                    }
                )
            }
        }

        // Trending Today Section
        if (uiState.trendingDaily.isNotEmpty()) {
            item {
                MovieSectionRow(
                    title = "Trending Today",
                    items = uiState.trendingDaily,
                    onItemClick = onMovieClick
                )
            }
        }

        // Top Rated Section
        if (uiState.topRated.isNotEmpty()) {
            item {
                MovieSectionRow(
                    title = "Top Rated Worldwide",
                    items = uiState.topRated,
                    onItemClick = onMovieClick
                )
            }
        }

        // Trending This Week Section
        if (uiState.trendingWeekly.isNotEmpty()) {
            item {
                MovieSectionRow(
                    title = "Trending This Week",
                    items = uiState.trendingWeekly,
                    onItemClick = onMovieClick
                )
            }
        }

        // Blockbuster Movies Section
        if (uiState.latestMovies.isNotEmpty()) {
            item {
                MovieSectionRow(
                    title = "Blockbuster Movies",
                    items = uiState.latestMovies,
                    onItemClick = onMovieClick
                )
            }
        }

        // TV Series Section
        if (uiState.tvSeries.isNotEmpty()) {
            item {
                MovieSectionRow(
                    title = "Binge-Worthy TV Series",
                    items = uiState.tvSeries,
                    onItemClick = onMovieClick
                )
            }
        }

        // Anime & Cartoons Section
        if (uiState.anime.isNotEmpty()) {
            item {
                MovieSectionRow(
                    title = "Anime & 3D Cartoons",
                    items = uiState.anime,
                    onItemClick = onMovieClick
                )
            }
        }

        item {
            Spacer(modifier = Modifier.height(30.dp))
        }
    }
}

@Composable
fun MovieSectionRow(
    title: String,
    items: List<MovieItem>,
    onItemClick: (MovieItem) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 12.dp)
    ) {
        Text(
            text = title,
            color = TextPrimary,
            fontSize = 17.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
        )

        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(items, key = { it.id }) { item ->
                MovieCard(
                    item = item,
                    onClick = { onItemClick(item) }
                )
            }
        }
    }
}

@Composable
fun ContinueWatchingSection(
    items: List<ContinueWatchingEntity>,
    onPlay: (ContinueWatchingEntity) -> Unit,
    onRemove: (Int) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 12.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(RedAccent)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "Continue Watching",
                color = TextPrimary,
                fontSize = 17.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.width(6.dp))
            Surface(
                color = Color.White.copy(alpha = 0.1f),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(
                    text = "${items.size}",
                    color = TextSecondary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                )
            }
        }

        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(items, key = { "cw_${it.id}" }) { item ->
                ContinueWatchingItemCard(
                    item = item,
                    onPlay = { onPlay(item) },
                    onRemove = { onRemove(item.id) }
                )
            }
        }
    }
}

@Composable
fun ContinueWatchingItemCard(
    item: ContinueWatchingEntity,
    onPlay: () -> Unit,
    onRemove: () -> Unit
) {
    val imagePath = item.backdropPath ?: item.posterPath
    val imageUrl = imagePath?.let { "https://image.tmdb.org/t/p/w780$it" }

    Card(
        modifier = Modifier
            .width(220.dp)
            .clip(RoundedCornerShape(10.dp))
            .clickable { onPlay() },
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = CardBg)
    ) {
        Column {
            // Backdrop Thumbnail with overlay & progress bar
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(124.dp)
                    .background(Color(0xFF1F1F1F))
            ) {
                if (imageUrl != null) {
                    AsyncImage(
                        model = imageUrl,
                        contentDescription = item.title,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                }

                // Dark overlay
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.35f))
                )

                // Play Button Center
                Box(
                    modifier = Modifier
                        .align(Alignment.Center)
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(RedAccent.copy(alpha = 0.9f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = "Resume",
                        tint = Color.White,
                        modifier = Modifier.size(22.dp)
                    )
                }

                // Remove Button Top Right
                IconButton(
                    onClick = onRemove,
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(4.dp)
                        .size(26.dp)
                        .clip(CircleShape)
                        .background(Color.Black.copy(alpha = 0.6f))
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Remove",
                        tint = Color.White,
                        modifier = Modifier.size(14.dp)
                    )
                }

                // Tag Top Left (e.g. S1:E2 or Movie)
                Surface(
                    color = Color.Black.copy(alpha = 0.75f),
                    shape = RoundedCornerShape(4.dp),
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(6.dp)
                ) {
                    Text(
                        text = if (item.mediaType == "tv") "S${item.season} • E${item.episode}" else "Movie",
                        color = Color.White,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }

                // Progress Bar at bottom
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .fillMaxWidth()
                        .height(3.dp)
                        .background(Color.DarkGray)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxHeight()
                            .fillMaxWidth(fraction = (item.progress.coerceIn(10, 100)) / 100f)
                            .background(RedAccent)
                    )
                }
            }

            // Info Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 10.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = item.title,
                        color = TextPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "${item.progress}% watched",
                        color = TextSecondary,
                        fontSize = 11.sp
                    )
                }

                IconButton(
                    onClick = onPlay,
                    modifier = Modifier.size(28.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = "Play",
                        tint = RedAccent,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}
