package com.mooflix.app.data.repository

import com.mooflix.app.data.api.RetrofitClient
import com.mooflix.app.data.local.ContinueWatchingDao
import com.mooflix.app.data.local.ContinueWatchingEntity
import com.mooflix.app.data.local.WatchlistDao
import com.mooflix.app.data.local.WatchlistEntity
import com.mooflix.app.data.model.*
import kotlinx.coroutines.flow.Flow
import java.text.SimpleDateFormat
import java.util.*

class MovieRepository(
    private val watchlistDao: WatchlistDao,
    private val continueWatchingDao: ContinueWatchingDao
) {
    private val api = RetrofitClient.apiService
    private val apiKey = RetrofitClient.API_KEY

    private fun getTodayDate(): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        return sdf.format(Date())
    }

    suspend fun getTrendingDaily(): List<MovieItem> {
        return try {
            val res = api.getTrendingDaily(apiKey)
            filterReleased(res.results)
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun getTrendingWeekly(): List<MovieItem> {
        return try {
            val res = api.getTrendingWeekly(apiKey)
            filterReleased(res.results)
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun getTopRated(): List<MovieItem> {
        return try {
            val res = api.getTopRatedMovies(apiKey)
            res.results.map { it.apply { mediaType = "movie" } }
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun getMovies(page: Int = 1, genreId: String? = null): List<MovieItem> {
        return try {
            val today = getTodayDate()
            val res = api.discoverMovies(
                apiKey = apiKey,
                page = page,
                withGenres = if (genreId != "all") genreId else null,
                releaseDateLte = today
            )
            res.results.map { it.apply { mediaType = "movie" } }
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun getTvSeries(page: Int = 1, genreId: String? = null): List<MovieItem> {
        return try {
            val today = getTodayDate()
            val res = api.discoverTv(
                apiKey = apiKey,
                page = page,
                withGenres = if (genreId != "all") genreId else null,
                airDateLte = today
            )
            res.results.map { it.apply { mediaType = "tv" } }
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun getAnime(page: Int = 1, genreId: String? = null): List<MovieItem> {
        return try {
            val today = getTodayDate()
            val genres = if (genreId != null && genreId != "all") "16,$genreId" else "16"
            val tvRes = api.discoverTv(apiKey = apiKey, page = page, withGenres = genres, airDateLte = today)
            val movieRes = api.discoverMovies(apiKey = apiKey, page = page, withGenres = genres, releaseDateLte = today)
            
            val combined = (
                tvRes.results.map { it.apply { mediaType = "tv" } } +
                movieRes.results.map { it.apply { mediaType = "movie" } }
            ).sortedByDescending { it.voteAverage ?: 0.0 }
            
            combined
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun search(query: String, page: Int = 1): List<MovieItem> {
        return try {
            val res = api.searchMulti(apiKey = apiKey, query = query, page = page)
            res.results.filter { it.mediaType == "movie" || it.mediaType == "tv" }
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun getTvDetails(id: Int): TvDetailsResponse? {
        return try {
            api.getTvDetails(id, apiKey)
        } catch (e: Exception) {
            null
        }
    }

    suspend fun getSeasonDetails(tvId: Int, seasonNumber: Int): List<EpisodeItem> {
        return try {
            val res = api.getSeasonDetails(tvId, seasonNumber, apiKey)
            res.episodes
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun getLogoUrl(mediaType: String, id: Int): String? {
        return try {
            val res = api.getImages(mediaType, id, apiKey)
            val logo = res.logos.firstOrNull { it.lang == "en" } ?: res.logos.firstOrNull()
            logo?.filePath?.let { "https://image.tmdb.org/t/p/w500$it" }
        } catch (e: Exception) {
            null
        }
    }

    private fun filterReleased(items: List<MovieItem>): List<MovieItem> {
        val today = getTodayDate()
        return items.filter {
            val date = it.releaseDate ?: it.firstAirDate
            date != null && date <= today
        }
    }

    // Watchlist Database operations
    fun getWatchlist(): Flow<List<WatchlistEntity>> = watchlistDao.getAllWatchlist()
    fun isWatchlisted(id: Int): Flow<Boolean> = watchlistDao.isInWatchlist(id)
    suspend fun addToWatchlist(item: MovieItem) = watchlistDao.addToWatchlist(WatchlistEntity.fromMovieItem(item))
    suspend fun removeFromWatchlist(id: Int) = watchlistDao.removeById(id)

    // Continue Watching Database operations
    fun getContinueWatching(): Flow<List<ContinueWatchingEntity>> = continueWatchingDao.getAllContinueWatching()
    suspend fun saveContinueWatching(item: MovieItem, season: Int = 1, episode: Int = 1, progress: Int = 35) {
        continueWatchingDao.saveProgress(ContinueWatchingEntity.fromMovieItem(item, season, episode, progress))
    }
    suspend fun removeFromContinueWatching(id: Int) = continueWatchingDao.removeById(id)
    suspend fun clearContinueWatching() = continueWatchingDao.clearAll()
}
