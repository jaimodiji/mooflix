package com.mooflix.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mooflix.app.data.model.MovieItem
import com.mooflix.app.ui.components.MovieCard
import com.mooflix.app.ui.theme.*
import com.mooflix.app.ui.viewmodel.BrowseViewModel

data class GenreItem(val id: String, val name: String)

val MOVIE_GENRES = listOf(
    GenreItem("all", "All"),
    GenreItem("28", "Action"),
    GenreItem("12", "Adventure"),
    GenreItem("16", "Animation"),
    GenreItem("35", "Comedy"),
    GenreItem("80", "Crime"),
    GenreItem("18", "Drama"),
    GenreItem("27", "Horror"),
    GenreItem("878", "Sci-Fi"),
    GenreItem("53", "Thriller"),
    GenreItem("10749", "Romance")
)

@Composable
fun BrowseScreen(
    title: String,
    viewModel: BrowseViewModel,
    onItemClick: (MovieItem) -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()
    val gridState = rememberLazyGridState()

    // Pagination detection
    val isNearEnd by remember {
        derivedStateOf {
            val total = gridState.layoutInfo.totalItemsCount
            val lastVisible = gridState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0
            total > 0 && lastVisible >= total - 4
        }
    }

    LaunchedEffect(isNearEnd) {
        if (isNearEnd && !uiState.isLoading && !uiState.isFetchingMore) {
            viewModel.loadNextPage()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BlackBg)
            .padding(top = 8.dp)
    ) {
        // Page Title
        Text(
            text = title,
            color = TextPrimary,
            fontSize = 22.sp,
            fontWeight = FontWeight.Black,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
        )

        if (uiState.isLoading && uiState.items.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(color = RedAccent)
            }
        } else {
            LazyVerticalGrid(
                state = gridState,
                columns = GridCells.Adaptive(minSize = 110.dp),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                itemsIndexed(uiState.items, key = { index, item -> "${item.id}-$index" }) { _, item ->
                    MovieCard(
                        item = item,
                        onClick = { onItemClick(item) },
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                if (uiState.isFetchingMore) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            CircularProgressIndicator(
                                color = RedAccent,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
