package com.mooflix.app.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.mooflix.app.data.model.MovieItem

@Entity(tableName = "continue_watching")
data class ContinueWatchingEntity(
    @PrimaryKey val id: Int,
    val title: String,
    val overview: String?,
    val posterPath: String?,
    val backdropPath: String?,
    val voteAverage: Double?,
    val releaseDate: String?,
    val mediaType: String,
    val season: Int = 1,
    val episode: Int = 1,
    val progress: Int = 30, // % watched
    val lastWatchedAt: Long = System.currentTimeMillis()
) {
    fun toMovieItem(): MovieItem {
        return MovieItem(
            id = id,
            title = if (mediaType == "movie") title else null,
            name = if (mediaType == "tv") title else null,
            overview = overview,
            posterPath = posterPath,
            backdropPath = backdropPath,
            voteAverage = voteAverage,
            releaseDate = if (mediaType == "movie") releaseDate else null,
            firstAirDate = if (mediaType == "tv") releaseDate else null,
            mediaType = mediaType
        )
    }

    companion object {
        fun fromMovieItem(item: MovieItem, season: Int = 1, episode: Int = 1, progress: Int = 35): ContinueWatchingEntity {
            return ContinueWatchingEntity(
                id = item.id,
                title = item.displayTitle,
                overview = item.overview,
                posterPath = item.posterPath,
                backdropPath = item.backdropPath,
                voteAverage = item.voteAverage,
                releaseDate = item.releaseDate ?: item.firstAirDate,
                mediaType = item.resolvedMediaType,
                season = season,
                episode = episode,
                progress = progress,
                lastWatchedAt = System.currentTimeMillis()
            )
        }
    }
}
