# MOOFLIX - Android App (Kotlin & Jetpack Compose)

This is the complete native Android project for **MOOFLIX Streaming Application**, built with **Kotlin, Jetpack Compose, Material 3, Retrofit, Room Database, and Hardware-Accelerated Video Player**.

---

## 📱 Features Included
- **Modern Jetpack Compose UI**: Dark theme aesthetic matching the Mooflix web app.
- **Top & Bottom Navigation**: Home, Movies, Series, Anime, Sports (Coming Soon), Search, and My List.
- **TMDB API Integration**: Real-time Trending, Top Rated, Genre Filtering, and Search.
- **Hardware-Accelerated Video Player**:
  - Fullscreen Landscape Auto-Rotation.
  - Multi-server fallback (Nxsha, Vidlink, EmbedSu, VidSrc).
  - TV Shows season & episode support.
- **Room Database**: Offline Watchlist & Saved Favorites.
- **Coil**: Smooth image & poster caching.

---

## 🚀 How to Open in Android Studio
1. Open **Android Studio** (Hedgehog / Iguana / Jellyfish or newer).
2. Click **Open** and select the `/android` directory.
3. Android Studio will automatically sync Gradle dependencies using `libs.versions.toml`.
4. Connect an Android phone via USB (or start an Android Emulator with API 24+).
5. Click **Run (`Shift + F10`)** or build APK via **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

---

## 📁 Project Directory Structure
```text
android/
├── build.gradle.kts
├── settings.gradle.kts
├── gradle/
│   └── libs.versions.toml
└── app/
    ├── build.gradle.kts
    └── src/main/
        ├── AndroidManifest.xml
        ├── res/
        │   └── values/ (strings.xml, colors.xml, themes.xml)
        └── java/com/mooflix/app/
            ├── MainActivity.kt
            ├── MooflixApplication.kt
            ├── data/
            │   ├── api/ (RetrofitClient.kt, TmdbApiService.kt)
            │   ├── local/ (AppDatabase.kt, WatchlistDao.kt, WatchlistEntity.kt)
            │   ├── model/ (MovieItem.kt, TmdbResponse.kt, PlayConfig.kt)
            │   └── repository/ (MovieRepository.kt)
            └── ui/
                ├── components/ (TopAppBar.kt, BottomNavBar.kt, MovieCard.kt, HeroBanner.kt)
                ├── navigation/ (NavGraph.kt, Screen.kt)
                ├── screens/ (HomeScreen.kt, BrowseScreen.kt, SportsScreen.kt, WatchlistScreen.kt, SearchScreen.kt, PlayerScreen.kt)
                ├── theme/ (Color.kt, Theme.kt, Type.kt)
                └── viewmodel/ (HomeViewModel.kt, BrowseViewModel.kt, SearchViewModel.kt, WatchlistViewModel.kt)
```
