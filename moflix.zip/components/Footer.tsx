import React from 'react';
import { ShieldAlert, FileText, Info, Mail, Film, ExternalLink, Send } from 'lucide-react';
import { StaticPageType } from './StaticPagesModal';

interface FooterProps {
  onOpenPage?: (page: StaticPageType) => void;
  onNavigateTab?: (tab: string) => void;
}

const Footer: React.FC<FooterProps> = ({ onOpenPage, onNavigateTab }) => {
  return (
    <footer className="w-full bg-[#08080c] border-t border-white/[0.08] text-neutral-400 select-none text-xs mt-12">
      <div className="max-w-[1800px] mx-auto px-4 sm:px-6 md:px-12 py-10 md:py-14">

        {/* Main Footer Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8 sm:gap-10 pb-10 border-b border-white/[0.06]">
          {/* Col 1 & 2: Brand Info & Mission (SEO anchor) */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-red-600 to-rose-600 flex items-center justify-center p-0.5 shadow-lg shadow-red-950/60">
                <span className="text-base font-black text-white">M</span>
              </div>
              <span className="text-xl font-black tracking-tight text-white">
                MOO<span className="text-red-500 font-extrabold">FLIX</span>
              </span>
            </div>

            <p className="text-xs text-neutral-400 leading-relaxed max-w-md">
              <strong>MooFlix</strong> is an ad-free online streaming platform offering instant access to movies, trending web series, anime, and live sports in Ultra HD 4K with automatic multi-server failover.
            </p>
          </div>

          {/* Col 3: Navigation */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold text-white uppercase tracking-wider">Explore Cinema</h4>
            <ul className="space-y-2 text-xs">
              <li>
                <a 
                  href="/" 
                  onClick={(e) => { e.preventDefault(); onNavigateTab?.('home'); }} 
                  className="hover:text-white transition-colors cursor-pointer text-left block"
                >
                  Home Showcase
                </a>
              </li>
              <li>
                <a 
                  href="/movies" 
                  onClick={(e) => { e.preventDefault(); onNavigateTab?.('movies'); }} 
                  className="hover:text-white transition-colors cursor-pointer text-left block"
                >
                  Featured Movies
                </a>
              </li>
              <li>
                <a 
                  href="/series" 
                  onClick={(e) => { e.preventDefault(); onNavigateTab?.('series'); }} 
                  className="hover:text-white transition-colors cursor-pointer text-left block"
                >
                  TV &amp; Web Series
                </a>
              </li>
              <li>
                <a 
                  href="/anime" 
                  onClick={(e) => { e.preventDefault(); onNavigateTab?.('anime'); }} 
                  className="hover:text-white transition-colors cursor-pointer text-left block"
                >
                  Anime Collection
                </a>
              </li>
              <li>
                <a 
                  href="/sports" 
                  onClick={(e) => { e.preventDefault(); onNavigateTab?.('sports'); }} 
                  className="hover:text-white transition-colors cursor-pointer text-left block"
                >
                  Live Sports &amp; Cricket
                </a>
              </li>
              <li>
                <a 
                  href="/blogs" 
                  onClick={(e) => { e.preventDefault(); onNavigateTab?.('blogs'); }} 
                  className="hover:text-white transition-colors cursor-pointer text-left block"
                >
                  Cinema Blogs &amp; Guides
                </a>
              </li>
              <li>
                <a 
                  href="/watchlist" 
                  onClick={(e) => { e.preventDefault(); onNavigateTab?.('watchlist'); }} 
                  className="hover:text-white transition-colors cursor-pointer text-left block"
                >
                  My Saved List
                </a>
              </li>
            </ul>
          </div>

          {/* Col 4: Trust & Legal Pages (Crucial for Search Console Ranking) */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold text-white uppercase tracking-wider">Legal &amp; Compliance</h4>
            <ul className="space-y-2 text-xs">
              <li>
                <a 
                  href="/dmca" 
                  onClick={(e) => { e.preventDefault(); onOpenPage?.('dmca'); }} 
                  className="hover:text-red-400 transition-colors cursor-pointer flex items-center gap-1.5 text-left text-neutral-300"
                >
                  <ShieldAlert size={12} className="text-amber-400 shrink-0" />
                  <span>DMCA Disclaimer</span>
                </a>
              </li>
              <li>
                <a 
                  href="/privacy" 
                  onClick={(e) => { e.preventDefault(); onOpenPage?.('privacy'); }} 
                  className="hover:text-white transition-colors cursor-pointer flex items-center gap-1.5 text-left text-neutral-300"
                >
                  <FileText size={12} className="text-emerald-400 shrink-0" />
                  <span>Privacy Policy</span>
                </a>
              </li>
              <li>
                <a 
                  href="/terms" 
                  onClick={(e) => { e.preventDefault(); onOpenPage?.('terms'); }} 
                  className="hover:text-white transition-colors cursor-pointer flex items-center gap-1.5 text-left text-neutral-300"
                >
                  <FileText size={12} className="text-blue-400 shrink-0" />
                  <span>Terms of Service</span>
                </a>
              </li>
              <li>
                <a 
                  href="/sitemap" 
                  className="hover:text-white transition-colors inline-flex items-center gap-1 text-left text-neutral-300"
                >
                  <span>HTML Sitemap</span>
                </a>
              </li>
              <li>
                <a 
                  href="/sitemap.xml" 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  className="hover:text-white transition-colors inline-flex items-center gap-1 text-left text-neutral-400"
                >
                  <span>Sitemap XML</span>
                  <ExternalLink size={10} />
                </a>
              </li>
            </ul>
          </div>

          {/* Col 5: Company & Support */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold text-white uppercase tracking-wider">Company &amp; Support</h4>
            <ul className="space-y-2 text-xs">
              <li>
                <a 
                  href="/about" 
                  onClick={(e) => { e.preventDefault(); onOpenPage?.('about'); }} 
                  className="hover:text-white transition-colors cursor-pointer flex items-center gap-1.5 text-left text-neutral-300"
                >
                  <Info size={12} className="text-purple-400 shrink-0" />
                  <span>About MooFlix</span>
                </a>
              </li>
              <li>
                <a 
                  href="/contact" 
                  onClick={(e) => { e.preventDefault(); onOpenPage?.('contact'); }} 
                  className="hover:text-white transition-colors cursor-pointer flex items-center gap-1.5 text-left text-neutral-300"
                >
                  <Mail size={12} className="text-rose-400 shrink-0" />
                  <span>Contact &amp; DMCA Agent</span>
                </a>
              </li>
              <li className="pt-2">
                <span className="text-[11px] text-neutral-500 block">Support &amp; Community:</span>
                <a 
                  href="https://t.me/+ziNHhQUYib5mNjk1" 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  className="text-[#29b6f6] hover:text-[#52c5ff] font-bold text-xs inline-flex items-center gap-1.5 hover:underline mt-0.5"
                >
                  <Send size={13} className="-rotate-12" />
                  <span>Join Telegram Support</span>
                </a>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Credits & Copyright */}
        <div className="pt-6 flex flex-col md:flex-row items-center justify-between gap-4 text-[11px] text-neutral-500">
          <p className="text-center md:text-left">
            © 2026 <strong>MooFlix Entertainment</strong>. All rights reserved. MooFlix does not host or upload any media files on its own servers. Content is indexed from publicly accessible APIs.
          </p>

          <div className="flex items-center gap-4 shrink-0 text-neutral-400">
            <span>Ad-Free HD Streaming</span>
            <span>•</span>
            <button 
              type="button" 
              onClick={() => onOpenPage?.('dmca')} 
              className="hover:text-white transition-colors cursor-pointer"
            >
              DMCA Notice
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
