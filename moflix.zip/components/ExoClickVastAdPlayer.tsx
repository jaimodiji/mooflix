import React, { useEffect } from 'react';

interface ExoClickVastAdPlayerProps {
  title?: string;
  isSeries?: boolean;
  season?: number;
  episode?: number;
  onComplete: () => void;
}

export const ExoClickVastAdPlayer: React.FC<ExoClickVastAdPlayerProps> = ({ onComplete }) => {
  useEffect(() => {
    onComplete();
  }, [onComplete]);

  return null;
};

export default ExoClickVastAdPlayer;
