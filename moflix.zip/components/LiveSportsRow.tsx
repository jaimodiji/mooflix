import React, { useState, useEffect, useRef } from 'react';
import { ChevronRight, ChevronLeft, Trophy, Play, Clock, Eye } from 'lucide-react';
import { 
  APIMatch, 
  fetchMatches, 
  fetchLiveMatches, 
  formatMatchTime, 
  getTeamBadgeUrl,
  getSportPosterUrl,
  SPORT_DEFAULT_IMAGES
} from '../services/sportsService';
import SportStreamModal from './SportStreamModal';

interface LiveSportsRowProps {
  onSeeAllSports: () => void;
}

export const LiveSportsRow: React.FC<LiveSportsRowProps> = ({ onSeeAllSports }) => {
  const [matches, setMatches] = useState<APIMatch[]>([]);
  const [activeMatch, setActiveMatch] = useState<APIMatch | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [showLeftArrow, setShowLeftArrow] = useState<boolean>(false);
  const [showRightArrow, setShowRightArrow] = useState<boolean>(true);

  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    let isMounted = true;

    // Fetch live matches first; if none, fetch today's popular matches
    Promise.all([
      fetchLiveMatches(),
      fetchMatches('all', 'all')
    ]).then(([live, allMatches]) => {
      if (!isMounted) return;
      const combined = [...live, ...allMatches.filter((p) => !live.some((l) => l.id === p.id))];
      setMatches(combined.slice(0, 14));
    }).catch((err) => {
      console.error('Error fetching live sports row:', err);
    }).finally(() => {
      if (isMounted) setLoading(false);
    });

    return () => {
      isMounted = false;
    };
  }, []);

  const handleScroll = () => {
    if (scrollRef.current) {
      const { scrollLeft, scrollWidth, clientWidth } = scrollRef.current;
      setShowLeftArrow(scrollLeft > 10);
      setShowRightArrow(scrollLeft < scrollWidth - clientWidth - 10);
    }
  };

  const scroll = (direction: 'left' | 'right') => {
    if (scrollRef.current) {
      const scrollAmount = 450;
      scrollRef.current.scrollBy({
        left: direction === 'left' ? -scrollAmount : scrollAmount,
        behavior: 'smooth',
      });
    }
  };

  if (!loading && matches.length === 0) {
    return null;
  }

  const liveMatchesCount = matches.filter((m) => formatMatchTime(m.date).status === 'live').length;

  return (
    <section className="space-y-3.5 my-6 sm:my-8 relative group/sports select-none">
      {/* Row Header - iOS 27 Sleek Title */}
      <div className="flex items-center justify-between px-3.5 sm:px-6 md:px-12">
        <div className="flex items-center gap-2.5">
          <div className="p-2 rounded-full bg-red-600/15 border border-red-500/25 text-red-500 shadow-sm">
            <Trophy size={16} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base sm:text-lg md:text-xl font-extrabold text-white tracking-tight">
                Live Sports & Matches
              </h2>
              {liveMatchesCount > 0 ? (
                <span className="px-2.5 py-0.5 rounded-full bg-red-600/20 border border-red-500/40 text-red-400 text-[10px] font-black tracking-wide animate-pulse">
                  {liveMatchesCount} LIVE NOW
                </span>
              ) : (
                <span className="px-2.5 py-0.5 rounded-full bg-amber-500/15 border border-amber-500/30 text-amber-300 text-[10px] font-bold">
                  UPCOMING (IST)
                </span>
              )}
            </div>
            <p className="text-[11px] sm:text-xs text-neutral-400 hidden sm:block">
              Football, Cricket, NFL, NBA, MLB, Motorsports & Fight live streams with Indian Standard Time (IST)
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={onSeeAllSports}
          className="flex items-center gap-1 px-3.5 py-1.5 rounded-full bg-white/5 hover:bg-white/10 text-xs sm:text-sm font-bold text-red-400 hover:text-red-300 transition-all border border-white/5 hover:border-white/10 cursor-pointer group select-none active:scale-95"
        >
          <span>All Sports Hub</span>
          <ChevronRight size={15} className="group-hover:translate-x-0.5 transition-transform" />
        </button>
      </div>

      {/* Carousel Container with iOS 27 Glass Navigation Buttons */}
      <div className="relative group/carousel">
        {/* Left Arrow Button - Anchored Center */}
        <div 
          className={`absolute left-1 sm:left-3 md:left-6 z-30 hidden md:block transition-opacity duration-200 ${
            showLeftArrow ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
          }`}
          style={{ top: '50%', transform: 'translateY(-50%)' }}
        >
          <button 
            type="button"
            onClick={() => scroll('left')}
            aria-label="Scroll sports left"
            className="w-10 h-10 sm:w-11 sm:h-11 rounded-full bg-[#0d0d14]/85 hover:bg-[#181824]/95 text-white backdrop-blur-2xl border border-white/25 shadow-[0_10px_35px_rgba(0,0,0,0.8),0_0_15px_rgba(255,255,255,0.06)] flex items-center justify-center transition-all duration-200 hover:scale-105 active:scale-95 cursor-pointer ring-1 ring-white/10"
          >
            <ChevronLeft size={20} className="translate-x-[-1px]" />
          </button>
        </div>

        {/* Right Arrow Button - Anchored Center */}
        <div 
          className={`absolute right-1 sm:right-3 md:right-6 z-30 hidden md:block transition-opacity duration-200 ${
            showRightArrow ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
          }`}
          style={{ top: '50%', transform: 'translateY(-50%)' }}
        >
          <button 
            type="button"
            onClick={() => scroll('right')}
            aria-label="Scroll sports right"
            className="w-10 h-10 sm:w-11 sm:h-11 rounded-full bg-[#0d0d14]/85 hover:bg-[#181824]/95 text-white backdrop-blur-2xl border border-white/25 shadow-[0_10px_35px_rgba(0,0,0,0.8),0_0_15px_rgba(255,255,255,0.06)] flex items-center justify-center transition-all duration-200 hover:scale-105 active:scale-95 cursor-pointer ring-1 ring-white/10"
          >
            <ChevronRight size={20} className="translate-x-[1px]" />
          </button>
        </div>

        {/* Scrollable Container */}
        <div 
          ref={scrollRef}
          onScroll={handleScroll}
          className="flex gap-3 sm:gap-4 overflow-x-auto px-3.5 sm:px-6 md:px-12 pb-3 scroll-smooth no-scrollbar"
        >
          {loading ? (
            Array.from({ length: 4 }).map((_, idx) => (
              <div
                key={idx}
                className="w-72 sm:w-80 h-64 rounded-3xl bg-[#101017]/80 border border-white/5 animate-pulse shrink-0 p-4 flex flex-col justify-between"
              >
                <div className="h-32 w-full bg-white/10 rounded-2xl" />
                <div className="space-y-2 mt-3">
                  <div className="h-4 w-3/4 bg-white/10 rounded-full" />
                  <div className="h-3 w-1/2 bg-white/10 rounded-full" />
                </div>
              </div>
            ))
          ) : (
            matches.map((match) => {
              const timeInfo = formatMatchTime(match.date);
              const isLive = timeInfo.status === 'live';
              const posterUrl = getSportPosterUrl(match.poster, match.category);
              const sportName = match.category.replace(/-/g, ' ');
              const viewersCount = match.viewers || Math.floor(14000 + (match.id.charCodeAt(0) * 110) % 16000);

              return (
                <div
                  key={match.id}
                  onClick={() => setActiveMatch(match)}
                  className="group w-72 sm:w-80 bg-[#101017]/85 hover:bg-[#161622]/95 backdrop-blur-2xl border border-white/[0.08] hover:border-white/20 rounded-3xl overflow-hidden transition-all duration-300 cursor-pointer shrink-0 shadow-[0_10px_30px_rgba(0,0,0,0.5)] hover:shadow-[0_16px_45px_rgba(0,0,0,0.7)] flex flex-col justify-between select-none active:scale-[0.985]"
                >
                  {/* Proper Visible Image on Card */}
                  <div className="relative w-full aspect-[16/9] overflow-hidden bg-black/60">
                    <img
                      src={posterUrl}
                      alt={match.title}
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                      loading="lazy"
                      onError={(e) => {
                        const target = e.target as HTMLImageElement;
                        const fallback = SPORT_DEFAULT_IMAGES[match.category.toLowerCase()] || SPORT_DEFAULT_IMAGES.default;
                        if (target.src !== fallback) target.src = fallback;
                      }}
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-[#101017] via-transparent to-black/60" />

                    {/* Top Badges */}
                    <div className="absolute top-2.5 left-2.5 right-2.5 flex items-center justify-between gap-1 pointer-events-none">
                      <span className="px-2.5 py-0.5 rounded-full bg-black/70 backdrop-blur-md border border-white/15 text-white font-bold uppercase text-[10px] tracking-wider truncate max-w-[130px]">
                        {sportName}
                      </span>

                      {isLive ? (
                        <span className="flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-red-600/90 text-white font-black text-[10px] animate-pulse shadow-md">
                          <span className="w-1.5 h-1.5 rounded-full bg-white" />
                          LIVE
                        </span>
                      ) : (
                        <span className="flex items-center gap-1 text-amber-300 font-bold text-[10px] bg-black/70 px-2 py-0.5 rounded-full border border-white/10">
                          <Clock size={10} className="text-amber-400" />
                          <span>{timeInfo.istTime}</span>
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Card Content: Team & Event Name with Sport Name */}
                  <div className="p-4 flex-1 flex flex-col justify-between gap-2.5">
                    <div>
                      <span className="text-[10px] text-neutral-400 font-bold uppercase tracking-wider block mb-0.5">
                        {match.league || `${sportName} Match`}
                      </span>
                      <h3 className="text-sm sm:text-base font-black text-white group-hover:text-red-400 transition-colors line-clamp-2 tracking-tight">
                        {match.title}
                      </h3>
                      <p className="text-[11px] text-amber-300 font-semibold mt-1">
                        {isLive ? '🔴 Currently Live' : timeInfo.istTime}
                      </p>
                    </div>

                    {/* Footer: Live Viewers & Action */}
                    <div className="pt-2.5 border-t border-white/[0.06] flex items-center justify-between">
                      <div className="flex items-center gap-1.5 text-[11px] text-neutral-300 font-semibold">
                        <Eye size={12} className={isLive ? 'text-red-500 animate-pulse' : 'text-neutral-400'} />
                        <span>{viewersCount.toLocaleString()}</span>
                      </div>
                      <div className={`flex items-center gap-1 text-[11px] font-black px-3 py-1 rounded-full transition-colors ${
                        isLive ? 'bg-red-600 text-white shadow-md' : 'bg-white/10 text-white group-hover:bg-red-600'
                      }`}>
                        <Play size={10} className="fill-current" />
                        <span>{isLive ? 'Watch Live' : 'Open'}</span>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>

      {activeMatch && (
        <SportStreamModal
          match={activeMatch}
          onClose={() => setActiveMatch(null)}
        />
      )}
    </section>
  );
};

export default LiveSportsRow;
