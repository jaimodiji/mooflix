import React, { useState } from 'react';
import { X, Code, Check, ExternalLink, Copy, Film, Tv } from 'lucide-react';
import { ContentItem } from '../types';

interface EmbedShareModalProps {
  item?: ContentItem | null;
  season?: number;
  episode?: number;
  onClose: () => void;
}

export const EmbedShareModal: React.FC<EmbedShareModalProps> = ({
  item,
  season: initialSeason = 1,
  episode: initialEpisode = 1,
  onClose,
}) => {
  const [copiedUrl, setCopiedUrl] = useState<boolean>(false);
  const [copiedCode, setCopiedCode] = useState<boolean>(false);
  const [dimensionMode, setDimensionMode] = useState<'responsive' | '1080p' | '720p'>('responsive');

  // Media type state: if item is passed, use item.type; otherwise default to movie
  const initialType: 'movie' | 'tv' = item ? (item.type === 'tv' || item.type === 'series' ? 'tv' : 'movie') : 'movie';
  const [mediaType, setMediaType] = useState<'movie' | 'tv'>(initialType);

  // TMDB ID state with user-requested defaults: 969681 for movie, 66732 for TV
  const [movieId, setMovieId] = useState<string>(item && initialType === 'movie' ? String((item as any).tmdbId || item.id) : '969681');
  const [tvId, setTvId] = useState<string>(item && initialType === 'tv' ? String((item as any).tmdbId || item.id) : '66732');
  const [seasonNum, setSeasonNum] = useState<number>(initialSeason || 1);
  const [episodeNum, setEpisodeNum] = useState<number>(initialEpisode || 1);

  const origin = typeof window !== 'undefined' ? window.location.origin : 'https://mooflix.online';

  const currentId = mediaType === 'tv' ? (tvId.trim() || '66732') : (movieId.trim() || '969681');
  const embedUrl = mediaType === 'tv' 
    ? `${origin}/embed/tv/${currentId}/${seasonNum || 1}/${episodeNum || 1}`
    : `${origin}/embed/movie/${currentId}`;

  let iframeCode = `<iframe src="${embedUrl}" width="100%" height="100%" frameborder="0" allowfullscreen allow="autoplay; encrypted-media; fullscreen; picture-in-picture"></iframe>`;

  if (dimensionMode === '1080p') {
    iframeCode = `<iframe src="${embedUrl}" width="1920" height="1080" frameborder="0" allowfullscreen allow="autoplay; encrypted-media; fullscreen; picture-in-picture"></iframe>`;
  } else if (dimensionMode === '720p') {
    iframeCode = `<iframe src="${embedUrl}" width="1280" height="720" frameborder="0" allowfullscreen allow="autoplay; encrypted-media; fullscreen; picture-in-picture"></iframe>`;
  }

  const handleCopyUrl = () => {
    navigator.clipboard.writeText(embedUrl);
    setCopiedUrl(true);
    setTimeout(() => setCopiedUrl(false), 2200);
  };

  const handleCopyCode = () => {
    navigator.clipboard.writeText(iframeCode);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2200);
  };

  return (
    <div 
      className="fixed inset-0 z-[500] bg-black/85 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div 
        className="relative w-full max-w-xl bg-[#121217] border border-white/15 rounded-2xl p-5 sm:p-7 shadow-2xl overflow-hidden max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-white/10 mb-5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-red-600/20 border border-red-500/30 flex items-center justify-center text-red-500">
              <Code size={20} />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
                <span>MooFlix Player API</span>
                <span className="px-2 py-0.5 rounded-full bg-red-600/30 text-red-400 font-mono text-[10px] uppercase font-bold border border-red-500/30">
                  Universal Embed
                </span>
              </h2>
              <p className="text-xs text-neutral-400 truncate max-w-xs sm:max-w-sm">
                Embed movies & TV series directly on your website or application
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            aria-label="Close"
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 text-neutral-300 hover:text-white flex items-center justify-center transition-colors cursor-pointer"
          >
            <X size={16} />
          </button>
        </div>

        {/* Media Selector Tabs */}
        <div className="flex gap-2 p-1 bg-black/50 border border-white/10 rounded-xl mb-4">
          <button
            type="button"
            onClick={() => setMediaType('movie')}
            className={`flex-1 py-2 rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
              mediaType === 'movie'
                ? 'bg-red-600 text-white shadow-md'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            <Film size={14} />
            <span>Movie Embed</span>
          </button>
          <button
            type="button"
            onClick={() => setMediaType('tv')}
            className={`flex-1 py-2 rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
              mediaType === 'tv'
                ? 'bg-red-600 text-white shadow-md'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            <Tv size={14} />
            <span>TV Series Embed</span>
          </button>
        </div>

        {/* Input Parameters */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-4">
          <div className="sm:col-span-1">
            <label className="text-[11px] font-bold text-neutral-400 uppercase tracking-wider block mb-1">
              TMDB ID
            </label>
            <input
              type="text"
              value={mediaType === 'movie' ? movieId : tvId}
              onChange={(e) => {
                if (mediaType === 'movie') setMovieId(e.target.value);
                else setTvId(e.target.value);
              }}
              placeholder={mediaType === 'movie' ? '969681' : '66732'}
              className="w-full px-3 py-2 bg-black/60 border border-white/15 rounded-lg text-xs font-mono text-white focus:outline-none focus:border-red-500"
            />
          </div>

          {mediaType === 'tv' && (
            <>
              <div>
                <label className="text-[11px] font-bold text-neutral-400 uppercase tracking-wider block mb-1">
                  Season
                </label>
                <input
                  type="number"
                  min="1"
                  value={seasonNum}
                  onChange={(e) => setSeasonNum(Math.max(1, parseInt(e.target.value, 10) || 1))}
                  className="w-full px-3 py-2 bg-black/60 border border-white/15 rounded-lg text-xs font-mono text-white focus:outline-none focus:border-red-500"
                />
              </div>
              <div>
                <label className="text-[11px] font-bold text-neutral-400 uppercase tracking-wider block mb-1">
                  Episode
                </label>
                <input
                  type="number"
                  min="1"
                  value={episodeNum}
                  onChange={(e) => setEpisodeNum(Math.max(1, parseInt(e.target.value, 10) || 1))}
                  className="w-full px-3 py-2 bg-black/60 border border-white/15 rounded-lg text-xs font-mono text-white focus:outline-none focus:border-red-500"
                />
              </div>
            </>
          )}
        </div>

        {/* Content Body */}
        <div className="space-y-4">
          {/* Direct API Embed URL */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-bold text-neutral-300 uppercase tracking-wider">
                Direct Player API URL
              </label>
              <a
                href={embedUrl}
                target="_blank"
                rel="noreferrer"
                className="text-[11px] text-red-400 hover:text-red-300 flex items-center gap-1 font-semibold transition-colors"
              >
                <span>Preview</span>
                <ExternalLink size={12} />
              </a>
            </div>
            <div className="flex items-center gap-2">
              <input
                type="text"
                readOnly
                value={embedUrl}
                className="w-full px-3.5 py-2.5 bg-black/70 border border-white/15 rounded-xl text-xs font-mono text-neutral-200 select-all focus:outline-none focus:border-red-500"
              />
              <button
                type="button"
                onClick={handleCopyUrl}
                className="px-3.5 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 active:scale-95 text-white font-bold text-xs flex items-center gap-1.5 transition-all cursor-pointer shrink-0"
              >
                {copiedUrl ? <Check size={14} className="text-emerald-400" /> : <Copy size={14} />}
                <span>{copiedUrl ? 'Copied' : 'Copy'}</span>
              </button>
            </div>
          </div>

          {/* Dimension Presets */}
          <div>
            <label className="text-xs font-bold text-neutral-300 uppercase tracking-wider block mb-1.5">
              Embed Dimension Preset
            </label>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => setDimensionMode('responsive')}
                className={`py-2 px-3 rounded-lg text-xs font-semibold border transition-all cursor-pointer ${
                  dimensionMode === 'responsive'
                    ? 'bg-red-600 text-white border-red-500 shadow-md shadow-red-950/40'
                    : 'bg-black/50 text-neutral-300 border-white/10 hover:bg-white/10'
                }`}
              >
                Responsive (100%)
              </button>
              <button
                type="button"
                onClick={() => setDimensionMode('1080p')}
                className={`py-2 px-3 rounded-lg text-xs font-semibold border transition-all cursor-pointer ${
                  dimensionMode === '1080p'
                    ? 'bg-red-600 text-white border-red-500 shadow-md shadow-red-950/40'
                    : 'bg-black/50 text-neutral-300 border-white/10 hover:bg-white/10'
                }`}
              >
                1080p (Full HD)
              </button>
              <button
                type="button"
                onClick={() => setDimensionMode('720p')}
                className={`py-2 px-3 rounded-lg text-xs font-semibold border transition-all cursor-pointer ${
                  dimensionMode === '720p'
                    ? 'bg-red-600 text-white border-red-500 shadow-md shadow-red-950/40'
                    : 'bg-black/50 text-neutral-300 border-white/10 hover:bg-white/10'
                }`}
              >
                720p (HD)
              </button>
            </div>
          </div>

          {/* Ready-to-use HTML Iframe Code */}
          <div>
            <label className="text-xs font-bold text-neutral-300 uppercase tracking-wider block mb-1.5">
              Ready-to-use HTML Iframe Code
            </label>
            <textarea
              rows={3}
              readOnly
              value={iframeCode}
              className="w-full px-3.5 py-2.5 bg-black/70 border border-white/15 rounded-xl text-xs font-mono text-neutral-200 resize-none select-all focus:outline-none focus:border-red-500"
            />
          </div>

          {/* API Endpoints Documentation */}
          <div className="bg-black/40 border border-white/10 rounded-xl p-3 text-xs text-neutral-400 space-y-1.5 font-mono">
            <div className="font-semibold text-neutral-300 font-sans">Ad-Free Auto-Failover Player API Formats:</div>
            <div className="text-[11px] text-neutral-300 bg-white/5 p-1.5 rounded">
              <span className="text-red-400 font-bold">Movie:</span> {origin}/embed/movie/:tmdb_or_imdb_id
            </div>
            <div className="text-[11px] text-neutral-300 bg-white/5 p-1.5 rounded">
              <span className="text-red-400 font-bold">Series:</span> {origin}/embed/series/:tmdb_or_imdb_id/:season/:episode (or /embed/tv/...)
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="flex items-center justify-end gap-3 mt-5 pt-4 border-t border-white/10">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl text-xs font-bold text-neutral-400 hover:text-white transition-colors cursor-pointer"
          >
            Close
          </button>
          <button
            type="button"
            onClick={handleCopyCode}
            className="px-6 py-2.5 rounded-xl bg-red-600 hover:bg-red-700 active:scale-95 text-white font-bold text-xs sm:text-sm flex items-center gap-2 shadow-lg shadow-red-950/60 transition-all cursor-pointer"
          >
            {copiedCode ? <Check size={16} /> : <Code size={16} />}
            <span>{copiedCode ? 'Iframe Code Copied!' : 'Copy Iframe Code'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default EmbedShareModal;
