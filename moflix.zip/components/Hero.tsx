import React, { useState, useEffect, useRef } from 'react';
import { Play, Info, Plus, Check, Volume2, VolumeX } from 'lucide-react';
import { ContentItem } from '../types';
import { fetchTrailerKey } from '../services/tmdbService';

interface HeroProps {
  item: ContentItem;
  logoUrl?: string | null;
  customLogoUrl?: string | null;
  imdbId?: string | null;
  onWatch: (target: any) => void;
  onDetails?: (item: ContentItem) => void;
  onInfo?: (item: ContentItem) => void;
  onDownload?: (item: ContentItem) => void;
}

export const Hero: React.FC<HeroProps> = ({ 
  item, 
  onWatch,
  onDetails,
  onInfo, 
  onDownload,
}) => {
  const [isInWatchLater, setIsInWatchLater] = useState(false);
  const [trailerKey, setTrailerKey] = useState<string | null>(null);
  const [isTrailerLoaded, setIsTrailerLoaded] = useState(false);
  const [isMuted, setIsMuted] = useState(true);
  const iframeRef = useRef<HTMLIFrameElement>(null);

  if (!item) return null;

  // Sync Watch Later status from localStorage
  useEffect(() => {
    try {
      const list = JSON.parse(localStorage.getItem('moflix_watchlist') || '[]');
      setIsInWatchLater(list.some((i: any) => String(i.id) === String(item.id)));
    } catch {
      setIsInWatchLater(false);
    }
  }, [item.id]);

  // Fetch Trailer Key for background playback
  useEffect(() => {
    let isCurrent = true;
    setIsTrailerLoaded(false);
    setTrailerKey(null);

    const loadTrailer = async () => {
      try {
        const key = await fetchTrailerKey(item.tmdbId || item.id, item.type);
        if (isCurrent && key) {
          // Slight delay to allow backdrop image to render smoothly first
          setTimeout(() => {
            if (isCurrent) {
              setTrailerKey(key);
            }
          }, 800);
        }
      } catch (err) {
        console.warn('Hero trailer fetch failed:', err);
      }
    };

    loadTrailer();

    return () => {
      isCurrent = false;
    };
  }, [item.id, item.tmdbId, item.type]);

  const toggleMute = () => {
    const nextMuted = !isMuted;
    setIsMuted(nextMuted);
    if (iframeRef.current && iframeRef.current.contentWindow) {
      const command = nextMuted ? 'mute' : 'unMute';
      iframeRef.current.contentWindow.postMessage(
        JSON.stringify({ event: 'command', func: command, args: [] }),
        '*'
      );
    }
  };

  const handlePlayClick = () => {
    onWatch(item);
  };

  const handleDetailsClick = () => {
    if (onDetails) {
      onDetails(item);
    } else if (onInfo) {
      onInfo(item);
    }
  };

  const toggleWatchLater = () => {
    try {
      const list = JSON.parse(localStorage.getItem('moflix_watchlist') || '[]');
      const exists = list.some((i: any) => String(i.id) === String(item.id));
      let updated;
      if (exists) {
        updated = list.filter((i: any) => String(i.id) !== String(item.id));
        setIsInWatchLater(false);
      } else {
        updated = [item, ...list];
        setIsInWatchLater(true);
      }
      localStorage.setItem('moflix_watchlist', JSON.stringify(updated));
      window.dispatchEvent(new Event('storage'));
    } catch (e) {
      console.warn('Failed to update watch later:', e);
    }
  };

  const posterImage = item.thumbnail || item.poster || item.backdrop;

  return (
    <div className="relative w-full h-[52vh] sm:h-[62vh] md:h-[72vh] lg:h-[80vh] min-h-[420px] sm:min-h-[480px] max-h-[760px] overflow-hidden bg-[#0a0a0a] select-none">
      {/* Background Stage: Trailer Video or Cinematic Backdrop */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {/* Fallback & Initial High-Res Backdrop Image */}
        {item.backdrop ? (
          <img 
            key={item.id}
            src={item.backdrop} 
            alt={item.title} 
            className="w-full h-full object-cover object-top sm:object-center brightness-[0.65] sm:brightness-[0.70] scale-[1.01] transition-transform duration-1000" 
            referrerPolicy="no-referrer"
          />
        ) : (
          <div className="w-full h-full bg-[#111111]" />
        )}

        {/* Background YouTube Trailer Video Player (Autoplay Muted Loop) */}
        {trailerKey && (
          <div className={`absolute inset-0 transition-opacity duration-1000 ${isTrailerLoaded ? 'opacity-85' : 'opacity-0'}`}>
            <iframe
              ref={iframeRef}
              src={`https://www.youtube-nocookie.com/embed/${trailerKey}?autoplay=1&mute=1&controls=0&loop=1&playlist=${trailerKey}&playsinline=1&enablejsapi=1&disablekb=1&modestbranding=1&iv_load_policy=3&rel=0`}
              title={`${item.title} Trailer`}
              allow="autoplay; encrypted-media"
              onLoad={() => setIsTrailerLoaded(true)}
              className="w-[120%] h-[120%] -top-[10%] -left-[10%] absolute object-cover border-0 pointer-events-none scale-105"
            />
          </div>
        )}
        
        {/* Seamless Smooth Dark Gradients for Text Legibility */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#0a0a0a] via-[#0a0a0a]/50 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-r from-[#0a0a0a]/95 via-[#0a0a0a]/50 to-transparent" />
      </div>

      {/* Content Area - Clean, Mobile-Optimized, No Overlaps */}
      <div className="relative z-10 flex flex-col justify-end h-full max-w-[1800px] mx-auto px-4 sm:px-6 md:px-12 pb-6 sm:pb-10 md:pb-14">
        <div className="max-w-xl lg:max-w-2xl">
          
          {/* Foreground Mini Poster Card + Title & Badges */}
          <div className="flex items-center gap-3 sm:gap-4 md:gap-5 mb-2.5 sm:mb-3">
            {/* Small Poster Card (Replaces the logo) */}
            {posterImage && (
              <div 
                onClick={handleDetailsClick}
                className="w-14 sm:w-18 md:w-22 aspect-[2/3] rounded-xl overflow-hidden border border-white/25 shadow-[0_12px_28px_rgba(0,0,0,0.95)] bg-neutral-900 flex-shrink-0 cursor-pointer group hover:scale-105 hover:border-red-500/60 transition-all duration-300"
                title="View details"
              >
                <img 
                  src={posterImage} 
                  alt={item.title} 
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  referrerPolicy="no-referrer"
                  loading="eager"
                />
              </div>
            )}

            {/* Title & Metadata Badges */}
            <div className="flex-1 min-w-0">
              <h1 className="text-lg sm:text-2xl md:text-3xl lg:text-4xl font-black text-white tracking-tight leading-snug drop-shadow-[0_4px_16px_rgba(0,0,0,0.9)] line-clamp-2">
                {item.title}
              </h1>

              {/* Minimal Clean Metadata Badges */}
              <div className="flex flex-wrap items-center gap-1.5 sm:gap-2 text-xs font-semibold text-neutral-300 mt-1.5 sm:mt-2">
                {item.year > 0 && (
                  <span className="px-2 py-0.5 rounded-md bg-white/10 text-neutral-200 border border-white/10 text-[10px] sm:text-xs">
                    {item.year}
                  </span>
                )}
                <span className="px-2 py-0.5 rounded-md bg-white/10 text-neutral-200 border border-white/10 text-[10px] sm:text-xs capitalize">
                  {item.type === 'movie' ? 'Movie' : 'TV Series'}
                </span>
                {item.rating && (
                  <span className="flex items-center gap-1 text-amber-400 font-bold text-[11px] sm:text-xs">
                    <span>★</span>
                    <span>{item.rating}</span>
                  </span>
                )}
              </div>
            </div>
          </div>

          {/* Clean Synopsis */}
          <p className="text-neutral-300/90 text-xs sm:text-sm md:text-base mb-3.5 sm:mb-5 line-clamp-2 sm:line-clamp-3 leading-relaxed font-normal max-w-lg drop-shadow-md">
            {item.description}
          </p>
          
          {/* Action Buttons Row: Naturally Flows Without Overlap */}
          <div className="flex flex-wrap items-center gap-2 sm:gap-3">
            {/* 1. Play Button */}
            <button 
              type="button"
              onClick={handlePlayClick}
              className="px-4 sm:px-6 py-2 sm:py-2.5 bg-red-600 hover:bg-red-500 active:scale-95 text-white rounded-full font-bold text-xs sm:text-sm transition-all duration-200 flex items-center gap-1.5 sm:gap-2 shadow-xl shadow-red-600/40 cursor-pointer"
            >
              <Play size={15} className="fill-white shrink-0" />
              <span>Play</span>
            </button>

            {/* 2. Details Button */}
            <button 
              type="button"
              onClick={handleDetailsClick}
              className="px-4 sm:px-6 py-2 sm:py-2.5 bg-white/15 hover:bg-white/25 active:scale-95 text-white rounded-full font-bold text-xs sm:text-sm transition-all duration-200 flex items-center gap-1.5 sm:gap-2 backdrop-blur-md border border-white/20 shadow-lg cursor-pointer"
            >
              <Info size={15} className="shrink-0" />
              <span>Details</span>
            </button>
            
            {/* 5. Watch Later '+' Button */}
            <button 
              type="button"
              onClick={toggleWatchLater}
              title={isInWatchLater ? "Added to Watchlist (Click to remove)" : "Add to Watchlist (+)"}
              aria-label={isInWatchLater ? "Remove from Watchlist" : "Add to Watchlist"}
              className={`w-8 h-8 sm:w-10 sm:h-10 rounded-full font-bold transition-all duration-200 flex items-center justify-center backdrop-blur-md border active:scale-95 cursor-pointer shadow-lg shrink-0 ${
                isInWatchLater
                  ? 'bg-red-600 border-red-500 text-white shadow-red-900/40'
                  : 'bg-white/10 hover:bg-white/20 text-white border-white/20 hover:border-white/40'
              }`}
            >
              {isInWatchLater ? (
                <Check size={15} className="text-white" />
              ) : (
                <Plus size={16} className="text-white" />
              )}
            </button>

            {/* 4. Safe Inline Trailer Mute / Unmute Button (Never Overlaps) */}
            {trailerKey && isTrailerLoaded && (
              <button
                type="button"
                onClick={toggleMute}
                className={`w-8 h-8 sm:w-10 sm:h-10 rounded-full font-bold transition-all duration-200 flex items-center justify-center backdrop-blur-md border active:scale-95 cursor-pointer shadow-lg shrink-0 ${
                  isMuted
                    ? 'bg-black/60 hover:bg-black/80 text-white/80 border-white/20'
                    : 'bg-red-600/90 hover:bg-red-600 border-red-500 text-white shadow-red-900/40'
                }`}
                title={isMuted ? "Unmute trailer audio" : "Mute trailer audio"}
                aria-label={isMuted ? "Unmute trailer audio" : "Mute trailer audio"}
              >
                {isMuted ? <VolumeX size={15} /> : <Volume2 size={15} className="animate-pulse" />}
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Hero;
