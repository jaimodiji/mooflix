import React, { useState, useEffect, useRef } from 'react';
import { Search, X, ArrowLeft, Loader2, Clock, Trash2, Film, Globe, ExternalLink, Star, Play, Flame, Mic, MicOff } from 'lucide-react';
import { ContentItem } from '../types';
import { searchContentDetailed, SearchResultWithMeta, PersonResult, fetchPersonFilmography, searchByExactTitleAndYear, fetchTrendingMovies } from '../services/tmdbService';
import MovieCard from './MovieCard';
import { MovieGridSkeleton } from './Skeletons';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onItemClick: (item: ContentItem) => void;
}

interface GroundingEntity {
  exactTitle: string;
  year?: string | null;
  type?: 'movie' | 'series' | 'star' | null;
  directorOrStar?: string | null;
}

interface GroundingData {
  summary: string | null;
  sources: { title: string; url: string }[];
  entity?: GroundingEntity | null;
}

const RECENT_SEARCHES_STORAGE_KEY = 'mooflix_recent_searches';
const MAX_RECENT_SEARCHES = 8;

const SearchModal: React.FC<SearchModalProps> = ({ isOpen, onClose, onItemClick }) => {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<ContentItem[]>([]);
  const [trendingMovies, setTrendingMovies] = useState<ContentItem[]>([]);
  const [searchMeta, setSearchMeta] = useState<SearchResultWithMeta | null>(null);
  const [selectedStar, setSelectedStar] = useState<PersonResult | null>(null);
  const [googleMatchedItem, setGoogleMatchedItem] = useState<ContentItem | null>(null);
  const [loading, setLoading] = useState(false);
  const [starLoading, setStarLoading] = useState(false);
  const [groundingData, setGroundingData] = useState<GroundingData | null>(null);
  const [groundingLoading, setGroundingLoading] = useState(false);
  const [recentSearches, setRecentSearches] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem(RECENT_SEARCHES_STORAGE_KEY);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const inputRef = useRef<HTMLInputElement>(null);
  const [isListening, setIsListening] = useState(false);
  const [voiceNotice, setVoiceNotice] = useState<string | null>(null);
  const recognitionRef = useRef<any>(null);

  const toggleVoiceSearch = () => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      setVoiceNotice('Voice search is not supported on this browser.');
      setTimeout(() => setVoiceNotice(null), 3000);
      return;
    }

    if (isListening) {
      recognitionRef.current?.stop();
      setIsListening(false);
      return;
    }

    try {
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = true;
      recognition.lang = navigator.language || 'en-US';

      recognition.onstart = () => {
        setIsListening(true);
        setVoiceNotice('Listening... speak movie or actor name');
      };

      recognition.onresult = (event: any) => {
        const transcript = Array.from(event.results)
          .map((res: any) => res[0].transcript)
          .join('');
        setQuery(transcript);
        if (event.results[0]?.isFinal) {
          saveRecentSearch(transcript.trim());
        }
      };

      recognition.onerror = (event: any) => {
        if (event.error !== 'no-speech') {
          setVoiceNotice('Microphone permission denied or audio error.');
          setTimeout(() => setVoiceNotice(null), 3000);
        }
        setIsListening(false);
      };

      recognition.onend = () => {
        setIsListening(false);
        setVoiceNotice(null);
      };

      recognitionRef.current = recognition;
      recognition.start();
    } catch (e) {
      console.error('Failed to start voice recognition:', e);
      setIsListening(false);
    }
  };

  useEffect(() => {
    return () => {
      if (recognitionRef.current) {
        try { recognitionRef.current.stop(); } catch {}
      }
    };
  }, []);

  // Save recent search query to localStorage
  const saveRecentSearch = (searchQuery: string) => {
    const trimmed = searchQuery.trim();
    if (!trimmed) return;

    setRecentSearches((prev) => {
      const filtered = prev.filter((item) => item.toLowerCase() !== trimmed.toLowerCase());
      const updated = [trimmed, ...filtered].slice(0, MAX_RECENT_SEARCHES);
      try {
        localStorage.setItem(RECENT_SEARCHES_STORAGE_KEY, JSON.stringify(updated));
      } catch (err) {
        console.error('Failed to save recent search:', err);
      }
      return updated;
    });
  };

  const removeRecentSearch = (e: React.MouseEvent, itemToRemove: string) => {
    e.stopPropagation();
    setRecentSearches((prev) => {
      const updated = prev.filter((item) => item !== itemToRemove);
      try {
        localStorage.setItem(RECENT_SEARCHES_STORAGE_KEY, JSON.stringify(updated));
      } catch (err) {
        console.error('Failed to remove recent search:', err);
      }
      return updated;
    });
  };

  const clearAllRecentSearches = () => {
    setRecentSearches([]);
    try {
      localStorage.removeItem(RECENT_SEARCHES_STORAGE_KEY);
    } catch (err) {
      console.error('Failed to clear recent searches:', err);
    }
  };

  useEffect(() => {
    if (isOpen) {
      const searchParams = new URLSearchParams(window.location.search);
      const urlQ = searchParams.get('q');
      if (urlQ && !query) {
        setQuery(urlQ);
      }
      if (trendingMovies.length === 0) {
        fetchTrendingMovies(1)
          .then((items) => {
            if (items && items.length > 0) setTrendingMovies(items.slice(0, 18));
          })
          .catch(() => {});
      }
      setTimeout(() => {
        inputRef.current?.focus();
      }, 100);
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
      setQuery('');
      setResults([]);
      setSearchMeta(null);
      setSelectedStar(null);
      setGoogleMatchedItem(null);
      setGroundingData(null);
      setGroundingLoading(false);
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [isOpen]);

  // Main search effect
  useEffect(() => {
    if (!query.trim()) {
      if (isOpen && window.location.pathname === '/search') {
        window.history.replaceState({ root: 'moflix_app', overlay: 'search' }, '', '/search');
      }
      setResults([]);
      setSearchMeta(null);
      setSelectedStar(null);
      setGoogleMatchedItem(null);
      setGroundingData(null);
      setGroundingLoading(false);
      return;
    }

    const trimmed = query.trim();
    if (isOpen) {
      window.history.replaceState({ root: 'moflix_app', overlay: 'search', q: trimmed }, '', `/search?q=${encodeURIComponent(trimmed)}`);
    }

    // 1. Fetch TMDB Results across all content
    const tmdbTimer = setTimeout(async () => {
      setLoading(true);
      try {
        const res = await searchContentDetailed(trimmed, 1, 'all');
        setResults(res.items);
        setSearchMeta(res);
      } catch (err) {
        console.error('Search failed:', err);
      } finally {
        setLoading(false);
      }
    }, 280);

    // 2. Fetch Google Real-Time Search Grounding Data via backend API
    const abortController = new AbortController();
    const groundingTimer = setTimeout(async () => {
      if (trimmed.length < 2) {
        setGroundingData(null);
        setGoogleMatchedItem(null);
        setGroundingLoading(false);
        return;
      }
      setGroundingLoading(true);
      try {
        const res = await fetch('/api/search-grounding', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ query: trimmed, category: 'all' }),
          signal: abortController.signal,
        });
        if (res.ok) {
          const data = await res.json();
          if (data && (data.summary || data.entity)) {
            setGroundingData(data);

            if (data.entity && data.entity.exactTitle) {
              try {
                const liveMatch = await searchByExactTitleAndYear(
                  data.entity.exactTitle,
                  data.entity.year,
                  data.entity.type
                );
                if (liveMatch) {
                  setGoogleMatchedItem(liveMatch);
                  setResults((prev) => {
                    const alreadyTop = prev[0]?.id === liveMatch.id;
                    if (alreadyTop) return prev;
                    const others = prev.filter((p) => p.id !== liveMatch.id);
                    return [
                      {
                        ...liveMatch,
                        badge: `Google Live Match`,
                        badgeType: 'trending' as any,
                      },
                      ...others,
                    ];
                  });
                }
              } catch (matchErr) {
                console.warn('Real-time TMDB lookup failed:', matchErr);
              }
            }
          } else {
            setGroundingData(null);
            setGoogleMatchedItem(null);
          }
        } else {
          setGroundingData(null);
          setGoogleMatchedItem(null);
        }
      } catch (err: any) {
        if (err?.name !== 'AbortError') {
          console.warn('Grounding fetch error:', err);
          setGroundingData(null);
          setGoogleMatchedItem(null);
        }
      } finally {
        if (!abortController.signal.aborted) {
          setGroundingLoading(false);
        }
      }
    }, 450);

    return () => {
      clearTimeout(tmdbTimer);
      clearTimeout(groundingTimer);
      abortController.abort();
    };
  }, [query]);

  // Click on a star / celebrity to view their full filmography
  const handleStarClick = async (person: PersonResult) => {
    setSelectedStar(person);
    setStarLoading(true);
    try {
      const filmography = await fetchPersonFilmography(person.id, person.name);
      setResults(filmography);
      setSearchMeta((prev) => ({
        ...prev,
        items: filmography,
        metaNotice: `Showing complete filmography of ${person.name}`,
        matchedPerson: person.name,
      }));

      try {
        const gRes = await fetch('/api/search-grounding', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ query: person.name, category: 'star' }),
        });
        if (gRes.ok) {
          const gData = await gRes.json();
          if (gData && gData.summary) {
            setGroundingData(gData);
          }
        }
      } catch {}
    } catch (e) {
      console.error('Failed to load star filmography:', e);
    } finally {
      setStarLoading(false);
    }
  };

  const starsList = searchMeta?.people || [];

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[190] bg-[#0a0a0a] flex flex-col animate-in fade-in duration-200">
      {/* Search Header Bar */}
      <div className="sticky top-0 z-20 bg-[#0a0a0a]/95 backdrop-blur-xl border-b border-white/[0.08] px-3 sm:px-6 md:px-12 py-3.5">
        <div className="max-w-4xl mx-auto flex items-center gap-2.5 sm:gap-3">
          <button
            onClick={onClose}
            aria-label="Back"
            className="w-10 h-10 rounded-full bg-white/5 hover:bg-white/10 text-neutral-300 hover:text-white flex items-center justify-center transition-colors cursor-pointer shrink-0"
          >
            <ArrowLeft size={20} />
          </button>

          <div className="relative flex-1 flex items-center">
            <Search size={18} className="absolute left-3.5 text-neutral-400 pointer-events-none" />
            <input
              ref={inputRef}
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && query.trim()) {
                  saveRecentSearch(query.trim());
                }
              }}
              placeholder={isListening ? "Listening... speak now" : "Search movies, TV shows, anime, stars..."}
              className={`w-full bg-[#161616] border ${
                isListening ? 'border-red-500 bg-red-950/20' : 'border-white/15 focus:border-[#e50914]/80 focus:bg-[#1a1a1a]'
              } text-white text-sm sm:text-base pl-10 pr-20 py-2.5 rounded-full outline-none transition-all placeholder:text-neutral-500 shadow-inner`}
            />

            <div className="absolute right-2.5 flex items-center gap-1.5">
              {query && (
                <button
                  type="button"
                  onClick={() => {
                    setQuery('');
                    setSearchMeta(null);
                    setSelectedStar(null);
                    inputRef.current?.focus();
                  }}
                  aria-label="Clear search"
                  className="w-6 h-6 rounded-full bg-white/10 hover:bg-white/20 text-neutral-300 hover:text-white flex items-center justify-center transition-colors cursor-pointer"
                >
                  <X size={14} />
                </button>
              )}

              {/* Voice Search Microphone Button */}
              <button
                type="button"
                onClick={toggleVoiceSearch}
                aria-label={isListening ? "Stop listening" : "Search by voice"}
                title={isListening ? "Listening... Click to stop" : "Speak to search"}
                className={`w-8 h-8 rounded-full flex items-center justify-center transition-all cursor-pointer ${
                  isListening
                    ? 'bg-red-600 text-white animate-pulse shadow-[0_0_15px_rgba(239,68,68,0.8)] scale-105'
                    : 'bg-white/5 hover:bg-white/15 text-neutral-300 hover:text-white'
                }`}
              >
                {isListening ? <MicOff size={16} /> : <Mic size={16} />}
              </button>
            </div>

            {/* Listening / Voice Feedback Pill */}
            {voiceNotice && (
              <div className="absolute -bottom-8 left-4 flex items-center gap-2 px-3 py-1 rounded-full bg-red-600/90 text-white text-[11px] font-bold shadow-lg animate-in fade-in duration-150 z-30">
                <span className="w-2 h-2 rounded-full bg-white animate-ping" />
                <span>{voiceNotice}</span>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Content Area */}
      <div className="flex-1 overflow-y-auto px-4 md:px-12 py-6">
        <div className="max-w-[1800px] mx-auto">
          {/* If no query, show recent searches + trending movies grid */}
          {!query.trim() && (
            <div className="w-full max-w-7xl mx-auto py-4 text-center">
              {/* Recent Searches Section */}
              {recentSearches.length > 0 && (
                <div className="mb-8 text-left bg-[#141414] border border-white/10 rounded-2xl p-4 sm:p-5">
                  <div className="flex items-center justify-between mb-3 pb-2 border-b border-white/[0.06]">
                    <div className="flex items-center gap-2 text-white text-xs sm:text-sm font-semibold">
                      <Clock size={15} className="text-[#e50914]" />
                      <span>Recent Searches</span>
                    </div>
                    <button
                      onClick={clearAllRecentSearches}
                      className="flex items-center gap-1 text-[11px] text-neutral-400 hover:text-red-400 transition-colors cursor-pointer font-medium"
                    >
                      <Trash2 size={12} />
                      <span>Clear All</span>
                    </button>
                  </div>

                  <div className="flex flex-wrap gap-2">
                    {recentSearches.map((item) => (
                      <div
                        key={item}
                        onClick={() => {
                          setQuery(item);
                          saveRecentSearch(item);
                        }}
                        className="group flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-[#1e1e1e] hover:bg-[#282828] border border-white/10 hover:border-white/20 text-neutral-200 text-xs font-medium cursor-pointer transition-colors"
                      >
                        <Clock size={12} className="text-neutral-500 group-hover:text-neutral-300" />
                        <span className="truncate max-w-[180px]">{item}</span>
                        <button
                          type="button"
                          onClick={(e) => removeRecentSearch(e, item)}
                          aria-label={`Remove ${item}`}
                          className="ml-0.5 w-4 h-4 rounded-full flex items-center justify-center text-neutral-500 hover:text-white hover:bg-white/20 transition-colors cursor-pointer"
                        >
                          <X size={10} />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Trending Movies Grid in Search Page (Replaces old keyboard tags) */}
              <div className="w-full text-left mt-4 mb-16">
                <div className="flex items-center gap-2 mb-4 pb-2 border-b border-white/[0.08]">
                  <Flame size={18} className="text-[#e50914]" />
                  <h3 className="text-sm sm:text-base font-bold text-white tracking-wide">
                    Trending Movies &amp; Shows
                  </h3>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3 md:gap-4">
                  {trendingMovies.map((item, idx) => (
                    <MovieCard
                      key={`search-trending-${item.id}-${idx}`}
                      item={item}
                      onClick={(clickedItem) => {
                        onItemClick(clickedItem);
                      }}
                    />
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Results Area when query is active */}
          {query.trim() && (
            <div>
              {/* 1. REAL-TIME GOOGLE SEARCH OVERVIEW CARD */}
              {(groundingLoading || (groundingData && groundingData.summary)) && (
                <div className="mb-6 rounded-2xl bg-[#111319] border border-blue-500/25 p-4 sm:p-5 shadow-2xl relative overflow-hidden transition-all">
                  <div className="absolute top-0 left-0 right-0 h-[3px] bg-gradient-to-r from-[#4285F4] via-[#EA4335] via-[#FBBC05] to-[#34A853]" />

                  <div className="flex items-center justify-between gap-3 mb-3">
                    <div className="flex items-center gap-2.5">
                      <div className="w-7 h-7 rounded-lg bg-white/10 flex items-center justify-center p-1.5 border border-white/15 shrink-0">
                        <svg className="w-full h-full" viewBox="0 0 24 24">
                          <path fill="#4285F4" d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.665-5.17 3.665-9.17Z" />
                          <path fill="#34A853" d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.25v3.15C3.26 21.36 7.33 24 12 24Z" />
                          <path fill="#FBBC05" d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.13-1.55.38-2.27V6.58H1.25C.45 8.18 0 9.98 0 12s.45 3.82 1.25 5.42l4.03-3.15Z" />
                          <path fill="#EA4335" d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.33 0 3.26 2.64 1.25 6.58l4.03 3.15c.95-2.83 3.6-4.98 6.72-4.98Z" />
                        </svg>
                      </div>
                      <div>
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="text-xs sm:text-sm font-bold text-white tracking-wide">
                            Google Live Overview
                          </span>
                          <span className="px-2 py-0.5 rounded-full bg-blue-500/15 border border-blue-500/30 text-[10px] text-blue-300 font-semibold flex items-center gap-1.5">
                            <span className="w-1.5 h-1.5 rounded-full bg-blue-400 animate-pulse" />
                            Real-Time Search Grounding
                          </span>
                        </div>
                        <p className="text-[11px] text-neutral-400">Live search summary & verified web info</p>
                      </div>
                    </div>

                    {groundingLoading && (
                      <div className="flex items-center gap-1.5 text-xs text-blue-300/90 shrink-0 bg-blue-950/40 px-2.5 py-1 rounded-full border border-blue-500/20">
                        <Loader2 size={12} className="animate-spin text-blue-400" />
                        <span className="text-[11px] font-medium hidden sm:inline">Fetching Google data...</span>
                      </div>
                    )}
                  </div>

                  {groundingLoading ? (
                    <div className="space-y-2 py-2 animate-pulse">
                      <div className="h-3.5 bg-white/10 rounded w-full sm:w-11/12" />
                      <div className="h-3.5 bg-white/10 rounded w-4/5" />
                    </div>
                  ) : (
                    groundingData?.summary && (
                      <div>
                        <p className="text-neutral-200 text-xs sm:text-sm leading-relaxed font-normal">
                          {groundingData.summary}
                        </p>

                        {groundingData.sources && groundingData.sources.length > 0 && (
                          <div className="mt-3.5 pt-2.5 border-t border-white/[0.08] flex items-center flex-wrap gap-2">
                            <span className="text-[10px] uppercase font-bold tracking-wider text-neutral-400">
                              Verified Sources:
                            </span>
                            {groundingData.sources.map((src, idx) => (
                              <a
                                key={idx}
                                href={src.url}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md bg-white/5 hover:bg-white/10 border border-white/10 hover:border-blue-400/40 text-[11px] text-neutral-300 hover:text-white transition-all cursor-pointer group"
                                title={src.title}
                              >
                                <Globe size={11} className="text-neutral-400 group-hover:text-blue-400" />
                                <span className="truncate max-w-[130px] sm:max-w-[220px]">{src.title}</span>
                                <ExternalLink size={10} className="text-neutral-500 group-hover:text-white shrink-0" />
                              </a>
                            ))}
                          </div>
                        )}

                        {groundingData?.entity?.exactTitle && (
                          <div className="mt-4 pt-3.5 border-t border-blue-500/25 bg-blue-950/30 -mx-4 -mb-4 sm:-mx-5 sm:-mb-5 p-3.5 sm:p-4 rounded-b-2xl flex items-center justify-between flex-wrap gap-3">
                            <div className="flex items-center gap-3 min-w-0">
                              {googleMatchedItem?.posterPath ? (
                                <img
                                  src={googleMatchedItem.posterPath}
                                  alt={groundingData.entity.exactTitle}
                                  className="w-10 h-14 object-cover rounded-lg shadow-md border border-white/20 shrink-0"
                                />
                              ) : (
                                <div className="w-10 h-10 rounded-lg bg-red-600 flex items-center justify-center shrink-0 shadow-lg shadow-red-950/50">
                                  <Film size={18} className="text-white" />
                                </div>
                              )}
                              <div className="min-w-0">
                                <div className="flex items-center gap-1.5 flex-wrap">
                                  <span className="text-[10px] uppercase font-bold text-blue-400 tracking-wider">
                                    Google Live Match:
                                  </span>
                                  <span className="text-xs sm:text-sm font-bold text-white truncate">
                                    {groundingData.entity.exactTitle} {groundingData.entity.year ? `(${groundingData.entity.year})` : ''}
                                  </span>
                                </div>
                                <p className="text-[11px] text-neutral-300 truncate">
                                  {groundingData.entity.directorOrStar ? `By / Starring: ${groundingData.entity.directorOrStar}` : 'Direct match from Google Real-Time Data'}
                                </p>
                              </div>
                            </div>

                            <div className="flex items-center gap-2">
                              {googleMatchedItem ? (
                                <button
                                  type="button"
                                  onClick={() => onItemClick(googleMatchedItem)}
                                  className="px-3.5 py-1.5 rounded-lg bg-[#e50914] hover:bg-[#b80710] text-white text-xs font-bold flex items-center gap-1.5 transition-all shadow-lg shadow-red-950/60 cursor-pointer shrink-0"
                                >
                                  <Play size={12} className="fill-white" />
                                  <span>Watch on MooFlix</span>
                                </button>
                              ) : (
                                <button
                                  type="button"
                                  onClick={() => {
                                    setQuery(groundingData.entity!.exactTitle);
                                  }}
                                  className="px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-white text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer shrink-0"
                                >
                                  <Search size={12} />
                                  <span>Search "{groundingData.entity.exactTitle}"</span>
                                </button>
                              )}
                            </div>
                          </div>
                        )}
                      </div>
                    )
                  )}
                </div>
              )}

              {/* 2. STARS & CELEBRITIES SECTION */}
              {starsList.length > 0 && (
                <div className="mb-6 bg-[#121212] border border-white/10 rounded-2xl p-4 sm:p-5">
                  <div className="flex items-center justify-between mb-3.5">
                    <div className="flex items-center gap-2">
                      <Star size={16} className="text-yellow-400 fill-yellow-400" />
                      <h3 className="text-sm font-bold text-white tracking-wide">
                        Stars & Celebrities matching "{query}"
                      </h3>
                    </div>
                    <span className="text-xs text-neutral-400">Click a star to see their titles</span>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3">
                    {starsList.map((person) => {
                      const isSelected = selectedStar?.id === person.id;
                      return (
                        <div
                          key={person.id}
                          onClick={() => handleStarClick(person)}
                          className={`flex items-center gap-3 p-2.5 rounded-xl border transition-all cursor-pointer ${
                            isSelected
                              ? 'bg-red-600/20 border-red-500 shadow-md ring-1 ring-red-500'
                              : 'bg-white/5 border-white/10 hover:border-white/25 hover:bg-white/10'
                          }`}
                        >
                          <img
                            src={person.profilePath}
                            alt={person.name}
                            className="w-12 h-12 rounded-full object-cover shrink-0 border border-white/20"
                            onError={(e) => {
                              (e.target as HTMLElement).style.display = 'none';
                            }}
                          />
                          <div className="min-w-0 flex-1">
                            <h4 className="text-xs sm:text-sm font-bold text-white truncate group-hover:text-red-400">
                              {person.name}
                            </h4>
                            <p className="text-[11px] text-neutral-400 truncate">
                              {person.knownForTitles?.length > 0 ? person.knownForTitles.join(', ') : person.knownForDepartment}
                            </p>
                            <span className="inline-block mt-1 text-[10px] text-red-400 font-semibold hover:underline">
                              {isSelected ? 'Viewing Titles' : 'View Titles →'}
                            </span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* 3. Loading Indicator with Skeleton Grid for Movies & Series */}
              {(loading || starLoading) && (
                <div className="py-6 space-y-4">
                  <div className="flex items-center gap-2.5 text-xs text-neutral-400 font-medium px-1">
                    <Loader2 size={16} className="animate-spin text-[#e50914]" />
                    <span>
                      {starLoading ? `Loading filmography of ${selectedStar?.name}...` : 'Searching...'}
                    </span>
                  </div>
                  <MovieGridSkeleton 
                    count={12} 
                    cols="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3 md:gap-4 pb-20" 
                  />
                </div>
              )}

              {/* 4. Movies & Series Results */}
              {!loading && !starLoading && (
                <div>
                  {/* Intelligent Meta Notice */}
                  {searchMeta?.metaNotice && (
                    <div className="flex items-center justify-between flex-wrap gap-2 mb-4 px-4 py-2.5 rounded-xl bg-red-600/10 border border-red-500/20 text-xs sm:text-sm text-red-200">
                      <span className="font-medium">{searchMeta.metaNotice}</span>
                      {searchMeta.suggestionQuery && searchMeta.suggestionQuery.toLowerCase() !== query.toLowerCase() && (
                        <button
                          onClick={() => setQuery(searchMeta.suggestionQuery!)}
                          className="underline font-semibold text-white hover:text-red-300 transition-colors cursor-pointer text-xs"
                        >
                          Search "{searchMeta.suggestionQuery}" instead
                        </button>
                      )}
                    </div>
                  )}

                  {/* Search Header Bar with counts */}
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-5 pb-3 border-b border-white/[0.06]">
                    <div className="flex items-center gap-2 flex-wrap">
                      <h2 className="text-sm sm:text-base font-semibold text-neutral-300">
                        Results for <span className="text-white">"{query}"</span>
                      </h2>
                      <span className="text-xs text-neutral-500">({results.length} found)</span>
                      {selectedStar && (
                        <button
                          onClick={() => {
                            setSelectedStar(null);
                            setQuery(query);
                          }}
                          className="px-2 py-0.5 rounded-full bg-white/10 hover:bg-white/20 text-[11px] text-neutral-300 flex items-center gap-1 cursor-pointer"
                        >
                          <span>Clear Star Filter</span>
                          <X size={10} />
                        </button>
                      )}
                    </div>
                  </div>

                  {results.length > 0 ? (
                    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3 md:gap-4 pb-20">
                      {results.map((item, idx) => (
                        <MovieCard
                          key={`${item.id}-${idx}`}
                          item={item}
                          onClick={(clickedItem) => {
                            onItemClick(clickedItem);
                          }}
                        />
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-16 max-w-sm mx-auto">
                      <p className="text-white font-semibold text-sm mb-1">
                        No titles found for "{query}"
                      </p>
                      <p className="text-neutral-500 text-xs">
                        Try searching another movie, web series, or actor name.
                      </p>
                    </div>
                  )}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export { SearchModal };
export default SearchModal;
