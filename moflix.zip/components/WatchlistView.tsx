import React, { useState, useEffect } from 'react';
import { ContentItem } from '../types';
import MovieCard from './MovieCard';
import { Bookmark, Trash2, Sparkles } from 'lucide-react';

interface WatchlistViewProps {
  onItemClick: (item: ContentItem) => void;
  onExploreContent?: () => void;
}

export const WatchlistView: React.FC<WatchlistViewProps> = ({ onItemClick, onExploreContent }) => {
  const [watchlist, setWatchlist] = useState<ContentItem[]>([]);
  const [filterType, setFilterType] = useState<'all' | 'movie' | 'tv'>('all');
  const [showClearConfirm, setShowClearConfirm] = useState(false);

  const loadWatchlist = () => {
    try {
      const items = JSON.parse(localStorage.getItem('moflix_watchlist') || '[]');
      setWatchlist(items);
    } catch {
      setWatchlist([]);
    }
  };

  useEffect(() => {
    loadWatchlist();
    window.addEventListener('storage', loadWatchlist);
    return () => window.removeEventListener('storage', loadWatchlist);
  }, []);

  const handleRemove = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    try {
      const updated = watchlist.filter(item => String(item.id) !== String(id));
      setWatchlist(updated);
      localStorage.setItem('moflix_watchlist', JSON.stringify(updated));
      window.dispatchEvent(new Event('storage'));
    } catch (err) {
      console.error(err);
    }
  };

  const confirmClearAll = () => {
    setWatchlist([]);
    try {
      localStorage.setItem('moflix_watchlist', JSON.stringify([]));
      window.dispatchEvent(new Event('storage'));
    } catch (err) {
      console.error(err);
    }
    setShowClearConfirm(false);
  };

  const isSeries = (item: ContentItem) => item.type === 'series' || item.type === 'tv' || item.type === 'anime';
  const isMovie = (item: ContentItem) => item.type === 'movie';

  const filteredItems = watchlist.filter(item => {
    if (filterType === 'all') return true;
    if (filterType === 'movie') return isMovie(item);
    if (filterType === 'tv') return isSeries(item);
    return true;
  });

  const movieCount = watchlist.filter(isMovie).length;
  const seriesCount = watchlist.filter(isSeries).length;

  return (
    <div className="px-4 md:px-12 pt-6 md:pt-10 min-h-screen">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-red-600/20 text-[#e50914] border border-red-500/30 flex items-center justify-center">
            <Bookmark size={22} />
          </div>
          <div>
            <h1 className="text-2xl md:text-3xl font-extrabold tracking-tight text-white flex items-center gap-2">
              My List
            </h1>
            <p className="text-xs text-neutral-400">
              {watchlist.length} {watchlist.length === 1 ? 'title' : 'titles'} saved in your list
            </p>
          </div>
        </div>

        {watchlist.length > 0 && (
          <div className="flex items-center gap-2">
            {/* Filter Pills */}
            <div className="flex items-center bg-[#161618] p-1 rounded-full border border-white/10 text-xs">
              <button
                onClick={() => setFilterType('all')}
                className={`px-3 py-1 rounded-full font-medium transition-all ${
                  filterType === 'all' ? 'bg-white text-black font-semibold' : 'text-neutral-400 hover:text-white'
                }`}
              >
                All ({watchlist.length})
              </button>
              <button
                onClick={() => setFilterType('movie')}
                className={`px-3 py-1 rounded-full font-medium transition-all ${
                  filterType === 'movie' ? 'bg-white text-black font-semibold' : 'text-neutral-400 hover:text-white'
                }`}
              >
                Movies ({movieCount})
              </button>
              <button
                onClick={() => setFilterType('tv')}
                className={`px-3 py-1 rounded-full font-medium transition-all ${
                  filterType === 'tv' ? 'bg-white text-black font-semibold' : 'text-neutral-400 hover:text-white'
                }`}
              >
                Series ({seriesCount})
              </button>
            </div>

            <button
              onClick={() => setShowClearConfirm(true)}
              title="Clear My List"
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-red-600/10 hover:bg-red-600 text-red-400 hover:text-white border border-red-500/20 transition-all cursor-pointer text-xs font-semibold active:scale-95"
            >
              <Trash2 size={14} />
              <span className="hidden sm:inline">Clear List</span>
            </button>
          </div>
        )}
      </div>

      {showClearConfirm && (
        <div 
          className="fixed inset-0 z-[600] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in duration-150"
          onClick={() => setShowClearConfirm(false)}
        >
          <div 
            className="bg-[#141416] border border-white/10 rounded-2xl p-5 sm:p-6 max-w-sm w-full shadow-2xl animate-in zoom-in-95 duration-150"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="w-12 h-12 rounded-full bg-red-600/15 border border-red-500/20 text-red-500 flex items-center justify-center mx-auto mb-4">
              <Trash2 size={24} />
            </div>

            <h3 className="text-base sm:text-lg font-bold text-white text-center">
              Clear entire My List?
            </h3>
            <p className="text-xs text-neutral-400 text-center mt-1.5 mb-5">
              This will remove all {watchlist.length} saved movies and series from your list.
            </p>

            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={() => setShowClearConfirm(false)}
                className="flex-1 py-2.5 px-4 rounded-xl bg-white/10 hover:bg-white/15 active:scale-95 text-white text-xs sm:text-sm font-semibold transition-all cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={confirmClearAll}
                className="flex-1 py-2.5 px-4 rounded-xl bg-[#e50914] hover:bg-[#b80710] active:scale-95 text-white text-xs sm:text-sm font-bold transition-all shadow-lg shadow-red-900/30 cursor-pointer"
              >
                Clear All
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Content */}
      {filteredItems.length === 0 ? (
        <div className="py-20 flex flex-col items-center justify-center text-center px-4">
          <div className="w-16 h-16 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-neutral-500 mb-4">
            <Bookmark size={30} strokeWidth={1.5} />
          </div>
          <h2 className="text-lg font-bold text-white mb-1">Your List is Empty</h2>
          <p className="text-xs text-neutral-400 max-w-sm mb-6">
            Explore trending movies and TV series, and tap the + My List button to save your favorites here.
          </p>
          {onExploreContent && (
            <button
              onClick={onExploreContent}
              className="px-6 py-2.5 rounded-full bg-[#e50914] hover:bg-[#b80710] text-white font-bold text-xs transition-all shadow-lg active:scale-95 flex items-center gap-2"
            >
              <Sparkles size={14} />
              <span>Explore Content</span>
            </button>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3 md:gap-4 pb-16">
          {filteredItems.map((item, idx) => (
            <React.Fragment key={item.id}>
              <div className="relative group">
                <MovieCard item={item} onClick={onItemClick} />
                <button
                  onClick={(e) => handleRemove(item.id, e)}
                  title="Remove from My List"
                  className="absolute top-2 right-2 z-20 w-7 h-7 rounded-full bg-black/80 hover:bg-red-600 text-white flex items-center justify-center transition-all opacity-0 group-hover:opacity-100 shadow-md border border-white/20"
                >
                  <Trash2 size={12} />
                </button>
              </div>
            </React.Fragment>
          ))}
        </div>
      )}
    </div>
  );
};

export default WatchlistView;
