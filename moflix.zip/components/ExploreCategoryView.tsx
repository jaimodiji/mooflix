import React, { useState, useEffect, useRef, useCallback } from 'react';
import { ArrowLeft, Film, Tv, Sparkles, Filter } from 'lucide-react';
import { ContentItem } from '../types';
import MovieCard from './MovieCard';
import { MovieGridSkeleton } from './Skeletons';
import { 
  fetchContentByGenre, 
  fetchTrending, 
  fetchRecentReleases, 
  fetchMovies, 
  fetchTVShows, 
  fetchTrendingMovies, 
  fetchTrendingSeries, 
  fetchTop10Movies, 
  fetchTop10Series,
  isIndianSerial 
} from '../services/tmdbService';

interface ExploreCategoryViewProps {
  category: {
    id: number | string;
    title: string;
    type?: 'genre' | 'trending' | 'recent' | 'top10movies' | 'top10series' | 'trending_movies' | 'trending_series';
  };
  onClose: () => void;
  onItemClick: (item: ContentItem) => void;
}

const ExploreCategoryView: React.FC<ExploreCategoryViewProps> = ({
  category,
  onClose,
  onItemClick,
}) => {
  const [items, setItems] = useState<ContentItem[]>([]);
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [hasMore, setHasMore] = useState(true);
  const [filterType, setFilterType] = useState<'all' | 'movie' | 'tv'>('all');
  const observer = useRef<IntersectionObserver | null>(null);

  // Fetch initial batch
  useEffect(() => {
    let isMounted = true;
    const loadInitial = async () => {
      setLoading(true);
      setPage(1);
      setItems([]);
      try {
        let results: ContentItem[] = [];
        if (category.type === 'trending_movies') {
          results = (await fetchTrendingMovies(1)).filter(i => i.type === 'movie');
        } else if (category.type === 'trending_series') {
          results = (await fetchTrendingSeries(1)).filter(i => i.type === 'series' && !isIndianSerial(i));
        } else if (category.type === 'trending') {
          results = await fetchTrending(1);
        } else if (category.type === 'recent') {
          results = await fetchRecentReleases();
        } else if (category.type === 'top10movies') {
          results = (await fetchTop10Movies(1)).filter(i => i.type === 'movie');
        } else if (category.type === 'top10series') {
          results = (await fetchTop10Series(1)).filter(i => i.type === 'series' && !isIndianSerial(i));
        } else {
          // Genre
          results = await fetchContentByGenre(category.id, 1, filterType);
        }

        if (isMounted) {
          setItems(results);
          setHasMore(results.length >= 10);
        }
      } catch (err) {
        console.error('Failed to load explore content:', err);
      } finally {
        if (isMounted) setLoading(false);
      }
    };

    loadInitial();
    return () => {
      isMounted = false;
    };
  }, [category, filterType]);

  // Load more pages on scroll
  const loadMore = useCallback(async () => {
    if (loadingMore || !hasMore || loading) return;
    setLoadingMore(true);
    const nextPage = page + 1;
    try {
      let nextResults: ContentItem[] = [];
      if (category.type === 'trending_movies') {
        nextResults = (await fetchTrendingMovies(nextPage)).filter(i => i.type === 'movie');
      } else if (category.type === 'trending_series') {
        nextResults = (await fetchTrendingSeries(nextPage)).filter(i => i.type === 'series' && !isIndianSerial(i));
      } else if (category.type === 'trending') {
        nextResults = await fetchTrending(nextPage);
      } else if (category.type === 'top10movies') {
        nextResults = (await fetchTop10Movies(nextPage)).filter(i => i.type === 'movie');
      } else if (category.type === 'top10series') {
        nextResults = (await fetchTop10Series(nextPage)).filter(i => i.type === 'series' && !isIndianSerial(i));
      } else if (category.type === 'recent') {
        setHasMore(false);
        setLoadingMore(false);
        return;
      } else {
        nextResults = await fetchContentByGenre(category.id, nextPage, filterType);
      }

      if (nextResults.length === 0) {
        setHasMore(false);
      } else {
        setItems(prev => {
          const existingIds = new Set(prev.map(i => i.id));
          const newUnique = nextResults.filter(i => !existingIds.has(i.id));
          return [...prev, ...newUnique];
        });
        setPage(nextPage);
      }
    } catch (err) {
      console.error('Failed to load more explore content:', err);
    } finally {
      setLoadingMore(false);
    }
  }, [loadingMore, hasMore, loading, page, category, filterType]);

  // Infinite scroll trigger
  const lastElementRef = useCallback((node: HTMLDivElement | null) => {
    if (loading || loadingMore) return;
    if (observer.current) observer.current.disconnect();
    observer.current = new IntersectionObserver(entries => {
      if (entries[0].isIntersecting && hasMore) {
        loadMore();
      }
    });
    if (node) observer.current.observe(node);
  }, [loading, loadingMore, hasMore, loadMore]);

  // Filter change handler
  const handleFilterChange = (type: 'all' | 'movie' | 'tv') => {
    if (type !== filterType) {
      setFilterType(type);
    }
  };

  return (
    <div className="fixed inset-0 z-[110] bg-[#0a0a0a] overflow-y-auto antialiased">
      {/* Sticky Dedicated Top Bar */}
      <div className="sticky top-0 z-30 bg-[#0a0a0a]/95 backdrop-blur-md border-b border-white/[0.06] py-3.5 px-4 md:px-12">
        <div className="max-w-[1800px] mx-auto flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3.5">
            <button
              onClick={onClose}
              className="p-2 rounded-full bg-white/[0.08] hover:bg-white/[0.15] text-white transition-colors cursor-pointer shrink-0"
              aria-label="Back to home"
            >
              <ArrowLeft size={18} />
            </button>
            <div>
              <h1 className="text-lg md:text-2xl font-bold tracking-tight text-white">
                {category.title}
              </h1>
              <span className="text-xs text-neutral-500 font-medium">
                {items.length} titles loaded • Endless Explore
              </span>
            </div>
          </div>

          {/* Media Type Filter Pills (if category is genre) */}
          {category.type !== 'top10movies' && category.type !== 'top10series' && category.type !== 'trending_movies' && category.type !== 'trending_series' && (
            <div className="flex items-center gap-1.5 self-start sm:self-auto bg-[#141414] p-1 rounded-full border border-white/[0.06]">
              <button
                onClick={() => handleFilterChange('all')}
                className={`px-3 py-1 rounded-full text-xs font-medium transition-colors cursor-pointer ${
                  filterType === 'all' 
                    ? 'bg-white text-black font-semibold' 
                    : 'text-neutral-400 hover:text-white'
                }`}
              >
                All
              </button>
              <button
                onClick={() => handleFilterChange('movie')}
                className={`px-3 py-1 rounded-full text-xs font-medium transition-colors cursor-pointer ${
                  filterType === 'movie' 
                    ? 'bg-white text-black font-semibold' 
                    : 'text-neutral-400 hover:text-white'
                }`}
              >
                Movies
              </button>
              <button
                onClick={() => handleFilterChange('tv')}
                className={`px-3 py-1 rounded-full text-xs font-medium transition-colors cursor-pointer ${
                  filterType === 'tv' 
                    ? 'bg-white text-black font-semibold' 
                    : 'text-neutral-400 hover:text-white'
                }`}
              >
                TV Series
              </button>
            </div>
          )}
        </div>
      </div>

      <div className="max-w-[1800px] mx-auto px-4 md:px-12 pt-4 pb-24 min-h-[calc(100vh-80px)]">
        {/* Content Grid */}
        {loading ? (
          <MovieGridSkeleton count={18} />
        ) : items.length > 0 ? (
          <div>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3 md:gap-4">
              {items.map((item, idx) => (
                <MovieCard 
                  key={`${item.id}-${idx}`}
                  item={item} 
                  onClick={onItemClick} 
                />
              ))}
            </div>

            {/* Bottom Infinite Loading Indicator with Skeleton Cards */}
            {hasMore && (
              <div ref={lastElementRef} className="py-8">
                {loadingMore && (
                  <div className="space-y-4">
                    <MovieGridSkeleton count={6} />
                  </div>
                )}
              </div>
            )}
          </div>
        ) : (
          <div className="text-center py-32 max-w-sm mx-auto">
            <h3 className="text-base font-semibold text-white mb-1">No titles found</h3>
            <p className="text-neutral-500 text-xs">
              No titles available in this category right now.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default ExploreCategoryView;
