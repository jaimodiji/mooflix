import React from 'react';

export const AntiAdblockNotice: React.FC = () => null;

export default AntiAdblockNotice;
