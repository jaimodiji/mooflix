import React, { useState, useEffect, useRef } from 'react';
import { Play, X, Film, Star, Plus, Check, Download, Share2, ExternalLink, RefreshCw } from 'lucide-react';
import { ContentItem, ExtendedDetails, PlayConfig } from '../types';
import { fetchExtendedDetails } from '../services/tmdbService';
import { DetailsModalSkeleton } from './Skeletons';
import { SocialBacklinkShareModal } from './SocialBacklinkShareModal';
import { getDownloadUrl } from '../utils/playerUtils';

interface MovieDetailsModalProps {
  item: ContentItem;
  onModalClose: () => void;
  onItemSelect: (item: ContentItem) => void;
  onPlay: (config: PlayConfig) => void;
  onDownload?: (config: { item: ContentItem; imdbId?: string | null }) => void;
}

const MovieDetailsModal: React.FC<MovieDetailsModalProps> = ({ 
  item, 
  onModalClose, 
  onItemSelect, 
  onPlay,
  onDownload,
}) => {
  const [details, setDetails] = useState<ExtendedDetails | null>(null);
  const [loading, setLoading] = useState(true);
  const [showTrailer, setShowTrailer] = useState(false);
  const [showDownloadWindow, setShowDownloadWindow] = useState(false);
  const [downloadReloadKey, setDownloadReloadKey] = useState(1);
  const [isInList, setIsInList] = useState(false);
  const [showShareModal, setShowShareModal] = useState(false);
  const modalRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const originalOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';

    const fetchDetails = async () => {
      setLoading(true);
      if (modalRef.current) modalRef.current.scrollTo(0, 0);
      try {
        const extendedDetails = await fetchExtendedDetails(item.id, item.type);
        setDetails(extendedDetails);
      } catch (error) { 
        console.error('Failed to load movie details:', error); 
      } finally { 
        setLoading(false); 
      }
    };
    fetchDetails();

    return () => { 
      document.body.style.overflow = originalOverflow; 
    };
  }, [item.id, item.type]);

  useEffect(() => {
    try {
      const saved = JSON.parse(localStorage.getItem('moflix_watchlist') || '[]');
      setIsInList(saved.some((i: any) => i.id === item.id));
    } catch {
      setIsInList(false);
    }
  }, [item.id]);

  const toggleWatchlist = () => {
    try {
      const saved = JSON.parse(localStorage.getItem('moflix_watchlist') || '[]');
      let updated;
      if (isInList) {
        updated = saved.filter((i: any) => i.id !== item.id);
        setIsInList(false);
      } else {
        updated = [...saved, item];
        setIsInList(true);
      }
      localStorage.setItem('moflix_watchlist', JSON.stringify(updated));
    } catch (err) {
      console.error(err);
    }
  };

  const formattedRuntime = details?.runtime 
    ? `${Math.floor(details.runtime / 60)}h ${details.runtime % 60}m` 
    : null;

  return (
    <div 
      className="fixed inset-0 z-[300] bg-black/85 backdrop-blur-md flex items-center justify-center p-0 md:p-6 overflow-hidden animate-in fade-in duration-200" 
      onClick={onModalClose}
    >
      <div 
        ref={modalRef}
        className="relative w-full h-full md:h-auto md:max-h-[90vh] max-w-4xl bg-[#0f0f0f] border border-white/[0.08] shadow-2xl overflow-y-auto rounded-none md:rounded-2xl no-scrollbar" 
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button 
          onClick={onModalClose} 
          aria-label="Close"
          className="absolute top-4 right-4 z-[210] w-9 h-9 bg-black/60 hover:bg-black/90 backdrop-blur-md border border-white/10 rounded-full flex items-center justify-center text-white/80 hover:text-white transition-colors"
        >
          <X size={18} />
        </button>

        {loading ? (
          <DetailsModalSkeleton />
        ) : (
          <>
            {/* Hero Area */}
            <div className="relative aspect-video w-full bg-[#141414] overflow-hidden">
              {item.backdrop ? (
                <img 
                  src={item.backdrop} 
                  className="w-full h-full object-cover brightness-[0.7]" 
                  alt={item.title} 
                  referrerPolicy="no-referrer"
                />
              ) : (
                <div className="w-full h-full bg-[#141414]" />
              )}
              <div className="absolute inset-0 bg-gradient-to-t from-[#0f0f0f] via-[#0f0f0f]/40 to-transparent" />
              
              <div className="absolute bottom-0 left-0 p-6 md:p-8 w-full">
                {details?.logoUrl ? (
                  <img 
                    src={details.logoUrl} 
                    className="h-12 md:h-20 object-contain mb-4 drop-shadow-xl max-w-[70%]" 
                    alt={item.title} 
                    referrerPolicy="no-referrer"
                  />
                ) : (
                  <h1 className="text-2xl md:text-4xl font-extrabold mb-3 tracking-tight text-white drop-shadow-lg">
                    {item.title}
                  </h1>
                )}
                
                <div className="flex flex-wrap items-center gap-2.5 sm:gap-3">
                  <button 
                    onClick={() => {
                      onPlay({ item, provider: '1', imdbId: details?.imdbId });
                    }} 
                    className="px-5 sm:px-6 py-2 sm:py-2.5 rounded-full font-bold text-xs sm:text-sm md:text-base transition-all duration-200 flex items-center gap-2 border active:scale-95 cursor-pointer shadow-lg bg-white hover:bg-neutral-200 text-black border-white"
                  >
                    <Play size={18} fill="currentColor" />
                    <span>Play</span>
                  </button>

                  <button 
                    onClick={() => {
                      setShowDownloadWindow(prev => !prev);
                      setShowTrailer(false);
                    }} 
                    className={`px-4 sm:px-5 py-2 sm:py-2.5 backdrop-blur-md rounded-full font-bold text-xs sm:text-sm md:text-base transition-all duration-200 flex items-center gap-2 border active:scale-95 cursor-pointer ${
                      showDownloadWindow 
                        ? 'bg-red-600 border-red-500 text-white shadow-lg shadow-red-900/40' 
                        : 'bg-white/10 hover:bg-white/20 text-white border-white/10'
                    }`}
                  >
                    <Download size={16} />
                    <span>{showDownloadWindow ? 'Hide Download' : 'Download'}</span>
                  </button>

                  {details?.trailerKey && (
                    <button 
                      onClick={() => {
                        setShowTrailer(prev => !prev);
                        setShowDownloadWindow(false);
                      }} 
                      className={`px-3.5 sm:px-4 py-2 sm:py-2.5 backdrop-blur-md rounded-full font-bold text-xs sm:text-sm transition-all duration-200 flex items-center gap-2 border active:scale-95 cursor-pointer ${
                        showTrailer 
                          ? 'bg-red-600 border-red-500 text-white shadow-lg shadow-red-900/40' 
                          : 'bg-white/10 hover:bg-white/20 text-white border-white/10'
                      }`}
                    >
                      <Film size={15} />
                      <span>{showTrailer ? 'Hide Trailer' : 'Trailer'}</span>
                    </button>
                  )}
                  
                  <button 
                    onClick={toggleWatchlist}
                    aria-label={isInList ? "Remove from List" : "Add to List"}
                    className={`w-9 h-9 sm:w-10 sm:h-10 rounded-full flex items-center justify-center text-white transition-all duration-200 backdrop-blur-md border border-white/15 active:scale-95 cursor-pointer ${
                      isInList ? 'bg-white/20' : 'bg-black/40 hover:bg-white/10'
                    }`}
                  >
                    {isInList ? <Check size={18} strokeWidth={2.5} /> : <Plus size={18} />}
                  </button>

                  <button 
                    onClick={() => setShowShareModal(true)}
                    aria-label="Share movie on WhatsApp and Twitter"
                    title="Share on WhatsApp & Twitter"
                    className="w-9 h-9 sm:w-10 sm:h-10 rounded-full flex items-center justify-center text-white transition-all duration-200 backdrop-blur-md border border-white/15 bg-black/40 hover:bg-white/10 active:scale-95 cursor-pointer"
                  >
                    <Share2 size={17} />
                  </button>
                </div>
              </div>
            </div>

            {/* Social Share & Backlink Modal */}
            <SocialBacklinkShareModal
              item={item}
              isOpen={showShareModal}
              onClose={() => setShowShareModal(false)}
            />

            {/* Official Trailer Overlay Window */}
            {showTrailer && details?.trailerKey && (
              <div className="p-4 md:p-6 bg-black/95 border-b border-white/10 animate-in fade-in duration-200">
                <div className="flex items-center justify-between pb-2 mb-2 border-b border-white/10 text-xs text-neutral-300">
                  <span className="font-semibold flex items-center gap-1.5 text-white">
                    <Film size={14} className="text-red-500" />
                    <span>Official Trailer</span>
                  </span>
                  <button 
                    onClick={() => setShowTrailer(false)} 
                    className="px-2.5 py-1 rounded-full bg-white/10 hover:bg-white/20 text-neutral-300 hover:text-white transition-all duration-200 active:scale-95 cursor-pointer"
                  >
                    Close
                  </button>
                </div>
                <div className="relative aspect-video rounded-lg overflow-hidden border border-white/10 bg-black">
                  <iframe 
                    src={`https://www.youtube.com/embed/${details.trailerKey}?autoplay=1`} 
                    className="w-full h-full" 
                    allow="autoplay; encrypted-media; fullscreen" 
                    allowFullScreen 
                  />
                </div>
              </div>
            )}

            {/* Direct Nxsha DL Download Window (Clean frame with ONLY Direct Download and Close buttons) */}
            {showDownloadWindow && (
              <div className="p-4 md:p-6 bg-[#0a0a0e] border-b border-red-500/20 animate-in fade-in duration-200">
                <div className="flex items-center justify-end gap-2 pb-2 mb-3 border-b border-white/10 text-xs">
                  <a
                    href={getDownloadUrl(item, 1)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-3.5 py-1.5 rounded-full bg-red-600/30 hover:bg-red-600 border border-red-500/40 text-white flex items-center gap-1.5 text-xs font-bold transition-all duration-200 shadow-sm active:scale-95 cursor-pointer"
                    title="Direct Download in New Window"
                  >
                    <span>Direct Download</span>
                    <ExternalLink size={12} />
                  </a>
                  <button
                    type="button"
                    onClick={() => setShowDownloadWindow(false)}
                    className="px-3 py-1.5 rounded-full bg-white/10 hover:bg-white/20 border border-white/10 text-neutral-300 hover:text-white text-xs font-bold transition-all duration-200 active:scale-95 cursor-pointer"
                  >
                    Close
                  </button>
                </div>

                {/* Sandboxed In-Modal Download Frame */}
                <div className="relative w-full h-[480px] sm:h-[550px] md:h-[620px] rounded-xl overflow-hidden border border-white/10 bg-[#0d0d12] shadow-2xl">
                  <iframe 
                    key={downloadReloadKey}
                    src={getDownloadUrl(item, 1)} 
                    className="w-full h-full border-0" 
                    allow="autoplay; encrypted-media; fullscreen"
                    title={`Download - ${item.title}`}
                  />
                </div>
              </div>
            )}

            {/* Details Content */}
            <div className="px-6 md:px-8 py-6 space-y-6">
              {/* Metadata row */}
              <div className="flex flex-wrap items-center gap-2 text-xs text-neutral-300 font-medium">
                {item.year > 0 && <span>{item.year}</span>}
                {formattedRuntime && (
                  <>
                    <span className="text-neutral-600">•</span>
                    <span>{formattedRuntime}</span>
                  </>
                )}
                {details?.genres && details.genres.length > 0 && (
                  <>
                    <span className="text-neutral-600">•</span>
                    <span>{details.genres.slice(0, 3).join(', ')}</span>
                  </>
                )}
              </div>

              {/* Synopsis */}
              <p className="text-sm md:text-base text-neutral-300 leading-relaxed font-normal">
                {item.description || 'No description available.'}
              </p>

              {/* Cast Profile Strip */}
              {details?.cast && details.cast.length > 0 && (
                <div className="pt-4 border-t border-white/[0.06]">
                  <h3 className="text-xs font-semibold text-neutral-400 uppercase tracking-wider mb-3">Cast</h3>
                  <div className="flex gap-3 overflow-x-auto pb-2 no-scrollbar">
                    {details.cast.slice(0, 7).map(actor => (
                      <div key={actor.id} className="flex flex-col items-center text-center w-18 shrink-0">
                        <div className="w-12 h-12 rounded-full overflow-hidden bg-neutral-800 mb-1.5">
                          {actor.profilePath ? (
                            <img src={actor.profilePath} alt={actor.name} className="w-full h-full object-cover" />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center text-xs text-neutral-500 font-bold">
                              {actor.name.charAt(0)}
                            </div>
                          )}
                        </div>
                        <span className="text-[10px] font-medium text-white truncate w-full">{actor.name}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* More Like This with 8 Ads (2 rows of 4) */}
              <div className="pt-4 border-t border-white/[0.06]">
                <h3 className="text-sm font-semibold text-white mb-3">More Like This</h3>
                {details?.recommendations && details.recommendations.length > 0 && (
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2.5 mb-4">
                    {details.recommendations.slice(0, 8).map((rec, idx) => (
                      <div 
                        key={`${rec.id}-${idx}`}
                        className="bg-[#161616] hover:bg-[#202020] rounded-lg overflow-hidden group cursor-pointer transition-colors duration-150"
                        onClick={() => onItemSelect(rec)}
                      >
                        <div className="relative aspect-[16/10] bg-[#121212]">
                          {rec.backdrop || rec.thumbnail ? (
                            <img 
                              src={rec.backdrop || rec.thumbnail} 
                              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" 
                              alt={rec.title} 
                            />
                          ) : (
                            <div className="w-full h-full bg-[#121212]" />
                          )}
                        </div>
                        <div className="p-2">
                          <h4 className="font-medium text-xs text-white truncate">{rec.title}</h4>
                          <span className="text-[10px] text-neutral-500">{rec.year}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
};

export default MovieDetailsModal;
