import React from 'react';

export const StreamLockModal: React.FC = () => null;

export default StreamLockModal;
