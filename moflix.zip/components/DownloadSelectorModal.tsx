import React from 'react';
import { ContentItem } from '../types';
import { X, Download, ArrowRight, Zap, ShieldCheck } from 'lucide-react';
import { getDownloadUrl } from '../utils/playerUtils';

interface DownloadSelectorModalProps {
  item: ContentItem;
  season?: number;
  episode?: number;
  imdbId?: string | null;
  onClose: () => void;
  onOpenInAppDownload?: (url: string, serverName: string) => void;
}

const DownloadSelectorModal: React.FC<DownloadSelectorModalProps> = ({
  item,
  season = 1,
  episode = 1,
  imdbId = null,
  onClose,
  onOpenInAppDownload,
}) => {
  const isMovie = item.type === 'movie';
  // Single high-speed direct download server per user request (Server 2 and ads removed)
  const downloadUrl = getDownloadUrl(item, 1, season, episode, imdbId);

  const handleDownload = () => {
    if (onOpenInAppDownload) {
      onOpenInAppDownload(downloadUrl, 'Direct High-Speed Server (Nxsha)');
    } else {
      window.open(downloadUrl, '_blank', 'noopener,noreferrer');
    }
  };

  return (
    <div
      className="fixed inset-0 z-[700] bg-black/85 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in duration-150 select-none"
      onClick={onClose}
    >
      <div
        className="relative bg-[#111116] border border-white/10 p-5 sm:p-6 rounded-3xl w-full max-w-sm sm:max-w-md shadow-2xl animate-in zoom-in-95 duration-150"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          type="button"
          onClick={onClose}
          aria-label="Close"
          className="absolute top-4 right-4 w-8 h-8 rounded-full bg-white/5 hover:bg-white/10 text-neutral-400 hover:text-white flex items-center justify-center transition-colors cursor-pointer"
        >
          <X size={16} />
        </button>

        {/* Minimal Title */}
        <div className="mb-4 text-center pt-1">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-red-600/15 border border-red-500/25 text-[#e50914] text-[10px] font-bold uppercase tracking-wider mb-2">
            <Download size={11} />
            <span>Direct High-Speed Download</span>
          </div>
          <h2 className="text-lg font-bold text-white tracking-tight truncate px-4">
            {item.title}
          </h2>
          <p className="text-neutral-400 text-xs mt-0.5">
            {!isMovie ? `Season ${season} • Episode ${episode}` : `${item.year || 'Full Movie'} • Ultra HD`}
          </p>
        </div>

        {/* Single Verified Download Server (Server 2 removed, pure ad-free experience) */}
        <div className="space-y-3">
          <button
            type="button"
            onClick={handleDownload}
            className="w-full flex items-center justify-between p-4 rounded-2xl bg-[#16161c] hover:bg-[#202028] border border-red-600/40 hover:border-red-500/80 text-left transition-all group active:scale-[0.98] cursor-pointer shadow-lg"
          >
            <div className="flex items-center gap-3.5 min-w-0">
              <div className="w-10 h-10 rounded-full bg-red-600/20 text-[#e50914] group-hover:bg-[#e50914] group-hover:text-white transition-all flex items-center justify-center shrink-0 shadow-sm">
                <Zap size={18} className="fill-current" />
              </div>
              <div className="min-w-0">
                <div className="flex items-center gap-2">
                  <span className="text-sm font-black text-white group-hover:text-[#ff3844] transition-colors">
                    Direct High-Speed Server
                  </span>
                  <span className="text-[9px] font-bold px-2 py-0.5 rounded-full bg-red-600/30 text-red-300 border border-red-500/30">
                    Fast HD
                  </span>
                </div>
                <span className="text-[11px] text-neutral-400 block mt-0.5 truncate">
                  nxsha.space • Clean Direct Download (No Ads)
                </span>
              </div>
            </div>
            <div className="w-8 h-8 rounded-full bg-white/5 group-hover:bg-[#e50914] text-neutral-400 group-hover:text-white flex items-center justify-center transition-all shrink-0 ml-2">
              <ArrowRight size={14} />
            </div>
          </button>
        </div>

        {/* Ad-free guarantee note */}
        <div className="mt-4 pt-3 border-t border-white/[0.08] flex items-center justify-center gap-2 text-emerald-400 text-xs font-semibold">
          <ShieldCheck size={14} />
          <span>Zero Ads & Popup Shield Active</span>
        </div>
      </div>
    </div>
  );
};

export default DownloadSelectorModal;
