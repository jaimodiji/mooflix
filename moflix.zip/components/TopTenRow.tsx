import React, { useState, useRef } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { ContentItem } from '../types';
import MovieCard from './MovieCard';

interface TopTenRowProps {
  title: string;
  items: ContentItem[];
  onItemClick: (item: ContentItem) => void;
  onExploreAll?: () => void;
}

const TopTenRow: React.FC<TopTenRowProps> = ({ 
  title, 
  items, 
  onItemClick,
  onExploreAll
}) => {
  const [showLeftArrow, setShowLeftArrow] = useState(false);
  const [showRightArrow, setShowRightArrow] = useState(true);
  const scrollRef = useRef<HTMLDivElement>(null);

  const handleScroll = () => {
    if (scrollRef.current) {
      const { scrollLeft, scrollWidth, clientWidth } = scrollRef.current;
      setShowLeftArrow(scrollLeft > 20);
      setShowRightArrow(scrollLeft < scrollWidth - clientWidth - 20);
    }
  };

  const scroll = (direction: 'left' | 'right') => {
    if (scrollRef.current) {
      const scrollAmount = scrollRef.current.clientWidth * 0.75;
      scrollRef.current.scrollBy({
        left: direction === 'left' ? -scrollAmount : scrollAmount,
        behavior: 'smooth'
      });
    }
  };

  if (!items || items.length === 0) return null;

  return (
    <div className="relative mb-6 md:mb-10 select-none">
      <div className="flex items-center justify-between mb-3 px-1">
        <h2 className="text-base md:text-xl font-bold text-white tracking-tight">
          {title}
        </h2>
        {onExploreAll && (
          <button 
            onClick={onExploreAll}
            className="group/explore flex items-center gap-1 text-xs md:text-sm font-medium text-neutral-400 hover:text-white transition-colors cursor-pointer py-1 px-2 rounded hover:bg-white/[0.06]"
          >
            <span>Explore All</span>
            <ChevronRight size={15} className="group-hover/explore:translate-x-0.5 transition-transform text-neutral-400 group-hover/explore:text-white" />
          </button>
        )}
      </div>
      
      <div className="relative group/topten">
        {/* iOS 27 Glass Navigation Arrows - Anchored Center */}
        <div 
          className={`absolute left-1 md:left-2 z-30 hidden md:block transition-opacity duration-200 ${
            showLeftArrow ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
          }`}
          style={{ top: '50%', transform: 'translateY(-50%)' }}
        >
          <button 
            type="button"
            onClick={() => scroll('left')}
            aria-label="Scroll left"
            className="w-10 h-10 md:w-11 md:h-11 rounded-full bg-[#0d0d14]/85 hover:bg-[#181824]/95 text-white backdrop-blur-2xl border border-white/25 shadow-[0_10px_35px_rgba(0,0,0,0.8),0_0_15px_rgba(255,255,255,0.06)] flex items-center justify-center transition-all duration-200 hover:scale-105 active:scale-95 cursor-pointer ring-1 ring-white/10"
          >
            <ChevronLeft size={20} className="translate-x-[-1px]" />
          </button>
        </div>

        <div 
          className={`absolute right-1 md:right-2 z-30 hidden md:block transition-opacity duration-200 ${
            showRightArrow ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
          }`}
          style={{ top: '50%', transform: 'translateY(-50%)' }}
        >
          <button 
            type="button"
            onClick={() => scroll('right')}
            aria-label="Scroll right"
            className="w-10 h-10 md:w-11 md:h-11 rounded-full bg-[#0d0d14]/85 hover:bg-[#181824]/95 text-white backdrop-blur-2xl border border-white/25 shadow-[0_10px_35px_rgba(0,0,0,0.8),0_0_15px_rgba(255,255,255,0.06)] flex items-center justify-center transition-all duration-200 hover:scale-105 active:scale-95 cursor-pointer ring-1 ring-white/10"
          >
            <ChevronRight size={20} className="translate-x-[1px]" />
          </button>
        </div>

        {/* Top 10 Scroller */}
        <div 
          ref={scrollRef}
          onScroll={handleScroll}
          className="flex overflow-x-auto overflow-y-hidden space-x-3 md:space-x-4 py-1 px-1 scroll-smooth no-scrollbar"
        >
          {items.slice(0, 10).map((item, index) => (
            <div key={item.id} className="flex items-center shrink-0 group relative pl-1">
              {/* Clean minimal stylized outline rank */}
              <span 
                className="text-[90px] sm:text-[115px] md:text-[140px] font-black leading-none text-[#0a0a0a] select-none pointer-events-none z-10 -mr-5 md:-mr-8"
                style={{ 
                  WebkitTextStroke: '2px #333333',
                  fontFamily: 'system-ui, -apple-system, sans-serif'
                }}
              >
                {index + 1}
              </span>
              
              <div className="w-[120px] sm:w-[145px] md:w-[170px] z-20 shadow-xl">
                <MovieCard 
                  item={{ ...item, badge: undefined, badgeType: undefined }} 
                  onClick={onItemClick} 
                  aspectRatio="portrait" 
                />
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default TopTenRow;
