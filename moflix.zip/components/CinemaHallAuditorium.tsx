import React, { useState, useEffect, useRef, memo } from 'react';
import confetti from 'canvas-confetti';
import { Sparkles, PartyPopper, Users, Volume2, Flame, Heart, ThumbsUp } from 'lucide-react';

interface CinemaHallAuditoriumProps {
  lightMode: 'dark' | 'dim' | 'normal';
  movieTitle?: string;
}

/**
 * Fires a spectacular multi-burst celebratory party paper (confetti) cannon blast
 */
export const triggerCinemaConfetti = () => {
  try {
    // Left Cannon Blast
    confetti({
      particleCount: 50,
      angle: 60,
      spread: 65,
      origin: { x: 0.08, y: 0.88 },
      colors: ['#e50914', '#ffd700', '#00f0ff', '#ff007f', '#ffffff'],
      shapes: ['circle', 'square'],
      scalar: 1.1,
      ticks: 240,
      zIndex: 9999,
    });

    // Right Cannon Blast
    confetti({
      particleCount: 50,
      angle: 120,
      spread: 65,
      origin: { x: 0.92, y: 0.88 },
      colors: ['#e50914', '#ffd700', '#00f0ff', '#ff007f', '#ffffff'],
      shapes: ['circle', 'square'],
      scalar: 1.1,
      ticks: 240,
      zIndex: 9999,
    });

    // Center Gold & Sparkle Burst after 220ms
    setTimeout(() => {
      confetti({
        particleCount: 65,
        spread: 100,
        origin: { x: 0.5, y: 0.65 },
        colors: ['#ffd700', '#fffbeb', '#f59e0b', '#f43f5e', '#38bdf8'],
        shapes: ['circle', 'square'],
        scalar: 1.25,
        ticks: 280,
        gravity: 0.85,
        zIndex: 9999,
      });
    }, 220);
  } catch (err) {
    console.warn('Confetti burst error:', err);
  }
};

export const CinemaHallAuditorium: React.FC<CinemaHallAuditoriumProps> = memo(({
  lightMode,
  movieTitle = 'Movie',
}) => {
  const [showPremiereToast, setShowPremiereToast] = useState(true);
  const [activeReactions, setActiveReactions] = useState<{ id: number; emoji: string; x: number }[]>([]);
  const [walkerState, setWalkerState] = useState<'idle' | 'walking_left' | 'walking_right' | 'finding_seat'>('idle');
  const [hasPersonLeftSeat, setHasPersonLeftSeat] = useState(false);
  const reactionIdRef = useRef(0);

  // Trigger grand premiere party papers on theater entry!
  useEffect(() => {
    const timer = setTimeout(() => {
      triggerCinemaConfetti();
    }, 600);

    const toastTimer = setTimeout(() => {
      setShowPremiereToast(false);
    }, 4500);

    return () => {
      clearTimeout(timer);
      clearTimeout(toastTimer);
    };
  }, []);

  // Ambient happening audience activity loop:
  // Random attendees standing up, walking to grab snacks, finding seats, walking back
  useEffect(() => {
    const cycleInterval = setInterval(() => {
      const rand = Math.random();
      if (rand < 0.35) {
        // Someone in Row B gets up to get snacks
        setHasPersonLeftSeat(true);
        setWalkerState('walking_left');
        setTimeout(() => {
          setWalkerState('idle');
          // Return after 6 seconds with fresh popcorn!
          setTimeout(() => {
            setWalkerState('walking_right');
            setTimeout(() => {
              setWalkerState('idle');
              setHasPersonLeftSeat(false);
            }, 3500);
          }, 4500);
        }, 3500);
      } else if (rand < 0.7) {
        // Late arrival walking in with glowing phone screen light
        setWalkerState('finding_seat');
        setTimeout(() => {
          setWalkerState('idle');
        }, 4000);
      }
    }, 14000);

    return () => clearInterval(cycleInterval);
  }, []);

  // Floating Emoji Reaction Spawner
  const handleEmojiReaction = (emoji: string) => {
    const id = ++reactionIdRef.current;
    const x = 25 + Math.random() * 50;
    setActiveReactions((prev) => [...prev.slice(-8), { id, emoji, x }]);

    if (emoji === '🎉') {
      triggerCinemaConfetti();
    }

    setTimeout(() => {
      setActiveReactions((prev) => prev.filter((r) => r.id !== id));
    }, 2000);
  };

  const opacityClass =
    lightMode === 'dark' ? 'opacity-40' : lightMode === 'normal' ? 'opacity-95' : 'opacity-85';

  return (
    <div className={`w-full max-w-4xl mx-auto relative select-none transition-opacity duration-700 ${opacityClass}`}>
      {/* Grand Premiere Banner Toast */}
      {showPremiereToast && (
        <div className="absolute -top-12 left-1/2 -translate-x-1/2 z-40 animate-in fade-in zoom-in-95 duration-500 pointer-events-none">
          <div className="flex items-center gap-2.5 px-4 py-1.5 rounded-full bg-gradient-to-r from-red-600/90 via-amber-500/90 to-red-600/90 text-white font-black text-xs shadow-[0_0_25px_rgba(229,9,20,0.6)] border border-white/30 backdrop-blur-md">
            <PartyPopper size={16} className="animate-bounce text-yellow-200" />
            <span className="tracking-tight uppercase text-[11px]">House Full Premiere • Welcome to MooFlix Cinema!</span>
            <Sparkles size={14} className="text-yellow-200 animate-spin" />
          </div>
        </div>
      )}

      {/* Floating Audience Reactions Layer */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden z-30">
        {activeReactions.map((r) => (
          <div
            key={r.id}
            className="absolute bottom-16 text-2xl sm:text-3xl animate-fade-slide-up pointer-events-none drop-shadow-[0_4px_12px_rgba(0,0,0,0.9)]"
            style={{ left: `${r.x}%` }}
          >
            {r.emoji}
          </div>
        ))}
      </div>

      {/* Dynamic Animated Aisle Walkers (People moving along the theater floor) */}
      {walkerState !== 'idle' && (
        <div className="absolute bottom-8 left-0 right-0 h-16 pointer-events-none z-25 overflow-hidden">
          {walkerState === 'walking_left' && (
            <div className="absolute bottom-1 right-10 flex items-center gap-1.5 animate-walker-left">
              {/* Silhouette of person walking down aisle with drink */}
              <svg width="24" height="42" viewBox="0 0 24 42" fill="none">
                <circle cx="12" cy="7" r="5" fill="#0d0d12" stroke="#222" strokeWidth="1" />
                <path d="M7 14 C7 12, 17 12, 17 14 L18 26 L15 38 L13 38 L14 26 L10 26 L11 38 L9 38 L6 26 Z" fill="#0b0b0f" />
                <rect x="18" y="17" width="4" height="7" rx="1" fill="#ef4444" opacity="0.85" />
                <line x1="20" y1="14" x2="20" y2="17" stroke="#ffffff" strokeWidth="1" />
              </svg>
              <span className="text-[8px] font-mono text-neutral-400 bg-black/80 px-1 rounded border border-white/10 opacity-70">
                Aisle Exit...
              </span>
            </div>
          )}

          {walkerState === 'walking_right' && (
            <div className="absolute bottom-1 left-10 flex items-center gap-1.5 animate-walker-right">
              {/* Person returning with fresh popcorn tub */}
              <svg width="26" height="42" viewBox="0 0 26 42" fill="none">
                <circle cx="14" cy="7" r="5" fill="#0d0d12" stroke="#222" strokeWidth="1" />
                <path d="M9 14 C9 12, 19 12, 19 14 L20 26 L17 38 L15 38 L16 26 L12 26 L13 38 L11 38 L8 26 Z" fill="#0b0b0f" />
                <path d="M4 16 L8 16 L7 22 L5 22 Z" fill="#fbbf24" stroke="#dc2626" strokeWidth="0.8" />
              </svg>
              <span className="text-[8px] font-mono text-amber-300 bg-black/80 px-1 rounded border border-amber-500/30 shadow-[0_0_8px_#f59e0b]">
                🍿 Returning with Snacks
              </span>
            </div>
          )}

          {walkerState === 'finding_seat' && (
            <div className="absolute bottom-2 left-1/4 flex items-center gap-2 animate-pulse">
              {/* Person searching seat with glowing phone screen */}
              <svg width="26" height="42" viewBox="0 0 26 42" fill="none">
                <circle cx="13" cy="7" r="5" fill="#0d0d12" />
                <path d="M8 14 C8 12, 18 12, 18 14 L19 28 L15 40 L13 40 L14 28 L11 28 L12 40 L10 40 L7 28 Z" fill="#09090d" />
                <rect x="18" y="16" width="3" height="6" rx="0.5" fill="#38bdf8" />
                <circle cx="19" cy="18" r="8" fill="#38bdf8" opacity="0.25" filter="blur(3px)" />
              </svg>
              <span className="text-[8px] font-mono text-sky-300 bg-black/90 px-1.5 py-0.5 rounded border border-sky-400/30">
                Finding Seat...
              </span>
            </div>
          )}
        </div>
      )}

      {/* MULTI-TIER AUDITORIUM SVG (5 ROWS: E, D, C, B, A + RANDOMIZED AUDIENCE STATES) */}
      <svg
        viewBox="0 0 920 270"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="w-full h-auto max-h-24 sm:max-h-28 md:max-h-32 drop-shadow-[0_15px_35px_rgba(0,0,0,0.95)] mx-auto pointer-events-none"
      >
        <defs>
          {/* Velvet Seat Gradients */}
          <linearGradient id="audVelvetVIP" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#be123c" />
            <stop offset="50%" stopColor="#9f1239" />
            <stop offset="100%" stopColor="#4c0519" />
          </linearGradient>

          <linearGradient id="audVelvetMid" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#881337" />
            <stop offset="70%" stopColor="#4c0519" />
            <stop offset="100%" stopColor="#25030d" />
          </linearGradient>

          <linearGradient id="audVelvetBack" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#4c0519" />
            <stop offset="100%" stopColor="#140207" />
          </linearGradient>

          {/* Armrest Metallic Gradient */}
          <linearGradient id="audArmrest" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#333333" />
            <stop offset="50%" stopColor="#1f1f1f" />
            <stop offset="100%" stopColor="#0d0d0d" />
          </linearGradient>

          {/* Screen Light Projection Reflection Gradient */}
          <linearGradient id="screenBeamReflection" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#ffffff" stopOpacity="0.22" />
            <stop offset="50%" stopColor="#e50914" stopOpacity="0.10" />
            <stop offset="100%" stopColor="#000000" stopOpacity="0" />
          </linearGradient>
        </defs>

        {/* ============================================================== */}
        {/* ROW E (HIGHEST BALCONY TIER - 12 SEATS, DENSE AUDIENCE) */}
        {/* ============================================================== */}
        <g opacity="0.45">
          {[48, 120, 192, 264, 336, 408, 480, 552, 624, 696, 768, 840].map((x, i) => {
            // Randomized animation class assignment based on index
            const animClass =
              i === 3
                ? 'animate-stand-sit anim-delay-1s'
                : i === 6
                ? 'animate-audience-shift anim-delay-3s'
                : i === 9
                ? 'animate-drink-sip anim-delay-2s'
                : i % 2 === 0
                ? 'animate-audience-subtle anim-delay-4s'
                : 'animate-turn-head anim-delay-5s';

            return (
              <g key={`row-e-${i}`}>
                {/* Seat Headrest */}
                <rect x={x} y="4" width="62" height="20" rx="6" fill="url(#audVelvetBack)" stroke="#3f0817" strokeWidth="0.6" />
                {/* Audience Silhouette with Randomized Motion State */}
                <g className={animClass}>
                  <circle cx={x + 31} cy="2" r="8" fill="#08080b" />
                  <path d={`M ${x + 19} 12 C ${x + 19} 5, ${x + 43} 5, ${x + 43} 12 Z`} fill="#070709" />
                </g>
              </g>
            );
          })}
        </g>

        {/* ============================================================== */}
        {/* ROW D (UPPER TIER - 11 SEATS, ACTIVE AUDIENCE & STANDING PERSON) */}
        {/* ============================================================== */}
        <g opacity="0.65">
          {[55, 132, 210, 288, 366, 444, 522, 600, 678, 756, 834].map((x, i) => {
            const animClass =
              i === 4
                ? 'animate-stand-sit anim-delay-2s' // Audience member standing up to stretch!
                : i === 7
                ? 'animate-audience-cheer anim-delay-3s' // Clapping / cheering
                : i === 2
                ? 'animate-audience-shift anim-delay-1s' // Shifting posture
                : i === 8
                ? 'animate-drink-sip anim-delay-5s' // Drinking
                : i % 2 === 1
                ? 'animate-turn-head anim-delay-2s' // Turning head
                : 'animate-audience-subtle';

            return (
              <g key={`row-d-${i}`}>
                <rect x={x} y="28" width="68" height="26" rx="7" fill="url(#audVelvetBack)" stroke="#5f0c24" strokeWidth="0.8" />
                <g className={animClass}>
                  <circle cx={x + 34} cy="22" r="10" fill="#0b0b0f" />
                  <path d={`M ${x + 18} 36 C ${x + 18} 25, ${x + 50} 25, ${x + 50} 36 Z`} fill="#08080c" />
                  {/* Subtle screen light reflection on shoulders */}
                  <path d={`M ${x + 22} 29 Q ${x + 34} 26 ${x + 46} 29`} stroke="#ffffff" strokeWidth="0.8" strokeLinecap="round" opacity="0.25" />
                </g>
              </g>
            );
          })}
        </g>

        {/* ============================================================== */}
        {/* ROW C (MID-BACK TIER - 10 SEATS, VIBRANT AUDIENCE) */}
        {/* ============================================================== */}
        <g opacity="0.8">
          {[70, 154, 238, 322, 406, 490, 574, 658, 742, 826].map((x, i) => {
            const animClass =
              i === 1
                ? 'animate-turn-head anim-delay-3s'
                : i === 5
                ? 'animate-stand-sit anim-delay-7s' // Standing up to let someone pass
                : i === 8
                ? 'animate-audience-shift anim-delay-4s'
                : i === 3
                ? 'animate-drink-sip anim-delay-1s'
                : i % 2 === 0
                ? 'animate-audience-subtle anim-delay-2s'
                : 'animate-audience-cheer anim-delay-5s';

            return (
              <g key={`row-c-${i}`}>
                <rect x={x} y="58" width="76" height="32" rx="9" fill="url(#audVelvetMid)" stroke="#7a0f2e" strokeWidth="1" />
                <g className={animClass}>
                  <circle cx={x + 38} cy="50" r="12" fill="#0d0d12" />
                  <path d={`M ${x + 20} 68 C ${x + 20} 55, ${x + 56} 55, ${x + 56} 68 Z`} fill="#09090d" />
                  {/* Light edge highlight from screen */}
                  <path d={`M ${x + 26} 43 Q ${x + 38} 39 ${x + 50} 43`} stroke="#ffffff" strokeWidth="1.2" strokeLinecap="round" opacity="0.3" />
                </g>
              </g>
            );
          })}
        </g>

        {/* ============================================================== */}
        {/* ROW B (MID TIER - 8 SEATS WITH POPCORN, 3D GLASSES & DRINKS) */}
        {/* ============================================================== */}
        <g opacity="0.95">
          {/* Row B Left Side Seats */}
          <g>
            {/* Seat 1 */}
            <rect x="95" y="96" width="90" height="38" rx="10" fill="url(#audVelvetMid)" stroke="#881337" strokeWidth="1" />
            <g className="animate-audience-shift anim-delay-2s">
              <circle cx="140" cy="86" r="13" fill="#0c0c11" />
              <path d="M 120 106 C 120 94, 160 94, 160 106 Z" fill="#0a0a0e" />
            </g>

            {/* Seat 2 */}
            <rect x="200" y="96" width="90" height="38" rx="10" fill="url(#audVelvetMid)" stroke="#881337" strokeWidth="1" />
            {!hasPersonLeftSeat ? (
              <g className="animate-popcorn-eater">
                <circle cx="245" cy="85" r="13" fill="#0c0c11" />
                <path d="M 225 106 C 225 94, 265 94, 265 106 Z" fill="#0a0a0e" />
                <path d="M 236 74 Q 245 71 254 74" stroke="#ffffff" strokeWidth="1.2" strokeLinecap="round" opacity="0.35" />
              </g>
            ) : (
              // Empty seat cushion while person stepped out to get popcorn
              <rect x="215" y="106" width="60" height="15" rx="4" fill="#380612" opacity="0.6" />
            )}
          </g>

          {/* Row B Center Walkway Pass-Through Indicator */}
          <g className="animate-pulse" opacity="0.7">
            <line x1="455" y1="92" x2="455" y2="132" stroke="#f59e0b" strokeWidth="1" strokeDasharray="2 3" />
          </g>

          {/* Row B Right Side Seats */}
          <g>
            {/* Seat 3 */}
            <rect x="630" y="96" width="90" height="38" rx="10" fill="url(#audVelvetMid)" stroke="#881337" strokeWidth="1" />
            <g className="animate-audience-cheer anim-delay-1s">
              <circle cx="675" cy="86" r="13" fill="#0c0c11" />
              <path d="M 655 106 C 655 94, 695 94, 695 106 Z" fill="#0a0a0e" />
              {/* 3D Glasses Hint */}
              <line x1="668" y1="85" x2="682" y2="85" stroke="#ef4444" strokeWidth="1.5" opacity="0.4" />
            </g>

            {/* Seat 4 */}
            <rect x="735" y="96" width="90" height="38" rx="10" fill="url(#audVelvetMid)" stroke="#881337" strokeWidth="1" />
            <g className="animate-drink-sip anim-delay-4s">
              <circle cx="780" cy="86" r="13" fill="#0c0c11" />
              <path d="M 760 106 C 760 94, 800 94, 800 106 Z" fill="#0a0a0e" />
            </g>
          </g>
        </g>

        {/* ============================================================== */}
        {/* ROW A (FRONT VIP LUXURY RECLINER ROW - CENTER STAGE) */}
        {/* ============================================================== */}
        <g>
          {/* Screen Light Projection Glow Beam onto Row A */}
          <ellipse cx="460" cy="150" rx="360" ry="70" fill="url(#screenBeamReflection)" />

          {/* Left VIP Recliner (Seat 1) */}
          <rect x="270" y="132" width="155" height="52" rx="14" fill="url(#audVelvetVIP)" stroke="#be123c" strokeWidth="1.5" />
          <rect x="280" y="139" width="135" height="38" rx="10" fill="#4c0519" opacity="0.5" />
          {/* Plush Bottom Cushion */}
          <rect x="260" y="178" width="175" height="58" rx="18" fill="url(#audVelvetVIP)" stroke="#9f1239" strokeWidth="2" />
          <line x1="347" y1="139" x2="347" y2="222" stroke="#fda4af" strokeWidth="1.5" strokeDasharray="3 3" opacity="0.3" />

          {/* Right VIP Recliner (Seat 2) */}
          <rect x="495" y="132" width="155" height="52" rx="14" fill="url(#audVelvetVIP)" stroke="#be123c" strokeWidth="1.5" />
          <rect x="505" y="139" width="135" height="38" rx="10" fill="#4c0519" opacity="0.5" />
          {/* Plush Bottom Cushion */}
          <rect x="485" y="178" width="175" height="58" rx="18" fill="url(#audVelvetVIP)" stroke="#9f1239" strokeWidth="2" />
          <line x1="572" y1="139" x2="572" y2="222" stroke="#fda4af" strokeWidth="1.5" strokeDasharray="3 3" opacity="0.3" />

          {/* AUDIENCE COUPLE SITTING IN VIP ROW */}
          {/* Left Person (Eating popcorn!) */}
          <g className="animate-popcorn-eater">
            <circle cx="347" cy="120" r="16" fill="#0d0d12" stroke="#222" strokeWidth="1" />
            <path d="M 322 142 C 322 128, 372 128, 372 142 Z" fill="#09090d" />
            <path d="M 365 138 Q 358 128 352 126" stroke="#09090d" strokeWidth="3.5" strokeLinecap="round" />
            <circle cx="352" cy="125" r="2.5" fill="#fde047" />
          </g>

          {/* Right Person (Whispering / Leaning in love seat!) */}
          <g className="animate-whisper-couple">
            <circle cx="565" cy="120" r="15" fill="#0d0d12" stroke="#222" strokeWidth="1" />
            <path d="M 542 142 C 542 128, 590 128, 590 142 Z" fill="#09090d" />
            <path d="M 555 109 Q 565 106 575 110" stroke="#ffffff" strokeWidth="1.5" strokeLinecap="round" opacity="0.4" />
          </g>

          {/* Outer Left Armrest */}
          <rect x="240" y="152" width="28" height="90" rx="12" fill="url(#audArmrest)" stroke="#444" strokeWidth="1" />
          <circle cx="254" cy="167" r="7" fill="#141414" stroke="#666" strokeWidth="1" />
          <circle cx="254" cy="167" r="3" fill="#38bdf8" opacity="0.8" />

          {/* VIP CENTER CONSOLE & FOOD TRAY */}
          <rect x="430" y="158" width="60" height="88" rx="14" fill="url(#audArmrest)" stroke="#555" strokeWidth="1.5" />

          {/* REAL CINEMA POPCORN TUB ON CONSOLE */}
          <g transform="translate(442, 162)">
            <path d="M 4 8 L 32 8 L 28 32 L 8 32 Z" fill="#ffffff" stroke="#dc2626" strokeWidth="1" />
            <line x1="12" y1="8" x2="11" y2="32" stroke="#dc2626" strokeWidth="2.5" />
            <line x1="18" y1="8" x2="18" y2="32" stroke="#dc2626" strokeWidth="2.5" />
            <line x1="24" y1="8" x2="25" y2="32" stroke="#dc2626" strokeWidth="2.5" />
            <circle cx="10" cy="6" r="3.5" fill="#fde047" stroke="#f59e0b" strokeWidth="0.8" />
            <circle cx="16" cy="5" r="4.5" fill="#fef08a" stroke="#f59e0b" strokeWidth="0.8" />
            <circle cx="23" cy="5" r="4" fill="#fde047" stroke="#f59e0b" strokeWidth="0.8" />
            <circle cx="27" cy="7" r="3" fill="#fef08a" stroke="#f59e0b" strokeWidth="0.8" />
            <circle cx="18" cy="2" r="3.5" fill="#fde047" stroke="#fbbf24" strokeWidth="0.8" />
          </g>

          {/* Illuminated Couple Cup Holders with Drinks */}
          <circle cx="446" cy="214" r="8" fill="#141414" stroke="#f59e0b" strokeWidth="1.2" />
          <circle cx="446" cy="214" r="4" fill="#f59e0b" opacity="0.9" />
          <line x1="446" y1="214" x2="450" y2="201" stroke="#ffffff" strokeWidth="1.5" strokeLinecap="round" />

          <circle cx="474" cy="214" r="8" fill="#141414" stroke="#38bdf8" strokeWidth="1.2" />
          <circle cx="474" cy="214" r="4" fill="#38bdf8" opacity="0.9" />
          <line x1="474" y1="214" x2="478" y2="201" stroke="#ffffff" strokeWidth="1.5" strokeLinecap="round" />

          {/* Outer Right Armrest */}
          <rect x="652" y="152" width="28" height="90" rx="12" fill="url(#audArmrest)" stroke="#444" strokeWidth="1" />
          <circle cx="666" cy="167" r="7" fill="#141414" stroke="#666" strokeWidth="1" />
          <circle cx="666" cy="167" r="3" fill="#38bdf8" opacity="0.8" />
        </g>

        {/* ============================================================== */}
        {/* MULTI-TIER AISLE STEP GUIDE LIGHTS (Left & Right Sides) */}
        {/* ============================================================== */}
        <g>
          {/* Left Aisle Step Lights (Row E down to Row A) */}
          <circle cx="26" cy="226" r="3.5" fill="#f59e0b" filter="drop-shadow(0 0 6px #f59e0b)" />
          <circle cx="30" cy="172" r="3" fill="#f59e0b" opacity="0.9" />
          <circle cx="34" cy="116" r="2.5" fill="#f59e0b" opacity="0.8" />
          <circle cx="38" cy="68" r="2" fill="#f59e0b" opacity="0.6" />
          <circle cx="42" cy="20" r="1.8" fill="#f59e0b" opacity="0.5" />

          {/* Right Aisle Step Lights (Row E down to Row A) */}
          <circle cx="894" cy="226" r="3.5" fill="#f59e0b" filter="drop-shadow(0 0 6px #f59e0b)" />
          <circle cx="890" cy="172" r="3" fill="#f59e0b" opacity="0.9" />
          <circle cx="886" cy="116" r="2.5" fill="#f59e0b" opacity="0.8" />
          <circle cx="882" cy="68" r="2" fill="#f59e0b" opacity="0.6" />
          <circle cx="878" cy="20" r="1.8" fill="#f59e0b" opacity="0.5" />
        </g>
      </svg>

      {/* INTERACTIVE AUDIENCE VIBE BAR & ROW IDENTIFIER */}
      <div className="flex items-center justify-between px-3 sm:px-6 py-1 -mt-1 bg-black/70 rounded-full border border-white/10 backdrop-blur-md max-w-2xl mx-auto shadow-lg pointer-events-auto">
        {/* Left: Theater Status & Tier Capacity */}
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
            <span className="text-[10px] font-mono text-emerald-400 font-bold uppercase tracking-wider">
              98% Occupied
            </span>
          </div>
          <span className="text-neutral-600 hidden sm:inline">•</span>
          <span className="text-[10px] text-neutral-400 hidden sm:inline font-mono">
            5 Rows (A-E)
          </span>
        </div>

        {/* Center: Live Audience Reaction Triggers */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          <button
            type="button"
            onClick={() => handleEmojiReaction('🎉')}
            className="flex items-center gap-1 px-2 sm:px-2.5 py-0.5 rounded-full bg-gradient-to-r from-red-600 to-amber-600 hover:from-red-500 hover:to-amber-500 text-white text-[10px] font-black tracking-tight active:scale-90 transition-all shadow-md shadow-red-900/40 cursor-pointer"
            title="Blast Party Confetti Papers!"
          >
            <span>🎉</span>
            <span className="hidden xs:inline">Party Blast</span>
          </button>

          <button
            type="button"
            onClick={() => handleEmojiReaction('🍿')}
            className="px-1.5 sm:px-2 py-0.5 rounded-full bg-white/10 hover:bg-white/20 text-[11px] active:scale-90 transition-all cursor-pointer"
            title="Popcorn reaction"
          >
            🍿
          </button>

          <button
            type="button"
            onClick={() => handleEmojiReaction('👏')}
            className="px-1.5 sm:px-2 py-0.5 rounded-full bg-white/10 hover:bg-white/20 text-[11px] active:scale-90 transition-all cursor-pointer"
            title="Applause / Clapping"
          >
            👏
          </button>

          <button
            type="button"
            onClick={() => handleEmojiReaction('🔥')}
            className="px-1.5 sm:px-2 py-0.5 rounded-full bg-white/10 hover:bg-white/20 text-[11px] active:scale-90 transition-all cursor-pointer"
            title="Hype / Fire"
          >
            🔥
          </button>

          <button
            type="button"
            onClick={() => handleEmojiReaction('😮')}
            className="px-1.5 sm:px-2 py-0.5 rounded-full bg-white/10 hover:bg-white/20 text-[11px] active:scale-90 transition-all cursor-pointer"
            title="Wow / Shock"
          >
            😮
          </button>
        </div>

        {/* Right: Sound & Theater Status */}
        <div className="flex items-center gap-1.5">
          <div className="w-1.5 h-1.5 rounded-full bg-amber-400" />
          <span className="text-[10px] font-mono text-amber-400 font-bold uppercase tracking-wider hidden sm:inline">
            Row A-VIP
          </span>
        </div>
      </div>
    </div>
  );
});

export default CinemaHallAuditorium;
