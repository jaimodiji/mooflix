import React from 'react';
import { X, Play, Sparkles, AlertTriangle } from 'lucide-react';
import { ContentItem, ServerProvider } from '../types';

interface PlayerSelectModalProps {
  item: ContentItem;
  season?: number;
  episode?: number;
  imdbId?: string | null;
  onSelectServer: (provider: ServerProvider) => void;
  onClose: () => void;
}

export const PlayerSelectModal: React.FC<PlayerSelectModalProps> = ({
  item,
  season,
  episode,
  onSelectServer,
  onClose,
}) => {
  const isSeries = item.type !== 'movie';
  const subtitle = isSeries && season && episode ? `Season ${season} • Episode ${episode}` : `${item.year || ''} • ${item.type === 'movie' ? 'Movie' : 'Series'}`;

  const handleChoose = (provider: ServerProvider) => {
    onSelectServer(provider);
  };

  const players = [
    {
      id: '1' as ServerProvider,
      name: 'Server 1',
      tag: 'Fast HD • Multi-Audio • Auto-Switch',
      badge: 'Primary',
    },
    {
      id: '2' as ServerProvider,
      name: 'Server 2',
      tag: 'Dual Audio (Hindi/Eng) • 4K Ultra HD',
      badge: 'Play4U',
    },
    {
      id: '3' as ServerProvider,
      name: 'Server 3',
      tag: 'Fast Mirror • Backup HD Stream',
      badge: 'Backup',
    },
    {
      id: '4' as ServerProvider,
      name: 'Server 4',
      tag: 'Ultra HD Reserve Mirror',
      badge: 'Reserve',
    },
  ];

  return (
    <div
      className="fixed inset-0 z-[999990] bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 select-none animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-sm sm:max-w-md rounded-3xl bg-[#0d0e14] border border-white/15 p-5 sm:p-6 shadow-[0_25px_80px_rgba(0,0,0,0.95)] text-center overflow-hidden animate-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="absolute -top-24 -left-24 w-48 h-48 bg-red-600/20 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 -right-24 w-48 h-48 bg-blue-600/20 rounded-full blur-3xl pointer-events-none" />

        <button
          type="button"
          onClick={onClose}
          aria-label="Close"
          className="absolute top-4 right-4 w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 text-neutral-400 hover:text-white flex items-center justify-center transition-colors cursor-pointer"
        >
          <X size={16} />
        </button>

        <div className="mb-4 text-center">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-md bg-white/10 border border-white/15 text-[11px] font-bold text-white mb-2">
            <Sparkles size={12} className="text-amber-400" />
            <span>Select Ad-Free Player</span>
          </div>
          <h3 className="text-base sm:text-lg font-black text-white truncate max-w-[280px] sm:max-w-[340px] mx-auto">
            {item.title}
          </h3>
          <p className="text-xs text-neutral-400 font-medium mt-0.5">{subtitle}</p>
        </div>

        <div className="space-y-2.5 my-4">
          {players.map((p) => (
            <button
              key={p.id}
              type="button"
              onClick={() => handleChoose(p.id)}
              className="w-full p-3 sm:p-3.5 rounded-2xl bg-white/[0.04] hover:bg-white/[0.09] border border-white/10 hover:border-white/25 active:scale-98 transition-all duration-200 flex items-center justify-between group cursor-pointer shadow-md text-left"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-white/10 group-hover:bg-white text-white group-hover:text-black flex items-center justify-center transition-all shadow-md shrink-0">
                  <Play size={16} fill="currentColor" className="ml-0.5" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs sm:text-sm font-bold text-white group-hover:text-white">
                      {p.name}
                    </span>
                    <span className="text-[10px] px-1.5 py-0.5 rounded font-bold bg-white/10 text-neutral-300 border border-white/10">
                      {p.badge}
                    </span>
                  </div>
                  <p className="text-[11px] text-neutral-400 mt-0.5">{p.tag}</p>
                </div>
              </div>
            </button>
          ))}
        </div>

        <div className="mt-3 pt-3 border-t border-white/10 flex items-center justify-center gap-1.5 text-[11px] sm:text-xs text-neutral-300 font-medium bg-white/[0.03] p-2.5 rounded-xl border border-white/5">
          <AlertTriangle size={13} className="text-amber-400 shrink-0" />
          <span>Auto-failover switches automatically if a server is unavailable.</span>
        </div>
      </div>
    </div>
  );
};

export default PlayerSelectModal;
