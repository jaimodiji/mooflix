import React from 'react';
import { Play, Clock, Eye, Radio, Sparkles, Layers, Tv } from 'lucide-react';
import { 
  APIMatch, 
  formatMatchTime, 
  getSportPosterUrl, 
  SPORT_DEFAULT_IMAGES 
} from '../services/sportsService';

interface SportMatchCardProps {
  match: APIMatch;
  onSelect: (match: APIMatch) => void;
}

const CATEGORY_EMOJIS: Record<string, string> = {
  'football': '⚽',
  'soccer': '⚽',
  'basketball': '🏀',
  'american-football': '🏈',
  'cricket': '🏏',
  'ice-hockey': '🏒',
  'hockey': '🏒',
  'wrestling': '🤼',
  'fight': '🥊',
  'combat': '🥊',
  'golf': '⛳',
  'rugby': '🏉',
  'australian-football': '🏉',
  '24-7-streams': '📺',
  '24-7': '📺',
  'default': '🏆'
};

export const SportMatchCard: React.FC<SportMatchCardProps> = ({ match, onSelect }) => {
  const ppv = match.rawPpvStream;
  const timeInfo = formatMatchTime(match.date, ppv?.starts_at);
  const isLive = timeInfo.status === 'live';

  const catKey = (match.category || 'default').toLowerCase().replace(/[^a-z0-9]/g, '-');
  const catEmoji = CATEGORY_EMOJIS[catKey] || CATEGORY_EMOJIS.default;
  const posterUrl = getSportPosterUrl(match.poster, match.category);

  // Dynamic ambient team color glow (from PPV.st colors API)
  const primaryColor = ppv?.colors?.[0] || '#e50914';
  const hasSubstreams = Boolean(ppv?.substreams && ppv.substreams.length > 0);
  const substreamCount = (ppv?.substreams?.length || 0) + 1;

  // Viewers formatting
  const viewers = Number(match.viewers) || 0;
  const formattedViewers = viewers >= 1000 ? `${(viewers / 1000).toFixed(1)}k` : `${viewers}`;

  const handleClick = () => {
    onSelect(match);
  };

  return (
    <div
      onClick={handleClick}
      className="group relative rounded-2xl sm:rounded-3xl bg-[#0e0f18]/80 hover:bg-[#151726]/95 backdrop-blur-3xl border border-white/[0.12] hover:border-white/30 transition-all duration-300 cursor-pointer shadow-[inset_0_1px_1px_rgba(255,255,255,0.18),0_12px_40px_rgba(0,0,0,0.6)] hover:shadow-[inset_0_1px_2px_rgba(255,255,255,0.3),0_20px_50px_rgba(0,0,0,0.85)] active:scale-[0.985] flex flex-col justify-between overflow-hidden select-none"
    >
      {/* iOS 27 Specular Ambient Glow underneath */}
      <div 
        className="absolute -top-12 -right-12 w-36 h-36 rounded-full blur-3xl opacity-20 group-hover:opacity-40 transition-opacity pointer-events-none"
        style={{ backgroundColor: primaryColor }}
      />

      {/* 1. TOP 16:9 POSTER WITH DYNAMIC OVERLAYS */}
      <div className="relative w-full aspect-[16/9] overflow-hidden bg-black/60">
        <img
          src={posterUrl}
          alt={match.title}
          className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-105"
          loading="lazy"
          onError={(e) => {
            const target = e.target as HTMLImageElement;
            const fallback = SPORT_DEFAULT_IMAGES[catKey] || SPORT_DEFAULT_IMAGES.default;
            if (target.src !== fallback) {
              target.src = fallback;
            }
          }}
        />

        {/* Ambient Top & Bottom Glass Gradients */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#0e0f18] via-transparent to-black/70 pointer-events-none" />

        {/* Top iOS Island Badges */}
        <div className="absolute top-2 sm:top-3 left-2 sm:left-3 right-2 sm:right-3 flex items-center justify-between gap-1 sm:gap-2 z-10 pointer-events-none">
          {/* League / Category Pill */}
          <span className="flex items-center gap-1 sm:gap-1.5 px-2 sm:px-2.5 py-0.5 sm:py-1 rounded-full bg-black/70 backdrop-blur-xl border border-white/20 text-white text-[9px] sm:text-[11px] font-bold tracking-tight shadow-md">
            <span>{catEmoji}</span>
            <span className="truncate max-w-[70px] sm:max-w-[120px]">{match.league || match.category}</span>
          </span>

          {/* Live indicator vs Start Time */}
          {isLive ? (
            <span className="flex items-center gap-1 sm:gap-1.5 px-2 sm:px-2.5 py-0.5 sm:py-1 rounded-full bg-red-600/90 border border-red-400 text-white text-[9px] sm:text-[10px] font-black tracking-wider shadow-[0_0_16px_rgba(239,68,68,0.8)] backdrop-blur-md">
              <span className="w-1.5 h-1.5 rounded-full bg-white animate-ping inline-block" />
              LIVE
            </span>
          ) : (
            <span className="flex items-center gap-1 px-1.5 sm:px-2.5 py-0.5 sm:py-1 rounded-full bg-black/75 backdrop-blur-xl border border-white/20 text-amber-300 text-[9px] sm:text-[10px] font-bold shadow-md">
              <Clock size={10} className="text-amber-400" />
              <span className="truncate max-w-[60px] sm:max-w-none">{timeInfo.countdown}</span>
            </span>
          )}
        </div>

        {/* Bottom Poster Tag (Broadcaster & Multi-Feed info) */}
        <div className="absolute bottom-1.5 sm:bottom-2.5 left-2 sm:left-3 right-2 sm:right-3 flex items-center justify-between pointer-events-none">
          {/* Broadcaster / Source Tag */}
          {ppv?.source_tag && (
            <span className="px-1.5 sm:px-2 py-0.5 rounded-md bg-black/75 backdrop-blur-md text-[9px] sm:text-[10px] font-bold text-neutral-200 border border-white/15 truncate max-w-[100px] sm:max-w-[150px]">
              📺 {ppv.source_tag}
            </span>
          )}

          {/* Multi-Feed Substream Indicator */}
          {hasSubstreams && (
            <span className="flex items-center gap-1 px-1.5 sm:px-2 py-0.5 rounded-md bg-blue-500/30 text-blue-300 border border-blue-400/40 text-[9px] sm:text-[10px] font-bold backdrop-blur-md">
              <Layers size={10} />
              <span>{substreamCount} Feeds</span>
            </span>
          )}
        </div>

        {/* Center Glass Play Button on Card Hover */}
        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none">
          <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-white/95 text-black flex items-center justify-center shadow-[0_10px_25px_rgba(0,0,0,0.8)] backdrop-blur-md transform scale-90 group-hover:scale-100 transition-transform duration-300">
            <Play size={18} className="fill-black translate-x-0.5" />
          </div>
        </div>
      </div>

      {/* 2. CARD CONTENT & METADATA (iOS 27 Glass Body) */}
      <div className="p-2.5 sm:p-3.5 md:p-4 flex flex-col gap-2 sm:gap-2.5 flex-1 justify-between">
        {/* Match / Event Title & Team Badges */}
        <div>
          {match.teams?.home && match.teams?.away ? (
            <div className="flex items-center gap-2 mb-1.5">
              <div className="flex items-center gap-1.5 min-w-0 flex-1">
                {match.teams.home.badge ? (
                  <img
                    src={match.teams.home.badge}
                    alt={match.teams.home.name}
                    className="w-5 h-5 object-contain shrink-0"
                    loading="lazy"
                    onError={(e) => { (e.target as HTMLElement).style.display = 'none'; }}
                  />
                ) : null}
                <span className="text-white text-xs sm:text-sm font-bold truncate">
                  {match.teams.home.name}
                </span>
              </div>
              <span className="text-[10px] font-black text-neutral-500 uppercase px-1 bg-white/5 rounded border border-white/5 shrink-0">
                vs
              </span>
              <div className="flex items-center gap-1.5 min-w-0 flex-1 justify-end">
                <span className="text-white text-xs sm:text-sm font-bold truncate text-right">
                  {match.teams.away.name}
                </span>
                {match.teams.away.badge ? (
                  <img
                    src={match.teams.away.badge}
                    alt={match.teams.away.name}
                    className="w-5 h-5 object-contain shrink-0"
                    loading="lazy"
                    onError={(e) => { (e.target as HTMLElement).style.display = 'none'; }}
                  />
                ) : null}
              </div>
            </div>
          ) : (
            <h3 className="text-white text-xs sm:text-sm md:text-base font-bold line-clamp-2 leading-snug group-hover:text-red-400 transition-colors">
              {match.title}
            </h3>
          )}

          {/* Timing details: Local Date + IST */}
          <div className="flex items-center gap-1 sm:gap-2 mt-1 sm:mt-1.5 text-[10px] sm:text-[11px] text-neutral-400 flex-wrap">
            <span>{timeInfo.formattedDate}</span>
            <span>•</span>
            <span className="text-neutral-300">{timeInfo.formattedTime}</span>
            <span className="px-1 sm:px-1.5 py-0.2 rounded bg-white/10 text-neutral-300 text-[9px] sm:text-[10px] font-mono border border-white/10">
              {timeInfo.istTime}
            </span>
          </div>
        </div>

        {/* 3. CARD FOOTER: Viewers + iOS Liquid Action Button */}
        <div className="pt-1.5 sm:pt-2 border-t border-white/[0.08] flex items-center justify-between gap-1 sm:gap-2">
          {/* Live Viewers Indicator */}
          <div className="flex items-center gap-1 sm:gap-1.5 text-[10px] sm:text-[11px] text-neutral-400">
            {isLive ? (
              <span className="flex items-center gap-1 text-emerald-400 font-semibold truncate">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse shrink-0" />
                <span>{formattedViewers}</span>
              </span>
            ) : (
              <span className="flex items-center gap-1 text-neutral-400 truncate">
                <Clock size={11} className="shrink-0" />
                <span>Upcoming</span>
              </span>
            )}
          </div>

          {/* Liquid Glass Stream Button */}
          <div className="px-2.5 sm:px-3 py-1 sm:py-1.5 rounded-full bg-white/10 group-hover:bg-red-600 text-white font-bold text-[11px] sm:text-xs flex items-center gap-1 sm:gap-1.5 transition-all duration-300 shadow-sm border border-white/15 group-hover:border-red-500 shrink-0">
            <Play size={10} className="fill-white" />
            <span>Watch</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SportMatchCard;
