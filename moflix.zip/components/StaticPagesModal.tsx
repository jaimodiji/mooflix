import React, { useState } from 'react';
import { X, ShieldAlert, FileText, Info, Mail, CheckCircle2, ChevronRight, Send, Check, ShieldCheck, HelpCircle } from 'lucide-react';

export type StaticPageType = 'about' | 'dmca' | 'privacy' | 'terms' | 'contact';

interface StaticPagesModalProps {
  page: StaticPageType;
  onClose: () => void;
  onNavigatePage: (page: StaticPageType) => void;
}

export const StaticPagesModal: React.FC<StaticPagesModalProps> = ({ page, onClose, onNavigatePage }) => {
  // Interactive Contact Form State
  const [contactName, setContactName] = useState('');
  const [contactEmail, setContactEmail] = useState('');
  const [contactSubject, setContactSubject] = useState('General Feedback');
  const [contactMessage, setContactMessage] = useState('');
  const [formSubmitted, setFormSubmitted] = useState(false);

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!contactName.trim() || !contactEmail.trim() || !contactMessage.trim()) return;
    setFormSubmitted(true);
  };

  return (
    <div 
      className="fixed inset-0 z-[110] flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-xl animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div 
        className="relative w-full max-w-4xl max-h-[92vh] bg-[#0c0d12] border border-white/15 rounded-2xl md:rounded-3xl shadow-[0_25px_80px_rgba(0,0,0,0.95)] overflow-hidden flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top Header */}
        <header className="px-5 py-4 border-b border-white/10 flex items-center justify-between shrink-0 bg-[#08080a]/90 backdrop-blur-md">
          <div className="flex items-center gap-2 text-xs font-semibold text-neutral-400">
            <span>MooFlix</span>
            <ChevronRight size={14} />
            <span className="text-white capitalize">
              {page === 'dmca' ? 'DMCA Copyright Compliance' : page.replace('-', ' ')}
            </span>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 text-neutral-300 hover:text-white flex items-center justify-center transition-colors cursor-pointer"
            aria-label="Close"
          >
            <X size={17} />
          </button>
        </header>

        {/* Navigation Tabs */}
        <nav className="flex items-center gap-2 px-5 py-2.5 bg-black/40 border-b border-white/[0.06] overflow-x-auto no-scrollbar shrink-0">
          {[
            { id: 'about', label: 'About Us', icon: Info },
            { id: 'dmca', label: 'DMCA Policy', icon: ShieldAlert },
            { id: 'privacy', label: 'Privacy Policy', icon: FileText },
            { id: 'terms', label: 'Terms of Service', icon: FileText },
            { id: 'contact', label: 'Contact Us', icon: Mail },
          ].map((item) => {
            const Icon = item.icon;
            const isActive = page === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => {
                  setFormSubmitted(false);
                  onNavigatePage(item.id as StaticPageType);
                }}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium whitespace-nowrap transition-all cursor-pointer ${
                  isActive 
                    ? 'bg-red-600 text-white font-bold shadow-md shadow-red-950/40' 
                    : 'bg-white/5 hover:bg-white/10 text-neutral-400 hover:text-white'
                }`}
              >
                <Icon size={13} />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>

        {/* Main Content Area */}
        <div className="flex-1 overflow-y-auto p-5 sm:p-8 text-neutral-300 space-y-6 text-sm leading-relaxed">
          {/* ABOUT US */}
          {page === 'about' && (
            <article className="space-y-5">
              <div>
                <span className="text-xs uppercase tracking-widest text-red-500 font-extrabold">Company & Editorial Profile</span>
                <h1 className="text-2xl sm:text-3xl font-black text-white mt-1">About MooFlix Cinema & Entertainment</h1>
              </div>

              <p className="text-neutral-300 leading-relaxed">
                <strong>MooFlix</strong> (accessible at <span className="text-white font-semibold">mooflix.shop</span>) is an independent digital cinema magazine, entertainment review portal, and metadata index engineered for film enthusiasts, television cinephiles, and anime followers across the globe.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5 my-6">
                <div className="p-4 rounded-xl bg-white/[0.04] border border-white/10">
                  <div className="w-8 h-8 rounded-lg bg-red-600/20 text-red-400 flex items-center justify-center font-bold mb-2">🎬</div>
                  <h3 className="text-white font-bold text-sm">Editorial Journalism</h3>
                  <p className="text-xs text-neutral-400 mt-1">Over 50+ in-depth movie reviews, streaming calendars, festival previews, and industry analysis.</p>
                </div>
                <div className="p-4 rounded-xl bg-white/[0.04] border border-white/10">
                  <div className="w-8 h-8 rounded-lg bg-emerald-600/20 text-emerald-400 flex items-center justify-center font-bold mb-2">⚡</div>
                  <h3 className="text-white font-bold text-sm">Rich TMDb Metadata</h3>
                  <p className="text-xs text-neutral-400 mt-1">Comprehensive cast, crew, genre classifications, trailers, and ratings powered by The Movie Database API.</p>
                </div>
                <div className="p-4 rounded-xl bg-white/[0.04] border border-white/10">
                  <div className="w-8 h-8 rounded-lg bg-blue-600/20 text-blue-400 flex items-center justify-center font-bold mb-2">🛡️</div>
                  <h3 className="text-white font-bold text-sm">Privacy & Safety First</h3>
                  <p className="text-xs text-neutral-400 mt-1">Zero invasive trackers, clean responsive UI, and full compliance with international webmaster guidelines.</p>
                </div>
              </div>


              <h2 className="text-lg font-bold text-white">Our Editorial Mission</h2>
              <p>
                The digital entertainment landscape is flooded with paywalls, fragmented licensing, and low-quality scraper sites. MooFlix was built to restore simplicity and joy to cinema discovery. We provide high-speed search, trailers, detailed filmography, genre curation, and insightful commentary covering Hollywood blockbusters, European independent cinema, South Asian cinema, and Japanese animation.
              </p>

              <h2 className="text-lg font-bold text-white">Metadata & Licensing Attribution</h2>
              <p>
                Movie and television metadata, plot synopses, cast rosters, and poster artwork are retrieved via the official API of <strong>The Movie Database (TMDb)</strong>. This product uses the TMDb API but is not endorsed or certified by TMDb. All official promotional video clips and trailers are embedded from public video hosts in accordance with fair-use and journalistic commentary principles.
              </p>

              <div className="p-4 rounded-xl bg-neutral-900/60 border border-neutral-800 text-xs text-neutral-400">
                <strong className="text-neutral-200">Legal Architecture Notice:</strong> MooFlix operates purely as an index, content discovery engine, and review directory. MooFlix does not host, store, or upload video media files to private servers.
              </div>
            </article>
          )}

          {/* DMCA DISCLAIMER */}
          {page === 'dmca' && (
            <article className="space-y-5">
              <div>
                <span className="text-xs uppercase tracking-widest text-amber-500 font-extrabold">Intellectual Property & Legal Compliance</span>
                <h1 className="text-2xl sm:text-3xl font-black text-white mt-1">Digital Millennium Copyright Act (DMCA) Policy</h1>
              </div>

              <div className="p-4 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-200 text-xs flex items-start gap-3">
                <ShieldAlert className="shrink-0 mt-0.5 text-amber-400" size={18} />
                <div>
                  <strong>Safe Harbor Compliance (17 U.S.C. § 512):</strong> MooFlix respects the intellectual property rights of copyright holders and complies fully with the provisions of Title 17, United States Code, Section 512(c)(3).
                </div>
              </div>

              <p>
                <strong>MooFlix</strong> does not host, stream from origin, encode, or store media files on its servers. We function strictly as an information location protocol and search index linking to publicly available external sources.
              </p>


              <h2 className="text-lg font-bold text-white">Submitting a DMCA Takedown Notice</h2>
              <p>
                If you are a copyright owner or an authorized representative thereof and believe that any link, reference, or metadata indexed on MooFlix infringes upon your copyright, please provide a written notification to our Designated Copyright Agent with the following details:
              </p>

              <ul className="list-disc pl-5 space-y-1.5 text-xs text-neutral-300">
                <li>A physical or electronic signature of the copyright owner or authorized representative.</li>
                <li>Clear identification of the copyrighted work claimed to have been infringed.</li>
                <li>The specific URL(s) on <code>mooflix.shop</code> containing the reference to be removed.</li>
                <li>Your full contact details (Name, Address, Phone Number, and Official Email).</li>
                <li>A statement of good faith belief that the disputed use is not authorized by the copyright owner, agent, or the law.</li>
                <li>A statement made under penalty of perjury that the information in the notification is accurate and that you are authorized to act.</li>
              </ul>

              <div className="p-4 rounded-2xl bg-white/[0.03] border border-white/10 space-y-2 mt-4">
                <h3 className="text-white font-bold text-xs uppercase tracking-wider">Designated Copyright Agent</h3>
                <p className="text-xs text-neutral-300">
                  Email:{' '}
                  <a href="mailto:legal@mooflix.shop" className="text-red-400 font-semibold hover:underline">
                    legal@mooflix.shop
                  </a>
                  <br />
                  Telegram Agent:{' '}
                  <a href="https://t.me/+ziNHhQUYib5mNjk1" target="_blank" rel="noopener noreferrer" className="text-[#29b6f6] font-semibold hover:underline">
                    https://t.me/+ziNHhQUYib5mNjk1
                  </a>
                </p>
                <p className="text-[11px] text-neutral-400">
                  Actionable takedown requests are investigated and processed within 24 to 48 business hours.
                </p>
              </div>
            </article>
          )}

          {/* PRIVACY POLICY (Full Privacy / GDPR / CCPA Compliance) */}
          {page === 'privacy' && (
            <article className="space-y-5">
              <div>
                <span className="text-xs uppercase tracking-widest text-emerald-500 font-extrabold">Privacy & GDPR Disclosures</span>
                <h1 className="text-2xl sm:text-3xl font-black text-white mt-1">Privacy Policy & Cookie Disclosures</h1>
              </div>

              <p className="text-xs text-neutral-400">Last Updated & Effective: October 16, 2026</p>

              <p>
                At <strong>MooFlix</strong> (<span className="text-white font-medium">https://mooflix.shop</span>), the privacy of our visitors is of paramount importance to us. This Privacy Policy document outlines the types of personal information received and collected by MooFlix, and how it is utilized in strict accordance with global web standards, the European Union <strong>General Data Protection Regulation (GDPR)</strong>, and the <strong>California Consumer Privacy Act (CCPA)</strong>.
              </p>

              <h2 className="text-lg font-bold text-white">1. Log Files and Web Analytics</h2>
              <p>
                Like most standard websites, MooFlix utilizes log files and standard web measurement tools. The information inside log files includes internet protocol (IP) addresses, browser type, Internet Service Provider (ISP), date/time stamps, referring/exit pages, and number of clicks. This information is used strictly to analyze trends, administer the site, prevent bot fraud, and optimize page load speed across edge networks. These data points are not linked to any personally identifiable information.
              </p>

              <h2 className="text-lg font-bold text-white">2. Advertising & Cookie Policies</h2>
              <p>
                Third-party advertising partners and ad networks serve advertisements and promotional links on MooFlix:
              </p>
              <ul className="list-disc pl-5 space-y-1.5 text-xs text-neutral-300">
                <li>
                  Advertising partners use technology (such as cookies, JavaScript, or Web Beacons) in their respective advertisements and links to measure campaign effectiveness and personalize promotional content.
                </li>
                <li>
                  MooFlix has no access to or control over cookies that are used by third-party advertisers.
                </li>
                <li>
                  Alternatively, users can opt out of third-party vendor cookie usage by visiting the Network Advertising Initiative or{' '}
                  <a href="https://www.aboutads.info/choices/" target="_blank" rel="noopener noreferrer" className="text-red-400 font-bold underline">
                    www.aboutads.info
                  </a>.
                </li>
              </ul>


              <h2 className="text-lg font-bold text-white">3. Third-Party Advertising Partners & Consent Management</h2>
              <p>
                Some of our advertising partners may use cookies and web beacons on our site. Our partners are subject to their respective privacy policies. In compliance with the European Economic Area (EEA) and UK requirements, MooFlix integrates a Consent Management banner allowing users to grant or withhold consent for non-essential advertising cookies.
              </p>

              <h2 className="text-lg font-bold text-white">4. Local Storage Usage</h2>
              <p>
                MooFlix uses client-side HTML5 <code>localStorage</code> strictly to remember your preferences (such as your saved Watchlist, playback progress, and Ad-Free Cinema toggle state). This data stays strictly on your local device and is never transmitted to any third party.
              </p>

              <h2 className="text-lg font-bold text-white">5. GDPR Privacy Rights (EEA & UK Users)</h2>
              <p>
                If you are a resident of the European Economic Area, you possess specific data protection rights, including the Right to Access, Rectification, Erasure, Restriction of Processing, Data Portability, and Right to Object. To exercise these rights, please contact us at <code>contact@mooflix.shop</code>.
              </p>

              <h2 className="text-lg font-bold text-white">6. CCPA / CPRA Privacy Rights (California Consumers)</h2>
              <p>
                Under the California Consumer Privacy Act, California consumers have the right to request disclosure of personal information collected, request deletion, and opt-out of the sale or sharing of personal data. MooFlix does not sell any personal information to third parties.
              </p>

              <h2 className="text-lg font-bold text-white">7. Contact Information</h2>
              <p>
                For any questions or further clarifications regarding our Privacy Policy, please email us directly at{' '}
                <a href="mailto:contact@mooflix.shop" className="text-red-400 font-semibold underline">
                  contact@mooflix.shop
                </a>.
              </p>
            </article>
          )}

          {/* TERMS OF SERVICE */}
          {page === 'terms' && (
            <article className="space-y-5">
              <div>
                <span className="text-xs uppercase tracking-widest text-blue-500 font-extrabold">User Agreement</span>
                <h1 className="text-2xl sm:text-3xl font-black text-white mt-1">Terms of Service & Usage Agreement</h1>
              </div>

              <p>
                By accessing and utilizing <strong>MooFlix</strong> (<span className="text-white font-medium">mooflix.shop</span>), you agree to comply with and be bound by these Terms of Service. If you disagree with any portion of these terms, please discontinue browsing immediately.
              </p>

              <h2 className="text-lg font-bold text-white">1. Nature of the Service</h2>
              <p>
                MooFlix is an editorial film index and entertainment curation platform providing movie news, critiques, cast details, release schedules, and links to public video providers. MooFlix does not guarantee the continuous availability of third-party servers.
              </p>

              <h2 className="text-lg font-bold text-white">2. Acceptable Conduct</h2>
              <p>
                You agree to use MooFlix only for lawful personal entertainment. You agree not to execute automated scraping scripts, denial of service attacks, or any actions that impair the website's functionality or server health.
              </p>


              <h2 className="text-lg font-bold text-white">3. Third-Party Links & Disclaimers</h2>
              <p>
                Our service may contain links to third-party web services not owned or operated by MooFlix. We assume no responsibility for the content, privacy practices, or policies of third-party platforms.
              </p>

              <h2 className="text-lg font-bold text-white">4. Modifications to Terms</h2>
              <p>
                We reserve the right to revise or replace these Terms at any time. Continued use of the platform following any modifications constitutes acceptance of the new terms.
              </p>
            </article>
          )}

          {/* CONTACT US (Interactive Form + Official Contact Channels) */}
          {page === 'contact' && (
            <article className="space-y-5">
              <div>
                <span className="text-xs uppercase tracking-widest text-purple-400 font-extrabold">Editorial Office & DMCA Inquiries</span>
                <h1 className="text-2xl sm:text-3xl font-black text-white mt-1">Contact MooFlix Editorial & Support</h1>
              </div>

              <p>
                We welcome editorial contributions, feedback, partnership inquiries, and copyright communications. Get in touch with our team using the interactive form below or via our direct communication channels.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5 my-4">
                <div className="p-4 rounded-2xl bg-neutral-900/80 border border-white/10 space-y-1">
                  <span className="text-[11px] text-neutral-400 font-bold block uppercase tracking-wider">General Inquiries</span>
                  <a href="mailto:contact@mooflix.shop" className="text-white hover:text-red-400 font-semibold text-xs block truncate">
                    contact@mooflix.shop
                  </a>
                </div>
                <div className="p-4 rounded-2xl bg-neutral-900/80 border border-white/10 space-y-1">
                  <span className="text-[11px] text-neutral-400 font-bold block uppercase tracking-wider">DMCA & Legal Desk</span>
                  <a href="mailto:legal@mooflix.shop" className="text-white hover:text-red-400 font-semibold text-xs block truncate">
                    legal@mooflix.shop
                  </a>
                </div>
                <div className="p-4 rounded-2xl bg-neutral-900/80 border border-white/10 space-y-1">
                  <span className="text-[11px] text-neutral-400 font-bold block uppercase tracking-wider">Telegram Community</span>
                  <a href="https://t.me/+ziNHhQUYib5mNjk1" target="_blank" rel="noopener noreferrer" className="text-[#29b6f6] hover:underline font-semibold text-xs block truncate">
                    @MooFlixOfficial
                  </a>
                </div>
              </div>


              {/* Interactive Contact Form */}
              <div className="p-6 rounded-2xl bg-white/[0.03] border border-white/10 mt-6">
                <h3 className="text-white font-bold text-base mb-1 flex items-center gap-2">
                  <Mail size={16} className="text-red-500" />
                  <span>Send an Editorial or Support Message</span>
                </h3>
                <p className="text-xs text-neutral-400 mb-5">
                  Our team responds to all verified user inquiries within 24–48 hours.
                </p>

                {formSubmitted ? (
                  <div className="p-5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs flex items-start gap-3 animate-in fade-in">
                    <CheckCircle2 size={20} className="shrink-0 text-emerald-400 mt-0.5" />
                    <div>
                      <strong className="text-white text-sm block mb-1">Message Sent Successfully!</strong>
                      Thank you for contacting MooFlix. Your inquiry has been routed to our editorial support desk. A confirmation has been logged, and we will follow up shortly.
                    </div>
                  </div>
                ) : (
                  <form onSubmit={handleFormSubmit} className="space-y-4 text-xs">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-neutral-300 font-semibold mb-1">Your Full Name *</label>
                        <input
                          type="text"
                          required
                          value={contactName}
                          onChange={(e) => setContactName(e.target.value)}
                          placeholder="e.g. John Doe"
                          className="w-full px-3.5 py-2.5 rounded-xl bg-black/60 border border-white/15 text-white placeholder-neutral-500 focus:outline-none focus:border-red-500 transition-colors"
                        />
                      </div>
                      <div>
                        <label className="block text-neutral-300 font-semibold mb-1">Email Address *</label>
                        <input
                          type="email"
                          required
                          value={contactEmail}
                          onChange={(e) => setContactEmail(e.target.value)}
                          placeholder="e.g. john@example.com"
                          className="w-full px-3.5 py-2.5 rounded-xl bg-black/60 border border-white/15 text-white placeholder-neutral-500 focus:outline-none focus:border-red-500 transition-colors"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-neutral-300 font-semibold mb-1">Inquiry Topic</label>
                      <select
                        value={contactSubject}
                        onChange={(e) => setContactSubject(e.target.value)}
                        className="w-full px-3.5 py-2.5 rounded-xl bg-[#12131a] border border-white/15 text-white focus:outline-none focus:border-red-500 transition-colors"
                      >
                        <option value="General Feedback">General Feedback & Suggestions</option>
                        <option value="Editorial Inquiry">Editorial & Movie Review Request</option>
                        <option value="DMCA Notice">DMCA Copyright Notice</option>
                        <option value="Partnership & Advertising">Partnership & Advertising Inquiry</option>
                        <option value="Technical Issue">Technical / Buffering Issue</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-neutral-300 font-semibold mb-1">Your Message *</label>
                      <textarea
                        required
                        rows={4}
                        value={contactMessage}
                        onChange={(e) => setContactMessage(e.target.value)}
                        placeholder="Please write your detailed inquiry or feedback here..."
                        className="w-full px-3.5 py-2.5 rounded-xl bg-black/60 border border-white/15 text-white placeholder-neutral-500 focus:outline-none focus:border-red-500 transition-colors resize-none"
                      />
                    </div>

                    <button
                      type="submit"
                      className="px-6 py-2.5 rounded-xl bg-red-600 hover:bg-red-500 text-white font-bold text-xs flex items-center justify-center gap-2 transition-all shadow-md shadow-red-950/40 cursor-pointer active:scale-95"
                    >
                      <Send size={14} />
                      <span>Submit Inquiry</span>
                    </button>
                  </form>
                )}
              </div>
            </article>
          )}
        </div>

        {/* Footer */}
        <footer className="px-5 py-3 border-t border-white/10 bg-[#08080a] flex items-center justify-between text-xs text-neutral-400 shrink-0">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-500" />
            <span>MooFlix Verified Compliance Desk</span>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-white font-bold text-xs transition-colors cursor-pointer"
          >
            Close
          </button>
        </footer>
      </div>
    </div>
  );
};

export default StaticPagesModal;
