import React, { useState, useRef, useEffect } from 'react';
import { ContentItem } from '../types';
import { ArrowLeft, X, RefreshCw, ExternalLink, Download, ShieldCheck, Loader2 } from 'lucide-react';

interface InAppDownloadModalProps {
  url: string;
  serverName: string;
  item: ContentItem;
  season?: number;
  episode?: number;
  onClose: () => void;
}

const InAppDownloadModal: React.FC<InAppDownloadModalProps> = ({
  url,
  serverName,
  item,
  season = 1,
  episode = 1,
  onClose,
}) => {
  const [isLoading, setIsLoading] = useState(true);
  const [iframeKey, setIframeKey] = useState(1);
  const isMovie = item.type === 'movie';
  const iframeRef = useRef<HTMLIFrameElement>(null);

  // Anti-Ad Popup Interceptor: Strictly block all unauthorized popups
  useEffect(() => {
    const originalOpen = window.open;
    window.open = function () {
      return null;
    };
    return () => {
      window.open = originalOpen;
    };
  }, []);

  const handleReload = () => {
    setIsLoading(true);
    setIframeKey((prev) => prev + 1);
  };

  const handleOpenExternal = () => {
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  return (
    <div className="fixed inset-0 z-[800] bg-[#0c0c10] flex flex-col select-none animate-in fade-in duration-150">
      {/* Top App Header / Navigation Bar */}
      <header className="h-14 sm:h-16 bg-[#121217] border-b border-white/[0.08] px-3 sm:px-6 flex items-center justify-between shrink-0 shadow-lg z-20">
        {/* Left Side: Back Button & Title */}
        <div className="flex items-center gap-2 sm:gap-4 min-w-0">
          <button
            type="button"
            onClick={onClose}
            aria-label="Back"
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/[0.06] hover:bg-white/[0.12] active:scale-95 text-neutral-300 hover:text-white transition-all cursor-pointer text-xs sm:text-sm font-semibold border border-white/10"
          >
            <ArrowLeft size={16} />
            <span className="hidden sm:inline">Back</span>
          </button>

          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <span className="text-xs sm:text-sm font-bold text-white truncate max-w-[140px] sm:max-w-xs md:max-w-md">
                {item.title}
              </span>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-red-600/20 text-[#ff3844] border border-red-500/30 font-bold shrink-0">
                {!isMovie ? `S${season}:E${episode}` : 'Movie'}
              </span>
            </div>
            <div className="flex items-center gap-1.5 text-[10px] sm:text-xs text-neutral-400 truncate">
              <span className="text-emerald-400 font-semibold">{serverName}</span>
              <span>•</span>
              <span className="text-neutral-500 truncate">Clean In-App Download</span>
            </div>
          </div>
        </div>

        {/* Right Side: Actions (Reload, Close) */}
        <div className="flex items-center gap-1.5 sm:gap-2 shrink-0 ml-2">
          {/* Reload Button */}
          <button
            type="button"
            onClick={handleReload}
            aria-label="Reload Download Page"
            title="Reload"
            className="w-8 h-8 sm:w-9 sm:h-9 rounded-full bg-white/[0.06] hover:bg-white/[0.12] active:scale-95 text-neutral-300 hover:text-white flex items-center justify-center transition-all cursor-pointer border border-white/10"
          >
            <RefreshCw size={15} className={isLoading ? 'animate-spin text-red-400' : ''} />
          </button>

          {/* Close Button */}
          <button
            type="button"
            onClick={onClose}
            aria-label="Close"
            className="w-8 h-8 sm:w-9 sm:h-9 rounded-full bg-red-600/20 hover:bg-red-600 text-red-400 hover:text-white active:scale-95 flex items-center justify-center transition-all cursor-pointer border border-red-500/30"
          >
            <X size={16} />
          </button>
        </div>
      </header>

      {/* Main Download Content Area (Sandboxed In-App WebView with Ad Popup Shield) */}
      <main className="flex-1 relative w-full h-full bg-[#0d0d12] overflow-hidden">
        {/* Loading Spinner overlay */}
        {isLoading && (
          <div className="absolute inset-0 z-10 bg-[#0d0d12] flex flex-col items-center justify-center p-4">
            <div className="relative mb-4">
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-red-600 to-rose-700 flex items-center justify-center shadow-xl shadow-red-950/50 border border-white/20">
                <Download size={24} className="text-white animate-bounce" />
              </div>
              <div className="absolute -inset-1 rounded-2xl bg-red-600/30 blur-md -z-10 animate-pulse" />
            </div>
            <div className="flex items-center gap-2 text-white font-bold text-sm sm:text-base">
              <Loader2 size={16} className="animate-spin text-red-500" />
              <span>Loading Clean Download Link...</span>
            </div>
            <p className="text-neutral-400 text-xs mt-1 text-center max-w-xs">
              Direct high-speed download window. Popup ads & trackers blocked.
            </p>
          </div>
        )}

        {/* Embedded Download Window Iframe with red theme proxy */}
        <iframe
          ref={iframeRef}
          key={iframeKey}
          src={url.startsWith('http') ? `/api/download-proxy?url=${encodeURIComponent(url)}` : url}
          title={`Download ${item.title}`}
          className="w-full h-full border-0 bg-[#0d0d12]"
          allow="clipboard-write; fullscreen; encrypted-media"
          onLoad={() => setIsLoading(false)}
        />
      </main>

      {/* Bottom Info Bar */}
      <footer className="py-2.5 px-4 bg-[#111116] border-t border-white/[0.06] flex items-center justify-between text-[11px] text-neutral-400 shrink-0">
        <div className="flex items-center gap-1.5 truncate">
          <ShieldCheck size={14} className="text-emerald-400 shrink-0" />
          <span className="truncate text-emerald-300 font-semibold">Ad-Block Active: All popup ads and redirect attempts are blocked</span>
        </div>
      </footer>
    </div>
  );
};

export default InAppDownloadModal;
