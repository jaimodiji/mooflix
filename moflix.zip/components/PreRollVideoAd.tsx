import React, { useEffect } from 'react';

interface PreRollVideoAdProps {
  onComplete: () => void;
  title?: string;
}

export const PreRollVideoAd: React.FC<PreRollVideoAdProps> = ({ onComplete }) => {
  useEffect(() => {
    onComplete();
  }, [onComplete]);

  return null;
};

export default PreRollVideoAd;
