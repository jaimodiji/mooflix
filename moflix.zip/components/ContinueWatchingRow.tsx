import React, { useState, useRef } from 'react';
import { Play, ChevronLeft, ChevronRight, X, RotateCcw } from 'lucide-react';
import { ContinueWatchingItem, ContentItem } from '../types';
import LazyImage from './LazyImage';

interface ContinueWatchingRowProps {
  items: ContinueWatchingItem[];
  onResume: (item: ContinueWatchingItem) => void;
  onItemDetails: (item: ContentItem) => void;
  onRemove: (id: string) => void;
  onClearAll?: () => void;
}

export const ContinueWatchingRow: React.FC<ContinueWatchingRowProps> = ({
  items,
  onResume,
  onItemDetails,
  onRemove,
  onClearAll,
}) => {
  const [showLeftArrow, setShowLeftArrow] = useState(false);
  const [showRightArrow, setShowRightArrow] = useState(true);
  const scrollRef = useRef<HTMLDivElement>(null);

  const handleScroll = () => {
    if (scrollRef.current) {
      const { scrollLeft, scrollWidth, clientWidth } = scrollRef.current;
      setShowLeftArrow(scrollLeft > 20);
      setShowRightArrow(scrollLeft < scrollWidth - clientWidth - 20);
    }
  };

  const scroll = (direction: 'left' | 'right') => {
    if (scrollRef.current) {
      const scrollAmount = scrollRef.current.clientWidth * 0.75;
      scrollRef.current.scrollBy({
        left: direction === 'left' ? -scrollAmount : scrollAmount,
        behavior: 'smooth'
      });
    }
  };

  if (!items || items.length === 0) return null;

  return (
    <div id="continue-watching-section" className="relative mb-6 md:mb-10 select-none animate-fadeIn">
      {/* Section Header */}
      <div className="flex items-center justify-between mb-3 px-1">
        <div className="flex items-center gap-2.5">
          <div className="w-2.5 h-2.5 rounded-full bg-red-600 animate-pulse" />
          <h2 className="text-base md:text-xl font-bold text-white tracking-tight flex items-center gap-2">
            <span>Continue Watching</span>
            <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-white/10 text-neutral-300">
              {items.length}
            </span>
          </h2>
        </div>

        {onClearAll && items.length > 1 && (
          <button
            id="clear-continue-watching-btn"
            onClick={onClearAll}
            className="flex items-center gap-1 text-xs text-neutral-400 hover:text-red-400 transition-colors py-1 px-2 rounded hover:bg-white/[0.04] cursor-pointer"
          >
            <RotateCcw size={13} />
            <span>Clear History</span>
          </button>
        )}
      </div>

      {/* Row Container */}
      <div className="relative group/row">
        {/* iOS Glass Navigation Arrows */}
        <div 
          className={`absolute left-1 md:left-2 z-30 hidden md:block transition-opacity duration-200 ${
            showLeftArrow ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
          }`}
          style={{ top: '50%', transform: 'translateY(-50%)' }}
        >
          <button 
            type="button"
            onClick={() => scroll('left')}
            aria-label="Scroll left"
            className="w-10 h-10 md:w-11 md:h-11 rounded-full bg-[#0d0d14]/85 hover:bg-[#181824]/95 text-white backdrop-blur-2xl border border-white/25 shadow-[0_10px_35px_rgba(0,0,0,0.8),0_0_15px_rgba(255,255,255,0.06)] flex items-center justify-center transition-all duration-200 hover:scale-105 active:scale-95 cursor-pointer ring-1 ring-white/10"
          >
            <ChevronLeft size={20} className="translate-x-[-1px]" />
          </button>
        </div>

        <div 
          className={`absolute right-1 md:right-2 z-30 hidden md:block transition-opacity duration-200 ${
            showRightArrow ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
          }`}
          style={{ top: '50%', transform: 'translateY(-50%)' }}
        >
          <button 
            type="button"
            onClick={() => scroll('right')}
            aria-label="Scroll right"
            className="w-10 h-10 md:w-11 md:h-11 rounded-full bg-[#0d0d14]/85 hover:bg-[#181824]/95 text-white backdrop-blur-2xl border border-white/25 shadow-[0_10px_35px_rgba(0,0,0,0.8),0_0_15px_rgba(255,255,255,0.06)] flex items-center justify-center transition-all duration-200 hover:scale-105 active:scale-95 cursor-pointer ring-1 ring-white/10"
          >
            <ChevronRight size={20} className="translate-x-[1px]" />
          </button>
        </div>

        {/* Horizontal Card List (Exact same portrait card styling and dimensions as Genre MovieRow) */}
        <div
          ref={scrollRef}
          onScroll={handleScroll}
          className="flex overflow-x-auto overflow-y-hidden space-x-2.5 md:space-x-3.5 py-2 px-1 scroll-smooth no-scrollbar"
        >
          {items.map((item) => {
            const imageSource = item.thumbnail || item.backdrop;

            return (
              <div
                key={`cw-${item.id}-${item.season || 1}-${item.episode || 1}`}
                id={`continue-watching-card-${item.id}`}
                className="w-[130px] sm:w-[155px] md:w-[185px] lg:w-[200px] shrink-0"
              >
                <div 
                  className="group relative w-full overflow-hidden rounded-lg cursor-pointer bg-[#121212] transition-all duration-300 hover:scale-[1.03] hover:z-20 hover:shadow-[0_16px_36px_rgba(0,0,0,0.9)] select-none"
                  onClick={() => onResume(item)}
                >
                  <div className="relative aspect-[2/3] w-full bg-[#161616] overflow-hidden">
                    {/* Portrait Image */}
                    <LazyImage 
                      src={imageSource} 
                      alt={item.title} 
                      aspectRatio="portrait"
                      className="group-hover:scale-105 transition-transform duration-500 ease-out" 
                      fallbackText={item.title}
                    />

                    {/* Subtle dark gradient overlay */}
                    <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent opacity-60 group-hover:opacity-90 transition-opacity duration-300 pointer-events-none" />

                    {/* Top Badges & Dismiss Button */}
                    <div className="absolute top-2 left-2 right-2 flex items-center justify-between z-10">
                      {/* Episode / Type Badge */}
                      <span className="text-[9px] font-extrabold uppercase tracking-wider px-2 py-0.5 rounded bg-red-600 text-white shadow-md backdrop-blur-md">
                        {item.type === 'series'
                          ? `S${item.season || 1} • E${item.episode || 1}`
                          : 'Movie'}
                      </span>

                      {/* Remove Button */}
                      <button
                        id={`remove-cw-${item.id}`}
                        onClick={(e) => {
                          e.stopPropagation();
                          onRemove(item.id);
                        }}
                        title="Remove from Continue Watching"
                        className="p-1 rounded-full bg-black/70 hover:bg-red-600 text-white/80 hover:text-white transition-all backdrop-blur-md border border-white/15 shadow-md active:scale-90"
                      >
                        <X size={12} />
                      </button>
                    </div>

                    {/* Minimal Play Icon on Hover */}
                    <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-200 pointer-events-none z-10">
                      <div className="w-10 h-10 rounded-full bg-white/95 text-black flex items-center justify-center shadow-xl backdrop-blur-sm transform scale-90 group-hover:scale-100 transition-transform">
                        <Play size={16} fill="currentColor" className="ml-0.5" />
                      </div>
                    </div>

                    {/* Bottom Info */}
                    <div className="absolute bottom-0 left-0 right-0 p-2.5 z-10 pointer-events-none">
                      <h3 className="text-white text-xs md:text-sm font-semibold truncate leading-tight group-hover:text-red-400 transition-colors">
                        {item.title}
                      </h3>
                      <div className="flex items-center gap-2 text-[10px] text-neutral-400 mt-0.5">
                        {item.year > 0 && <span>{item.year}</span>}
                        <span className="capitalize">
                          {item.type === 'series' ? `S${item.season || 1} : E${item.episode || 1}` : 'Movie'}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default ContinueWatchingRow;
