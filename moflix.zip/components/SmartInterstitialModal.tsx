import React, { useEffect } from 'react';

interface SmartInterstitialModalProps {
  isOpen: boolean;
  onClose: () => void;
  targetTitle?: string;
}

const SmartInterstitialModal: React.FC<SmartInterstitialModalProps> = ({ isOpen, onClose }) => {
  useEffect(() => {
    if (isOpen) onClose();
  }, [isOpen, onClose]);

  return null;
};

export default SmartInterstitialModal;
