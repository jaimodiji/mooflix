import React, { useState, useRef } from 'react';
import { ChevronLeft, ChevronRight, ArrowRight } from 'lucide-react';
import { ContentItem } from '../types';
import MovieCard from './MovieCard';
import { MovieRowSkeleton, MovieCardSkeleton, MovieGridSkeleton, HeroSkeleton } from './Skeletons';

export { MovieRowSkeleton, MovieCardSkeleton, MovieGridSkeleton, HeroSkeleton };

export interface MovieRowProps {
  title: string;
  items?: ContentItem[];
  isLoading?: boolean;
  skeletonCount?: number;
  onItemClick?: (item: ContentItem) => void;
  onExploreAll?: () => void;
  aspectRatio?: 'landscape' | 'portrait';
}

const MovieRow: React.FC<MovieRowProps> = ({ 
  title, 
  items = [], 
  isLoading = false,
  skeletonCount = 7,
  onItemClick, 
  onExploreAll,
  aspectRatio = 'portrait' 
}) => {
  const [showLeftArrow, setShowLeftArrow] = useState(false);
  const [showRightArrow, setShowRightArrow] = useState(true);
  const scrollRef = useRef<HTMLDivElement>(null);

  if (isLoading || (items.length === 0 && isLoading)) {
    return (
      <MovieRowSkeleton 
        title={title} 
        count={skeletonCount} 
        aspectRatio={aspectRatio} 
      />
    );
  }

  const handleScroll = () => {
    if (scrollRef.current) {
      const { scrollLeft, scrollWidth, clientWidth } = scrollRef.current;
      setShowLeftArrow(scrollLeft > 20);
      setShowRightArrow(scrollLeft < scrollWidth - clientWidth - 20);
    }
  };

  const scroll = (direction: 'left' | 'right') => {
    if (scrollRef.current) {
      const scrollAmount = scrollRef.current.clientWidth * 0.75;
      scrollRef.current.scrollBy({
        left: direction === 'left' ? -scrollAmount : scrollAmount,
        behavior: 'smooth'
      });
    }
  };

  if (!items || items.length === 0) return null;

  return (
    <div className="relative mb-6 md:mb-10 select-none">
      {/* Row Header with Title & Explore All button */}
      <div className="flex items-center justify-between mb-3 px-1">
        <h2 className="text-base md:text-xl font-bold text-white tracking-tight">
          {title}
        </h2>
        {onExploreAll && (
          <button 
            onClick={onExploreAll}
            className="group/explore flex items-center gap-1 text-xs md:text-sm font-medium text-neutral-400 hover:text-white transition-colors cursor-pointer py-1 px-2 rounded hover:bg-white/[0.06]"
          >
            <span>Explore All</span>
            <ChevronRight size={15} className="group-hover/explore:translate-x-0.5 transition-transform text-neutral-400 group-hover/explore:text-white" />
          </button>
        )}
      </div>
      
      <div className="relative group/row">
        {/* iOS 27 Glass Navigation Arrows - Anchored Center, Cannot Jump Down on Cursor Hover */}
        <div 
          className={`absolute left-1 md:left-2 z-30 hidden md:block transition-opacity duration-200 ${
            showLeftArrow ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
          }`}
          style={{ top: '50%', transform: 'translateY(-50%)' }}
        >
          <button 
            type="button"
            onClick={() => scroll('left')}
            aria-label="Scroll left"
            className="w-10 h-10 md:w-11 md:h-11 rounded-full bg-[#0d0d14]/85 hover:bg-[#181824]/95 text-white backdrop-blur-2xl border border-white/25 shadow-[0_10px_35px_rgba(0,0,0,0.8),0_0_15px_rgba(255,255,255,0.06)] flex items-center justify-center transition-all duration-200 hover:scale-105 active:scale-95 cursor-pointer ring-1 ring-white/10"
          >
            <ChevronLeft size={20} className="translate-x-[-1px]" />
          </button>
        </div>

        <div 
          className={`absolute right-1 md:right-2 z-30 hidden md:block transition-opacity duration-200 ${
            showRightArrow ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
          }`}
          style={{ top: '50%', transform: 'translateY(-50%)' }}
        >
          <button 
            type="button"
            onClick={() => scroll('right')}
            aria-label="Scroll right"
            className="w-10 h-10 md:w-11 md:h-11 rounded-full bg-[#0d0d14]/85 hover:bg-[#181824]/95 text-white backdrop-blur-2xl border border-white/25 shadow-[0_10px_35px_rgba(0,0,0,0.8),0_0_15px_rgba(255,255,255,0.06)] flex items-center justify-center transition-all duration-200 hover:scale-105 active:scale-95 cursor-pointer ring-1 ring-white/10"
          >
            <ChevronRight size={20} className="translate-x-[1px]" />
          </button>
        </div>

        {/* Scrollable Container */}
        <div 
          ref={scrollRef}
          onScroll={handleScroll}
          className="flex overflow-x-auto overflow-y-hidden space-x-2.5 md:space-x-3.5 py-1 px-1 scroll-smooth no-scrollbar"
        >
          {items.map((item, index) => (
            <div 
              key={`${item.id}-${index}`} 
              className={`shrink-0 ${
                aspectRatio === 'landscape' 
                  ? 'w-[220px] sm:w-[260px] md:w-[300px]' 
                  : 'w-[130px] sm:w-[155px] md:w-[185px] lg:w-[200px]'
              }`}
            >
              <MovieCard 
                item={item} 
                onClick={onItemClick} 
                aspectRatio={aspectRatio}
              />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default MovieRow;
