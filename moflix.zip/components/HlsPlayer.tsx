import React, { useEffect, useRef, useState, useCallback } from 'react';
import Hls from 'hls.js';
import {
  Play,
  Pause,
  Volume2,
  VolumeX,
  Maximize,
  Minimize,
  RotateCcw,
  RotateCw,
  Globe,
  Settings,
  AlertCircle,
  Loader2,
} from 'lucide-react';

interface AudioTrack {
  id: number;
  name: string;
  lang?: string;
}

interface QualityLevel {
  id: number;
  height: number;
  bitrate: number;
}

interface HlsPlayerProps {
  streamUrl: string;
  title?: string;
  autoPlay?: boolean;
  onFallbackToNxsha?: () => void;
}

export const HlsPlayer: React.FC<HlsPlayerProps> = ({
  streamUrl,
  title,
  autoPlay = true,
  onFallbackToNxsha,
}) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const hlsRef = useRef<Hls | null>(null);

  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [isBuffering, setIsBuffering] = useState<boolean>(true);
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [duration, setDuration] = useState<number>(0);
  const [volume, setVolume] = useState<number>(1);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);
  const [showControls, setShowControls] = useState<boolean>(true);
  const controlsTimeoutRef = useRef<any>(null);

  // Audio & Quality Settings
  const [audioTracks, setAudioTracks] = useState<AudioTrack[]>([]);
  const [selectedAudio, setSelectedAudio] = useState<number>(0);
  const [showAudioMenu, setShowAudioMenu] = useState<boolean>(false);

  const [qualityLevels, setQualityLevels] = useState<QualityLevel[]>([]);
  const [selectedQuality, setSelectedQuality] = useState<number>(-1); // -1 is Auto
  const [showQualityMenu, setShowQualityMenu] = useState<boolean>(false);

  const [hasError, setHasError] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string>('');

  // Format seconds to mm:ss or hh:mm:ss
  const formatTime = (secs: number) => {
    if (isNaN(secs) || secs < 0) return '00:00';
    const h = Math.floor(secs / 3600);
    const m = Math.floor((secs % 3600) / 60);
    const s = Math.floor(secs % 60);
    if (h > 0) {
      return `${h}:${m < 10 ? '0' : ''}${m}:${s < 10 ? '0' : ''}${s}`;
    }
    return `${m < 10 ? '0' : ''}${m}:${s < 10 ? '0' : ''}${s}`;
  };

  // Initialize HLS.js
  useEffect(() => {
    const video = videoRef.current;
    if (!video || !streamUrl) return;

    setHasError(false);
    setIsBuffering(true);

    if (hlsRef.current) {
      hlsRef.current.destroy();
      hlsRef.current = null;
    }

    if (Hls.isSupported()) {
      const hls = new Hls({
        enableWorker: true,
        lowLatencyMode: true,
        backBufferLength: 90,
      });

      hlsRef.current = hls;
      hls.loadSource(streamUrl);
      hls.attachMedia(video);

      hls.on(Hls.Events.MANIFEST_PARSED, (_event, data) => {
        setIsBuffering(false);
        // Extract available quality levels
        const levels = data.levels.map((lvl, index) => ({
          id: index,
          height: lvl.height,
          bitrate: lvl.bitrate,
        }));
        setQualityLevels(levels);

        // Extract audio tracks (Hindi / English etc)
        if (hls.audioTracks && hls.audioTracks.length > 0) {
          setAudioTracks(
            hls.audioTracks.map((t, idx) => ({
              id: idx,
              name: t.name || t.lang || `Track ${idx + 1}`,
              lang: t.lang,
            }))
          );
          setSelectedAudio(hls.audioTrack);
        }

        if (autoPlay) {
          video.play().catch(() => {
            // Browser autoplay policy might require muted initially
            video.muted = true;
            setIsMuted(true);
            video.play().catch(() => {});
          });
        }
      });

      hls.on(Hls.Events.AUDIO_TRACK_LOADED, () => {
        if (hls.audioTracks) {
          setAudioTracks(
            hls.audioTracks.map((t, idx) => ({
              id: idx,
              name: t.name || t.lang || `Track ${idx + 1}`,
              lang: t.lang,
            }))
          );
        }
      });

      hls.on(Hls.Events.ERROR, (_event, data) => {
        if (data.fatal) {
          switch (data.type) {
            case Hls.ErrorTypes.NETWORK_ERROR:
              console.warn('8Stream: Network error encountered, attempting recovery...');
              hls.startLoad();
              break;
            case Hls.ErrorTypes.MEDIA_ERROR:
              console.warn('8Stream: Media error encountered, attempting recovery...');
              hls.recoverMediaError();
              break;
            default:
              console.error('8Stream: Fatal stream error:', data);
              hls.destroy();
              setHasError(true);
              setErrorMessage('Stream load error. Switch to Nxsha server.');
              break;
          }
        }
      });
    } else if (video.canPlayType('application/vnd.apple.mpegurl')) {
      // Native Apple HLS (Safari iOS/macOS)
      video.src = streamUrl;
      video.addEventListener('loadedmetadata', () => {
        setIsBuffering(false);
        if (autoPlay) {
          video.play().catch(() => {});
        }
      });
      video.addEventListener('error', () => {
        setHasError(true);
        setErrorMessage('Stream failed to load on device.');
      });
    } else {
      setHasError(true);
      setErrorMessage('HLS playback is not supported on this browser.');
    }

    return () => {
      if (hlsRef.current) {
        hlsRef.current.destroy();
        hlsRef.current = null;
      }
    };
  }, [streamUrl, autoPlay]);

  // Video event listeners
  const onTimeUpdate = () => {
    if (videoRef.current) {
      setCurrentTime(videoRef.current.currentTime);
      setDuration(videoRef.current.duration || 0);
    }
  };

  const onWaiting = () => setIsBuffering(true);
  const onPlaying = () => {
    setIsBuffering(false);
    setIsPlaying(true);
  };
  const onPause = () => setIsPlaying(false);

  // Play / Pause toggle
  const togglePlay = () => {
    const video = videoRef.current;
    if (!video) return;
    if (video.paused) {
      video.play().catch(() => {});
    } else {
      video.pause();
    }
  };

  // Skip 10 seconds
  const skip = (seconds: number) => {
    if (!videoRef.current) return;
    videoRef.current.currentTime = Math.max(0, Math.min(duration, videoRef.current.currentTime + seconds));
  };

  // Seek handler
  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    setCurrentTime(val);
    if (videoRef.current) {
      videoRef.current.currentTime = val;
    }
  };

  // Volume handler
  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    setVolume(val);
    if (videoRef.current) {
      videoRef.current.volume = val;
      videoRef.current.muted = val === 0;
      setIsMuted(val === 0);
    }
  };

  const toggleMute = () => {
    if (!videoRef.current) return;
    if (isMuted) {
      videoRef.current.muted = false;
      setIsMuted(false);
      videoRef.current.volume = volume || 0.8;
    } else {
      videoRef.current.muted = true;
      setIsMuted(true);
    }
  };

  // Fullscreen handler
  const toggleFullscreen = () => {
    const container = containerRef.current;
    if (!container) return;

    if (!document.fullscreenElement) {
      container.requestFullscreen().then(() => setIsFullscreen(true)).catch(() => {});
    } else {
      document.exitFullscreen().then(() => setIsFullscreen(false)).catch(() => {});
    }
  };

  // Switch Audio Track
  const handleSelectAudio = (trackId: number) => {
    setSelectedAudio(trackId);
    setShowAudioMenu(false);
    if (hlsRef.current) {
      hlsRef.current.audioTrack = trackId;
    }
  };

  // Switch Quality
  const handleSelectQuality = (lvlId: number) => {
    setSelectedQuality(lvlId);
    setShowQualityMenu(false);
    if (hlsRef.current) {
      hlsRef.current.currentLevel = lvlId; // -1 for auto
    }
  };

  // Auto-hide controls
  const handleMouseMove = () => {
    setShowControls(true);
    if (controlsTimeoutRef.current) {
      clearTimeout(controlsTimeoutRef.current);
    }
    controlsTimeoutRef.current = setTimeout(() => {
      if (isPlaying) setShowControls(false);
    }, 3500);
  };

  return (
    <div
      ref={containerRef}
      onMouseMove={handleMouseMove}
      className="relative w-full h-full bg-black flex items-center justify-center overflow-hidden select-none group"
    >
      {/* HTML5 Native Video Tag */}
      <video
        ref={videoRef}
        playsInline
        onTimeUpdate={onTimeUpdate}
        onWaiting={onWaiting}
        onPlaying={onPlaying}
        onPause={onPause}
        onClick={togglePlay}
        className="w-full h-full object-contain cursor-pointer"
      />

      {/* Buffering Spinner */}
      {isBuffering && !hasError && (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/40 backdrop-blur-[2px] pointer-events-none">
          <Loader2 className="w-12 h-12 text-red-500 animate-spin" />
          <span className="text-white text-xs font-mono mt-2 tracking-wide">
            8Stream Loading HD Stream...
          </span>
        </div>
      )}

      {/* Fatal Error State / Fallback Notice */}
      {hasError && (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/90 p-6 text-center z-20">
          <AlertCircle className="w-12 h-12 text-red-500 mb-3" />
          <h4 className="text-white text-base font-bold mb-1">Direct Stream Unavailable</h4>
          <p className="text-neutral-400 text-xs max-w-sm mb-4">
            {errorMessage || '8StreamApi direct m3u8 link is offline or blocked.'}
          </p>
          {onFallbackToNxsha && (
            <button
              type="button"
              onClick={onFallbackToNxsha}
              className="px-5 py-2.5 rounded-xl bg-red-600 hover:bg-red-500 text-white font-bold text-xs uppercase tracking-wider shadow-lg active:scale-95 transition-all cursor-pointer"
            >
              Switch to Nxsha (MbPly Server)
            </button>
          )}
        </div>
      )}

      {/* Overlay UI Controls */}
      <div
        className={`absolute inset-0 flex flex-col justify-between p-3 sm:p-5 bg-gradient-to-t from-black/90 via-transparent to-black/60 transition-opacity duration-300 pointer-events-auto ${
          showControls ? 'opacity-100' : 'opacity-0 pointer-events-none'
        }`}
      >
        {/* Top Bar: Title & Audio / Quality Quick Info */}
        <div className="flex items-center justify-between text-white text-xs">
          <span className="font-bold truncate max-w-[60%] tracking-wide">
            {title || '8Stream Direct Player (m3u8)'}
          </span>
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded bg-red-600/80 font-mono text-[10px] font-bold">
              8STREAM HLS
            </span>
            <span className="px-2 py-0.5 rounded bg-white/10 font-mono text-[10px]">
              {selectedQuality === -1 ? 'AUTO 1080p' : `${qualityLevels[selectedQuality]?.height}p`}
            </span>
          </div>
        </div>

        {/* Center Play/Pause button indicator */}
        <div className="flex items-center justify-center gap-6">
          <button
            type="button"
            onClick={() => skip(-10)}
            className="w-10 h-10 rounded-full bg-black/60 hover:bg-black/90 text-white flex items-center justify-center border border-white/10 active:scale-90 transition-all cursor-pointer"
            title="Rewind 10s"
          >
            <RotateCcw size={18} />
          </button>
          <button
            type="button"
            onClick={togglePlay}
            className="w-14 h-14 rounded-full bg-red-600 hover:bg-red-500 text-white flex items-center justify-center shadow-xl active:scale-95 transition-all cursor-pointer"
            title={isPlaying ? 'Pause' : 'Play'}
          >
            {isPlaying ? <Pause size={24} /> : <Play size={24} className="ml-1" />}
          </button>
          <button
            type="button"
            onClick={() => skip(10)}
            className="w-10 h-10 rounded-full bg-black/60 hover:bg-black/90 text-white flex items-center justify-center border border-white/10 active:scale-90 transition-all cursor-pointer"
            title="Fast Forward 10s"
          >
            <RotateCw size={18} />
          </button>
        </div>

        {/* Bottom Control Bar */}
        <div className="space-y-2">
          {/* Progress / Seek bar */}
          <div className="flex items-center gap-2">
            <input
              type="range"
              min={0}
              max={duration || 100}
              step={0.1}
              value={currentTime}
              onChange={handleSeek}
              className="w-full h-1.5 bg-white/20 rounded-lg appearance-none cursor-pointer accent-red-600 hover:h-2 transition-all"
            />
          </div>

          <div className="flex items-center justify-between text-white text-xs">
            {/* Left Controls: Time & Volume */}
            <div className="flex items-center gap-3">
              <span className="font-mono text-[11px] text-neutral-300">
                {formatTime(currentTime)} / {formatTime(duration)}
              </span>

              {/* Volume */}
              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={toggleMute}
                  className="hover:text-red-400 transition-colors cursor-pointer"
                >
                  {isMuted || volume === 0 ? <VolumeX size={16} /> : <Volume2 size={16} />}
                </button>
                <input
                  type="range"
                  min={0}
                  max={1}
                  step={0.05}
                  value={isMuted ? 0 : volume}
                  onChange={handleVolumeChange}
                  className="w-14 sm:w-20 h-1 bg-white/20 rounded-lg appearance-none cursor-pointer accent-white"
                />
              </div>
            </div>

            {/* Right Controls: Audio Tracks + Quality + Fullscreen */}
            <div className="flex items-center gap-2 relative">
              {/* Multi-Audio Language Menu */}
              {audioTracks.length > 0 && (
                <div className="relative">
                  <button
                    type="button"
                    onClick={() => {
                      setShowAudioMenu(!showAudioMenu);
                      setShowQualityMenu(false);
                    }}
                    title="Audio Language (Hindi/English)"
                    className="p-1.5 rounded-lg hover:bg-white/15 transition-colors cursor-pointer flex items-center gap-1 text-[11px]"
                  >
                    <Globe size={15} />
                    <span className="hidden sm:inline">
                      {audioTracks[selectedAudio]?.name || 'Audio'}
                    </span>
                  </button>

                  {showAudioMenu && (
                    <div className="absolute bottom-full right-0 mb-2 w-36 bg-[#161722] border border-white/20 rounded-xl shadow-2xl p-1.5 z-30 space-y-1">
                      <div className="text-[10px] uppercase font-bold text-neutral-400 px-2 py-1">
                        Select Audio
                      </div>
                      {audioTracks.map((trk) => (
                        <button
                          key={trk.id}
                          type="button"
                          onClick={() => handleSelectAudio(trk.id)}
                          className={`w-full text-left px-2 py-1.5 rounded-lg text-xs transition-colors cursor-pointer ${
                            selectedAudio === trk.id
                              ? 'bg-red-600 text-white font-bold'
                              : 'text-neutral-300 hover:bg-white/10'
                          }`}
                        >
                          {trk.name}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {/* Quality Settings Menu */}
              {qualityLevels.length > 0 && (
                <div className="relative">
                  <button
                    type="button"
                    onClick={() => {
                      setShowQualityMenu(!showQualityMenu);
                      setShowAudioMenu(false);
                    }}
                    title="Video Quality"
                    className="p-1.5 rounded-lg hover:bg-white/15 transition-colors cursor-pointer"
                  >
                    <Settings size={15} />
                  </button>

                  {showQualityMenu && (
                    <div className="absolute bottom-full right-0 mb-2 w-32 bg-[#161722] border border-white/20 rounded-xl shadow-2xl p-1.5 z-30 space-y-1">
                      <div className="text-[10px] uppercase font-bold text-neutral-400 px-2 py-1">
                        Resolution
                      </div>
                      <button
                        type="button"
                        onClick={() => handleSelectQuality(-1)}
                        className={`w-full text-left px-2 py-1.5 rounded-lg text-xs transition-colors cursor-pointer ${
                          selectedQuality === -1
                            ? 'bg-red-600 text-white font-bold'
                            : 'text-neutral-300 hover:bg-white/10'
                        }`}
                      >
                        Auto (Best)
                      </button>
                      {qualityLevels.map((lvl) => (
                        <button
                          key={lvl.id}
                          type="button"
                          onClick={() => handleSelectQuality(lvl.id)}
                          className={`w-full text-left px-2 py-1.5 rounded-lg text-xs transition-colors cursor-pointer ${
                            selectedQuality === lvl.id
                              ? 'bg-red-600 text-white font-bold'
                              : 'text-neutral-300 hover:bg-white/10'
                          }`}
                        >
                          {lvl.height}p
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {/* Fullscreen Button */}
              <button
                type="button"
                onClick={toggleFullscreen}
                className="p-1.5 rounded-lg hover:bg-white/15 transition-colors cursor-pointer"
                title={isFullscreen ? 'Exit Fullscreen' : 'Fullscreen'}
              >
                {isFullscreen ? <Minimize size={16} /> : <Maximize size={16} />}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
