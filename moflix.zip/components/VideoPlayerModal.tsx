import React, { useEffect, useRef, useState, useCallback } from 'react';
import {
  ArrowLeft,
  Maximize,
  Minimize,
  RotateCcw,
  ChevronLeft,
  ChevronRight,
  X,
} from 'lucide-react';
import { ContentItem } from '../types';
import { resolveTmdbId, fetchImdbId } from '../services/tmdbService';
import { getEmbedUrl, normalizeServerNo } from '../utils/playerUtils';

interface VideoPlayerModalProps {
  item: ContentItem;
  initialServer?: string;
  initialSeason?: number;
  initialEpisode?: number;
  initialImdbId?: string | null;
  onClose: () => void;
  onItemClick?: (item: ContentItem) => void;
  onDownload?: (config: { item: ContentItem; season?: number; episode?: number; imdbId?: string | null }) => void;
  onEpisodeChange?: (season: number, episode: number) => void;
}

type ServerKey = '1' | '2' | '3' | '4';
type AvailabilityMap = Record<ServerKey, boolean | 'unknown'>;

const SERVERS: { id: ServerKey; name: string; tag: string; label: string }[] = [
  { id: '1', name: 'Server 1', tag: 'Fast HD • Zero Ads', label: 'S1' },
  { id: '2', name: 'Server 2', tag: 'Multi-Audio HD • Zero Ads', label: 'S2' },
  { id: '3', name: 'Server 3', tag: 'Backup HD • Zero Ads', label: 'S3' },
  { id: '4', name: 'Server 4', tag: 'Ultra HD Mirror • Zero Ads', label: 'S4' },
];

const SERVER_ORDER: ServerKey[] = ['1', '2', '3', '4'];

function extractInitialTmdb(item: ContentItem): string {
  const raw =
    (item as any).tmdbId ||
    (typeof item.id === 'number'
      ? String(item.id)
      : typeof item.id === 'string' && !item.id.startsWith('tt')
        ? item.id
        : '');
  return String(raw || '').trim();
}

function extractInitialImdb(item: ContentItem, initialImdbId?: string | null): string {
  if (initialImdbId && String(initialImdbId).startsWith('tt')) return String(initialImdbId).trim();
  if (item.imdbId && String(item.imdbId).startsWith('tt')) return String(item.imdbId).trim();
  if (typeof item.id === 'string' && item.id.startsWith('tt')) return item.id.trim();
  return '';
}

export const VideoPlayerModal: React.FC<VideoPlayerModalProps> = ({
  item: initialItem,
  initialServer = '1',
  initialSeason = 1,
  initialEpisode = 1,
  initialImdbId,
  onClose,
  onEpisodeChange,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const triedServersRef = useRef<Set<ServerKey>>(new Set());
  const manualOverrideRef = useRef<boolean>(false);

  const [activeItem, setActiveItem] = useState<ContentItem>(initialItem);
  const [currentServer, setCurrentServer] = useState<ServerKey>(normalizeServerNo(initialServer));
  const [season, setSeason] = useState<number>(Math.max(1, initialSeason || 1));
  const [episode, setEpisode] = useState<number>(Math.max(1, initialEpisode || 1));
  const [isServerMenuOpen, setIsServerMenuOpen] = useState<boolean>(false);
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(true);
  const [isResolving, setIsResolving] = useState<boolean>(true);
  const [iframeKey, setIframeKey] = useState<number>(0);
  const [failoverNotice, setFailoverNotice] = useState<string | null>(null);
  const [availability, setAvailability] = useState<AvailabilityMap>({
    '1': 'unknown',
    '2': 'unknown',
    '3': 'unknown',
    '4': 'unknown',
  });

  const [resolvedTmdbId, setResolvedTmdbId] = useState<string>(() => extractInitialTmdb(initialItem));
  const [resolvedImdbId, setResolvedImdbId] = useState<string>(() => extractInitialImdb(initialItem, initialImdbId));

  // Sync if initialItem or initial episode props change
  useEffect(() => {
    setActiveItem(initialItem);
    setResolvedTmdbId(extractInitialTmdb(initialItem));
    setResolvedImdbId(extractInitialImdb(initialItem, initialImdbId));
    setSeason(Math.max(1, initialSeason || 1));
    setEpisode(Math.max(1, initialEpisode || 1));
    setCurrentServer(normalizeServerNo(initialServer));
    triedServersRef.current = new Set();
    manualOverrideRef.current = false;
    setFailoverNotice(null);
  }, [initialItem, initialImdbId, initialSeason, initialEpisode, initialServer]);

  const isTv = activeItem.type === 'tv' || activeItem.type === 'series';
  const pad = (n: number | string) => String(n).padStart(2, '0');

  // Disarm popups & redirects
  useEffect(() => {
    document.body.classList.add('player-active', 'ads-free-mode');
    const originalOpen = window.open;

    const blockedOpen = function () {
      return {
        close: () => {},
        closed: true,
        focus: () => {},
        blur: () => {},
        postMessage: () => {},
        location: { href: 'about:blank' },
      } as any;
    };

    window.open = blockedOpen as any;
    try {
      if (window.top && window.top !== window) (window.top as any).open = blockedOpen;
      if (window.parent && window.parent !== window) (window.parent as any).open = blockedOpen;
    } catch {}

    return () => {
      document.body.classList.remove('player-active', 'ads-free-mode');
      window.open = originalOpen;
      try {
        if (window.top && window.top !== window) (window.top as any).open = originalOpen;
        if (window.parent && window.parent !== window) (window.parent as any).open = originalOpen;
      } catch {}
    };
  }, []);

  // Fullscreen management
  useEffect(() => {
    const el = containerRef.current;
    if (el && !document.fullscreenElement) {
      el.requestFullscreen?.().then(() => setIsFullscreen(true)).catch(() => {});
    }
    const handleFullscreenChange = () => setIsFullscreen(Boolean(document.fullscreenElement));
    document.addEventListener('fullscreenchange', handleFullscreenChange);
    return () => document.removeEventListener('fullscreenchange', handleFullscreenChange);
  }, []);

  // Resolve TMDB / IMDb IDs + auto-check availability across Server 1 -> Server 2 -> Server 3 -> Server 4
  useEffect(() => {
    let isMounted = true;
    setIsResolving(true);
    setLoading(true);
    triedServersRef.current = new Set();

    const tmdbQuery = resolvedTmdbId || (!String(activeItem.id).startsWith('tt') ? String(activeItem.id) : '');
    const imdbQuery = resolvedImdbId || (String(activeItem.id).startsWith('tt') ? String(activeItem.id) : '');

    async function resolveStreamAndIds() {
      try {
        const params = new URLSearchParams({
          type: isTv ? 'tv' : 'movie',
          tmdbId: tmdbQuery,
          imdbId: imdbQuery,
          season: String(season),
          episode: String(episode),
        });
        const res = await fetch(`/api/player/resolve?${params.toString()}`);
        if (res.ok) {
          const data = await res.json();
          if (!isMounted) return;

          if (data.resolvedTmdbId && data.resolvedTmdbId !== resolvedTmdbId) {
            setResolvedTmdbId(String(data.resolvedTmdbId));
          }
          if (data.resolvedImdbId && data.resolvedImdbId !== resolvedImdbId) {
            setResolvedImdbId(String(data.resolvedImdbId));
          }
          if (data.availability) {
            setAvailability(data.availability);
            if (!manualOverrideRef.current) {
              const chosen = currentServer;
              if (data.availability[chosen] === false && data.recommendedServer && data.recommendedServer !== chosen) {
                triedServersRef.current.add(chosen);
                setFailoverNotice(`Not found on Server ${chosen} — switching automatically to Server ${data.recommendedServer}...`);
                setCurrentServer(data.recommendedServer as ServerKey);
              }
            }
          }
          setIsResolving(false);
          return;
        }
      } catch {
        // Fallback to direct TMDB resolution
      }

      try {
        let finalTmdb = tmdbQuery;
        if (!finalTmdb && imdbQuery.startsWith('tt')) {
          const tId = await resolveTmdbId(imdbQuery);
          if (tId) finalTmdb = String(tId);
        }
        if (isMounted && finalTmdb && finalTmdb !== resolvedTmdbId) {
          setResolvedTmdbId(finalTmdb);
        }
        if (!imdbQuery && finalTmdb) {
          const imdb = await fetchImdbId(finalTmdb, isTv ? 'series' : 'movie');
          if (isMounted && imdb) setResolvedImdbId(imdb);
        }
      } catch {}

      if (isMounted) setIsResolving(false);
    }

    resolveStreamAndIds();
    return () => {
      isMounted = false;
    };
  }, [activeItem.id, isTv, season, episode]);

  // Helper to advance to next untried working server (1 -> 2 -> 3 -> 4)
  const advanceToNextServer = useCallback(
    (failedServer: ServerKey, reason: 'not_found' | 'timeout' = 'not_found') => {
      triedServersRef.current.add(failedServer);
      setAvailability((prev) => ({ ...prev, [failedServer]: false }));

      // Pick first untried server that isn't explicitly known unavailable; fall back to first untried server
      const nextBest =
        SERVER_ORDER.find((srv) => !triedServersRef.current.has(srv) && availability[srv] !== false) ||
        SERVER_ORDER.find((srv) => !triedServersRef.current.has(srv));

      if (!nextBest) {
        if (reason === 'timeout') {
          setIsResolving(false);
          setLoading(false);
        }
        return;
      }

      triedServersRef.current.add(nextBest);
      setFailoverNotice(
        reason === 'timeout'
          ? `Server ${failedServer} took more than 10s — switching automatically to Server ${nextBest}...`
          : `Not found on Server ${failedServer} — switching automatically to Server ${nextBest}...`
      );
      setIsResolving(false);
      setCurrentServer(nextBest);
      setLoading(true);
      setIframeKey((k) => k + 1);
    },
    [availability]
  );

  // Auto-switch server if loading lasts more than 10 seconds
  useEffect(() => {
    if (!loading && !isResolving) return;
    const timeoutId = setTimeout(() => {
      advanceToNextServer(currentServer, 'timeout');
    }, 10000);
    return () => clearTimeout(timeoutId);
  }, [loading, isResolving, currentServer, iframeKey, season, episode, advanceToNextServer]);

  // Auto-hide failover notice banner after 4.5s
  useEffect(() => {
    if (!failoverNotice) return;
    const t = setTimeout(() => setFailoverNotice(null), 4500);
    return () => clearTimeout(t);
  }, [failoverNotice]);

  // Listen for iframe postMessages (both episode changes and MOOFLIX_PLAYER_NOT_FOUND failover)
  useEffect(() => {
    const handlePostMessage = (event: MessageEvent) => {
      try {
        const data = event.data;
        if (!data) return;

        if (data.type === 'MOOFLIX_PLAYER_NOT_FOUND') {
          const failedSrv = normalizeServerNo(data.server || currentServer) as ServerKey;
          advanceToNextServer(failedSrv);
          return;
        }

        if (
          data.type === 'MEDIA_DATA' ||
          data.type === 'PLAYER_EPISODE_CHANGE' ||
          data.event === 'episode_change' ||
          data.event === 'next_episode' ||
          data.event === 'nextEpisode'
        ) {
          const targetS = Number(data.season || data.data?.season || season);
          const targetE = Number(data.episode || data.data?.episode || data.episode_number);
          if (targetE && (targetS !== season || targetE !== episode)) {
            manualOverrideRef.current = false;
            setSeason(targetS);
            setEpisode(targetE);
            setLoading(true);
            if (onEpisodeChange) onEpisodeChange(targetS, targetE);
          }
        }
      } catch {}
    };

    window.addEventListener('message', handlePostMessage);
    return () => window.removeEventListener('message', handlePostMessage);
  }, [season, episode, currentServer, onEpisodeChange, advanceToNextServer]);

  const handleClose = useCallback(() => {
    if (document.fullscreenElement) {
      document.exitFullscreen?.().catch(() => {});
    }
    if (iframeRef.current) {
      try {
        iframeRef.current.src = 'about:blank';
      } catch {}
    }
    onClose();
  }, [onClose]);

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      containerRef.current?.requestFullscreen?.().then(() => setIsFullscreen(true)).catch(() => {});
    } else {
      document.exitFullscreen?.().then(() => setIsFullscreen(false)).catch(() => {});
    }
  };

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        handleClose();
      } else if (e.key === 'f' || e.key === 'F') {
        const target = e.target as HTMLElement;
        if (target && (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA')) return;
        toggleFullscreen();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleClose]);

  const handleSelectServer = (serverNo: ServerKey) => {
    manualOverrideRef.current = true;
    setFailoverNotice(null);
    setCurrentServer(serverNo);
    setIsServerMenuOpen(false);
    setLoading(true);
    setIframeKey((k) => k + 1);
  };

  const handlePrevEpisode = () => {
    manualOverrideRef.current = false;
    setFailoverNotice(null);
    if (episode > 1) {
      const nextEp = episode - 1;
      setEpisode(nextEp);
      setLoading(true);
      if (onEpisodeChange) onEpisodeChange(season, nextEp);
    } else if (season > 1) {
      const nextS = season - 1;
      setSeason(nextS);
      setEpisode(1);
      setLoading(true);
      if (onEpisodeChange) onEpisodeChange(nextS, 1);
    }
  };

  const handleNextEpisode = () => {
    manualOverrideRef.current = false;
    setFailoverNotice(null);
    const nextEp = episode + 1;
    setEpisode(nextEp);
    setLoading(true);
    if (onEpisodeChange) onEpisodeChange(season, nextEp);
  };

  const effectiveItem: ContentItem = {
    ...activeItem,
    tmdbId: resolvedTmdbId || activeItem.tmdbId,
    imdbId: resolvedImdbId || activeItem.imdbId,
  };

  const embedUrl = isResolving
    ? ''
    : getEmbedUrl(currentServer, effectiveItem, season, episode, resolvedImdbId);
  const activeServerInfo = SERVERS.find((s) => s.id === currentServer) || SERVERS[0];

  // Auto-skip if current server has no required ID after resolution (e.g. Server 2 with missing IMDb ID)
  useEffect(() => {
    if (!isResolving && !embedUrl) {
      advanceToNextServer(currentServer);
    }
  }, [isResolving, embedUrl, currentServer, advanceToNextServer]);

  return (
    <div
      ref={containerRef}
      className="fixed inset-0 z-[999999] w-screen h-screen bg-black overflow-hidden flex items-center justify-center select-none"
      style={{
        backgroundColor: '#000000',
        color: '#ffffff',
        fontFamily: "'Inter', -apple-system, BlinkMacSystemFont, sans-serif",
      }}
      onClick={() => setIsServerMenuOpen(false)}
    >
      <div className="relative w-full h-full max-w-full max-h-full bg-black overflow-hidden flex items-center justify-center">
        {/* Top Bar */}
        <div
          className="absolute top-0 left-0 right-0 z-40 flex items-center justify-between pointer-events-none transition-all duration-200"
          style={{
            padding: 'max(8px, env(safe-area-inset-top, 8px)) max(8px, env(safe-area-inset-right, 8px)) 12px max(8px, env(safe-area-inset-left, 8px))',
            background: 'linear-gradient(180deg, rgba(0,0,0,0.92) 0%, rgba(0,0,0,0.65) 60%, rgba(0,0,0,0) 100%)',
          }}
        >
          {/* Left: Back Button, Brand & Title */}
          <div className="flex items-center gap-1.5 sm:gap-2.5 pointer-events-auto min-w-0">
            <button
              type="button"
              onClick={handleClose}
              aria-label="Back"
              title="Back"
              className="w-8 h-8 sm:w-auto sm:px-3 sm:py-1.5 rounded-lg bg-black/60 hover:bg-white/20 active:scale-95 text-white border border-white/20 flex items-center justify-center gap-1.5 text-xs font-bold transition-all cursor-pointer backdrop-blur-md shadow-md shrink-0"
            >
              <ArrowLeft size={16} />
              <span className="hidden sm:inline">Back</span>
            </button>

            <div
              className="flex items-center gap-1 font-black tracking-tight text-white cursor-pointer select-none shrink-0"
              style={{ fontSize: 'clamp(13px, 2.4vw, 17px)' }}
              onClick={handleClose}
            >
              <div>MOO<span style={{ color: '#e50914' }}>FLIX</span></div>
            </div>

            <div className="hidden md:flex items-center gap-2 pl-2 border-l border-white/20 text-xs text-neutral-300 font-medium truncate">
              <span className="truncate max-w-[150px] lg:max-w-[300px] text-white font-semibold">
                {activeItem.title}
              </span>
              {isTv && (
                <span className="px-2 py-0.5 rounded bg-white/10 text-white font-mono font-bold text-[11px] border border-white/10 shrink-0">
                  S{season}:E{episode}
                </span>
              )}
            </div>
          </div>

          {/* Right: Episode Switcher, Server Dropdown & Controls */}
          <div className="flex items-center gap-1 sm:gap-2 pointer-events-auto shrink-0">
            {isTv && (
              <div className="flex items-center bg-black/70 backdrop-blur-md rounded-lg border border-white/15 p-0.5 sm:p-1 shadow-sm">
                <button
                  type="button"
                  onClick={handlePrevEpisode}
                  disabled={season <= 1 && episode <= 1}
                  className="w-7 h-7 sm:w-auto sm:px-2 sm:py-1 rounded text-neutral-300 hover:text-white hover:bg-white/15 disabled:opacity-30 disabled:hover:bg-transparent flex items-center justify-center gap-0.5 cursor-pointer transition-all"
                  title="Previous Episode"
                >
                  <ChevronLeft size={15} />
                  <span className="hidden lg:inline text-xs font-semibold">Prev</span>
                </button>
                <div className="px-1.5 py-0.5 text-[10px] sm:text-[11px] font-mono font-bold text-white bg-white/15 rounded">
                  S{season}E{pad(episode)}
                </div>
                <button
                  type="button"
                  onClick={handleNextEpisode}
                  className="w-7 h-7 sm:w-auto sm:px-2 sm:py-1 rounded text-neutral-300 hover:text-white hover:bg-white/15 flex items-center justify-center gap-0.5 cursor-pointer transition-all"
                  title="Next Episode"
                >
                  <span className="hidden lg:inline text-xs font-semibold">Next</span>
                  <ChevronRight size={15} />
                </button>
              </div>
            )}

            {/* Server Switcher */}
            <div className="relative">
              <button
                type="button"
                id="serverToggleBtn"
                onClick={(e) => {
                  e.stopPropagation();
                  setIsServerMenuOpen((prev) => !prev);
                }}
                className="cursor-pointer flex items-center gap-1 sm:gap-1.5 text-white rounded-lg font-bold transition-all shadow-md active:scale-95"
                style={{
                  backgroundColor: '#e50914',
                  border: '1px solid rgba(255, 255, 255, 0.2)',
                  padding: '5px 8px',
                  fontSize: 'clamp(11px, 2vw, 13px)',
                  boxShadow: '0 4px 14px rgba(229, 9, 20, 0.5)',
                  whiteSpace: 'nowrap',
                }}
              >
                <span>{activeServerInfo.name}</span>
                <span id="currentServerLabel" style={{ opacity: 0.9, fontWeight: 800 }}>
                  ({activeServerInfo.label})
                </span>
              </button>

              {isServerMenuOpen && (
                <div
                  id="serverMenu"
                  className="absolute top-[calc(100%+6px)] right-0 rounded-xl p-1.5 flex flex-col gap-1 z-50 shadow-2xl animate-in fade-in zoom-in-95 duration-150 max-h-[75vh] overflow-y-auto no-scrollbar"
                  style={{
                    backgroundColor: 'rgba(18, 18, 22, 0.97)',
                    backdropFilter: 'blur(16px)',
                    border: '1px solid rgba(255, 255, 255, 0.16)',
                    minWidth: 'clamp(190px, 48vw, 240px)',
                    boxShadow: '0 12px 35px rgba(0,0,0,0.95)',
                  }}
                  onClick={(e) => e.stopPropagation()}
                >
                  <div className="px-2 py-1 text-[10px] font-bold uppercase tracking-wider text-neutral-400 border-b border-white/10 mb-0.5 flex items-center justify-between">
                    <span>Select Server (Zero Ads)</span>
                    <span className="text-emerald-400">AUTO</span>
                  </div>
                  {SERVERS.map((srv) => {
                    const isSelected = currentServer === srv.id;
                    const srvStatus = availability[srv.id];
                    return (
                      <button
                        key={srv.id}
                        type="button"
                        data-server={srv.id}
                        onClick={() => handleSelectServer(srv.id)}
                        className="server-item text-left rounded-lg cursor-pointer transition-all flex items-center justify-between p-2 font-medium"
                        style={{
                          backgroundColor: isSelected ? '#e50914' : 'transparent',
                          color: '#ffffff',
                          fontSize: '12px',
                          fontWeight: isSelected ? 700 : 500,
                          border: 'none',
                          outline: 'none',
                        }}
                        onMouseEnter={(e) => {
                          if (!isSelected) e.currentTarget.style.backgroundColor = 'rgba(255, 255, 255, 0.15)';
                        }}
                        onMouseLeave={(e) => {
                          if (!isSelected) e.currentTarget.style.backgroundColor = 'transparent';
                        }}
                      >
                        <div className="flex flex-col">
                          <span className="font-bold flex items-center gap-1.5">
                            {srv.name}
                            {srvStatus === false && (
                              <span className="text-[9px] text-amber-300 font-normal">(Fallback)</span>
                            )}
                          </span>
                          <span className="text-[10px] opacity-75">{srv.tag}</span>
                        </div>
                        <span
                          className={`text-[10px] px-1.5 py-0.5 rounded font-mono font-bold ${
                            isSelected ? 'bg-black/30 text-white' : 'bg-white/10 text-neutral-300'
                          }`}
                        >
                          {srv.label}
                        </span>
                      </button>
                    );
                  })}
                </div>
              )}
            </div>

            <button
              type="button"
              onClick={() => {
                setLoading(true);
                setIframeKey((k) => k + 1);
              }}
              aria-label="Reload Stream"
              title="Reload Stream"
              className="w-8 h-8 rounded-lg bg-black/60 hover:bg-white/20 active:scale-95 text-white border border-white/20 flex items-center justify-center transition-all cursor-pointer backdrop-blur-md"
            >
              <RotateCcw size={14} />
            </button>

            <button
              type="button"
              onClick={toggleFullscreen}
              aria-label={isFullscreen ? 'Exit Fullscreen' : 'Enter Fullscreen'}
              title={isFullscreen ? 'Exit Fullscreen (F)' : 'Fullscreen (F)'}
              className="w-8 h-8 rounded-lg bg-black/60 hover:bg-white/20 active:scale-95 text-white border border-white/20 flex items-center justify-center transition-all cursor-pointer backdrop-blur-md"
            >
              {isFullscreen ? <Minimize size={14} /> : <Maximize size={14} />}
            </button>

            <button
              type="button"
              onClick={handleClose}
              aria-label="Close Cinema Player"
              title="Close"
              className="w-8 h-8 rounded-lg bg-[#e50914] hover:bg-[#f40612] active:scale-95 text-white border border-white/20 flex items-center justify-center transition-all cursor-pointer shadow-md"
            >
              <X size={15} />
            </button>
          </div>
        </div>

        {/* Auto-failover status banner */}
        {failoverNotice && (
          <div
            className="absolute left-1/2 -translate-x-1/2 z-40 bg-black/90 border border-red-500/50 text-white px-4 py-1.5 rounded-lg text-[11px] sm:text-xs font-semibold shadow-xl pointer-events-none whitespace-nowrap"
            style={{ top: 'max(54px, calc(env(safe-area-inset-top, 8px) + 46px))' }}
          >
            {failoverNotice}
          </div>
        )}

        {/* Video Viewport */}
        <div
          id="videoWrapper"
          className="absolute inset-0 w-full h-full z-10 bg-black flex items-center justify-center overflow-hidden"
        >
          {(loading || isResolving) && (
            <div className="absolute inset-0 z-20 flex flex-col items-center justify-center bg-black gap-3 text-white pointer-events-none">
              <div className="w-10 h-10 sm:w-12 sm:h-12 border-3 border-white/20 border-t-[#e50914] rounded-full animate-spin" />
              <div className="text-xs sm:text-sm font-semibold tracking-wide text-neutral-300 flex items-center gap-2">
                <span>
                  {isResolving
                    ? 'Finding best ad-free stream...'
                    : `Loading ${activeServerInfo.name} (${activeServerInfo.label})`}
                </span>
                <span className="w-1.5 h-1.5 rounded-full bg-[#e50914] animate-ping" />
              </div>
            </div>
          )}

          {embedUrl && (
            <iframe
              ref={iframeRef}
              key={`stream-${activeItem.id}-${season}-${episode}-${currentServer}-${resolvedTmdbId}-${resolvedImdbId}-${iframeKey}`}
              src={embedUrl}
              title={`${activeItem.title} - ${activeServerInfo.name}`}
              className="w-full h-full border-0 block bg-black"
              style={{
                width: '100%',
                height: '100%',
                border: 0,
                outline: 'none',
                display: 'block',
              }}
              sandbox={
                currentServer === '3'
                  ? 'allow-scripts allow-same-origin allow-forms allow-presentation'
                  : undefined
              }
              onLoad={() => setLoading(false)}
              onError={() => advanceToNextServer(currentServer)}
              allowFullScreen
              scrolling="no"
              referrerPolicy="no-referrer-when-downgrade"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
            />
          )}
        </div>
      </div>
    </div>
  );
};

export default VideoPlayerModal;
