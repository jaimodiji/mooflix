import React from 'react';

export const CookieConsentBanner: React.FC<any> = () => null;

export default CookieConsentBanner;
