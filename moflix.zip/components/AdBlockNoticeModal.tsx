import React from 'react';

interface AdBlockNoticeModalProps {
  isOpen: boolean;
  onClose: (hideForWeek?: boolean) => void;
}

const AdBlockNoticeModal: React.FC<AdBlockNoticeModalProps> = () => {
  return null;
};

export default AdBlockNoticeModal;
