import React, { useEffect, useRef, useState, useCallback } from 'react';
import {
  ArrowLeft,
  Maximize,
  Minimize,
  RotateCcw,
  X,
  Tv,
} from 'lucide-react';
import {
  APIMatch,
  StreamSource,
  fetchAllStreamsForMatch,
  formatMatchTime,
} from '../services/sportsService';

interface SportStreamModalProps {
  match: APIMatch;
  allMatches?: APIMatch[];
  onSelectMatch?: (match: APIMatch) => void;
  onClose: () => void;
}

export const SportStreamModal: React.FC<SportStreamModalProps> = ({
  match,
  onClose,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const triedIndicesRef = useRef<Set<number>>(new Set([0]));

  const [streams, setStreams] = useState<StreamSource[]>([]);
  const [selectedStreamIndex, setSelectedStreamIndex] = useState<number>(0);
  const [loading, setLoading] = useState<boolean>(true);
  const [iframeKey, setIframeKey] = useState<number>(0);
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);
  const [isFeedMenuOpen, setIsFeedMenuOpen] = useState<boolean>(false);
  const [failoverBanner, setFailoverBanner] = useState<string | null>(null);

  const ppv = match.rawPpvStream;
  const timeInfo = formatMatchTime(match.date, ppv?.starts_at);
  const isLive = timeInfo.status === 'live' || match.rawOnDemandStream?.status === 'live';

  // Anti-Popup Shield for Sports Player (Zero Ads)
  useEffect(() => {
    document.body.classList.add('player-active', 'ads-free-mode');
    const originalOpen = window.open;

    const blockedOpen = function () {
      return {
        close: () => {},
        closed: true,
        focus: () => {},
        blur: () => {},
        postMessage: () => {},
        location: { href: 'about:blank' },
      } as any;
    };

    window.open = blockedOpen as any;
    try {
      if (window.top && window.top !== window) {
        (window.top as any).open = blockedOpen;
      }
      if (window.parent && window.parent !== window) {
        (window.parent as any).open = blockedOpen;
      }
    } catch {}

    return () => {
      document.body.classList.remove('player-active', 'ads-free-mode');
      window.open = originalOpen;
      try {
        if (window.top && window.top !== window) {
          (window.top as any).open = originalOpen;
        }
        if (window.parent && window.parent !== window) {
          (window.parent as any).open = originalOpen;
        }
      } catch {}
    };
  }, []);

  // Fullscreen sync
  useEffect(() => {
    const el = containerRef.current;
    if (el && !document.fullscreenElement) {
      el.requestFullscreen?.().then(() => {
        setIsFullscreen(true);
      }).catch(() => {});
    }

    const handleFullscreenChange = () => {
      setIsFullscreen(Boolean(document.fullscreenElement));
    };

    document.addEventListener('fullscreenchange', handleFullscreenChange);
    return () => {
      document.removeEventListener('fullscreenchange', handleFullscreenChange);
    };
  }, []);

  // Load streams for the match
  useEffect(() => {
    let isMounted = true;
    setLoading(true);
    triedIndicesRef.current = new Set([0]);
    setFailoverBanner(null);

    fetchAllStreamsForMatch(match).then((sources) => {
      if (!isMounted) return;
      const normalized = sources.map((s, idx) => ({
        ...s,
        streamNo: idx + 1,
        source: `Server ${idx + 1}`,
        serverName: `Server ${idx + 1}`,
      }));
      setStreams(normalized);
      setSelectedStreamIndex(0);
      setLoading(false);
    });

    return () => {
      isMounted = false;
    };
  }, [match]);

  // Auto-failover to next available sports server on error/offline/10s timeout
  const advanceToNextStream = useCallback((reason: 'error' | 'timeout' = 'error') => {
    if (streams.length <= 1) {
      if (reason === 'timeout') setLoading(false);
      return;
    }
    triedIndicesRef.current.add(selectedStreamIndex);

    const nextIdx = streams.findIndex((_, idx) => !triedIndicesRef.current.has(idx));
    if (nextIdx === -1) {
      if (reason === 'timeout') setLoading(false);
      return;
    }

    triedIndicesRef.current.add(nextIdx);
    setFailoverBanner(
      reason === 'timeout'
        ? `Server ${selectedStreamIndex + 1} took more than 10s — switching automatically to Server ${nextIdx + 1}...`
        : `Server ${selectedStreamIndex + 1} unavailable — switching automatically to Server ${nextIdx + 1}...`
    );
    setSelectedStreamIndex(nextIdx);
    setLoading(true);
    setIframeKey((k) => k + 1);
  }, [streams, selectedStreamIndex]);

  // Auto-switch server if sports stream stays loading for more than 10 seconds
  useEffect(() => {
    if (!loading || streams.length === 0) return;
    const timeoutId = setTimeout(() => {
      advanceToNextStream('timeout');
    }, 10000);
    return () => clearTimeout(timeoutId);
  }, [loading, streams.length, selectedStreamIndex, iframeKey, advanceToNextStream]);

  useEffect(() => {
    const handleMessage = (event: MessageEvent) => {
      if (event.data && event.data.type === 'MOOFLIX_SPORTS_ERROR') {
        advanceToNextStream('error');
      }
    };
    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, [advanceToNextStream]);

  useEffect(() => {
    if (!failoverBanner) return;
    const t = setTimeout(() => setFailoverBanner(null), 4500);
    return () => clearTimeout(t);
  }, [failoverBanner]);

  const handleClose = useCallback(() => {
    if (document.fullscreenElement) {
      document.exitFullscreen?.().catch(() => {});
    }
    if (iframeRef.current) {
      try {
        iframeRef.current.src = 'about:blank';
      } catch {}
    }
    onClose();
    if (typeof window !== 'undefined') {
      window.history.replaceState({ root: 'moflix_app', tab: 'sports' }, '', '/sports');
    }
  }, [onClose]);

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      containerRef.current?.requestFullscreen?.().then(() => {
        setIsFullscreen(true);
      }).catch(() => {});
    } else {
      document.exitFullscreen?.().then(() => {
        setIsFullscreen(false);
      }).catch(() => {});
    }
  };

  useEffect(() => {
    const originalOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        handleClose();
      } else if (e.key === 'f' || e.key === 'F') {
        const target = e.target as HTMLElement;
        if (target && (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA')) return;
        toggleFullscreen();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => {
      document.body.style.overflow = originalOverflow;
      window.removeEventListener('keydown', handleKeyDown);
      if (iframeRef.current) {
        try {
          iframeRef.current.src = 'about:blank';
        } catch {}
      }
    };
  }, [handleClose]);

  const currentStream = streams[selectedStreamIndex] || streams[0];
  let rawEmbedUrl = currentStream?.embedUrl || '';

  if (rawEmbedUrl.includes('/player/jw/?')) {
    rawEmbedUrl = rawEmbedUrl.replace('/player/jw/?', '/player/hls/?v=542&');
  }

  // Only route hosts that inject popups/ad-scripts or sandbox blockers through /api/clean-stream.
  // damitv.st, ondemand.st & ppv.st require their own origin (for dtk token & /c/*.m3u8 HLS access)
  // and already ship without third-party ad network scripts.
  const shouldCleanProxy = (() => {
    if (!rawEmbedUrl || !rawEmbedUrl.startsWith('http')) return false;
    try {
      const host = new URL(rawEmbedUrl).hostname.toLowerCase();
      return (
        host.includes('bintv-sources') ||
        host.includes('taifood-blog') ||
        host.includes('modiplay')
      );
    } catch {
      return false;
    }
  })();

  const cleanEmbedUrl = rawEmbedUrl
    ? shouldCleanProxy
      ? `/api/clean-stream?url=${encodeURIComponent(rawEmbedUrl)}`
      : rawEmbedUrl
    : '';

  return (
    <div
      ref={containerRef}
      className="fixed inset-0 z-[999999] w-screen h-screen bg-black overflow-hidden flex flex-col items-center justify-between select-none"
      style={{
        backgroundColor: '#000000',
        color: '#ffffff',
        fontFamily: "'Inter', -apple-system, BlinkMacSystemFont, sans-serif",
      }}
      onClick={() => setIsFeedMenuOpen(false)}
    >
      {/* Top Bar */}
      <div
        className="w-full z-40 flex items-center justify-between pointer-events-none transition-all duration-200 shrink-0 border-b border-white/10"
        style={{
          padding: 'max(8px, env(safe-area-inset-top, 8px)) max(8px, env(safe-area-inset-right, 8px)) 8px max(8px, env(safe-area-inset-left, 8px))',
          background: 'linear-gradient(180deg, rgba(0,0,0,0.95) 0%, rgba(10,10,14,0.85) 100%)',
        }}
      >
        <div className="flex items-center gap-1.5 sm:gap-2.5 pointer-events-auto min-w-0">
          <button
            type="button"
            onClick={handleClose}
            aria-label="Back to Sports"
            title="Back"
            className="w-8 h-8 sm:w-auto sm:px-2.5 sm:py-1 rounded-lg bg-black/60 hover:bg-white/20 active:scale-95 text-white border border-white/20 flex items-center justify-center gap-1 text-xs font-bold transition-all cursor-pointer backdrop-blur-md shadow-md shrink-0"
          >
            <ArrowLeft size={16} />
            <span className="hidden sm:inline">Back</span>
          </button>

          <div
            className="flex items-center gap-1 font-black tracking-tight text-white cursor-pointer select-none shrink-0"
            style={{ fontSize: 'clamp(13px, 2.4vw, 17px)' }}
            onClick={handleClose}
          >
            <div>MOO<span style={{ color: '#e50914' }}>FLIX</span></div>
          </div>

          <div className="flex items-center gap-1.5 pl-1.5 sm:pl-2 border-l border-white/20 text-xs text-neutral-300 font-medium truncate max-w-[130px] sm:max-w-[200px] md:max-w-[340px]">
            <span className="truncate text-white font-semibold text-[11px] sm:text-xs">
              {match.title}
            </span>
            {isLive && (
              <span className="hidden sm:flex px-1.5 py-0.5 rounded bg-red-600/30 text-red-400 font-bold text-[9px] border border-red-500/40 uppercase tracking-wide items-center gap-1 shrink-0">
                <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse" />
                <span>Live</span>
              </span>
            )}
          </div>
        </div>

        {/* Right: Server Switcher, Reload, Fullscreen & Close */}
        <div className="flex items-center gap-1 sm:gap-1.5 pointer-events-auto shrink-0">
          {streams.length > 0 && (
            <div className="relative">
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  setIsFeedMenuOpen((prev) => !prev);
                }}
                className="cursor-pointer flex items-center gap-1 text-white rounded-lg font-bold transition-all shadow-md active:scale-95"
                style={{
                  backgroundColor: '#e50914',
                  border: '1px solid rgba(255, 255, 255, 0.2)',
                  padding: '5px 8px',
                  fontSize: 'clamp(10px, 1.8vw, 12px)',
                  boxShadow: '0 4px 12px rgba(229, 9, 20, 0.4)',
                  whiteSpace: 'nowrap',
                }}
              >
                <Tv size={12} />
                <span>Server {selectedStreamIndex + 1}</span>
                <span style={{ opacity: 0.9, fontWeight: 800 }}>
                  (S{selectedStreamIndex + 1})
                </span>
              </button>

              {isFeedMenuOpen && (
                <div
                  className="absolute top-[calc(100%+6px)] right-0 rounded-xl p-1.5 flex flex-col gap-1 z-50 shadow-2xl animate-in fade-in zoom-in-95 duration-150 max-h-[75vh] overflow-y-auto no-scrollbar"
                  style={{
                    backgroundColor: 'rgba(18, 18, 22, 0.97)',
                    backdropFilter: 'blur(16px)',
                    border: '1px solid rgba(255, 255, 255, 0.16)',
                    minWidth: 'clamp(180px, 55vw, 230px)',
                    boxShadow: '0 12px 35px rgba(0,0,0,0.95)',
                  }}
                  onClick={(e) => e.stopPropagation()}
                >
                  <div className="px-2 py-1 text-[10px] font-bold uppercase tracking-wider text-neutral-400 border-b border-white/10 mb-0.5">
                    Select Server ({streams.length} Available • Zero Ads)
                  </div>
                  {streams.map((s, idx) => {
                    const isSelected = selectedStreamIndex === idx;
                    return (
                      <button
                        key={s.id || idx}
                        type="button"
                        onClick={() => {
                          setSelectedStreamIndex(idx);
                          setIsFeedMenuOpen(false);
                          setFailoverBanner(null);
                          setLoading(true);
                          setIframeKey((k) => k + 1);
                        }}
                        className="text-left rounded-lg cursor-pointer transition-all flex items-center justify-between p-2 font-medium"
                        style={{
                          backgroundColor: isSelected ? '#e50914' : 'transparent',
                          color: '#ffffff',
                          fontSize: '11px',
                          fontWeight: isSelected ? 700 : 500,
                          border: 'none',
                          outline: 'none',
                        }}
                      >
                        <div className="flex flex-col truncate pr-2">
                          <span className="font-bold truncate">Server {idx + 1}</span>
                          <span className="text-[9px] opacity-75">{s.hd ? '1080p HD • Zero Ads' : '720p HD • Zero Ads'}</span>
                        </div>
                        <span
                          className={`text-[9px] px-1.5 py-0.5 rounded font-mono font-bold shrink-0 ${
                            isSelected ? 'bg-black/30 text-white' : 'bg-white/10 text-neutral-300'
                          }`}
                        >
                          S{idx + 1}
                        </span>
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          <button
            type="button"
            onClick={() => {
              setLoading(true);
              setIframeKey((k) => k + 1);
            }}
            aria-label="Reload Stream"
            title="Reload Stream"
            className="w-7 h-7 sm:w-8 sm:h-8 rounded-lg bg-black/60 hover:bg-white/20 active:scale-95 text-white border border-white/20 flex items-center justify-center transition-all cursor-pointer backdrop-blur-md"
          >
            <RotateCcw size={13} />
          </button>

          <button
            type="button"
            onClick={toggleFullscreen}
            aria-label={isFullscreen ? 'Exit Fullscreen' : 'Enter Fullscreen'}
            title={isFullscreen ? 'Exit Fullscreen (F)' : 'Fullscreen (F)'}
            className="w-7 h-7 sm:w-8 sm:h-8 rounded-lg bg-black/60 hover:bg-white/20 active:scale-95 text-white border border-white/20 flex items-center justify-center transition-all cursor-pointer backdrop-blur-md"
          >
            {isFullscreen ? <Minimize size={13} /> : <Maximize size={13} />}
          </button>

          <button
            type="button"
            onClick={handleClose}
            aria-label="Close Stream Player"
            title="Close"
            className="w-7 h-7 sm:w-8 sm:h-8 rounded-lg bg-[#e50914] hover:bg-[#f40612] active:scale-95 text-white border border-white/20 flex items-center justify-center transition-all cursor-pointer shadow-md"
          >
            <X size={14} />
          </button>
        </div>
      </div>

      {/* Main Player Area */}
      <div className="relative w-full flex-1 flex flex-col md:flex-row items-center justify-center overflow-hidden bg-black">
        <div
          className={`relative w-full bg-black flex items-center justify-center ${
            isFullscreen ? 'h-full' : 'aspect-video md:h-full md:aspect-auto max-h-[100vh]'
          }`}
        >
          {failoverBanner && (
            <div className="absolute top-3 left-1/2 -translate-x-1/2 z-30 bg-black/90 border border-red-500/50 text-white px-3.5 py-1.5 rounded-lg text-[11px] sm:text-xs font-semibold shadow-xl pointer-events-none whitespace-nowrap">
              {failoverBanner}
            </div>
          )}

          {loading && (
            <div className="absolute inset-0 z-20 flex flex-col items-center justify-center bg-black gap-2 text-white pointer-events-none p-4">
              <div className="w-8 h-8 sm:w-10 sm:h-10 border-3 border-white/20 border-t-[#e50914] rounded-full animate-spin" />
              <div className="text-xs sm:text-sm font-semibold tracking-wide text-neutral-300 flex items-center gap-1.5 text-center">
                <span>Connecting Server {selectedStreamIndex + 1}...</span>
                <span className="w-1.5 h-1.5 rounded-full bg-[#e50914] animate-ping" />
              </div>
            </div>
          )}

          {cleanEmbedUrl ? (
            <iframe
              ref={iframeRef}
              key={`sports-player-${selectedStreamIndex}-${iframeKey}`}
              src={cleanEmbedUrl}
              title={`${match.title} - Server ${selectedStreamIndex + 1}`}
              className="w-full h-full border-0 block bg-black"
              style={{
                width: '100%',
                height: '100%',
                border: 0,
                outline: 'none',
                display: 'block',
              }}
              onLoad={() => setLoading(false)}
              onError={() => advanceToNextStream('error')}
              allowFullScreen
              scrolling="no"
              referrerPolicy="no-referrer-when-downgrade"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
            />
          ) : !loading && (
            <div className="flex flex-col items-center justify-center h-full text-neutral-400 gap-2 p-6 text-center">
              <p className="text-base font-bold text-white">Stream is preparing to broadcast live.</p>
              <p className="text-xs text-neutral-500">{timeInfo.countdown}</p>
            </div>
          )}
        </div>

        {/* Mobile Portrait Controls Bar */}
        {!isFullscreen && (
          <div className="md:hidden w-full bg-neutral-950/95 border-t border-white/10 p-3 flex flex-col gap-2.5 overflow-y-auto max-h-[38vh]">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 min-w-0">
                <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse shrink-0" />
                <span className="text-xs font-bold text-white truncate">{match.title}</span>
              </div>
              <span className="text-[10px] font-mono text-neutral-400 bg-white/10 px-1.5 py-0.5 rounded shrink-0">
                {match.category || 'Live Arena'}
              </span>
            </div>

            {streams.length > 1 && (
              <div className="flex flex-col gap-1">
                <div className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider">
                  Available Servers ({streams.length}):
                </div>
                <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-0.5">
                  {streams.map((s, idx) => {
                    const isSelected = selectedStreamIndex === idx;
                    return (
                      <button
                        key={`quick-server-${idx}`}
                        type="button"
                        onClick={() => {
                          setSelectedStreamIndex(idx);
                          setFailoverBanner(null);
                          setLoading(true);
                          setIframeKey((k) => k + 1);
                        }}
                        className={`px-2.5 py-1.5 rounded-lg text-xs font-semibold shrink-0 flex items-center gap-1.5 transition-all cursor-pointer ${
                          isSelected
                            ? 'bg-[#e50914] text-white shadow-md shadow-red-900/40 ring-1 ring-red-400/50'
                            : 'bg-white/10 text-neutral-300 hover:bg-white/15'
                        }`}
                      >
                        <Tv size={11} />
                        <span>Server {idx + 1}</span>
                        <span className={`text-[9px] px-1 py-0.2 rounded font-mono ${isSelected ? 'bg-black/30' : 'bg-black/20 text-neutral-400'}`}>
                          {s.hd ? 'HD' : 'SD'}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            <div className="flex items-center gap-2 pt-1">
              <button
                type="button"
                onClick={toggleFullscreen}
                className="flex-1 py-2 px-3 rounded-xl bg-white/10 hover:bg-white/15 active:scale-98 text-white font-bold text-xs flex items-center justify-center gap-2 border border-white/10 transition-all cursor-pointer"
              >
                <Maximize size={13} />
                <span>Tap for Fullscreen Cinema</span>
              </button>
              <button
                type="button"
                onClick={() => {
                  setLoading(true);
                  setIframeKey((k) => k + 1);
                }}
                className="py-2 px-3 rounded-xl bg-white/10 hover:bg-white/15 active:scale-98 text-white font-bold text-xs flex items-center justify-center gap-1.5 border border-white/10 transition-all cursor-pointer"
                title="Reload"
              >
                <RotateCcw size={13} />
                <span>Reload</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default SportStreamModal;
