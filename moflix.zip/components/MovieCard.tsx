import React, { memo } from 'react';
import { ContentItem } from '../types';
import { Play } from 'lucide-react';
import LazyImage from './LazyImage';

interface MovieCardProps {
  item: ContentItem;
  onClick: (item: ContentItem) => void;
  aspectRatio?: 'landscape' | 'portrait';
}

const MovieCardComponent: React.FC<MovieCardProps> = ({ 
  item, 
  onClick, 
  aspectRatio = 'portrait' 
}) => {
  const isLandscape = aspectRatio === 'landscape';
  const imageSource = isLandscape 
    ? (item.backdrop || item.thumbnail) 
    : (item.thumbnail || item.backdrop);
  
  const isNewItem = item.badgeType === 'new_release' || 
                    item.badgeType === 'new_episode' || 
                    item.badge?.toLowerCase().includes('new') ||
                    item.badge?.toLowerCase().includes('episode');

  return (
    <div 
      className="group relative w-full overflow-hidden rounded-lg cursor-pointer bg-[#121212] transition-all duration-300 hover:scale-[1.03] hover:z-20 hover:shadow-[0_16px_36px_rgba(0,0,0,0.9)] select-none"
      onClick={() => onClick(item)}
    >
      <div className={`relative ${isLandscape ? 'aspect-video' : 'aspect-[2/3]'} w-full bg-[#161616] overflow-hidden`}>
        {/* Custom Lazy Image with Low-Quality Image Placeholder (LQIP) and Blur-Up transition */}
        <LazyImage 
          src={imageSource} 
          alt={item.title} 
          aspectRatio={isLandscape ? 'landscape' : 'portrait'}
          className="group-hover:scale-105 transition-transform duration-500 ease-out" 
          fallbackText={item.title}
        />
        
        {/* Subtle dark gradient overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent opacity-60 group-hover:opacity-90 transition-opacity duration-300 pointer-events-none" />
        
        {/* Minimal Badges */}
        {(isNewItem || (item.badge && !item.badge.includes('★') && !item.badge.toLowerCase().includes('imdb'))) && (
          <div className="absolute top-2 left-2 right-2 flex items-center justify-between pointer-events-none z-10">
            {isNewItem ? (
              <span className="text-[9px] font-extrabold uppercase tracking-wider px-2 py-0.5 rounded bg-[#e50914] text-white shadow-md backdrop-blur-md">
                Newly Added
              </span>
            ) : item.badge ? (
              <span className="text-[9px] font-bold uppercase tracking-wider px-2 py-0.5 rounded backdrop-blur-md shadow-sm bg-white/15 text-white/90 border border-white/10">
                {item.badge}
              </span>
            ) : null}
          </div>
        )}

        {/* Minimal Play Icon on Hover */}
        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-200 pointer-events-none z-10">
          <div className="w-10 h-10 rounded-full bg-white/90 text-black flex items-center justify-center shadow-xl backdrop-blur-sm transform scale-90 group-hover:scale-100 transition-transform">
            <Play size={16} fill="currentColor" className="ml-0.5" />
          </div>
        </div>

        {/* Minimal Bottom Info */}
        <div className="absolute bottom-0 left-0 right-0 p-2.5 z-10 pointer-events-none">
          <h3 className="text-white text-xs md:text-sm font-semibold truncate leading-tight">
            {item.title}
          </h3>
          <div className="flex items-center gap-2 text-[10px] text-neutral-400 mt-0.5">
            {item.year > 0 && <span>{item.year}</span>}
            <span className="capitalize">{item.type === 'movie' ? 'Movie' : 'Series'}</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export const MovieCard = memo(MovieCardComponent);
export default MovieCard;
