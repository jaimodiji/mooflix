import React, { useEffect, useState, useMemo, useCallback, useRef } from 'react';
import {
  Radio,
  Play,
  Clock,
  Tv,
  RefreshCw,
  X,
  ChevronLeft,
  ChevronRight,
  Film,
  Trophy,
  Layers,
  Sparkles,
  Eye,
  SlidersHorizontal,
  Info,
  ExternalLink,
  Search
} from 'lucide-react';
import {
  APIMatch,
  SportCategory,
  LiveSportsChannel,
  PPVVodCategory,
  PPVVodItem,
  PPVVodDetail,
  fetchSportsList,
  fetchMatches,
  fetchLiveSportsChannels,
  getLiveSportsChannels,
  fetchPPVVods,
  fetchPPVVodById,
  isMatchLive,
  convertPpvToMatch,
  formatMatchTime
} from '../services/sportsService';
import SportMatchCard from './SportMatchCard';
import SportStreamModal from './SportStreamModal';

interface SportsViewProps {
  onExploreMovies?: () => void;
  onExploreSeries?: () => void;
}

type TabType = 'live' | 'upcoming' | 'channels';

export const SportsView: React.FC<SportsViewProps> = ({
  onExploreMovies,
  onExploreSeries,
}) => {
  const [categories, setCategories] = useState<SportCategory[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [activeTab, setActiveTab] = useState<TabType>('live');

  const [matches, setMatches] = useState<APIMatch[]>([]);
  const [channels, setChannels] = useState<LiveSportsChannel[]>([]);
  const [channelSearch, setChannelSearch] = useState<string>('');
  const [channelCategory, setChannelCategory] = useState<string>('all');

  const [vodCategories, setVodCategories] = useState<PPVVodCategory[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [refreshing, setRefreshing] = useState<boolean>(false);

  // Active Stream Player State (Popup Window Modal)
  const [activeMatch, setActiveMatch] = useState<APIMatch | null>(null);

  // Category Slider Scroll Ref & Arrow States
  const categoryScrollRef = useRef<HTMLDivElement>(null);
  const [showCatLeftArrow, setShowCatLeftArrow] = useState(false);
  const [showCatRightArrow, setShowCatRightArrow] = useState(true);

  const checkCategoryArrows = () => {
    if (categoryScrollRef.current) {
      const { scrollLeft, scrollWidth, clientWidth } = categoryScrollRef.current;
      setShowCatLeftArrow(scrollLeft > 15);
      setShowCatRightArrow(scrollLeft < scrollWidth - clientWidth - 15);
    }
  };

  const scrollCategories = (direction: 'left' | 'right') => {
    if (categoryScrollRef.current) {
      const scrollAmount = 260;
      categoryScrollRef.current.scrollBy({
        left: direction === 'left' ? -scrollAmount : scrollAmount,
        behavior: 'smooth'
      });
      setTimeout(checkCategoryArrows, 300);
    }
  };

  // 1. Fetch Categories & Initial Data from PPV.st & JSON dataset
  const loadSportsData = useCallback(async (isRefresh = false) => {
    if (isRefresh) setRefreshing(true);
    else setLoading(true);

    try {
      const [fetchedCategories, fetchedMatches, fetchedChannels, fetchedVods] = await Promise.all([
        fetchSportsList(),
        fetchMatches('all', 'all'),
        fetchLiveSportsChannels(),
        fetchPPVVods(),
      ]);

      setCategories(fetchedCategories);
      setMatches(fetchedMatches);
      setChannels(fetchedChannels);
      setVodCategories(fetchedVods);
    } catch (err) {
      console.error('Error fetching sports data:', err);
    } finally {
      setLoading(false);
      setRefreshing(false);
      setTimeout(checkCategoryArrows, 200);
    }
  }, []);

  useEffect(() => {
    loadSportsData();
  }, [loadSportsData]);

  // Auto-refresh match status every 45s
  useEffect(() => {
    const interval = setInterval(() => {
      loadSportsData(true);
    }, 45000);
    return () => clearInterval(interval);
  }, [loadSportsData]);

  // Compute live counts
  const liveMatchesCount = useMemo(() => {
    return matches.filter((m) => {
      if (m.rawOnDemandStream?.status === 'live') return true;
      const startsAt = m.rawOnDemandStream?.starts_at || m.rawPpvStream?.starts_at;
      const endsAt = m.rawOnDemandStream?.ends_at || m.rawPpvStream?.ends_at;
      const alwaysLive = m.rawOnDemandStream?.always_live || m.rawPpvStream?.always_live;
      return isMatchLive(startsAt, endsAt, alwaysLive);
    }).length;
  }, [matches]);

  const upcomingMatchesCount = useMemo(() => {
    const nowSec = Math.floor(Date.now() / 1000);
    return matches.filter((m) => {
      if (m.rawOnDemandStream?.status === 'upcoming') return true;
      const startsAt = m.rawOnDemandStream?.starts_at || m.rawPpvStream?.starts_at;
      const alwaysLive = m.rawOnDemandStream?.always_live || m.rawPpvStream?.always_live;
      return startsAt && startsAt > nowSec && !alwaysLive;
    }).length;
  }, [matches]);

  // Filter matches based on Active Tab, Category, and Search
  const filteredMatches = useMemo(() => {
    let result = matches;

    // Filter by Tab
    if (activeTab === 'live') {
      result = result.filter((m) => {
        if (m.rawOnDemandStream?.status === 'live' || m.rawPpvStream?.status === 'live' || m.rawOnDemandStream?.always_live || m.rawPpvStream?.always_live) return true;
        const startsAt = m.rawOnDemandStream?.starts_at || m.rawPpvStream?.starts_at;
        const endsAt = m.rawOnDemandStream?.ends_at || m.rawPpvStream?.ends_at;
        const alwaysLive = m.rawOnDemandStream?.always_live || m.rawPpvStream?.always_live;
        return isMatchLive(startsAt, endsAt, alwaysLive);
      });
    } else if (activeTab === 'upcoming') {
      const nowSec = Math.floor(Date.now() / 1000);
      result = result.filter((m) => {
        if (m.rawOnDemandStream?.status === 'upcoming' || m.rawPpvStream?.status === 'upcoming') return true;
        const startsAt = m.rawOnDemandStream?.starts_at || m.rawPpvStream?.starts_at;
        const alwaysLive = m.rawOnDemandStream?.always_live || m.rawPpvStream?.always_live;
        return startsAt && startsAt > nowSec && !alwaysLive;
      });
    } else if (activeTab === 'channels') {
      result = result.filter((m) => Boolean(m.rawOnDemandStream?.always_live || m.rawPpvStream?.always_live) || m.league?.toLowerCase().includes('channel'));
    }

    // Filter by Category
    if (selectedCategory !== 'all') {
      const norm = selectedCategory.toLowerCase().replace(/[^a-z0-9]/g, '');
      const byCategory = result.filter((m) => {
        const cNorm = (m.category || '').toLowerCase().replace(/[^a-z0-9]/g, '');
        return cNorm === norm || cNorm.includes(norm) || norm.includes(cNorm);
      });

      // If tab has matches for this category, return them; otherwise show all fixtures for this category so cards never disappear
      if (byCategory.length > 0) {
        return byCategory;
      } else {
        return matches.filter((m) => {
          const cNorm = (m.category || '').toLowerCase().replace(/[^a-z0-9]/g, '');
          return cNorm === norm || cNorm.includes(norm) || norm.includes(cNorm);
        });
      }
    }

    // If activeTab is 'live' and result is empty, show all active fixtures so deployment is never blank
    if (result.length === 0 && matches.length > 0) {
      return matches.slice(0, 24);
    }

    return result;
  }, [matches, activeTab, selectedCategory]);

  // Sport genres excluding 24/7 Streams (as requested by user)
  const sportGenres = useMemo(() => {
    return categories.filter((cat) => {
      const lower = (cat.name || '').toLowerCase();
      const idLower = (cat.id || '').toLowerCase();
      return !lower.includes('24/7') && !idLower.includes('24-7');
    });
  }, [categories]);

  // Flattened VODs
  const allVods = useMemo(() => {
    const list: PPVVodItem[] = [];
    vodCategories.forEach((cat) => {
      cat.vods?.forEach((v) => {
        list.push({ ...v, category_name: cat.category });
      });
    });
    return list;
  }, [vodCategories]);

  // Channel categories available across 219+ streams
  const channelCategories = useMemo(() => {
    const order = ['all', 'Cricket', 'Football', 'Sports', 'Motorsport', 'Movies & TV', 'Kids', 'News', 'American Football', 'Basketball', 'Combat Sports', 'Tennis', 'Golf'];
    const set = new Set<string>();
    channels.forEach((c) => {
      if (c.category) set.add(c.category);
    });
    const found = Array.from(set);
    return order.filter((o) => o === 'all' || found.includes(o)).concat(found.filter((f) => !order.includes(f)));
  }, [channels]);

  // Filtered channels based on search and category
  const filteredChannels = useMemo(() => {
    let list = channels;
    if (channelCategory !== 'all') {
      list = list.filter((c) => c.category?.toLowerCase() === channelCategory.toLowerCase());
    }
    if (channelSearch.trim()) {
      const q = channelSearch.toLowerCase().trim();
      list = list.filter((c) => c.name.toLowerCase().includes(q) || (c.category && c.category.toLowerCase().includes(q)));
    }
    return list;
  }, [channels, channelCategory, channelSearch]);

  // Open Stream Player & synchronize browser URL to /sport/play?id=...
  const handleOpenStream = useCallback((targetMatch: APIMatch) => {
    setActiveMatch(targetMatch);
    if (typeof window !== 'undefined') {
      const playUrl = `/sport/play?id=${encodeURIComponent(targetMatch.id)}`;
      window.history.pushState({ overlay: 'sport_player', matchId: targetMatch.id }, '', playUrl);
      document.title = `${targetMatch.title} - Live Stream Player`;
    }
  }, []);

  // Close Stream Player & restore /sport URL cleanly
  const handleCloseStream = useCallback(() => {
    setActiveMatch(null);
    if (typeof window !== 'undefined') {
      window.history.replaceState({ root: 'moflix_app', tab: 'sports' }, '', '/sport');
      document.title = 'Live Sports & Matches - MooFlix';
    }
  }, []);

  // Handle clicking a 24/7 Channel
  const handleSelectChannel = (ch: LiveSportsChannel) => {
    const fakeMatch: APIMatch = {
      id: ch.id,
      title: ch.name,
      category: ch.category,
      date: Date.now(),
      poster: ch.logo,
      popular: true,
      sources: ch.sources.map((_, idx) => ({ source: `Server ${idx + 1}`, id: `${ch.id}-${idx + 1}` })),
      viewers: ch.viewers,
      league: '24/7 Live Channel',
      venue: 'Server 1',
      _streamSources: ch.sources.map((s, idx) => ({
        ...s,
        streamNo: idx + 1,
        source: `Server ${idx + 1}`,
        serverName: `Server ${idx + 1}`,
      })),
    };
    handleOpenStream(fakeMatch);
  };

  // Synchronize on browser Back / Forward buttons
  useEffect(() => {
    if (typeof window === 'undefined') return;
    const handlePopState = () => {
      const path = window.location.pathname.toLowerCase();
      if (path === '/sport/play' || path === '/sports/play') {
        const id = new URLSearchParams(window.location.search).get('id');
        if (id) {
          const foundMatch = matches.find((m) => m.id === id);
          if (foundMatch) {
            setActiveMatch(foundMatch);
            return;
          }
          const foundChannel = channels.find((c) => c.id === id);
          if (foundChannel) {
            handleSelectChannel(foundChannel);
            return;
          }
        }
      } else {
        setActiveMatch(null);
      }
    };

    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, [matches, channels]);

  // Direct deep link check on initial load (e.g. user visits /sport/play?id=...)
  useEffect(() => {
    if (typeof window === 'undefined') return;
    const path = window.location.pathname.toLowerCase();
    if (path === '/sport/play' || path === '/sports/play') {
      const id = new URLSearchParams(window.location.search).get('id');
      if (id) {
        const found = matches.find((m) => m.id === id);
        if (found) {
          setActiveMatch(found);
        } else {
          const foundCh = channels.find((c) => c.id === id);
          if (foundCh) {
            handleSelectChannel(foundCh);
          } else if (!loading) {
            // Standalone stream fallback
            const fallbackMatch: APIMatch = {
              id,
              title: id.replace(/^cr-|^ft-|^channel-/, '').replace(/-/g, ' ').toUpperCase(),
              category: 'Sports',
              date: Date.now(),
              popular: true,
              sources: [{ source: 'Server 1', id: `${id}-1` }],
              league: 'Live Sports',
              _streamSources: [
                {
                  id: `${id}-official`,
                  streamNo: 1,
                  language: 'English',
                  hd: true,
                  embedUrl: `https://damitv.st/embed/?id=${id}`,
                  source: 'Server 1',
                  serverName: 'Server 1',
                },
              ],
            };
            setActiveMatch(fallbackMatch);
          }
        }
      }
    }
  }, [matches, channels, loading]);

  // Handle clicking a VOD - Opens in unified full-tab SportStreamModal
  const handleSelectVod = async (vod: PPVVodItem) => {
    try {
      const detail = await fetchPPVVodById(vod.id);
      const streamUrl = detail?.source?.data || `https://api.ppv.st/vods/${vod.id}`;
      const fakeMatch: APIMatch = {
        id: `vod-${vod.id}`,
        title: vod.name,
        category: vod.category_name || 'VOD Replay',
        date: vod.event_date ? vod.event_date * 1000 : Date.now(),
        poster: vod.poster,
        popular: true,
        sources: [{ source: 'Server 1', id: `vod-${vod.id}` }],
        league: vod.category_name || 'PPV Replay',
        venue: vod.tag,
        _streamSources: [{
          id: `vod-${vod.id}-s1`,
          streamNo: 1,
          language: 'English',
          hd: true,
          embedUrl: streamUrl,
          source: 'Server 1',
          serverName: 'Server 1',
        }],
      };
      handleOpenStream(fakeMatch);
    } catch {
      console.warn('Failed to fetch VOD detail');
    }
  };

  return (
    <div className="min-h-screen bg-[#07070d] text-white pt-20 sm:pt-24 pb-20 px-3.5 sm:px-6 md:px-12 select-none relative overflow-x-hidden">
      {/* iOS 27 Liquid Glass Ambient Backlight Elements */}
      <div className="fixed top-16 left-1/4 w-[500px] h-[300px] bg-red-600/10 rounded-full blur-[140px] pointer-events-none" />
      <div className="fixed top-1/2 right-10 w-[450px] h-[300px] bg-blue-600/10 rounded-full blur-[140px] pointer-events-none" />

      <div className="max-w-[1750px] mx-auto space-y-4 md:space-y-6 relative z-10">
        
        {/* 1. TOP MAIN FILTER BUTTONS ROW: Live, Upcoming, 24/7 Streams (Only 3 buttons, without counts) */}
        <div className="flex items-center justify-between gap-2 sm:gap-3 pt-1">
          {/* iOS 27 Segmented Action Pills */}
          <div className="p-1 sm:p-1.5 rounded-full bg-white/[0.06] backdrop-blur-3xl border border-white/15 flex items-center gap-1 sm:gap-1.5 shadow-[inset_0_1px_1px_rgba(255,255,255,0.2),0_8px_32px_rgba(0,0,0,0.5)] overflow-x-auto no-scrollbar shrink min-w-0 max-w-full">
            {[
              { id: 'live', label: 'Live', icon: Radio, highlight: true },
              { id: 'upcoming', label: 'Upcoming', icon: Clock },
              { id: 'channels', label: '24/7 Streams', icon: Tv },
            ].map((tab) => {
              const isActive = activeTab === tab.id;
              const IconComp = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as TabType)}
                  className={`px-3.5 sm:px-5 py-1.5 sm:py-2.5 rounded-full text-xs sm:text-sm font-bold transition-all flex items-center gap-1.5 sm:gap-2 cursor-pointer shrink-0 select-none ${
                    isActive
                      ? 'bg-white text-black shadow-[0_4px_20px_rgba(255,255,255,0.45)] scale-[1.02]'
                      : 'text-neutral-300 hover:text-white hover:bg-white/10'
                  }`}
                >
                  <IconComp size={14} className={isActive ? 'text-black' : tab.highlight ? 'text-red-400 animate-pulse' : 'text-neutral-400'} />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>

          {/* Refresh Action */}
          <button
            onClick={() => loadSportsData(true)}
            disabled={refreshing}
            title="Refresh Stream Schedule"
            className="p-2 sm:px-3 sm:py-2 rounded-full bg-white/[0.06] hover:bg-white/15 active:scale-95 text-white text-xs font-bold border border-white/15 transition-all flex items-center gap-1.5 cursor-pointer shadow-md shrink-0"
          >
            <RefreshCw size={14} className={refreshing ? 'animate-spin text-red-400' : ''} />
            <span className="hidden sm:inline">Refresh</span>
          </button>
        </div>

        {/* 2. GAMES GENRES ROW WITH LOCKED VERTICAL SLIDE ARROWS (Fixed without shifting down) */}
        <div className="relative group/genres pt-1">
          {/* Left Slide Button (Vertically centered & fixed) */}
          {showCatLeftArrow && (
            <div className="absolute left-0 inset-y-0 z-20 flex items-center pr-3 bg-gradient-to-r from-[#07070d] via-[#07070d]/90 to-transparent pointer-events-none">
              <button
                type="button"
                onClick={(e) => {
                  e.preventDefault();
                  e.stopPropagation();
                  scrollCategories('left');
                }}
                aria-label="Slide Left"
                className="w-8 h-8 sm:w-9 sm:h-9 rounded-full bg-black/90 hover:bg-black active:scale-95 text-white border border-white/25 shadow-xl flex items-center justify-center transition-all cursor-pointer pointer-events-auto"
              >
                <ChevronLeft size={18} />
              </button>
            </div>
          )}

          {/* Right Slide Button (Vertically centered & fixed) */}
          {showCatRightArrow && (
            <div className="absolute right-0 inset-y-0 z-20 flex items-center pl-3 bg-gradient-to-l from-[#07070d] via-[#07070d]/90 to-transparent pointer-events-none">
              <button
                type="button"
                onClick={(e) => {
                  e.preventDefault();
                  e.stopPropagation();
                  scrollCategories('right');
                }}
                aria-label="Slide Right"
                className="w-8 h-8 sm:w-9 sm:h-9 rounded-full bg-black/90 hover:bg-black active:scale-95 text-white border border-white/25 shadow-xl flex items-center justify-center transition-all cursor-pointer pointer-events-auto"
              >
                <ChevronRight size={18} />
              </button>
            </div>
          )}

          {/* Scrollable Category Row */}
          <div
            ref={categoryScrollRef}
            onScroll={checkCategoryArrows}
            className="flex items-center gap-2 overflow-x-auto no-scrollbar py-1.5 px-1 scroll-smooth"
          >
            {sportGenres.map((cat) => {
              const isSelected = selectedCategory === cat.id;
              return (
                <button
                  key={cat.id}
                  onClick={() => setSelectedCategory(cat.id)}
                  className={`px-3.5 py-1.5 sm:py-2 rounded-full text-xs font-bold transition-all flex items-center gap-1.5 shrink-0 border cursor-pointer select-none ${
                    isSelected
                      ? 'bg-red-600 text-white border-red-500 shadow-[0_0_16px_rgba(229,9,20,0.5)]'
                      : 'bg-white/[0.05] hover:bg-white/[0.12] text-neutral-300 hover:text-white border-white/15 backdrop-blur-md'
                  }`}
                >
                  <span>{cat.icon || '🏆'}</span>
                  <span>{cat.name}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* 3. MAIN CONTENT AREA */}
        {loading ? (
          /* Loading Skeletons */
          <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-3 xl:grid-cols-4 gap-2.5 sm:gap-4 md:gap-6 pt-2">
            {Array.from({ length: 8 }).map((_, i) => (
              <div key={i} className="rounded-2xl sm:rounded-3xl bg-white/[0.04] border border-white/10 aspect-[16/11] animate-pulse p-2.5 sm:p-4 flex flex-col justify-between">
                <div className="w-full aspect-[16/9] rounded-xl sm:rounded-2xl bg-white/5" />
                <div className="space-y-2 mt-2 sm:mt-3">
                  <div className="h-3.5 sm:h-4 bg-white/10 rounded-md w-3/4" />
                  <div className="h-2.5 sm:h-3 bg-white/5 rounded-md w-1/2" />
                </div>
              </div>
            ))}
          </div>
        ) : activeTab === 'vods' ? (
          /* VODs / PPV REPLAYS SECTION */
          <div className="space-y-4 pt-1">
            <div className="flex items-center gap-2">
              <Film size={18} className="text-purple-400" />
              <h2 className="text-base sm:text-lg font-black text-white tracking-tight">
                PPV Replays &amp; Exclusive VODs
              </h2>
            </div>

            {allVods.length === 0 ? (
              <div className="rounded-2xl sm:rounded-3xl bg-white/[0.03] border border-white/10 p-12 text-center text-neutral-400">
                <Film size={36} className="mx-auto mb-3 text-neutral-500" />
                <p className="text-base font-semibold">No PPV replays found matching your search.</p>
              </div>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-3 xl:grid-cols-4 gap-2.5 sm:gap-4 md:gap-6">
                {allVods.map((vod) => (
                  <div
                    key={`vod-${vod.id}`}
                    onClick={() => handleSelectVod(vod)}
                    className="group relative rounded-2xl sm:rounded-3xl bg-[#0e0f18]/80 hover:bg-[#151726]/95 backdrop-blur-3xl border border-white/[0.12] hover:border-white/30 transition-all duration-300 cursor-pointer shadow-[inset_0_1px_1px_rgba(255,255,255,0.18),0_12px_40px_rgba(0,0,0,0.6)] hover:shadow-[0_20px_50px_rgba(0,0,0,0.85)] active:scale-[0.985] flex flex-col justify-between overflow-hidden"
                  >
                    <div className="relative aspect-[16/9] w-full bg-black/60 overflow-hidden">
                      <img
                        src={vod.poster}
                        alt={vod.name}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                        loading="lazy"
                        onError={(e) => {
                          (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?w=800';
                        }}
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-[#0e0f18] via-transparent to-black/60 pointer-events-none" />
                      
                      <div className="absolute top-2 sm:top-3 left-2 sm:left-3">
                        <span className="px-2 sm:px-2.5 py-0.5 sm:py-1 rounded-full bg-purple-600/80 text-white text-[9px] sm:text-[10px] font-black uppercase tracking-wider backdrop-blur-md border border-purple-400/40">
                          {vod.category_name || 'VOD Replay'}
                        </span>
                      </div>

                      <div className="absolute bottom-1.5 sm:bottom-2.5 right-2 sm:right-3 flex items-center gap-1 px-1.5 sm:px-2 py-0.5 rounded-md bg-black/70 backdrop-blur-md text-[9px] sm:text-[10px] text-neutral-300 border border-white/15">
                        <Eye size={10} className="text-neutral-400" />
                        <span>{vod.views?.toLocaleString() || '1.2k'}</span>
                      </div>

                      <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                        <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-white/95 text-black flex items-center justify-center shadow-2xl transform scale-90 group-hover:scale-100 transition-transform">
                          <Play size={18} className="fill-black translate-x-0.5" />
                        </div>
                      </div>
                    </div>

                    <div className="p-2.5 sm:p-4 flex flex-col justify-between gap-2 sm:gap-3 flex-1">
                      <div>
                        <h3 className="text-white text-xs sm:text-sm md:text-base font-bold line-clamp-2 leading-snug group-hover:text-purple-400 transition-colors">
                          {vod.name}
                        </h3>
                        {vod.tag && (
                          <p className="text-[10px] sm:text-xs text-neutral-400 mt-1 truncate">
                            Tag: {vod.tag}
                          </p>
                        )}
                      </div>

                      <div className="pt-1.5 sm:pt-2 border-t border-white/[0.08] flex items-center justify-between">
                        <span className="text-[10px] sm:text-[11px] text-neutral-400">Full Replay</span>
                        <div className="px-2.5 sm:px-3 py-1 rounded-full bg-purple-600/20 group-hover:bg-purple-600 text-purple-300 group-hover:text-white font-bold text-[10px] sm:text-xs border border-purple-500/30 transition-all flex items-center gap-1">
                          <Play size={10} className="fill-current" />
                          <span>Watch</span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        ) : activeTab === 'channels' ? (
          /* 24/7 LIVE CHANNELS SECTION (219 CHANNELS WITH SEARCH & GENRE PILLS) */
          <div className="space-y-4 pt-1">
            {/* Header & Search Bar */}
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 bg-white/[0.04] p-3 sm:p-4 rounded-2xl sm:rounded-3xl border border-white/10 backdrop-blur-xl">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-blue-500/20 border border-blue-400/30 flex items-center justify-center text-blue-400 shrink-0">
                  <Tv size={17} />
                </div>
                <div>
                  <h2 className="text-sm sm:text-base md:text-lg font-black text-white tracking-tight flex items-center gap-2">
                    <span>24/7 Global Live TV Channels</span>
                    <span className="px-2 py-0.5 rounded-full bg-blue-600/30 border border-blue-400/30 text-blue-300 text-[10px] font-bold">
                      {channels.length} Total
                    </span>
                  </h2>
                  <p className="text-[11px] text-neutral-400 hidden sm:block">
                    Cricket, Football, Sports, Entertainment, Kids, News & Movies networks
                  </p>
                </div>
              </div>

              {/* Search Bar */}
              <div className="relative w-full sm:w-72 md:w-80">
                <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400 pointer-events-none" />
                <input
                  type="text"
                  value={channelSearch}
                  onChange={(e) => setChannelSearch(e.target.value)}
                  placeholder="Search channels (e.g. Willow, Sony, Sky, beIN)..."
                  className="w-full pl-9 pr-8 py-2 rounded-xl sm:rounded-2xl bg-white/[0.07] border border-white/15 focus:border-blue-400 focus:bg-white/[0.12] text-xs text-white placeholder-neutral-500 outline-none transition-all"
                />
                {channelSearch && (
                  <button
                    onClick={() => setChannelSearch('')}
                    className="absolute right-2.5 top-1/2 -translate-y-1/2 text-neutral-400 hover:text-white p-0.5 rounded-full hover:bg-white/10"
                  >
                    <X size={14} />
                  </button>
                )}
              </div>
            </div>

            {/* Category Filter Pills */}
            <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-1">
              {channelCategories.map((cat) => {
                const isSelected = channelCategory.toLowerCase() === cat.toLowerCase();
                const count = cat === 'all'
                  ? channels.length
                  : channels.filter((c) => c.category?.toLowerCase() === cat.toLowerCase()).length;
                return (
                  <button
                    key={cat}
                    onClick={() => setChannelCategory(cat)}
                    className={`px-3 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-all duration-200 cursor-pointer flex items-center gap-1.5 shrink-0 ${
                      isSelected
                        ? 'bg-blue-600 text-white shadow-[0_0_15px_rgba(37,99,235,0.4)] border border-blue-400/40'
                        : 'bg-white/[0.05] hover:bg-white/[0.1] text-neutral-300 hover:text-white border border-white/[0.08]'
                    }`}
                  >
                    <span>{cat === 'all' ? 'All Channels' : cat}</span>
                    <span className={`text-[10px] px-1.5 py-0.2 rounded-full ${isSelected ? 'bg-white/20 text-white' : 'bg-white/10 text-neutral-400'}`}>
                      {count}
                    </span>
                  </button>
                );
              })}
            </div>

            {/* Channels Count & Active Filter Indicator */}
            <div className="flex items-center justify-between text-xs text-neutral-400 px-1">
              <span>Showing <strong className="text-white">{filteredChannels.length}</strong> of {channels.length} channels</span>
              {(channelSearch || channelCategory !== 'all') && (
                <button
                  onClick={() => { setChannelSearch(''); setChannelCategory('all'); }}
                  className="text-blue-400 hover:text-blue-300 font-medium underline cursor-pointer"
                >
                  Reset filters
                </button>
              )}
            </div>

            {/* 219 Channels Grid */}
            {filteredChannels.length === 0 ? (
              <div className="rounded-2xl sm:rounded-3xl bg-white/[0.03] border border-white/10 p-12 text-center text-neutral-400 max-w-lg mx-auto">
                <Tv size={36} className="mx-auto mb-3 text-neutral-500 animate-pulse" />
                <h3 className="text-base font-bold text-white mb-1">No channels found</h3>
                <p className="text-xs text-neutral-400 mb-4">
                  No channels match "{channelSearch || channelCategory}". Try searching for another network.
                </p>
                <button
                  onClick={() => { setChannelSearch(''); setChannelCategory('all'); }}
                  className="px-4 py-2 rounded-full bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold transition-all cursor-pointer"
                >
                  Show All {channels.length} Channels
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-3 xl:grid-cols-4 gap-2.5 sm:gap-4 md:gap-6">
                {filteredChannels.map((ch) => (
                  <div
                    key={ch.id}
                    onClick={() => handleSelectChannel(ch)}
                    className="group relative rounded-2xl sm:rounded-3xl bg-[#0e0f18]/80 hover:bg-[#151726]/95 backdrop-blur-3xl border border-white/[0.12] hover:border-white/30 transition-all duration-300 cursor-pointer shadow-[inset_0_1px_1px_rgba(255,255,255,0.18),0_12px_40px_rgba(0,0,0,0.6)] hover:shadow-[0_20px_50px_rgba(0,0,0,0.85)] active:scale-[0.985] flex flex-col justify-between overflow-hidden"
                  >
                    <div className="relative aspect-[16/9] w-full bg-black/60 overflow-hidden flex items-center justify-center p-3">
                      <img
                        src={ch.logo}
                        alt={ch.name}
                        className="w-full h-full object-contain group-hover:scale-105 transition-transform duration-500"
                        loading="lazy"
                        onError={(e) => {
                          // Fallback to high quality generic sports logo
                          (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1540747913346-19e32dc3e97e?w=600&auto=format&fit=crop&q=80';
                        }}
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-[#0e0f18] via-transparent to-black/60 pointer-events-none" />

                      <div className="absolute top-2 sm:top-3 left-2 sm:left-3">
                        <span className="px-2 sm:px-2.5 py-0.5 sm:py-1 rounded-full bg-blue-600/90 text-white text-[9px] sm:text-[10px] font-black uppercase tracking-wider backdrop-blur-md border border-blue-400/40">
                          {ch.category || 'Live TV'}
                        </span>
                      </div>

                      <div className="absolute top-2 sm:top-3 right-2 sm:right-3 flex items-center gap-1 sm:gap-1.5 px-1.5 sm:px-2 py-0.5 rounded-full bg-red-600/90 text-white text-[9px] sm:text-[10px] font-black tracking-wider animate-pulse">
                        <span className="w-1.5 h-1.5 rounded-full bg-white" />
                        <span>LIVE</span>
                      </div>

                      <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                        <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-white/95 text-black flex items-center justify-center shadow-2xl transform scale-90 group-hover:scale-100 transition-transform">
                          <Play size={18} className="fill-black translate-x-0.5" />
                        </div>
                      </div>
                    </div>

                    <div className="p-2.5 sm:p-4 flex flex-col justify-between gap-2 sm:gap-3 flex-1">
                      <div>
                        <div className="flex items-center gap-1.5 sm:gap-2">
                          <span className="text-[10px] sm:text-[11px] font-bold text-neutral-400">{ch.category}</span>
                          <span className="text-neutral-500">•</span>
                          <span className="text-[10px] sm:text-[11px] font-mono text-neutral-400">{ch.quality || '1080p HD'}</span>
                        </div>
                        <h3 className="text-white text-xs sm:text-sm md:text-base font-bold leading-snug group-hover:text-blue-400 transition-colors mt-0.5">
                          {ch.name}
                        </h3>
                        <p className="text-[10px] sm:text-xs text-neutral-400 mt-1 line-clamp-1">
                          {ch.currentShow || 'Live Broadcast Stream'}
                        </p>
                      </div>

                      <div className="pt-1.5 sm:pt-2 border-t border-white/[0.08] flex items-center justify-between">
                        <div className="flex items-center gap-1 text-[10px] sm:text-[11px] text-emerald-400 font-semibold truncate">
                          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse shrink-0" />
                          <span>{(ch.viewers / 1000).toFixed(1)}k watching</span>
                        </div>
                        <div className="px-2.5 sm:px-3 py-1 rounded-full bg-white/10 group-hover:bg-blue-600 text-white font-bold text-[10px] sm:text-xs border border-white/15 transition-all flex items-center gap-1 shrink-0">
                          <Play size={10} className="fill-current" />
                          <span>Stream</span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        ) : (
          /* MATCH STREAMS GRID (Live, Upcoming, All) */
          <div>
            {filteredMatches.length === 0 ? (
              <div className="rounded-2xl sm:rounded-3xl bg-white/[0.03] border border-white/10 p-8 sm:p-12 text-center text-neutral-400 max-w-lg mx-auto space-y-3">
                <Radio size={36} className="mx-auto text-neutral-500 animate-pulse" />
                <h3 className="text-base font-bold text-white">No active fixtures in {selectedCategory !== 'all' ? selectedCategory : 'this category'} right now</h3>
                <p className="text-xs text-neutral-400">
                  Live matches will appear here automatically when events begin. You can explore all live matches or watch 24/7 sports networks.
                </p>
                <div className="flex items-center justify-center gap-2.5 pt-2">
                  <button
                    onClick={() => { setSelectedCategory('all'); setActiveTab('live'); }}
                    className="px-4 py-2 rounded-full bg-white/10 hover:bg-white/20 text-white text-xs font-bold border border-white/15 transition-all cursor-pointer active:scale-95"
                  >
                    All Live Sports
                  </button>
                  <button
                    onClick={() => setActiveTab('channels')}
                    className="px-4 py-2 rounded-full bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold transition-all cursor-pointer active:scale-95"
                  >
                    24/7 Sports TV
                  </button>
                </div>
              </div>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-3 xl:grid-cols-4 gap-2.5 sm:gap-4 md:gap-6">
                {filteredMatches.map((match) => (
                  <SportMatchCard
                    key={`match-${match.id}`}
                    match={match}
                    onSelect={(m) => handleOpenStream(m)}
                  />
                ))}
              </div>
            )}
          </div>
        )}

      </div>

      {/* 4. ACTIVE LIVE MATCH / STREAM POPUP MODAL (Window modal like movie/series details) */}
      {activeMatch && (
        <SportStreamModal
          match={activeMatch}
          allMatches={matches}
          onSelectMatch={handleOpenStream}
          onClose={handleCloseStream}
        />
      )}

    </div>
  );
};

export default SportsView;
