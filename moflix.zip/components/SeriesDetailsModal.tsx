import React, { useState, useEffect, useMemo, useRef } from 'react';
import { Play, X, Film, Star, Plus, Check, Download, Share2, ExternalLink, RefreshCw, ChevronLeft, ChevronRight } from 'lucide-react';
import { ContentItem, ExtendedDetails, Episode, PlayConfig } from '../types';
import { fetchExtendedDetails, fetchEpisodes } from '../services/tmdbService';
import { SocialBacklinkShareModal } from './SocialBacklinkShareModal';
import { getDownloadUrl } from '../utils/playerUtils';

interface SeriesDetailsModalProps {
  item: ContentItem;
  onModalClose: () => void;
  onItemSelect: (item: ContentItem) => void;
  onPlay: (config: PlayConfig) => void;
  onDownload?: (config: { item: ContentItem; season: number; episode: number; imdbId?: string | null }) => void;
}

const SeriesDetailsModal: React.FC<SeriesDetailsModalProps> = ({ 
  item, 
  onModalClose, 
  onItemSelect, 
  onPlay,
  onDownload,
}) => {
  const [details, setDetails] = useState<ExtendedDetails | null>(null);
  const [episodes, setEpisodes] = useState<Episode[]>([]);
  const [activeSeason, setActiveSeason] = useState<number>(1);
  const [loadingDetails, setLoadingDetails] = useState(true);
  const [loadingEpisodes, setLoadingEpisodes] = useState(false);
  const [showTrailer, setShowTrailer] = useState(false);
  const [activeDownloadEpNumber, setActiveDownloadEpNumber] = useState<number | null>(null);
  const [downloadReloadKey, setDownloadReloadKey] = useState(1);
  const [isInList, setIsInList] = useState(false);
  const [showShareModal, setShowShareModal] = useState(false);
  const modalRef = useRef<HTMLDivElement>(null);
  const seasonsContainerRef = useRef<HTMLDivElement>(null);

  const scrollSeasons = (direction: 'left' | 'right') => {
    if (seasonsContainerRef.current) {
      seasonsContainerRef.current.scrollBy({
        left: direction === 'left' ? -220 : 220,
        behavior: 'smooth'
      });
    }
  };

  useEffect(() => {
    const originalOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';

    const fetchDetails = async () => {
      setLoadingDetails(true);
      if (modalRef.current) modalRef.current.scrollTo(0, 0);
      try {
        const extendedDetails = await fetchExtendedDetails(item.id, item.type);
        setDetails(extendedDetails);
        
        if (extendedDetails.seasons && extendedDetails.seasons.length > 0) {
          // Find the latest released season (highest season number > 0)
          const validSeasons = extendedDetails.seasons
            .filter(s => s.seasonNumber > 0)
            .sort((a, b) => a.seasonNumber - b.seasonNumber);

          if (validSeasons.length > 0) {
            const firstSeason = validSeasons[0].seasonNumber;
            setActiveSeason(firstSeason);
          } else {
            setActiveSeason(1);
          }
        } else {
          setActiveSeason(1);
        }
      } catch (error) { 
        console.error('Failed to load series details:', error);
      } finally { 
        setLoadingDetails(false); 
      }
    };
    fetchDetails();

    return () => { 
      document.body.style.overflow = originalOverflow; 
    };
  }, [item.id, item.type]);

  useEffect(() => {
    if (activeSeason === null) return;
    const fetchSeasonEpisodes = async () => {
      setLoadingEpisodes(true);
      try {
        const episodeData = await fetchEpisodes(item.id, activeSeason);
        setEpisodes(episodeData);
      } catch (error) { 
        setEpisodes([]); 
      } finally { 
        setLoadingEpisodes(false); 
      }
    };
    fetchSeasonEpisodes();
  }, [activeSeason, item.id]);

  useEffect(() => {
    try {
      const saved = JSON.parse(localStorage.getItem('moflix_watchlist') || '[]');
      setIsInList(saved.some((i: any) => i.id === item.id));
    } catch {
      setIsInList(false);
    }
  }, [item.id]);

  const toggleWatchlist = () => {
    try {
      const saved = JSON.parse(localStorage.getItem('moflix_watchlist') || '[]');
      let updated;
      if (isInList) {
        updated = saved.filter((i: any) => i.id !== item.id);
        setIsInList(false);
      } else {
        updated = [...saved, { ...item, type: 'series' }];
        setIsInList(true);
      }
      localStorage.setItem('moflix_watchlist', JSON.stringify(updated));
    } catch (err) {
      console.error(err);
    }
  };

  const seasons = useMemo(() => {
    return (details?.seasons?.filter(s => s.seasonNumber > 0) || [])
      .sort((a, b) => a.seasonNumber - b.seasonNumber);
  }, [details]);

  return (
    <div 
      className="fixed inset-0 z-[300] bg-black/85 backdrop-blur-md flex items-center justify-center p-0 md:p-6 overflow-hidden animate-in fade-in duration-200" 
      onClick={onModalClose}
    >
      <div 
        ref={modalRef}
        className="relative w-full h-full md:h-auto md:max-h-[90vh] max-w-4xl bg-[#0f0f0f] border border-white/[0.08] shadow-2xl overflow-y-auto rounded-none md:rounded-2xl no-scrollbar" 
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button 
          onClick={onModalClose} 
          aria-label="Close"
          className="absolute top-4 right-4 z-[210] w-9 h-9 bg-black/60 hover:bg-black/90 backdrop-blur-md border border-white/10 rounded-full flex items-center justify-center text-white/80 hover:text-white transition-colors cursor-pointer"
        >
          <X size={18} />
        </button>

        {loadingDetails ? (
          <div className="min-h-[50vh] flex flex-col items-center justify-center gap-3">
            <div className="w-8 h-8 border-2 border-white/20 border-t-white rounded-full animate-spin"></div>
          </div>
        ) : (
          <>
            {/* Hero Area */}
            <div className="relative aspect-video w-full bg-[#141414] overflow-hidden">
              {item.backdrop ? (
                <img 
                  src={item.backdrop} 
                  className="w-full h-full object-cover brightness-[0.7]" 
                  alt={item.title} 
                  referrerPolicy="no-referrer"
                />
              ) : (
                <div className="w-full h-full bg-[#141414]" />
              )}
              <div className="absolute inset-0 bg-gradient-to-t from-[#0f0f0f] via-[#0f0f0f]/40 to-transparent" />
              
              <div className="absolute bottom-0 left-0 p-6 md:p-8 w-full">
                {details?.logoUrl ? (
                  <img 
                    src={details.logoUrl} 
                    className="h-12 md:h-20 object-contain mb-4 drop-shadow-xl max-w-[70%]" 
                    alt={item.title} 
                    referrerPolicy="no-referrer"
                  />
                ) : (
                  <h1 className="text-2xl md:text-4xl font-extrabold mb-3 tracking-tight text-white drop-shadow-lg">
                    {item.title}
                  </h1>
                )}
                
                <div className="flex flex-wrap items-center gap-2.5 sm:gap-3">
                  <button 
                    onClick={() => {
                      setShowTrailer(false);
                      onPlay({ item, season: activeSeason, episode: 1, provider: '1', imdbId: details?.imdbId });
                    }} 
                    className="px-5 sm:px-6 py-2 sm:py-2.5 rounded-full font-bold text-xs sm:text-sm md:text-base transition-all duration-200 flex items-center gap-2 border active:scale-95 cursor-pointer shadow-lg bg-white hover:bg-neutral-200 text-black border-white"
                  >
                    <Play size={18} fill="currentColor" />
                    <span>{`Play S${activeSeason}:E1`}</span>
                  </button>

                  {details?.trailerKey && (
                    <button 
                      onClick={() => {
                        setShowTrailer(prev => !prev);
                      }} 
                      className={`px-3.5 sm:px-4 py-2 sm:py-2.5 backdrop-blur-md rounded-full font-bold text-xs sm:text-sm transition-all duration-200 flex items-center gap-2 border active:scale-95 cursor-pointer ${
                        showTrailer 
                          ? 'bg-red-600 border-red-500 text-white shadow-lg shadow-red-900/40' 
                          : 'bg-white/10 hover:bg-white/20 text-white border-white/10'
                      }`}
                    >
                      <Film size={15} />
                      <span>{showTrailer ? 'Hide Trailer' : 'Trailer'}</span>
                    </button>
                  )}
                  
                  <button 
                    onClick={toggleWatchlist}
                    aria-label={isInList ? "Remove from List" : "Add to List"}
                    className={`w-9 h-9 sm:w-10 sm:h-10 rounded-full flex items-center justify-center text-white transition-all duration-200 backdrop-blur-md border border-white/15 active:scale-95 cursor-pointer ${
                      isInList ? 'bg-white/20' : 'bg-black/40 hover:bg-white/10'
                    }`}
                  >
                    {isInList ? <Check size={18} strokeWidth={2.5} /> : <Plus size={18} />}
                  </button>

                  <button 
                    onClick={() => setShowShareModal(true)}
                    aria-label="Share show on WhatsApp and Twitter"
                    title="Share on WhatsApp & Twitter"
                    className="w-9 h-9 sm:w-10 sm:h-10 rounded-full flex items-center justify-center text-white transition-all duration-200 backdrop-blur-md border border-white/15 bg-black/40 hover:bg-white/10 active:scale-95 cursor-pointer"
                  >
                    <Share2 size={17} />
                  </button>
                </div>
              </div>
            </div>

            {/* Social Share & Backlink Modal */}
            <SocialBacklinkShareModal
              item={item}
              isOpen={showShareModal}
              onClose={() => setShowShareModal(false)}
            />

            {/* Official Trailer Overlay Window */}
            {showTrailer && details?.trailerKey && (
              <div className="p-4 md:p-6 bg-black/95 border-b border-white/10 animate-in fade-in duration-200">
                <div className="flex items-center justify-between pb-2 mb-2 border-b border-white/10 text-xs text-neutral-300">
                  <span className="font-semibold flex items-center gap-1.5 text-white">
                    <Film size={14} className="text-red-500" />
                    <span>Official Trailer</span>
                  </span>
                  <button 
                    onClick={() => setShowTrailer(false)} 
                    className="px-2.5 py-1 rounded-full bg-white/10 hover:bg-white/20 text-neutral-300 hover:text-white transition-all duration-200 active:scale-95 cursor-pointer"
                  >
                    Close
                  </button>
                </div>
                <div className="relative aspect-video rounded-lg overflow-hidden border border-white/10 bg-black">
                  <iframe 
                    src={`https://www.youtube.com/embed/${details.trailerKey}?autoplay=1`} 
                    className="w-full h-full" 
                    allow="autoplay; encrypted-media; fullscreen" 
                    allowFullScreen 
                  />
                </div>
              </div>
            )}

            {/* Content & Episodes */}
            <div className="px-6 md:px-8 py-6 space-y-6">
              {/* Metadata row */}
              <div className="flex flex-wrap items-center gap-2 text-xs text-neutral-300 font-medium">
                {item.year > 0 && <span>{item.year}</span>}
                {seasons.length > 0 && (
                  <>
                    <span className="text-neutral-600">•</span>
                    <span>{seasons.length} {seasons.length === 1 ? 'Season' : 'Seasons'}</span>
                  </>
                )}
                {details?.genres && details.genres.length > 0 && (
                  <>
                    <span className="text-neutral-600">•</span>
                    <span>{details.genres.slice(0, 3).join(', ')}</span>
                  </>
                )}
              </div>

              {/* Synopsis */}
              <p className="text-sm md:text-base text-neutral-300 leading-relaxed font-normal">
                {item.description || 'No description available.'}
              </p>

              {/* Episodes Section - OTT Platform Style */}
              <div className="pt-4 border-t border-white/[0.08]">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <h3 className="text-base sm:text-lg font-bold text-white tracking-wide">Episodes</h3>
                    <span className="text-xs text-neutral-400 font-semibold px-2 py-0.5 rounded-full bg-white/5 border border-white/10">
                      Season {activeSeason}
                    </span>
                  </div>
                </div>

                {/* OTT Horizontal Season Tabs Bar with Dedicated Scroll Buttons */}
                {seasons.length > 0 && (
                  <div className="relative flex items-center gap-1.5 pb-3 mb-3 border-b border-white/[0.06]">
                    {seasons.length > 3 && (
                      <button
                        type="button"
                        onClick={() => scrollSeasons('left')}
                        aria-label="Scroll seasons left"
                        className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 active:scale-95 text-white flex items-center justify-center shrink-0 transition-all cursor-pointer border border-white/10 shadow-sm"
                      >
                        <ChevronLeft size={16} />
                      </button>
                    )}

                    <div
                      ref={seasonsContainerRef}
                      className="flex items-center gap-2 overflow-x-auto no-scrollbar scroll-smooth flex-1 py-1"
                    >
                      {seasons.map((s) => {
                        const isActive = activeSeason === s.seasonNumber;
                        return (
                          <button
                            key={s.id}
                            type="button"
                            onClick={() => setActiveSeason(s.seasonNumber)}
                            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap flex items-center gap-2 cursor-pointer active:scale-95 shrink-0 ${
                              isActive
                                ? 'bg-white text-black shadow-lg shadow-white/20'
                                : 'bg-white/10 hover:bg-white/20 text-neutral-300 hover:text-white border border-white/10'
                            }`}
                          >
                            <span>{s.name || `Season ${s.seasonNumber}`}</span>
                            {s.episodeCount > 0 && (
                              <span className={`text-[10px] px-1.5 py-0.5 rounded-full font-semibold ${
                                isActive ? 'bg-black/10 text-black' : 'bg-white/10 text-neutral-400'
                              }`}>
                                {s.episodeCount} eps
                              </span>
                            )}
                          </button>
                        );
                      })}
                    </div>

                    {seasons.length > 3 && (
                      <button
                        type="button"
                        onClick={() => scrollSeasons('right')}
                        aria-label="Scroll seasons right"
                        className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 active:scale-95 text-white flex items-center justify-center shrink-0 transition-all cursor-pointer border border-white/10 shadow-sm"
                      >
                        <ChevronRight size={16} />
                      </button>
                    )}
                  </div>
                )}

                {loadingEpisodes ? (
                  <div className="py-12 flex flex-col items-center justify-center gap-2">
                    <div className="w-8 h-8 border-2 border-white/20 border-t-white rounded-full animate-spin"></div>
                    <span className="text-xs text-neutral-400 font-medium">Loading TMDB Episodes...</span>
                  </div>
                ) : episodes.length === 0 ? (
                  <div className="py-8 text-center text-xs text-neutral-400">
                    No episodes available for Season {activeSeason}.
                  </div>
                ) : (
                  <div className="space-y-3">
                    {episodes.map((ep) => (
                      <React.Fragment key={ep.id}>
                        <div
                          onClick={() => {
                            onPlay({ item, season: ep.seasonNumber || activeSeason, episode: ep.episodeNumber, provider: '1', imdbId: details?.imdbId });
                          }}
                          className="flex flex-row items-center gap-3 sm:gap-4 p-2 sm:p-3 rounded-xl bg-white/[0.03] hover:bg-white/[0.08] border border-white/5 hover:border-white/15 cursor-pointer transition-all duration-200 group shadow-md"
                        >
                          {/* 16:9 Thumbnail with OTT Play Overlay (Identical to Window View on Mobile) */}
                          <div className="relative w-28 sm:w-36 md:w-44 aspect-video rounded-lg overflow-hidden bg-black/60 shrink-0">
                            {ep.stillPath ? (
                              <img src={ep.stillPath} alt={ep.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" />
                            ) : (
                              <div className="w-full h-full flex items-center justify-center bg-[#15151b]">
                                <Film size={18} className="text-neutral-600" />
                              </div>
                            )}

                            {/* Episode Badge */}
                            <div className="absolute top-1.5 left-1.5 px-1.5 py-0.5 rounded bg-black/80 backdrop-blur-md text-[9px] sm:text-[10px] font-black text-white border border-white/10">
                              EP {ep.episodeNumber}
                            </div>

                            {/* Hover Play Button */}
                            <div className="absolute inset-0 bg-black/40 group-hover:bg-black/10 transition-colors flex items-center justify-center">
                              <div className="w-7 h-7 sm:w-9 sm:h-9 rounded-full bg-white text-black flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all scale-90 group-hover:scale-100 shadow-xl">
                                <Play size={12} fill="currentColor" className="ml-0.5 text-black" />
                              </div>
                            </div>
                          </div>

                          {/* Episode Details */}
                          <div className="min-w-0 flex-1 flex flex-col justify-between py-0.5">
                            <div>
                              <div className="flex items-start justify-between gap-1.5 sm:gap-2">
                                <h4 className="text-xs sm:text-sm font-bold text-white group-hover:text-red-400 transition-colors line-clamp-1">
                                  {ep.episodeNumber}. {ep.name || `Episode ${ep.episodeNumber}`}
                                </h4>
                                {ep.runtime > 0 && (
                                  <span className="text-[10px] sm:text-[11px] text-neutral-400 font-mono shrink-0 px-1.5 py-0.5 rounded bg-white/5">
                                    {ep.runtime}m
                                  </span>
                                )}
                              </div>
                              <p className="text-[10px] sm:text-xs text-neutral-400 line-clamp-1 sm:line-clamp-2 mt-0.5 sm:mt-1 leading-relaxed">
                                {ep.overview || 'Stream this episode in full HD with multi-audio support.'}
                              </p>
                            </div>

                            {/* Action Buttons */}
                            <div className="flex items-center gap-2 mt-2">
                              <button
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  onPlay({ item, season: ep.seasonNumber || activeSeason, episode: ep.episodeNumber, provider: '1', imdbId: details?.imdbId });
                                }}
                                className="px-2.5 sm:px-3 py-1 rounded-full text-[11px] sm:text-xs font-bold transition-all flex items-center gap-1 shadow-sm cursor-pointer active:scale-95 bg-white text-black hover:bg-neutral-200"
                              >
                                <Play size={10} fill="currentColor" />
                                <span>Play</span>
                              </button>

                              <button
                                type="button"
                                title={`Download Episode ${ep.episodeNumber}`}
                                aria-label={`Download Episode ${ep.episodeNumber}`}
                                onClick={(e) => {
                                  e.stopPropagation();
                                  const isOpening = activeDownloadEpNumber !== ep.episodeNumber;
                                  setActiveDownloadEpNumber(isOpening ? ep.episodeNumber : null);
                                }}
                                className={`px-2.5 sm:px-3 py-1 rounded-full border flex items-center gap-1.5 transition-all duration-200 cursor-pointer active:scale-95 text-[11px] sm:text-xs font-bold shadow-sm ${
                                  activeDownloadEpNumber === ep.episodeNumber
                                    ? 'bg-red-600 border-red-500 text-white shadow-red-900/40'
                                    : 'bg-white/10 hover:bg-white/20 text-white border-white/10'
                                }`}
                              >
                                <Download size={11} />
                                <span>{activeDownloadEpNumber === ep.episodeNumber ? 'Close' : 'Download'}</span>
                              </button>
                            </div>
                          </div>
                        </div>

                      {/* Inline Episode Download Frame - Clean frame with ONLY Direct Download and Close buttons */}
                      {activeDownloadEpNumber === ep.episodeNumber && (
                        <div className="mt-2 mb-4 p-3 sm:p-4 bg-[#09090d] border border-red-500/30 rounded-xl animate-in fade-in duration-200 shadow-xl">
                          <div className="flex items-center justify-end gap-2 pb-2 mb-2.5 border-b border-white/10 text-xs">
                            <a
                              href={getDownloadUrl(item, 1, activeSeason, ep.episodeNumber)}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="px-3.5 py-1.5 rounded-full bg-red-600/30 hover:bg-red-600 border border-red-500/40 text-white flex items-center gap-1.5 text-xs font-bold transition-all duration-200 shadow-sm active:scale-95 cursor-pointer"
                              title="Direct Download in New Window"
                            >
                              <span>Direct Download</span>
                              <ExternalLink size={12} />
                            </a>
                            <button
                              type="button"
                              onClick={() => setActiveDownloadEpNumber(null)}
                              className="px-3 py-1.5 rounded-full bg-white/10 hover:bg-white/20 border border-white/10 text-neutral-300 hover:text-white text-xs font-bold transition-all duration-200 active:scale-95 cursor-pointer"
                            >
                              Close
                            </button>
                          </div>

                          <div className="relative w-full h-[450px] sm:h-[520px] rounded-lg overflow-hidden border border-white/10 bg-[#0d0d12]">
                            <iframe 
                              key={`${downloadReloadKey}-${ep.episodeNumber}`}
                              src={getDownloadUrl(item, 1, activeSeason, ep.episodeNumber)} 
                              className="w-full h-full border-0" 
                              allow="autoplay; encrypted-media; fullscreen"
                              title={`Download - ${item.title} S${activeSeason}E${ep.episodeNumber}`}
                            />
                          </div>
                        </div>
                      )}
                    </React.Fragment>
                    ))}
                  </div>
                )}
              </div>

              {/* Cast */}
              {details?.cast && details.cast.length > 0 && (
                <div className="pt-4 border-t border-white/[0.06]">
                  <h3 className="text-xs font-semibold text-neutral-400 uppercase tracking-wider mb-3">Cast</h3>
                  <div className="flex gap-3 overflow-x-auto pb-2 no-scrollbar">
                    {details.cast.slice(0, 7).map(actor => (
                      <div key={actor.id} className="flex flex-col items-center text-center w-18 shrink-0">
                        <div className="w-12 h-12 rounded-full overflow-hidden bg-neutral-800 mb-1.5">
                          {actor.profilePath ? (
                            <img src={actor.profilePath} alt={actor.name} className="w-full h-full object-cover" />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center text-xs text-neutral-500 font-bold">
                              {actor.name.charAt(0)}
                            </div>
                          )}
                        </div>
                        <span className="text-[10px] font-medium text-white truncate w-full">{actor.name}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* More Like This (Recommended Series) with 8 Ads (2 rows of 4) */}
              <div className="pt-4 border-t border-white/[0.06]">
                <h3 className="text-sm font-semibold text-white mb-3">More Like This</h3>
                {details?.recommendations && details.recommendations.length > 0 && (
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2.5 mb-4">
                    {details.recommendations.slice(0, 8).map((rec, idx) => (
                      <div 
                        key={`${rec.id}-${idx}`}
                        className="bg-[#161616] hover:bg-[#202020] rounded-lg overflow-hidden group cursor-pointer transition-colors duration-150"
                        onClick={() => onItemSelect(rec)}
                      >
                        <div className="relative aspect-[16/10] bg-[#121212]">
                          {rec.backdrop || rec.thumbnail ? (
                            <img 
                              src={rec.backdrop || rec.thumbnail} 
                              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" 
                              alt={rec.title} 
                              referrerPolicy="no-referrer"
                            />
                          ) : (
                            <div className="w-full h-full bg-[#121212]" />
                          )}
                        </div>
                        <div className="p-2">
                          <h4 className="font-medium text-xs text-white truncate">{rec.title}</h4>
                          <span className="text-[10px] text-neutral-500">{rec.year > 0 ? rec.year : ''}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
};

export default SeriesDetailsModal;
