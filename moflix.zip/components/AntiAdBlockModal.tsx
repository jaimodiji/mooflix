import React from 'react';

/**
 * AntiAdBlockModal - Removed per user instruction
 */
export const AntiAdBlockModal: React.FC = () => null;

export default AntiAdBlockModal;
