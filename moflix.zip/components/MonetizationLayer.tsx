import React, { memo } from 'react';

interface MonetizationLayerProps {
  isPlayerActive?: boolean;
}

/**
 * MonetizationLayer - All background ads removed per user request
 */
export const MonetizationLayer: React.FC<MonetizationLayerProps> = memo(() => null);

export default MonetizationLayer;
