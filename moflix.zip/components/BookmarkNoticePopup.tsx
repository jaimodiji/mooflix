import React, { useState, useEffect } from 'react';
import { Bookmark, X, Check, Star } from 'lucide-react';

export const BookmarkNoticePopup: React.FC = () => {
  const [isVisible, setIsVisible] = useState(false);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    // Check if dismissed previously within the last 7 days
    try {
      const dismissedTime = localStorage.getItem('moflix_bookmark_dismissed_time');
      if (dismissedTime && Date.now() - Number(dismissedTime) < 7 * 24 * 60 * 60 * 1000) {
        return;
      }
    } catch {}

    // Show popup after 3 seconds of browsing
    const timer = setTimeout(() => {
      setIsVisible(true);
    }, 3000);

    return () => clearTimeout(timer);
  }, []);

  const handleDismiss = () => {
    setIsVisible(false);
    try {
      localStorage.setItem('moflix_bookmark_dismissed_time', String(Date.now()));
    } catch {}
  };

  const handleBookmarkClick = () => {
    // Attempt standard bookmark shortcut prompt or copy URL
    setCopied(true);
    try {
      navigator.clipboard.writeText(window.location.origin);
    } catch {}

    setTimeout(() => {
      setCopied(false);
    }, 3500);
  };

  if (!isVisible) return null;

  const isMac = typeof navigator !== 'undefined' && /Mac|iPhone|iPad|iPod/i.test(navigator.userAgent);
  const isMobile = typeof navigator !== 'undefined' && /Android|iPhone|iPad|iPod/i.test(navigator.userAgent);
  const shortcutText = isMobile ? 'Tap Menu (⋮) → Star ★' : isMac ? '⌘ + D' : 'Ctrl + D';

  return (
    <div 
      className="fixed bottom-16 sm:bottom-6 left-3 sm:left-6 z-40 max-w-[290px] sm:max-w-[320px] select-none animate-in fade-in slide-in-from-bottom-4 duration-400"
      style={{
        paddingBottom: 'env(safe-area-inset-bottom, 0px)',
        paddingLeft: 'env(safe-area-inset-left, 0px)',
      }}
    >
      <div className="relative rounded-2xl bg-[#11111a]/95 backdrop-blur-2xl border border-white/20 p-3.5 sm:p-4 shadow-[0_20px_50px_rgba(0,0,0,0.85),0_0_20px_rgba(229,9,20,0.15)] flex flex-col gap-2.5">
        {/* Glow Accent */}
        <div className="absolute -top-10 -left-10 w-24 h-24 bg-red-600/20 rounded-full blur-2xl pointer-events-none" />

        {/* Top Header with Bookmark Icon & Close Button */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-red-600/20 border border-red-500/40 flex items-center justify-center text-red-400">
              <Bookmark size={15} className="fill-red-500" />
            </div>
            <span className="text-xs font-bold text-white tracking-wide">
              Bookmark MooFlix
            </span>
          </div>

          <button
            type="button"
            onClick={handleDismiss}
            aria-label="Dismiss notice"
            className="p-1 rounded-full text-neutral-400 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X size={14} />
          </button>
        </div>

        {/* Explanation text */}
        <p className="text-[11px] sm:text-xs text-neutral-300 leading-relaxed">
          Never lose your free movies &amp; live sports access! Press{' '}
          <kbd className="px-1.5 py-0.5 rounded bg-white/15 text-white font-mono font-bold text-[10px] border border-white/15 shadow-sm">
            {shortcutText}
          </kbd>{' '}
          to save to your browser bookmarks.
        </p>

        {/* Action Button */}
        <button
          type="button"
          onClick={handleBookmarkClick}
          className="w-full py-2 px-3 rounded-xl bg-red-600 hover:bg-red-500 active:scale-95 text-white font-bold text-xs shadow-md shadow-red-600/30 flex items-center justify-center gap-1.5 transition-all cursor-pointer"
        >
          {copied ? (
            <>
              <Check size={13} className="text-white" />
              <span>URL Copied! Now Press {shortcutText}</span>
            </>
          ) : (
            <>
              <Star size={13} className="fill-white" />
              <span>Save / Copy Bookmark</span>
            </>
          )}
        </button>
      </div>
    </div>
  );
};

export default BookmarkNoticePopup;
