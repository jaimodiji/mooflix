import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useParams, useSearchParams } from 'react-router-dom';
import {
  Maximize,
  Minimize,
  RotateCcw,
  ChevronLeft,
  ChevronRight,
  X,
  Share2,
  Check,
  Server as ServerIcon,
} from 'lucide-react';
import { ContentItem } from '../types';
import { fetchContentItemById, fetchImdbId, resolveTmdbId } from '../services/tmdbService';
import { getEmbedUrl } from '../utils/playerUtils';

interface EmbedPlayerViewProps {
  type?: 'movie' | 'tv';
}

type ServerKey = '1' | '2' | '3' | '4';
type AvailabilityMap = Record<ServerKey, boolean | 'unknown'>;

const SERVERS: { id: ServerKey; name: string; tag: string; label: string }[] = [
  { id: '1', name: 'Server 1', tag: 'Fast HD • Zero Ads', label: 'S1' },
  { id: '2', name: 'Server 2', tag: 'Multi-Audio HD • Zero Ads', label: 'S2' },
  { id: '3', name: 'Server 3', tag: 'Backup HD • Zero Ads', label: 'S3' },
  { id: '4', name: 'Server 4', tag: 'Ultra HD Mirror • Zero Ads', label: 'S4' },
];

const SERVER_ORDER: ServerKey[] = ['1', '2', '3', '4'];

export const EmbedPlayerView: React.FC<EmbedPlayerViewProps> = ({ type: propType }) => {
  const params = useParams<{ id?: string; season?: string; episode?: string }>();
  const [searchParams] = useSearchParams();

  const queryType = searchParams.get('type');
  const isTvInitial = propType === 'tv' || queryType === 'tv' || queryType === 'series' || Boolean(params.season);
  const mediaType: 'movie' | 'tv' = isTvInitial ? 'tv' : 'movie';

  const defaultDemoId = mediaType === 'tv' ? '66732' : '969681';
  const rawId = params.id || searchParams.get('id') || searchParams.get('tmdb') || searchParams.get('tmdbId') || defaultDemoId;

  const rawSeason = Number(params.season || searchParams.get('s') || searchParams.get('season') || 1);
  const rawEpisode = Number(params.episode || searchParams.get('e') || searchParams.get('episode') || 1);

  const [season, setSeason] = useState<number>(rawSeason > 0 ? rawSeason : 1);
  const [episode, setEpisode] = useState<number>(rawEpisode > 0 ? rawEpisode : 1);
  const [currentServer, setCurrentServer] = useState<ServerKey>('1');
  const [isServerMenuOpen, setIsServerMenuOpen] = useState<boolean>(false);
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(true);
  const [isResolving, setIsResolving] = useState<boolean>(true);
  const [iframeKey, setIframeKey] = useState<number>(0);
  const [showShareModal, setShowShareModal] = useState<boolean>(false);
  const [copiedShare, setCopiedShare] = useState<boolean>(false);
  const [failoverNotice, setFailoverNotice] = useState<string | null>(null);
  const [availability, setAvailability] = useState<AvailabilityMap>({
    '1': 'unknown',
    '2': 'unknown',
    '3': 'unknown',
    '4': 'unknown',
  });

  const [item, setItem] = useState<ContentItem>({
    id: rawId,
    title: mediaType === 'tv' ? 'TV Series' : 'Movie',
    type: mediaType === 'tv' ? 'series' : 'movie',
    thumbnail: '',
    backdrop: '',
    rating: 8.0,
    year: new Date().getFullYear(),
    description: '',
  });

  const [resolvedTmdbId, setResolvedTmdbId] = useState<string>(() =>
    String(rawId).startsWith('tt') ? '' : String(rawId)
  );
  const [resolvedImdbId, setResolvedImdbId] = useState<string | null>(() =>
    String(rawId).startsWith('tt') ? String(rawId) : null
  );

  const containerRef = useRef<HTMLDivElement>(null);
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const triedServersRef = useRef<Set<ServerKey>>(new Set());
  const manualOverrideRef = useRef<boolean>(false);

  useEffect(() => {
    if (params.season) setSeason(Math.max(1, Number(params.season) || 1));
    if (params.episode) setEpisode(Math.max(1, Number(params.episode) || 1));
  }, [params.season, params.episode]);

  // Resolve IDs, metadata, and server availability with auto-failover
  useEffect(() => {
    let isMounted = true;
    setIsResolving(true);
    setLoading(true);
    triedServersRef.current = new Set();

    async function loadMetaAndAvailability() {
      const initialIsImdb = typeof rawId === 'string' && rawId.startsWith('tt');
      let cleanTmdb = initialIsImdb ? '' : String(rawId);
      let cleanImdb = initialIsImdb ? String(rawId) : '';

      try {
        const resolveParams = new URLSearchParams({
          type: mediaType,
          tmdbId: cleanTmdb,
          imdbId: cleanImdb,
          season: String(season),
          episode: String(episode),
        });
        const res = await fetch(`/api/player/resolve?${resolveParams.toString()}`);
        if (res.ok) {
          const data = await res.json();
          if (!isMounted) return;
          if (data.resolvedTmdbId) cleanTmdb = String(data.resolvedTmdbId);
          if (data.resolvedImdbId) cleanImdb = String(data.resolvedImdbId);

          if (data.availability) {
            setAvailability(data.availability);
            if (!manualOverrideRef.current && data.availability[currentServer] === false && data.recommendedServer) {
              triedServersRef.current.add(currentServer);
              setFailoverNotice(
                `Not found on Server ${currentServer} — switching automatically to Server ${data.recommendedServer}...`
              );
              setCurrentServer(data.recommendedServer as ServerKey);
            }
          }
        }
      } catch {}

      try {
        if (!cleanTmdb && initialIsImdb) {
          const resolved = await resolveTmdbId(rawId);
          if (resolved) cleanTmdb = String(resolved);
        }
        if (!cleanImdb && cleanTmdb) {
          const imdb = await fetchImdbId(cleanTmdb, mediaType);
          if (imdb) cleanImdb = imdb;
        }
        if (cleanTmdb) {
          const meta = await fetchContentItemById(cleanTmdb, mediaType);
          if (isMounted && meta) setItem(meta);
        }
      } catch {}

      if (isMounted) {
        if (cleanTmdb) setResolvedTmdbId(cleanTmdb);
        if (cleanImdb) setResolvedImdbId(cleanImdb);
        setIsResolving(false);
      }
    }

    loadMetaAndAvailability();
    return () => {
      isMounted = false;
    };
  }, [rawId, mediaType, season, episode]);

  const advanceToNextServer = useCallback(
    (failedServer: ServerKey, reason: 'not_found' | 'timeout' = 'not_found') => {
      triedServersRef.current.add(failedServer);
      setAvailability((prev) => ({ ...prev, [failedServer]: false }));

      const nextBest =
        SERVER_ORDER.find((srv) => !triedServersRef.current.has(srv) && availability[srv] !== false) ||
        SERVER_ORDER.find((srv) => !triedServersRef.current.has(srv));

      if (!nextBest) {
        if (reason === 'timeout') {
          setIsResolving(false);
          setLoading(false);
        }
        return;
      }

      triedServersRef.current.add(nextBest);
      setFailoverNotice(
        reason === 'timeout'
          ? `Server ${failedServer} took more than 10s — switching automatically to Server ${nextBest}...`
          : `Not found on Server ${failedServer} — switching automatically to Server ${nextBest}...`
      );
      setIsResolving(false);
      setCurrentServer(nextBest);
      setLoading(true);
      setIframeKey((k) => k + 1);
    },
    [availability]
  );

  // Auto-switch server if loading lasts more than 10 seconds
  useEffect(() => {
    if (!loading && !isResolving) return;
    const timeoutId = setTimeout(() => {
      advanceToNextServer(currentServer, 'timeout');
    }, 10000);
    return () => clearTimeout(timeoutId);
  }, [loading, isResolving, currentServer, iframeKey, season, episode, advanceToNextServer]);

  useEffect(() => {
    if (!failoverNotice) return;
    const t = setTimeout(() => setFailoverNotice(null), 4500);
    return () => clearTimeout(t);
  }, [failoverNotice]);

  useEffect(() => {
    const handleMessage = (event: MessageEvent) => {
      if (event.data && event.data.type === 'MOOFLIX_PLAYER_NOT_FOUND') {
        advanceToNextServer(currentServer);
      }
    };
    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, [currentServer, advanceToNextServer]);

  // Ads Shield: Block unwanted popups / window.open
  useEffect(() => {
    const originalOpen = window.open;
    const blockedOpen = function () {
      return {
        close: () => {},
        closed: true,
        focus: () => {},
        blur: () => {},
        postMessage: () => {},
        location: { href: 'about:blank' },
      } as any;
    };
    window.open = blockedOpen as any;
    return () => {
      window.open = originalOpen;
    };
  }, []);

  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(Boolean(document.fullscreenElement));
    };
    document.addEventListener('fullscreenchange', handleFullscreenChange);
    return () => document.removeEventListener('fullscreenchange', handleFullscreenChange);
  }, []);

  const toggleFullscreen = () => {
    const el = containerRef.current;
    if (!el) return;
    if (!document.fullscreenElement) {
      el.requestFullscreen?.().catch(() => {});
    } else {
      document.exitFullscreen?.().catch(() => {});
    }
  };

  const handleReload = () => {
    setLoading(true);
    setIframeKey((prev) => prev + 1);
  };

  const routePrefix =
    typeof window !== 'undefined' && window.location.pathname.includes('/embed/series') ? 'series' : 'tv';

  const handlePrevEpisode = () => {
    manualOverrideRef.current = false;
    setFailoverNotice(null);
    const idForUrl = resolvedTmdbId || rawId;
    if (episode > 1) {
      const nextEp = episode - 1;
      setEpisode(nextEp);
      setLoading(true);
      window.history.replaceState(null, '', `/embed/${routePrefix}/${idForUrl}/${season}/${nextEp}`);
    } else if (season > 1) {
      const nextSeason = season - 1;
      setSeason(nextSeason);
      setEpisode(1);
      setLoading(true);
      window.history.replaceState(null, '', `/embed/${routePrefix}/${idForUrl}/${nextSeason}/1`);
    }
  };

  const handleNextEpisode = () => {
    manualOverrideRef.current = false;
    setFailoverNotice(null);
    const idForUrl = resolvedTmdbId || rawId;
    const nextEp = episode + 1;
    setEpisode(nextEp);
    setLoading(true);
    window.history.replaceState(null, '', `/embed/${routePrefix}/${idForUrl}/${season}/${nextEp}`);
  };

  const pad = (n: number | string) => String(n).padStart(2, '0');
  const embedUrl = isResolving
    ? ''
    : getEmbedUrl(
        currentServer,
        {
          ...item,
          type: mediaType === 'tv' ? 'series' : 'movie',
          tmdbId: resolvedTmdbId,
          id: resolvedTmdbId || rawId,
        },
        season,
        episode,
        resolvedImdbId
      );
  const activeServerInfo = SERVERS.find((s) => s.id === currentServer) || SERVERS[0];

  useEffect(() => {
    if (!isResolving && !embedUrl) {
      advanceToNextServer(currentServer);
    }
  }, [isResolving, embedUrl, currentServer, advanceToNextServer]);

  const origin = typeof window !== 'undefined' ? window.location.origin : 'https://mooflix.online';
  const idForEndpoint = resolvedTmdbId || rawId;
  const playerEndpoint =
    mediaType === 'tv'
      ? `${origin}/embed/${routePrefix}/${idForEndpoint}/${season}/${episode}`
      : `${origin}/embed/movie/${idForEndpoint}`;
  const iframeSnippet = `<iframe src="${playerEndpoint}" width="100%" height="100%" frameborder="0" allowfullscreen allow="autoplay; encrypted-media; fullscreen; picture-in-picture"></iframe>`;

  const copyIframe = () => {
    navigator.clipboard.writeText(iframeSnippet);
    setCopiedShare(true);
    setTimeout(() => setCopiedShare(false), 2500);
  };

  return (
    <div
      ref={containerRef}
      className="fixed inset-0 w-screen h-screen bg-black overflow-hidden flex items-center justify-center select-none"
      style={{
        backgroundColor: '#000000',
        color: '#ffffff',
        fontFamily: "'Inter', -apple-system, BlinkMacSystemFont, sans-serif",
      }}
      onClick={() => setIsServerMenuOpen(false)}
    >
      <div className="relative w-full h-full max-w-full max-h-full bg-black overflow-hidden flex items-center justify-center">
        {/* Top Floating Control Bar */}
        <div
          className="absolute top-0 left-0 right-0 z-40 flex items-center justify-between pointer-events-none transition-all duration-200"
          style={{
            padding: 'max(8px, env(safe-area-inset-top, 8px)) max(10px, env(safe-area-inset-right, 10px)) 12px max(10px, env(safe-area-inset-left, 10px))',
            background: 'linear-gradient(180deg, rgba(0,0,0,0.92) 0%, rgba(0,0,0,0.65) 60%, rgba(0,0,0,0) 100%)',
          }}
        >
          <div className="flex items-center gap-2 pointer-events-auto min-w-0">
            <div
              className="flex items-center gap-1 font-black tracking-tight text-white cursor-pointer select-none shrink-0"
              style={{ fontSize: 'clamp(13px, 2.4vw, 17px)' }}
            >
              <div>MOO<span style={{ color: '#e50914' }}>FLIX</span></div>
              <span className="text-[10px] uppercase font-bold tracking-wider px-1.5 py-0.5 rounded bg-white/10 text-neutral-300 ml-1">
                Embed
              </span>
            </div>

            <div className="hidden sm:flex items-center gap-2 pl-2 border-l border-white/20 text-xs text-neutral-300 font-medium truncate">
              <span className="truncate max-w-[150px] lg:max-w-[280px] text-white font-semibold">
                {item.title}
              </span>
              {mediaType === 'tv' && (
                <span className="px-2 py-0.5 rounded bg-white/10 text-white font-mono font-bold text-[11px] border border-white/10 shrink-0">
                  S{season}:E{episode}
                </span>
              )}
            </div>
          </div>

          <div className="flex items-center gap-1.5 sm:gap-2 pointer-events-auto shrink-0">
            {mediaType === 'tv' && (
              <div className="flex items-center bg-black/70 backdrop-blur-md rounded-lg border border-white/15 p-0.5 shadow-sm">
                <button
                  type="button"
                  onClick={handlePrevEpisode}
                  disabled={season <= 1 && episode <= 1}
                  className="w-7 h-7 sm:w-auto sm:px-2 sm:py-1 rounded text-neutral-300 hover:text-white hover:bg-white/15 disabled:opacity-30 disabled:hover:bg-transparent flex items-center justify-center gap-0.5 cursor-pointer transition-all"
                  title="Previous Episode"
                >
                  <ChevronLeft size={15} />
                  <span className="hidden md:inline text-xs font-semibold">Prev</span>
                </button>
                <div className="px-1.5 py-0.5 text-[10px] sm:text-[11px] font-mono font-bold text-white bg-white/15 rounded">
                  S{season}E{pad(episode)}
                </div>
                <button
                  type="button"
                  onClick={handleNextEpisode}
                  className="w-7 h-7 sm:w-auto sm:px-2 sm:py-1 rounded text-neutral-300 hover:text-white hover:bg-white/15 flex items-center justify-center gap-0.5 cursor-pointer transition-all"
                  title="Next Episode"
                >
                  <span className="hidden md:inline text-xs font-semibold">Next</span>
                  <ChevronRight size={15} />
                </button>
              </div>
            )}

            {/* Server Selector Dropdown */}
            <div className="relative">
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  setIsServerMenuOpen((prev) => !prev);
                }}
                className="px-2.5 sm:px-3 py-1.5 rounded-lg bg-[#e50914] hover:bg-[#f40612] text-white flex items-center gap-1.5 text-xs font-bold transition-all cursor-pointer shadow-md shadow-red-950/40 active:scale-95 border border-white/20"
                title="Change Streaming Server"
              >
                <ServerIcon size={13} />
                <span className="truncate max-w-[70px] sm:max-w-none">{activeServerInfo.name}</span>
                <span className="text-[10px] opacity-80">({activeServerInfo.label})</span>
              </button>

              {isServerMenuOpen && (
                <div
                  className="absolute right-0 mt-2 w-56 sm:w-64 rounded-xl bg-[#121216]/98 border border-white/15 shadow-2xl backdrop-blur-2xl p-1.5 z-50 text-left animate-in fade-in zoom-in-95 duration-150"
                  onClick={(e) => e.stopPropagation()}
                >
                  <div className="px-2.5 py-1.5 text-[10px] font-bold uppercase tracking-wider text-neutral-400 border-b border-white/10 mb-1 flex items-center justify-between">
                    <span>Streaming Servers</span>
                    <span className="text-emerald-400 font-mono">ZERO ADS</span>
                  </div>
                  <div className="flex flex-col gap-1">
                    {SERVERS.map((srv) => (
                      <button
                        key={srv.id}
                        type="button"
                        onClick={() => {
                          manualOverrideRef.current = true;
                          setFailoverNotice(null);
                          setCurrentServer(srv.id);
                          setIsServerMenuOpen(false);
                          setLoading(true);
                          setIframeKey((k) => k + 1);
                        }}
                        className={`w-full px-3 py-2 rounded-lg text-left text-xs transition-all flex items-center justify-between cursor-pointer ${
                          currentServer === srv.id
                            ? 'bg-[#e50914] text-white font-bold shadow-md'
                            : 'text-neutral-200 hover:bg-white/10 hover:text-white'
                        }`}
                      >
                        <div className="flex flex-col min-w-0">
                          <div className="flex items-center gap-1.5">
                            <span className="font-bold">{srv.name}</span>
                            <span className={`text-[10px] px-1 py-0.2 rounded font-mono ${currentServer === srv.id ? 'bg-black/30' : 'bg-white/10'}`}>
                              {srv.label}
                            </span>
                            {availability[srv.id] === false && (
                              <span className="text-[9px] text-amber-300 font-normal">(Fallback)</span>
                            )}
                          </div>
                          <span className="text-[10px] opacity-75 truncate">{srv.tag}</span>
                        </div>
                        {currentServer === srv.id && <span className="text-white text-xs">✓</span>}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>

            <button
              type="button"
              onClick={handleReload}
              className="w-8 h-8 rounded-lg bg-black/60 hover:bg-white/20 active:scale-95 text-neutral-300 hover:text-white border border-white/15 flex items-center justify-center transition-all cursor-pointer backdrop-blur-md"
              title="Reload Video Stream"
            >
              <RotateCcw size={14} />
            </button>

            <button
              type="button"
              onClick={() => setShowShareModal(true)}
              className="w-8 h-8 rounded-lg bg-black/60 hover:bg-white/20 active:scale-95 text-neutral-300 hover:text-white border border-white/15 flex items-center justify-center transition-all cursor-pointer backdrop-blur-md"
              title="Embed Code"
            >
              <Share2 size={14} />
            </button>

            <button
              type="button"
              onClick={toggleFullscreen}
              className="w-8 h-8 rounded-lg bg-black/60 hover:bg-white/20 active:scale-95 text-neutral-300 hover:text-white border border-white/15 flex items-center justify-center transition-all cursor-pointer backdrop-blur-md"
              title={isFullscreen ? 'Exit Fullscreen' : 'Enter Fullscreen'}
            >
              {isFullscreen ? <Minimize size={14} /> : <Maximize size={14} />}
            </button>
          </div>
        </div>

        {/* Auto-failover status banner */}
        {failoverNotice && (
          <div
            className="absolute left-1/2 -translate-x-1/2 z-40 bg-black/90 border border-red-500/50 text-white px-4 py-1.5 rounded-lg text-[11px] sm:text-xs font-semibold shadow-xl pointer-events-none whitespace-nowrap"
            style={{ top: 'max(54px, calc(env(safe-area-inset-top, 8px) + 46px))' }}
          >
            {failoverNotice}
          </div>
        )}

        {/* Video Player Viewport */}
        <div className="relative w-full h-full flex items-center justify-center bg-black">
          {(loading || isResolving) && (
            <div className="absolute inset-0 z-20 flex flex-col items-center justify-center bg-black gap-3 text-white pointer-events-none">
              <div className="w-10 h-10 sm:w-12 sm:h-12 border-3 border-white/20 border-t-[#e50914] rounded-full animate-spin" />
              <div className="text-xs sm:text-sm font-semibold tracking-wide text-neutral-300 flex items-center gap-2">
                <span>
                  {isResolving
                    ? 'Finding best ad-free stream...'
                    : `Loading ${activeServerInfo.name} (${activeServerInfo.label})`}
                </span>
                <span className="w-1.5 h-1.5 rounded-full bg-[#e50914] animate-ping" />
              </div>
            </div>
          )}

          {embedUrl && (
            <iframe
              ref={iframeRef}
              key={`stream-${resolvedTmdbId}-${resolvedImdbId}-${season}-${episode}-${currentServer}-${iframeKey}`}
              src={embedUrl}
              title={`${item.title} - ${activeServerInfo.name}`}
              className="w-full h-full border-0 block bg-black"
              style={{
                width: '100%',
                height: '100%',
                border: 0,
                outline: 'none',
                display: 'block',
              }}
              sandbox={
                currentServer === '3'
                  ? 'allow-scripts allow-same-origin allow-forms allow-presentation'
                  : undefined
              }
              allow="autoplay; encrypted-media; fullscreen; picture-in-picture"
              allowFullScreen
              referrerPolicy="no-referrer-when-downgrade"
              onLoad={() => setLoading(false)}
              onError={() => advanceToNextServer(currentServer)}
            />
          )}
        </div>

        {/* Share / Embed Code Modal */}
        {showShareModal && (
          <div
            className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4"
            onClick={() => setShowShareModal(false)}
          >
            <div
              className="w-full max-w-lg bg-[#141419] border border-white/20 rounded-2xl p-6 shadow-2xl text-left"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex items-center justify-between pb-3 border-b border-white/10 mb-4">
                <div className="flex items-center gap-2">
                  <Share2 size={16} className="text-[#e50914]" />
                  <h3 className="text-base font-bold text-white">Embed MooFlix Player</h3>
                </div>
                <button
                  type="button"
                  onClick={() => setShowShareModal(false)}
                  className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white"
                >
                  <X size={14} />
                </button>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="text-xs font-semibold text-neutral-400 uppercase tracking-wider block mb-1.5">
                    Direct Embed URL
                  </label>
                  <input
                    type="text"
                    readOnly
                    value={playerEndpoint}
                    className="w-full px-3 py-2 bg-black/60 border border-white/15 rounded-lg text-xs font-mono text-neutral-200 select-all"
                  />
                </div>

                <div>
                  <label className="text-xs font-semibold text-neutral-400 uppercase tracking-wider block mb-1.5">
                    Ready-to-use HTML Iframe Code
                  </label>
                  <textarea
                    rows={3}
                    readOnly
                    value={iframeSnippet}
                    className="w-full px-3 py-2 bg-black/60 border border-white/15 rounded-lg text-xs font-mono text-neutral-200 resize-none select-all"
                  />
                </div>

                <div className="flex items-center justify-end gap-3 pt-2">
                  <button
                    type="button"
                    onClick={() => setShowShareModal(false)}
                    className="px-4 py-2 rounded-lg text-xs font-bold text-neutral-400 hover:text-white"
                  >
                    Close
                  </button>
                  <button
                    type="button"
                    onClick={copyIframe}
                    className="px-5 py-2.5 rounded-lg bg-[#e50914] hover:bg-[#f40612] text-white text-xs font-bold flex items-center gap-2 shadow-lg shadow-red-950/50 cursor-pointer active:scale-95"
                  >
                    {copiedShare ? <Check size={14} /> : <Share2 size={14} />}
                    <span>{copiedShare ? 'Copied Code!' : 'Copy Iframe Code'}</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default EmbedPlayerView;
