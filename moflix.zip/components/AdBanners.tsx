import React, { memo } from 'react';

export const AD_KEYS = {
  DESKTOP_LEADERBOARD_728x90: '',
  MOBILE_BANNER_320x50: '',
  NATIVE_RECTANGLE_300x250: '',
  BANNER_468x60: '',
  SMARTLINK_DIRECT: '',
};

interface BannerAdProps {
  className?: string;
  isLightMode?: boolean;
}

export const BannerAd: React.FC<BannerAdProps> = memo(() => null);
export const NativeRectangleAd: React.FC<{ className?: string }> = memo(() => null);
export const MovieCardAd: React.FC<{ className?: string }> = memo(() => null);
export const StickyBottomAd: React.FC = memo(() => null);

export const NativeAdCard: React.FC<{ className?: string; isLightMode?: boolean }> = NativeRectangleAd;
export const Square1x1Ad: React.FC<{ className?: string }> = NativeRectangleAd;
export const MoreLikeThisAdGrid: React.FC<{ className?: string }> = NativeRectangleAd;
export const MobileBannerAd: React.FC<{ className?: string }> = BannerAd;
export const InFeedBannerAd: React.FC<{ className?: string }> = BannerAd;
export const NativeSquare1x1Ad: React.FC<{ className?: string }> = NativeRectangleAd;
export const NativeAdRow: React.FC<{ title?: string; className?: string }> = BannerAd;
export const SkyscraperAd: React.FC<{ className?: string; side?: 'left' | 'right' }> = NativeRectangleAd;
export const CinemaHallAd: React.FC<{ lightMode?: 'strict' | 'normal' }> = BannerAd;
export const AdScriptLoader: React.FC<{ keyId?: string; width?: number; height?: number; isNative?: boolean; autoRefreshSeconds?: number }> = memo(() => null);

export default BannerAd;
