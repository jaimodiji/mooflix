import React, { useState, useEffect } from 'react';
import { 
  BookOpen, 
  Clock, 
  Calendar, 
  User, 
  Share2, 
  ArrowLeft, 
  Sparkles, 
  Flame, 
  Check, 
  Film, 
  ExternalLink,
  Tag
} from 'lucide-react';
import { BLOG_POSTS, BlogPost } from '../services/blogData';
import { ContentItem } from '../types';
import { useAdBlock } from '../context/AdBlockContext';

interface BlogsViewProps {
  initialSlug?: string | null;
  onOpenMovie?: (item: ContentItem) => void;
  onNavigateHome?: () => void;
}

/**
 * Parses markdown text into formatted React elements:
 * - [label](url) -> interactive internal blog link or external link
 * - **bold** -> <strong>
 * - *italic* -> <em>
 */
const renderFormattedText = (
  text: string, 
  onSelectSlug?: (slug: string) => void
): React.ReactNode => {
  if (!text) return null;

  const pattern = /(\[([^\]]+)\]\(([^)]+)\)|\*\*([^*]+)\*\*|\*([^*]+)\*)/g;
  const elements: React.ReactNode[] = [];
  let lastIndex = 0;
  let match: RegExpExecArray | null;

  while ((match = pattern.exec(text)) !== null) {
    if (match.index > lastIndex) {
      elements.push(text.substring(lastIndex, match.index));
    }

    const [, , linkLabel, linkUrl, boldText, italicText] = match;

    if (linkLabel && linkUrl) {
      const isInternalBlog = linkUrl.startsWith('/blog/') || linkUrl.includes('mooflix.online/blog/') || linkUrl.includes('mooflix.shop/blog/');
      if (isInternalBlog && onSelectSlug) {
        const slug = linkUrl
          .replace('https://mooflix.online/blog/', '')
          .replace('https://mooflix.shop/blog/', '')
          .replace('/blog/', '')
          .trim();
        elements.push(
          <button
            key={match.index}
            type="button"
            onClick={(e) => {
              e.preventDefault();
              onSelectSlug(slug);
            }}
            className="inline-flex items-center gap-1 text-red-400 hover:text-red-300 font-bold underline underline-offset-4 decoration-red-500/50 hover:decoration-red-400 transition-all cursor-pointer bg-red-950/20 px-1.5 py-0.5 rounded mx-0.5"
            title={`Read article: ${linkLabel}`}
          >
            <span>{linkLabel}</span>
            <span className="text-[10px] text-red-500">↗</span>
          </button>
        );
      } else {
        const isInternalSiteLink = linkUrl.startsWith('/') || linkUrl.startsWith('https://mooflix.online');
        elements.push(
          <a
            key={match.index}
            href={linkUrl}
            target={isInternalSiteLink ? '_self' : '_blank'}
            rel={isInternalSiteLink ? undefined : 'noopener noreferrer'}
            className="inline-flex items-center gap-1 text-blue-400 hover:text-blue-300 font-semibold underline underline-offset-2 transition-colors mx-0.5"
          >
            {linkLabel}
          </a>
        );
      }
    } else if (boldText) {
      elements.push(
        <strong key={match.index} className="font-bold text-white">
          {boldText}
        </strong>
      );
    } else if (italicText) {
      elements.push(
        <em key={match.index} className="italic text-neutral-200">
          {italicText}
        </em>
      );
    }

    lastIndex = pattern.lastIndex;
  }

  if (lastIndex < text.length) {
    elements.push(text.substring(lastIndex));
  }

  return <>{elements}</>;
};

export const BlogsView: React.FC<BlogsViewProps> = ({ 
  initialSlug, 
  onOpenMovie, 
  onNavigateHome 
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [activePost, setActivePost] = useState<BlogPost | null>(() => {
    if (initialSlug) {
      return BLOG_POSTS.find((p) => p.slug === initialSlug) || null;
    }
    return null;
  });
  const { isAdsFreeMode } = useAdBlock();
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (initialSlug) {
      const match = BLOG_POSTS.find((p) => p.slug === initialSlug);
      if (match) setActivePost(match);
    }
  }, [initialSlug]);

  useEffect(() => {
    if (activePost) {
      document.title = `${activePost.title} - MooFlix Cinema Blog`;
      window.history.replaceState({ root: 'moflix_app', tab: 'blogs', slug: activePost.slug }, '', `/blog/${activePost.slug}`);
      // Ensure article opens from the very top (heading)
      window.scrollTo({ top: 0, left: 0, behavior: 'instant' });
      const timer = setTimeout(() => {
        window.scrollTo({ top: 0, left: 0, behavior: 'instant' });
      }, 50);
      return () => clearTimeout(timer);
    } else {
      document.title = 'MooFlix Cinema Blog - Streaming Guides & Entertainment News';
      if (window.location.pathname.startsWith('/blog') || window.location.pathname.startsWith('/blogs')) {
        window.history.replaceState({ root: 'moflix_app', tab: 'blogs' }, '', '/blogs');
      }
      window.scrollTo({ top: 0, left: 0, behavior: 'instant' });
    }
  }, [activePost]);

  const categories = ['All', ...Array.from(new Set(BLOG_POSTS.map((p) => p.category)))];

  const filteredPosts = selectedCategory === 'All' 
    ? BLOG_POSTS 
    : BLOG_POSTS.filter((p) => p.category === selectedCategory);

  const handleShare = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(window.location.href);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    }
  };

  return (
    <div className="min-h-screen bg-[#07070a] text-white pt-20 sm:pt-24 pb-20 px-3 sm:px-6 md:px-12 max-w-[1600px] mx-auto select-none">
      
      {/* Blog Article Reader View */}
      {activePost ? (
        <article className="max-w-4xl mx-auto animate-in fade-in duration-300">
          
          {/* Schema.org BlogPosting JSON-LD */}
          <script type="application/ld+json" dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              "@context": "https://schema.org",
              "@type": "BlogPosting",
              "headline": activePost.title,
              "description": activePost.excerpt,
              "image": activePost.coverImage,
              "datePublished": activePost.publishedDate,
              "author": {
                "@type": "Organization",
                "name": activePost.author,
                "url": "https://mooflix.online"
              },
              "publisher": {
                "@type": "Organization",
                "name": "MooFlix Entertainment",
                "logo": {
                  "@type": "ImageObject",
                  "url": "https://mooflix.online/favicon.svg"
                }
              },
              "mainEntityOfPage": {
                "@type": "WebPage",
                "@id": `https://mooflix.online/blog/${activePost.slug}`
              },
              "keywords": activePost.keywords.join(', ')
            })
          }} />

          {/* Back button */}
          <button
            type="button"
            onClick={() => setActivePost(null)}
            className="flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white/10 hover:bg-white/20 active:scale-95 text-neutral-300 hover:text-white text-xs font-semibold mb-6 transition-all cursor-pointer"
          >
            <ArrowLeft size={14} />
            <span>Back to All Articles</span>
          </button>

          {/* Category Badge & Meta */}
          <div className="flex flex-wrap items-center gap-3 text-xs text-neutral-400 font-mono mb-3">
            <span className="px-2.5 py-0.5 rounded-full bg-red-600 text-white font-bold text-[10px] tracking-wide">
              {activePost.category}
            </span>
            <span className="flex items-center gap-1">
              <Calendar size={13} className="text-neutral-500" />
              <span>{activePost.publishedDate}</span>
            </span>
            <span className="flex items-center gap-1">
              <Clock size={13} className="text-neutral-500" />
              <span>{activePost.readTime}</span>
            </span>
            <span className="flex items-center gap-1">
              <User size={13} className="text-neutral-500" />
              <span>{activePost.author}</span>
            </span>
          </div>

          {/* Title */}
          <h1 className="text-2xl sm:text-3xl md:text-4xl font-black text-white tracking-tight leading-tight mb-4">
            {activePost.title}
          </h1>

          {/* Social Share & Action Bar */}
          <div className="flex flex-wrap items-center justify-between gap-2.5 py-3 border-y border-white/10 mb-6 text-xs text-neutral-400">
            <span className="hidden sm:inline">Published on MooFlix Cinema Journal</span>
            <div className="flex items-center gap-1.5 flex-wrap">
              <button
                type="button"
                onClick={handleShare}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-white transition-all cursor-pointer active:scale-95 text-xs font-semibold"
              >
                {copied ? <Check size={14} className="text-emerald-400" /> : <Share2 size={14} />}
                <span>{copied ? 'Link Copied!' : 'Copy Link'}</span>
              </button>

              <a
                href={`https://reddit.com/submit?url=${encodeURIComponent(`https://mooflix.online/blog/${activePost.slug}`)}&title=${encodeURIComponent(activePost.title)}`}
                target="_blank"
                rel="noopener noreferrer"
                className="px-2.5 py-1.5 rounded-lg bg-[#ff4500]/20 hover:bg-[#ff4500] text-white border border-[#ff4500]/30 transition-all font-bold text-xs shadow-sm active:scale-95"
                title="Post to Reddit"
              >
                Reddit
              </a>

              <a
                href={`https://twitter.com/intent/tweet?text=${encodeURIComponent(activePost.title)}&url=${encodeURIComponent(`https://mooflix.online/blog/${activePost.slug}`)}`}
                target="_blank"
                rel="noopener noreferrer"
                className="px-2.5 py-1.5 rounded-lg bg-black/60 hover:bg-black text-white border border-white/20 transition-all font-bold text-xs shadow-sm active:scale-95"
                title="Post to X (Twitter)"
              >
                X
              </a>

              <a
                href={`https://pinterest.com/pin/create/button/?url=${encodeURIComponent(`https://mooflix.online/blog/${activePost.slug}`)}&media=${encodeURIComponent(activePost.coverImage)}&description=${encodeURIComponent(activePost.title)}`}
                target="_blank"
                rel="noopener noreferrer"
                className="px-2.5 py-1.5 rounded-lg bg-[#e60023]/20 hover:bg-[#e60023] text-white border border-[#e60023]/30 transition-all font-bold text-xs shadow-sm active:scale-95"
                title="Pin on Pinterest"
              >
                Pinterest
              </a>
            </div>
          </div>

          {/* Cover Hero Image */}
          <div className="w-full h-64 sm:h-96 rounded-3xl overflow-hidden mb-8 border border-white/10 shadow-2xl relative bg-black">
            <img 
              src={activePost.coverImage} 
              alt={activePost.title} 
              className="w-full h-full object-cover"
            />
          </div>


          {/* Article Formatted Content with Rich Markdown & Internal Links */}
          <div className="prose prose-invert max-w-none text-neutral-300 text-sm sm:text-base leading-relaxed space-y-4">
            {activePost.content.split('\n\n').map((paragraph, index) => {
              const trimmed = paragraph.trim();
              if (!trimmed) return null;

              if (trimmed === '---') {
                return <hr key={index} className="my-6 border-white/10" />;
              }

              if (trimmed.startsWith('## ')) {
                return (
                  <h2 key={index} className="text-xl sm:text-2xl font-black text-white mt-8 mb-3 tracking-tight border-b border-white/10 pb-2 flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-red-500" />
                    <span>{trimmed.replace('## ', '')}</span>
                  </h2>
                );
              }

              if (trimmed.startsWith('### ')) {
                return (
                  <h3 key={index} className="text-lg sm:text-xl font-bold text-white mt-6 mb-2 tracking-tight flex items-center gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-rose-500" />
                    <span>{trimmed.replace('### ', '')}</span>
                  </h3>
                );
              }

              if (trimmed.startsWith('#### ')) {
                return (
                  <h4 key={index} className="text-base sm:text-lg font-semibold text-neutral-200 mt-4 mb-2">
                    {trimmed.replace('#### ', '')}
                  </h4>
                );
              }

              if (trimmed.startsWith('> ')) {
                return (
                  <blockquote key={index} className="my-4 pl-4 py-2 border-l-4 border-red-500 bg-red-950/20 rounded-r-xl text-neutral-200 italic">
                    {renderFormattedText(trimmed.replace(/^>\s*/, ''), (slug) => {
                      const match = BLOG_POSTS.find(p => p.slug === slug || p.slug === slug.replace('/blog/', ''));
                      if (match) {
                        setActivePost(match);
                        window.scrollTo({ top: 0, behavior: 'smooth' });
                      }
                    })}
                  </blockquote>
                );
              }

              if (trimmed.startsWith('|') && trimmed.includes('|')) {
                const rows = trimmed.split('\n').filter(r => r.trim().startsWith('|'));
                if (rows.length >= 2) {
                  const headerCells = rows[0].split('|').map(c => c.trim()).filter(Boolean);
                  const dataRows = rows.slice(2); // Skip separator row
                  return (
                    <div key={index} className="my-4 overflow-x-auto rounded-xl border border-white/10 bg-black/40">
                      <table className="w-full text-left text-xs sm:text-sm">
                        <thead className="bg-white/[0.06] text-white border-b border-white/10">
                          <tr>
                            {headerCells.map((h, hi) => (
                              <th key={hi} className="px-3.5 py-2.5 font-bold uppercase tracking-wider">{h}</th>
                            ))}
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-white/5">
                          {dataRows.map((dr, dri) => {
                            const cells = dr.split('|').map(c => c.trim()).filter(Boolean);
                            return (
                              <tr key={dri} className="hover:bg-white/[0.02]">
                                {cells.map((c, ci) => (
                                  <td key={ci} className="px-3.5 py-2 text-neutral-300">
                                    {renderFormattedText(c, (slug) => {
                                      const match = BLOG_POSTS.find(p => p.slug === slug || p.slug === slug.replace('/blog/', ''));
                                      if (match) {
                                        setActivePost(match);
                                        window.scrollTo({ top: 0, behavior: 'smooth' });
                                      }
                                    })}
                                  </td>
                                ))}
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  );
                }
              }

              if (trimmed.startsWith('- ') || trimmed.startsWith('* ')) {
                const listItems = trimmed.split('\n').filter(Boolean);
                return (
                  <ul key={index} className="list-disc list-inside space-y-2 my-3 text-neutral-300 pl-2">
                    {listItems.map((li, i) => (
                      <li key={i} className="leading-relaxed">
                        {renderFormattedText(li.replace(/^[-*]\s*/, ''), (slug) => {
                          const match = BLOG_POSTS.find(p => p.slug === slug || p.slug === slug.replace('/blog/', ''));
                          if (match) {
                            setActivePost(match);
                            window.scrollTo({ top: 0, behavior: 'smooth' });
                          }
                        })}
                      </li>
                    ))}
                  </ul>
                );
              }

              if (/^\d+\./.test(trimmed)) {
                const orderedItems = trimmed.split('\n').filter(Boolean);
                return (
                  <ol key={index} className="list-decimal list-inside space-y-2 my-3 text-neutral-300 pl-2">
                    {orderedItems.map((oi, i) => (
                      <li key={i} className="leading-relaxed">
                        {renderFormattedText(oi.replace(/^\d+\.\s*/, ''), (slug) => {
                          const match = BLOG_POSTS.find(p => p.slug === slug || p.slug === slug.replace('/blog/', ''));
                          if (match) {
                            setActivePost(match);
                            window.scrollTo({ top: 0, behavior: 'smooth' });
                          }
                        })}
                      </li>
                    ))}
                  </ol>
                );
              }

              const allParagraphs = activePost.content.split('\n\n');
              const totalP = allParagraphs.length;
              const ad1 = Math.max(2, Math.floor(totalP * 0.25));
              const ad2 = Math.max(ad1 + 2, Math.floor(totalP * 0.5));
              const ad3 = Math.max(ad2 + 2, Math.floor(totalP * 0.75));

              return (
                <React.Fragment key={index}>
                  <p className="text-neutral-300 leading-relaxed">
                    {renderFormattedText(trimmed, (slug) => {
                      const match = BLOG_POSTS.find(p => p.slug === slug || p.slug === slug.replace('/blog/', ''));
                      if (match) {
                        setActivePost(match);
                        window.scrollTo({ top: 0, behavior: 'smooth' });
                      }
                    })}
                  </p>
                </React.Fragment>
              );
            })}
          </div>

          {/* Keywords / Tags Cloud */}
          <div className="mt-8 pt-6 border-t border-white/10">
            <span className="text-xs font-mono uppercase text-neutral-400 font-bold block mb-3">
              Topics & Search Keywords:
            </span>
            <div className="flex flex-wrap gap-2">
              {activePost.keywords.map((kw) => (
                <span 
                  key={kw} 
                  className="text-xs bg-white/[0.05] hover:bg-red-600/20 text-neutral-300 hover:text-white px-3 py-1 rounded-lg border border-white/10 transition-colors"
                >
                  #{kw}
                </span>
              ))}
            </div>
          </div>

          {/* Related Articles Section for Seamless Internal Navigation */}
          <div className="mt-12 pt-8 border-t border-white/15">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h3 className="text-lg sm:text-xl font-bold text-white flex items-center gap-2">
                  <Sparkles size={18} className="text-red-500" />
                  <span>Related Articles & Recommended Guides</span>
                </h3>
                <p className="text-xs text-neutral-400 mt-1">
                  Explore connected streaming tutorials, live match guides, and cinema reviews
                </p>
              </div>
              <button
                type="button"
                onClick={() => {
                  setActivePost(null);
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                className="text-xs font-semibold text-red-400 hover:text-red-300 transition-colors"
              >
                View All ({BLOG_POSTS.length}) →
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {BLOG_POSTS
                .filter(p => p.id !== activePost.id)
                .slice(0, 3)
                .map((relPost) => (
                  <div
                    key={relPost.id}
                    onClick={() => {
                      setActivePost(relPost);
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }}
                    className="group bg-[#0e0e14] hover:bg-[#14141d] border border-white/10 hover:border-red-500/40 rounded-xl overflow-hidden cursor-pointer transition-all duration-300 p-3.5 flex flex-col justify-between"
                  >
                    <div>
                      <div className="w-full h-28 rounded-lg overflow-hidden mb-3 relative bg-black">
                        <img 
                          src={relPost.coverImage} 
                          alt={relPost.title} 
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                          loading="lazy"
                        />
                        <span className="absolute top-2 left-2 text-[9px] bg-red-600 font-bold px-2 py-0.5 rounded text-white shadow">
                          {relPost.category}
                        </span>
                      </div>
                      <h4 className="text-xs font-bold text-white group-hover:text-red-400 transition-colors line-clamp-2 leading-snug mb-1">
                        {relPost.title}
                      </h4>
                      <p className="text-[11px] text-neutral-400 line-clamp-2 leading-relaxed">
                        {relPost.excerpt}
                      </p>
                    </div>
                    <div className="mt-3 pt-2 border-t border-white/5 flex items-center justify-between text-[10px] text-red-500 font-semibold">
                      <span>Read Guide →</span>
                      <span className="text-neutral-500 font-mono">{relPost.readTime}</span>
                    </div>
                  </div>
                ))}
            </div>
          </div>

          {/* Back button at footer */}
          <div className="mt-10 text-center">
            <button
              type="button"
              onClick={() => {
                setActivePost(null);
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="py-3 px-8 rounded-full bg-red-600 hover:bg-red-700 text-white font-bold text-xs shadow-lg transition-all cursor-pointer active:scale-95"
            >
              Explore All Articles
            </button>
          </div>
        </article>
      ) : (
        /* Blog List Catalog View */
        <div className="space-y-8 animate-in fade-in duration-200">
          
          {/* Header Banner */}
          <div className="relative rounded-3xl p-6 sm:p-10 md:p-12 overflow-hidden bg-gradient-to-br from-red-950/30 via-[#0d0d12] to-[#07070b] border border-red-500/20 shadow-2xl">
            <div className="max-w-2xl relative z-10">
              {/* Back to Home Breadcrumb */}
              <button
                type="button"
                onClick={onNavigateHome}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/10 hover:bg-white/20 active:scale-95 text-neutral-300 hover:text-white text-xs font-semibold mb-4 transition-all cursor-pointer border border-white/10"
              >
                <ArrowLeft size={13} />
                <span>← Back to MooFlix Home</span>
              </button>

              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-red-600/20 border border-red-500/30 text-red-400 text-xs font-bold uppercase tracking-wider mb-3">
                <BookOpen size={13} className="text-amber-400" />
                <span>MooFlix Cinema Blog & Entertainment Guides</span>
              </div>
              <h1 className="text-2xl sm:text-4xl font-black text-white tracking-tight leading-tight">
                Movie Guides, 4K Reviews & Release Radar
              </h1>
              <p className="mt-2 text-xs sm:text-sm text-neutral-400 leading-relaxed">
                Expert editorials on the best free streaming portals, upcoming Indian and Hollywood blockbusters, anime schedules, and theater setup guides.
              </p>
            </div>
          </div>

          {/* Categories Filter Pills */}
          <div className="flex items-center gap-2 overflow-x-auto pb-2 no-scrollbar">
            {categories.map((cat) => (
              <button
                key={cat}
                type="button"
                onClick={() => setSelectedCategory(cat)}
                className={`px-4 py-1.5 rounded-full text-xs font-bold transition-all shrink-0 cursor-pointer ${
                  selectedCategory === cat
                    ? 'bg-red-600 text-white shadow-lg shadow-red-900/40 border border-red-400/40'
                    : 'bg-white/[0.05] hover:bg-white/[0.1] text-neutral-300 border border-white/10'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>


          {/* Posts Grid with Native Ad Integration for Maximum High-CPM Impressions */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredPosts.map((post, postIdx) => (
              <React.Fragment key={post.id}>
                <article
                  onClick={() => setActivePost(post)}
                  className="bg-[#0f0f15] border border-white/10 hover:border-red-500/40 rounded-2xl overflow-hidden transition-all duration-300 hover:-translate-y-1 hover:shadow-xl hover:shadow-red-950/20 cursor-pointer flex flex-col group"
                >
                  <div className="w-full h-48 overflow-hidden relative bg-black">
                    <img 
                      src={post.coverImage} 
                      alt={post.title} 
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      loading="lazy"
                    />
                    <span className="absolute top-3 left-3 bg-red-600 text-white font-bold text-[10px] px-2.5 py-0.5 rounded shadow">
                      {post.category}
                    </span>
                  </div>

                  <div className="p-5 flex-1 flex flex-col justify-between">
                    <div>
                      <div className="flex items-center gap-2.5 text-[11px] text-neutral-400 font-mono mb-2">
                        <span>{post.publishedDate}</span>
                        <span>•</span>
                        <span>{post.readTime}</span>
                      </div>

                      <h2 className="text-base font-bold text-white group-hover:text-red-400 transition-colors line-clamp-2 leading-snug">
                        {post.title}
                      </h2>

                      <p className="text-xs text-neutral-400 mt-2 line-clamp-3 leading-relaxed">
                        {post.excerpt}
                      </p>
                    </div>

                    <div className="mt-4 pt-3 border-t border-white/10 flex items-center justify-between text-xs text-red-500 font-semibold">
                      <span>Read Article →</span>
                      <span className="text-[10px] text-neutral-500 font-mono">By {post.author}</span>
                    </div>
                  </div>
                </article>

              </React.Fragment>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default BlogsView;
