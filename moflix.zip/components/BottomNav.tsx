import React from 'react';
import { Home, Tv, Film, Flame, Trophy } from 'lucide-react';

interface BottomNavProps {
  activeTab: string;
  isSearchOpen?: boolean;
  searchQuery?: string;
  onNavigate: (tab: string) => void;
  onSearchClick?: () => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({ 
  activeTab, 
  isSearchOpen,
  onNavigate, 
  onSearchClick,
}) => {
  // Mobile & Tablet navigation items
  const navItems = [
    { id: 'home', label: 'Home', icon: Home },
    { id: 'movies', label: 'Movies', icon: Film },
    { id: 'series', label: 'Shows', icon: Tv },
    { id: 'anime', label: 'Anime', icon: Flame },
    { id: 'sports', label: 'Sports', icon: Trophy },
  ];

  return (
    <nav className="lg:hidden fixed bottom-2 sm:bottom-4 left-1.5 right-1.5 sm:left-1/2 sm:-translate-x-1/2 sm:w-[540px] sm:max-w-[96vw] z-[100] h-14 sm:h-16 bg-[#09090d]/95 backdrop-blur-2xl border border-white/[0.12] rounded-full px-1 sm:px-3 select-none shadow-[0_10px_35px_rgba(0,0,0,0.85),0_0_0_1px_rgba(255,255,255,0.05)] flex items-center">
      <div className="flex items-center justify-around w-full max-w-lg mx-auto">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;

          const handleClick = () => {
            onNavigate(item.id);
          };

          return (
            <button
              key={item.id}
              type="button"
              onClick={handleClick}
              className={`relative flex flex-col items-center justify-center py-1 px-1.5 sm:px-2.5 rounded-full transition-all duration-200 cursor-pointer select-none active:scale-90 touch-manipulation ${
                isActive 
                  ? 'text-white bg-white/12 border border-white/25 shadow-[0_2px_12px_rgba(255,255,255,0.08)] scale-[1.02]' 
                  : 'text-neutral-400 hover:text-white hover:bg-white/5 border border-transparent hover:border-white/10 active:bg-white/10'
              }`}
              aria-label={item.label}
            >
              <div className="relative">
                <Icon 
                  size={17} 
                  strokeWidth={isActive ? 2.5 : 1.8} 
                  className={`transition-all duration-200 ${
                    isActive 
                      ? 'scale-110 text-white drop-shadow-[0_2px_8px_rgba(255,255,255,0.4)]' 
                      : 'text-neutral-400 group-hover:text-white'
                  }`}
                />
              </div>
              <span className={`text-[9.5px] sm:text-[11px] font-semibold tracking-tight transition-colors duration-200 mt-0.5 ${
                isActive ? 'text-white font-bold' : 'text-neutral-400'
              }`}>
                {item.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};

export default BottomNav;
