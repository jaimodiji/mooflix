import React, { useState } from 'react';
import { X, Copy, Check, Share2, ExternalLink } from 'lucide-react';
import { ContentItem } from '../types';

interface SocialBacklinkShareModalProps {
  item: ContentItem;
  isOpen: boolean;
  onClose: () => void;
}

export const SocialBacklinkShareModal: React.FC<SocialBacklinkShareModalProps> = ({
  item,
  isOpen,
  onClose,
}) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const type = item.type === 'movie' ? 'movie' : 'series';
  const shareUrl = `https://mooflix.shop/${type}/${item.id}`;
  const posterUrl = item.backdrop || item.thumbnail || 'https://mooflix.shop/og-image.jpg';
  const shareTitle = `Watch ${item.title} (${item.year || 2026}) Online Free in Ultra HD 4K on MooFlix`;
  const redditText = `Watch ${item.title} full ${type === 'movie' ? 'movie' : 'series'} stream online free without sign up on MooFlix`;

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(shareUrl);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    } catch {
      // Fallback
    }
  };

  const shareNetworks = [
    {
      name: 'Reddit',
      desc: 'Top US/UK Cinema Communities (r/movies, r/Streaming)',
      color: 'bg-[#ff4500] hover:bg-[#e03d00] text-white',
      url: `https://reddit.com/submit?url=${encodeURIComponent(shareUrl)}&title=${encodeURIComponent(redditText)}`,
      icon: (
        <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
          <path d="M12 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0zm5.01 4.744c.688 0 1.25.561 1.25 1.249a1.25 1.25 0 0 1-2.498.056l-2.597-.547-.8 3.747c1.824.07 3.48.632 4.674 1.488.308-.309.73-.491 1.207-.491.968 0 1.754.786 1.754 1.754 0 .716-.435 1.333-1.01 1.614a3.111 3.111 0 0 1 .042.52c0 2.694-3.13 4.87-7.004 4.87-3.874 0-7.004-2.176-7.004-4.87 0-.183.015-.366.043-.534A1.748 1.748 0 0 1 4.028 12c0-.968.786-1.754 1.754-1.754.463 0 .898.196 1.207.49 1.207-.883 2.878-1.43 4.744-1.487l.885-4.182a.342.342 0 0 1 .14-.197.35.35 0 0 1 .238-.042l2.906.614a1.245 1.245 0 0 1 1.108-.7z"/>
        </svg>
      ),
    },
    {
      name: 'X (Twitter)',
      desc: 'Post trending Hollywood & movie tweet',
      color: 'bg-black hover:bg-neutral-900 text-white border border-white/20',
      url: `https://twitter.com/intent/tweet?text=${encodeURIComponent(`Stream ${item.title} free in 4K UHD with zero ads/buffering on #MooFlix!`)}&url=${encodeURIComponent(shareUrl)}`,
      icon: (
        <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
          <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/>
        </svg>
      ),
    },
    {
      name: 'Pinterest',
      desc: 'Create viral cinema movie poster pin',
      color: 'bg-[#e60023] hover:bg-[#ad001a] text-white',
      url: `https://pinterest.com/pin/create/button/?url=${encodeURIComponent(shareUrl)}&media=${encodeURIComponent(posterUrl)}&description=${encodeURIComponent(shareTitle)}`,
      icon: (
        <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
          <path d="M12 0a12 12 0 0 0-4.37 23.18c-.06-.99-.12-2.52.02-3.6.14-1.04.93-6.52.93-6.52s-.24-.48-.24-1.19c0-1.11.64-1.94 1.45-1.94.68 0 1.01.51 1.01 1.13 0 .69-.44 1.72-.66 2.67-.19.8.4 1.45 1.19 1.45 1.43 0 2.53-1.51 2.53-3.68 0-1.92-1.38-3.26-3.35-3.26-2.45 0-3.89 1.84-3.89 3.73 0 .74.28 1.53.64 1.96.07.09.08.16.06.25-.07.28-.22.9-.25 1.03-.04.17-.14.21-.32.13-1.2-.56-1.95-2.31-1.95-3.72 0-3.03 2.2-5.81 6.35-5.81 3.33 0 5.92 2.37 5.92 5.55 0 3.31-2.09 5.98-4.99 5.98-.97 0-1.89-.51-2.2-.11l-.6 2.28c-.22.84-.81 1.89-1.21 2.53A11.98 11.98 0 0 0 12 24c6.63 0 12-5.37 12-12S18.63 0 12 0z"/>
        </svg>
      ),
    },
    {
      name: 'Telegram',
      desc: 'Share to channels & friends',
      color: 'bg-[#0088cc] hover:bg-[#0077b5] text-white',
      url: `https://t.me/share/url?url=${encodeURIComponent(shareUrl)}&text=${encodeURIComponent(shareTitle)}`,
      icon: (
        <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
          <path d="M12 0C5.373 0 0 5.373 0 12s5.373 12 12 12 12-5.373 12-12S18.627 0 12 0zm5.894 8.221l-1.97 9.28c-.145.658-.537.818-1.084.508l-3-2.21-1.446 1.394c-.16.16-.295.295-.605.295l.213-3.053 5.56-5.023c.242-.213-.054-.333-.373-.121l-6.871 4.326-2.962-.924c-.643-.204-.657-.643.136-.953l11.57-4.458c.538-.196 1.006.128.832.943z"/>
        </svg>
      ),
    },
    {
      name: 'WhatsApp',
      desc: 'Send to chats & status',
      color: 'bg-[#25d366] hover:bg-[#20ba59] text-white',
      url: `https://api.whatsapp.com/send?text=${encodeURIComponent(`${shareTitle}\n${shareUrl}`)}`,
      icon: (
        <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
          <path d="M17.507 14.307l-.009.075c-2.399-1.2-2.823-1.4-3.325-1.4-.413 0-.712.18-.94.49l-.65.86c-.23.31-.49.36-.88.16-1.57-.81-2.73-1.97-3.54-3.54-.2-.39-.15-.65.16-.88l.86-.65c.31-.23.49-.53.49-.94 0-.5-.2-.93-1.4-3.33l-.08-.01c-.48-.04-.94.13-1.28.46l-.88.88c-.68.68-.9 1.63-.58 2.55 1.13 3.25 3.69 5.81 6.94 6.94.92.32 1.87.1 2.55-.58l.88-.88c.33-.34.5-.8.46-1.28zM12.04 2c-5.52 0-10 4.48-10 10 0 1.77.46 3.45 1.28 4.95L2 22l5.22-1.3c1.44.77 3.07 1.2 4.82 1.2 5.52 0 10-4.48 10-10s-4.48-10-10-10z"/>
        </svg>
      ),
    },
  ];

  return (
    <div
      className="fixed inset-0 z-[600] bg-black/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 select-none animate-in fade-in duration-150"
      onClick={onClose}
    >
      <div
        className="relative bg-[#111116] border border-white/15 p-5 sm:p-6 rounded-2xl w-full max-w-md shadow-2xl animate-in zoom-in-95 duration-150"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-white/10 mb-4">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-red-600/20 text-red-400 flex items-center justify-center border border-red-500/30">
              <Share2 size={16} />
            </div>
            <h3 className="text-base font-bold text-white tracking-wide">Share with Others</h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close"
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 text-neutral-300 hover:text-white flex items-center justify-center transition-all cursor-pointer"
          >
            <X size={15} />
          </button>
        </div>

        {/* Canonical Clean Link Copy Box */}
        <div className="mb-4">
          <label className="text-[11px] font-semibold text-neutral-400 block mb-1">
            Copy Link:
          </label>
          <div className="flex items-center gap-2 bg-[#09090c] border border-white/15 rounded-xl p-1.5 px-3">
            <input
              type="text"
              readOnly
              value={shareUrl}
              className="bg-transparent border-0 text-neutral-300 text-xs w-full focus:outline-none select-all truncate font-mono"
            />
            <button
              type="button"
              onClick={handleCopy}
              className={`flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer active:scale-95 shrink-0 ${
                copied
                  ? 'bg-emerald-500 text-black'
                  : 'bg-white/15 hover:bg-white/25 text-white'
              }`}
            >
              {copied ? <Check size={13} /> : <Copy size={13} />}
              <span>{copied ? 'Copied!' : 'Copy'}</span>
            </button>
          </div>
        </div>

        {/* Global Social Sharing Networks */}
        <div className="space-y-2">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {shareNetworks.map((net) => (
              <a
                key={net.name}
                href={net.url}
                target="_blank"
                rel="noopener noreferrer"
                className={`flex items-center gap-2.5 px-3.5 py-2.5 rounded-xl font-semibold text-xs transition-all shadow-md active:scale-95 cursor-pointer ${net.color}`}
              >
                {net.icon}
                <div className="flex-1 text-left min-w-0">
                  <div className="font-bold leading-tight">{net.name}</div>
                  <div className="text-[10px] opacity-80 truncate">{net.desc}</div>
                </div>
                <ExternalLink size={12} className="opacity-70" />
              </a>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default SocialBacklinkShareModal;
