import React, { useState, useEffect, useRef, memo } from 'react';
import { Film } from 'lucide-react';

interface LazyImageProps {
  src?: string | null;
  alt: string;
  className?: string;
  containerClassName?: string;
  aspectRatio?: 'portrait' | 'landscape' | 'video' | 'square' | 'auto';
  priority?: boolean;
  fallbackText?: string;
  referrerPolicy?: React.HTMLAttributeReferrerPolicy;
}

/**
 * Derives a micro-sized Low Quality Image Placeholder (LQIP) URL.
 * For TMDB assets, it replaces /w500/ or /original/ with the ultra-light /w92/ variant (~1-2KB).
 */
export const getLqipUrl = (url?: string | null): string | null => {
  if (!url) return null;
  if (url.includes('image.tmdb.org/t/p/')) {
    return url.replace(/\/t\/p\/(w\d+|original)\//, '/t/p/w92/');
  }
  // For Unsplash images, request a tiny 20px thumbnail with blur
  if (url.includes('images.unsplash.com')) {
    const base = url.split('?')[0];
    return `${base}?w=40&auto=format&fit=crop&q=20&blur=10`;
  }
  return null;
};

/**
 * Custom High-Performance Image Component
 * - Native lazy loading (`loading="lazy"`)
 * - Asynchronous image decoding (`decoding="async"`)
 * - Low-Quality Image Placeholder (LQIP) progressive blur-up transition
 * - Zero Cumulative Layout Shift (CLS)
 * - Graceful fallback handling
 */
export const LazyImage: React.FC<LazyImageProps> = memo(({
  src,
  alt,
  className = '',
  containerClassName = '',
  aspectRatio = 'portrait',
  priority = false,
  fallbackText,
  referrerPolicy = 'no-referrer',
}) => {
  const [isLoaded, setIsLoaded] = useState<boolean>(false);
  const [isLqipLoaded, setIsLqipLoaded] = useState<boolean>(false);
  const [hasError, setHasError] = useState<boolean>(false);
  const imgRef = useRef<HTMLImageElement>(null);

  const lqipSrc = getLqipUrl(src);

  // Check if image is already cached by browser
  useEffect(() => {
    setIsLoaded(false);
    setIsLqipLoaded(false);
    setHasError(false);

    if (imgRef.current && imgRef.current.complete) {
      if (imgRef.current.naturalWidth > 0) {
        setIsLoaded(true);
      }
    }
  }, [src]);

  const aspectClass = 
    aspectRatio === 'portrait' ? 'aspect-[2/3]' :
    aspectRatio === 'landscape' || aspectRatio === 'video' ? 'aspect-video' :
    aspectRatio === 'square' ? 'aspect-square' : '';

  if (!src || hasError) {
    return (
      <div 
        className={`w-full h-full ${aspectClass} bg-[#18181b] flex flex-col items-center justify-center p-3 text-center border border-white/5 ${containerClassName}`}
        role="img"
        aria-label={alt}
      >
        <Film size={24} className="text-neutral-600 mb-1.5 opacity-60" />
        <span className="text-neutral-400 text-[11px] font-medium line-clamp-2 px-1">
          {fallbackText || alt}
        </span>
      </div>
    );
  }

  return (
    <div 
      className={`relative w-full h-full ${aspectClass} overflow-hidden bg-[#121215] ${containerClassName}`}
    >
      {/* 1. Shimmer Base Skeleton: Prevents CLS before any network response */}
      {!isLoaded && (
        <div className="absolute inset-0 bg-[#16161a] overflow-hidden pointer-events-none">
          <div className="absolute inset-0 -translate-x-full animate-[shimmer_1.8s_infinite] bg-gradient-to-r from-transparent via-white/[0.05] to-transparent" />
        </div>
      )}

      {/* 2. Low Quality Image Placeholder (LQIP) Layer: Ultra-fast progressive blur-up */}
      {lqipSrc && !isLoaded && (
        <img
          src={lqipSrc}
          alt=""
          aria-hidden="true"
          className={`absolute inset-0 w-full h-full object-cover scale-105 filter blur-md transition-opacity duration-300 pointer-events-none ${
            isLqipLoaded ? 'opacity-80' : 'opacity-0'
          }`}
          onLoad={() => setIsLqipLoaded(true)}
          loading="eager"
          decoding="async"
          referrerPolicy={referrerPolicy}
        />
      )}

      {/* 3. Primary Full-Resolution Image */}
      <img
        ref={imgRef}
        src={src}
        alt={alt}
        loading={priority ? 'eager' : 'lazy'}
        decoding="async"
        fetchPriority={priority ? 'high' : 'auto'}
        onLoad={() => {
          setIsLoaded(true);
        }}
        onError={() => {
          setHasError(true);
        }}
        referrerPolicy={referrerPolicy}
        className={`w-full h-full object-cover transition-all duration-500 ease-out ${
          isLoaded 
            ? 'opacity-100 filter-none scale-100' 
            : 'opacity-0 filter blur-sm scale-[1.02]'
        } ${className}`}
      />
    </div>
  );
});

LazyImage.displayName = 'LazyImage';

export default LazyImage;
