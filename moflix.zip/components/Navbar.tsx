import React, { useState, useEffect } from 'react';
import { Search, Bookmark, Code } from 'lucide-react';

interface NavbarProps {
  activeTab: string;
  onNavigate: (tab: string) => void;
  onOpenSearch?: () => void;
  onOpenApiModal?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ 
  activeTab, 
  onNavigate, 
  onOpenSearch, 
  onOpenApiModal,
}) => {
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 20) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };
    handleScroll();
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header 
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled 
          ? 'bg-black/35 backdrop-blur-xl shadow-[0_8px_32px_rgba(0,0,0,0.6),inset_0_1px_1px_rgba(255,255,255,0.12)] py-2.5 sm:py-3 border-b border-white/10' 
          : 'bg-transparent py-3 sm:py-4 md:py-5 border-b border-white/[0.05]'
      }`}
    >
      <nav 
        className="max-w-[1920px] mx-auto px-3.5 sm:px-6 md:px-12 flex items-center justify-between"
        aria-label="Main Navigation"
      >
        {/* Left: Brand Logo & Desktop Links */}
        <div className="flex items-center gap-4 sm:gap-6 md:gap-10">
          {/* Brand Logo */}
          <div 
            onClick={() => onNavigate('home')}
            className="flex items-center select-none cursor-pointer group"
            aria-label="MooFlix Home"
          >
            <span className="text-xl sm:text-2xl md:text-3xl lg:text-4xl font-black tracking-tighter text-[#e50914] uppercase drop-shadow-[0_2px_14px_rgba(229,9,20,0.85)] select-none font-sans group-hover:scale-105 transition-transform">
              MOOFLIX
            </span>
          </div>

          {/* Desktop Navigation Links */}
          <div className="hidden lg:flex items-center gap-1.5 lg:gap-2">
            {[
              { id: 'home', label: 'Home' },
              { id: 'movies', label: 'Movies' },
              { id: 'series', label: 'Shows' },
              { id: 'anime', label: 'Anime' },
              { id: 'sports', label: 'Sports' },
              { id: 'watchlist', label: 'Watchlist' },
            ].map((tab) => {
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => onNavigate(tab.id)}
                  className={`px-3.5 py-1.5 rounded-full text-xs lg:text-sm font-medium transition-all cursor-pointer select-none ${
                    isActive
                      ? 'text-white font-bold bg-white/15 backdrop-blur-md shadow-[inset_0_1px_1px_rgba(255,255,255,0.25)] border border-white/20'
                      : 'text-neutral-200 hover:text-white hover:bg-white/[0.08]'
                  }`}
                  aria-current={isActive ? 'page' : undefined}
                >
                  {tab.label}
                </button>
              );
            })}
          </div>
        </div>

        {/* Mobile & Tablet Header Right Actions (< lg) */}
        <div className="flex lg:hidden items-center gap-1.5 sm:gap-2">
          {/* Watchlist / Watch Later Button */}
          <button
            type="button"
            onClick={() => onNavigate('watchlist')}
            className={`flex items-center justify-center w-8 h-8 sm:w-9 sm:h-9 rounded-full ${
              activeTab === 'watchlist' 
                ? 'bg-red-600 text-white shadow-[0_0_12px_rgba(239,68,68,0.5)] border border-red-500/50' 
                : 'bg-white/[0.08] hover:bg-white/20 text-neutral-200 hover:text-white border border-white/15 shadow-[inset_0_1px_1px_rgba(255,255,255,0.2)] backdrop-blur-md'
            } transition-all cursor-pointer shadow-sm active:scale-95`}
            aria-label="My Watch Later"
            title="Watch Later"
          >
            <Bookmark size={15} />
          </button>

          {/* API Button next to Watch Later on Mobile */}
          <button
            type="button"
            onClick={() => onOpenApiModal?.()}
            className="flex items-center gap-1 px-2.5 h-8 sm:h-9 rounded-full bg-white/[0.08] hover:bg-white/20 border border-white/15 text-neutral-200 hover:text-white transition-all cursor-pointer shadow-[inset_0_1px_1px_rgba(255,255,255,0.2)] backdrop-blur-md active:scale-95 text-xs font-bold"
            aria-label="Player API"
            title="Player API"
          >
            <Code size={13} className="text-red-500" />
            <span>API</span>
          </button>

          {/* Search Button */}
          <button
            type="button"
            onClick={() => onOpenSearch?.()}
            className="flex items-center justify-center w-8 h-8 sm:w-9 sm:h-9 rounded-full bg-white/[0.08] hover:bg-white/20 border border-white/15 text-neutral-200 hover:text-white transition-all cursor-pointer shadow-[inset_0_1px_1px_rgba(255,255,255,0.2)] backdrop-blur-md active:scale-95"
            aria-label="Search"
            title="Search Movies & Shows"
          >
            <Search size={15} />
          </button>
        </div>

        {/* Desktop Header Actions (>= lg) */}
        <div className="hidden lg:flex items-center gap-2.5">
          {/* Search Button */}
          <button
            type="button"
            onClick={() => onOpenSearch?.()}
            className="flex items-center gap-2 px-4 py-1.5 md:py-2 rounded-full bg-white/[0.08] hover:bg-white/[0.18] border border-white/15 hover:border-white/30 text-neutral-200 hover:text-white transition-all text-xs sm:text-sm font-medium cursor-pointer shadow-[inset_0_1px_1px_rgba(255,255,255,0.2)] backdrop-blur-md active:scale-95 group select-none"
            aria-label="Search"
          >
            <Search size={15} className="text-neutral-300 group-hover:text-white transition-colors" />
            <span>Search</span>
            <kbd className="hidden md:inline-block ml-1 text-[10px] bg-white/15 text-neutral-300 px-1.5 py-0.5 rounded font-mono border border-white/10">
              /
            </kbd>
          </button>

          {/* API Button placed immediately next to Search in Desktop Header */}
          <button
            type="button"
            onClick={() => onOpenApiModal?.()}
            className="flex items-center gap-1.5 px-3.5 py-1.5 md:py-2 rounded-full bg-white/[0.08] hover:bg-white/[0.18] border border-white/15 hover:border-red-500/40 text-neutral-200 hover:text-white transition-all text-xs sm:text-sm font-bold cursor-pointer shadow-[inset_0_1px_1px_rgba(255,255,255,0.2)] backdrop-blur-md active:scale-95 group select-none"
            aria-label="Player API"
            title="Player Embed API"
          >
            <Code size={15} className="text-red-500 group-hover:scale-110 transition-transform" />
            <span>API</span>
          </button>
        </div>
      </nav>
    </header>
  );
};

export default Navbar;
