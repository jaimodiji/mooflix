import React, { memo } from 'react';

export interface MovieCardSkeletonProps {
  aspectRatio?: 'portrait' | 'landscape';
  className?: string;
}

/**
 * High-fidelity Skeleton Placeholder for individual MovieCard
 * Matches exact aspect ratios, subtle borders, and dark cinema aesthetics.
 */
export const MovieCardSkeleton: React.FC<MovieCardSkeletonProps> = memo(({
  aspectRatio = 'portrait',
  className = '',
}) => {
  const isLandscape = aspectRatio === 'landscape';

  return (
    <div
      className={`relative w-full overflow-hidden rounded-lg bg-[#141414] border border-white/[0.05] select-none ${className}`}
      aria-hidden="true"
    >
      <div className={`relative ${isLandscape ? 'aspect-video' : 'aspect-[2/3]'} w-full bg-[#161616] overflow-hidden`}>
        {/* Shimmer sweep effect */}
        <div className="animate-skeleton-shimmer" />

        {/* Top Badges Placeholders */}
        <div className="absolute top-2 left-2 right-2 flex items-center justify-between pointer-events-none z-10">
          <div className="h-3.5 w-12 rounded bg-white/[0.08] backdrop-blur-sm" />
          <div className="h-3.5 w-8 rounded bg-white/[0.08] backdrop-blur-sm" />
        </div>

        {/* Bottom subtle gradient */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent pointer-events-none" />

        {/* Bottom Metadata Placeholders */}
        <div className="absolute bottom-0 left-0 right-0 p-2.5 z-10 space-y-1.5 pointer-events-none">
          {/* Title Placeholder */}
          <div className="h-3.5 w-4/5 rounded bg-white/[0.12]" />
          {/* Year & Type Placeholder */}
          <div className="flex items-center gap-2">
            <div className="h-2.5 w-8 rounded bg-white/[0.06]" />
            <div className="h-2.5 w-10 rounded bg-white/[0.06]" />
          </div>
        </div>
      </div>
    </div>
  );
});

export interface MovieRowSkeletonProps {
  title?: string;
  showTitle?: boolean;
  count?: number;
  aspectRatio?: 'portrait' | 'landscape';
  className?: string;
}

/**
 * Skeleton Placeholder for horizontal MovieRow
 * Mirrors scrollable card row with responsive card widths.
 */
export const MovieRowSkeleton: React.FC<MovieRowSkeletonProps> = memo(({
  title,
  showTitle = true,
  count = 7,
  aspectRatio = 'portrait',
  className = '',
}) => {
  const isLandscape = aspectRatio === 'landscape';
  const dummyItems = Array.from({ length: count });

  return (
    <div className={`relative mb-6 md:mb-10 select-none ${className}`} aria-hidden="true">
      {/* Row Header */}
      {showTitle && (
        <div className="flex items-center justify-between mb-3 px-1">
          {title ? (
            <h2 className="text-base md:text-xl font-bold text-neutral-400 tracking-tight flex items-center gap-2">
              <span>{title}</span>
              <span className="w-1.5 h-1.5 rounded-full bg-red-500/60 animate-ping" />
            </h2>
          ) : (
            <div className="h-5 w-40 md:w-56 rounded bg-white/[0.10] animate-pulse" />
          )}
          <div className="h-4 w-16 rounded bg-white/[0.05] animate-pulse" />
        </div>
      )}

      {/* Row Container */}
      <div className="relative group/row">
        <div className="flex overflow-x-hidden space-x-2.5 md:space-x-3.5 py-1 px-1">
          {dummyItems.map((_, idx) => (
            <div
              key={idx}
              className={`shrink-0 ${
                isLandscape
                  ? 'w-[220px] sm:w-[260px] md:w-[300px]'
                  : 'w-[130px] sm:w-[155px] md:w-[185px] lg:w-[200px]'
              }`}
            >
              <MovieCardSkeleton aspectRatio={aspectRatio} />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
});

export interface MovieGridSkeletonProps {
  count?: number;
  aspectRatio?: 'portrait' | 'landscape';
  cols?: string;
  className?: string;
}

/**
 * Responsive Grid Skeleton for Browse views (Movies, TV, Anime), Explore Categories, Search results
 */
export const MovieGridSkeleton: React.FC<MovieGridSkeletonProps> = memo(({
  count = 12,
  aspectRatio = 'portrait',
  cols = 'grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3 md:gap-4',
  className = '',
}) => {
  const dummyItems = Array.from({ length: count });

  return (
    <div className={`${cols} ${className}`} aria-hidden="true">
      {dummyItems.map((_, idx) => (
        <MovieCardSkeleton key={idx} aspectRatio={aspectRatio} />
      ))}
    </div>
  );
});

/**
 * Hero Banner Cinematic Skeleton for initial App load
 */
export const HeroSkeleton: React.FC = memo(() => {
  return (
    <div
      className="relative w-full h-[55vh] sm:h-[65vh] md:h-[75vh] max-h-[750px] bg-[#101010] overflow-hidden select-none"
      aria-hidden="true"
    >
      {/* Background Shimmer */}
      <div className="animate-skeleton-shimmer" />

      {/* Gradient Overlays */}
      <div className="absolute inset-0 bg-gradient-to-t from-[#0a0a0a] via-[#0a0a0a]/50 to-transparent" />
      <div className="absolute inset-0 bg-gradient-to-r from-[#0a0a0a]/90 via-[#0a0a0a]/30 to-transparent" />

      {/* Hero Content Placeholders */}
      <div className="absolute bottom-12 md:bottom-20 left-4 md:left-12 max-w-xl z-20 space-y-4">
        {/* Category / Trending pill placeholder */}
        <div className="h-4 w-28 rounded bg-white/[0.12] animate-pulse" />

        {/* Large Movie Title placeholder */}
        <div className="h-10 sm:h-12 md:h-16 w-3/4 max-w-md rounded-lg bg-white/[0.15] animate-pulse" />

        {/* Description line placeholders */}
        <div className="space-y-2 pt-2">
          <div className="h-3.5 w-full max-w-lg rounded bg-white/[0.08]" />
          <div className="h-3.5 w-4/5 max-w-md rounded bg-white/[0.08]" />
          <div className="h-3.5 w-2/3 max-w-sm rounded bg-white/[0.08]" />
        </div>

        {/* Action Button Placeholders */}
        <div className="flex items-center gap-3 pt-3">
          <div className="h-10 sm:h-11 w-28 sm:w-32 rounded-lg bg-white/[0.22] animate-pulse" />
          <div className="h-10 sm:h-11 w-32 sm:w-36 rounded-lg bg-white/[0.10] animate-pulse" />
        </div>
      </div>
    </div>
  );
});

/**
 * Details Modal Skeleton for Movie/Series modal backdrop and metadata
 */
export const DetailsModalSkeleton: React.FC = memo(() => {
  return (
    <div className="w-full select-none" aria-hidden="true">
      {/* Hero aspect ratio placeholder */}
      <div className="relative aspect-video w-full bg-[#141414] overflow-hidden">
        <div className="animate-skeleton-shimmer" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#0f0f0f] via-[#0f0f0f]/40 to-transparent" />
        <div className="absolute bottom-6 left-6 right-6 space-y-3">
          <div className="h-8 md:h-12 w-1/2 rounded bg-white/[0.15] animate-pulse" />
          <div className="flex items-center gap-3">
            <div className="h-9 w-28 rounded-lg bg-white/[0.25]" />
            <div className="h-9 w-9 rounded-full bg-white/[0.12]" />
          </div>
        </div>
      </div>

      {/* Details body */}
      <div className="p-6 md:p-8 space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="md:col-span-2 space-y-3">
            <div className="h-3.5 w-full rounded bg-white/[0.08]" />
            <div className="h-3.5 w-11/12 rounded bg-white/[0.08]" />
            <div className="h-3.5 w-3/4 rounded bg-white/[0.08]" />
          </div>
          <div className="space-y-2">
            <div className="h-3 w-1/2 rounded bg-white/[0.06]" />
            <div className="h-3 w-3/4 rounded bg-white/[0.06]" />
            <div className="h-3 w-2/3 rounded bg-white/[0.06]" />
          </div>
        </div>

        {/* Recommendations skeleton grid */}
        <div className="pt-4 border-t border-white/[0.06] space-y-3">
          <div className="h-4 w-32 rounded bg-white/[0.10]" />
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2.5">
            {Array.from({ length: 4 }).map((_, idx) => (
              <div key={idx} className="bg-[#161616] rounded-lg overflow-hidden border border-white/[0.04]">
                <div className="relative aspect-[16/10] bg-[#141414] overflow-hidden">
                  <div className="animate-skeleton-shimmer" />
                </div>
                <div className="p-2 space-y-1">
                  <div className="h-3 w-3/4 rounded bg-white/[0.10]" />
                  <div className="h-2 w-1/3 rounded bg-white/[0.06]" />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
});
