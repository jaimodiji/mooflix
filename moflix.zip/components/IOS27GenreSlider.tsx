import React, { useRef, useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight, Sparkles } from 'lucide-react';

export interface GenreItem {
  id: string | number;
  name: string;
  icon?: string;
}

export const MOVIE_GENRES: GenreItem[] = [
  { id: 'all', name: 'All Movies', icon: '🍿' },
  { id: 28, name: 'Action', icon: '💥' },
  { id: 35, name: 'Comedy', icon: '😂' },
  { id: 18, name: 'Drama', icon: '🎭' },
  { id: 878, name: 'Sci-Fi', icon: '🚀' },
  { id: 27, name: 'Horror', icon: '👻' },
  { id: 53, name: 'Thriller', icon: '🔪' },
  { id: 10749, name: 'Romance', icon: '❤️' },
  { id: 16, name: 'Animation', icon: '🎨' },
  { id: 80, name: 'Crime', icon: '🕵️' },
  { id: 14, name: 'Fantasy', icon: '🧙' },
  { id: 12, name: 'Adventure', icon: '🗺️' },
  { id: 9648, name: 'Mystery', icon: '🔍' },
  { id: 'lang_hi', name: 'Bollywood', icon: '🇮🇳' },
  { id: 'lang_ta_te', name: 'South Cinema', icon: '🌟' },
  { id: 'lang_ko', name: 'K-Drama', icon: '🇰🇷' },
  { id: 10751, name: 'Family', icon: '👨‍👩‍👧' },
  { id: 10752, name: 'War', icon: '🎖️' },
  { id: 36, name: 'History', icon: '📜' },
];

export const SERIES_GENRES: GenreItem[] = [
  { id: 'all', name: 'All TV Series', icon: '📺' },
  { id: 18, name: 'Drama', icon: '🎭' },
  { id: 80, name: 'Crime', icon: '🕵️' },
  { id: 10765, name: 'Sci-Fi & Fantasy', icon: '🛸' },
  { id: 10759, name: 'Action & Adventure', icon: '⚡' },
  { id: 35, name: 'Comedy', icon: '😂' },
  { id: 9648, name: 'Mystery', icon: '🔍' },
  { id: 16, name: 'Animation', icon: '🎨' },
  { id: 'lang_ko', name: 'K-Drama & Asian', icon: '🇰🇷' },
  { id: 'lang_hi', name: 'Hindi Web Series', icon: '🇮🇳' },
  { id: 99, name: 'Documentary', icon: '📽️' },
  { id: 10768, name: 'War & Politics', icon: '🏛️' },
  { id: 37, name: 'Western', icon: '🤠' },
];

export const ANIME_GENRES: GenreItem[] = [
  { id: 'all', name: 'All Anime', icon: '⚡' },
  { id: 28, name: 'Shonen & Action', icon: '🔥' },
  { id: 10759, name: 'Action & Adventure', icon: '⚔️' },
  { id: 10765, name: 'Fantasy & Isekai', icon: '✨' },
  { id: 878, name: 'Sci-Fi & Mecha', icon: '🤖' },
  { id: 35, name: 'Comedy', icon: '🤣' },
  { id: 18, name: 'Drama', icon: '🎭' },
  { id: 10749, name: 'Romance & Shoujo', icon: '🌸' },
  { id: 14, name: 'Supernatural', icon: '🔮' },
  { id: 9648, name: 'Psychological Mystery', icon: '🧠' },
  { id: 16, name: 'Classic Cartoons', icon: '🐣' },
  { id: 'lang_ja', name: 'Japanese Originals', icon: '🇯🇵' },
];

interface IOS27GenreSliderProps {
  type: 'movie' | 'series' | 'anime';
  selectedGenreId: string | number;
  onSelectGenre: (genre: GenreItem) => void;
  className?: string;
}

export const IOS27GenreSlider: React.FC<IOS27GenreSliderProps> = ({
  type,
  selectedGenreId,
  onSelectGenre,
  className = '',
}) => {
  const sliderRef = useRef<HTMLDivElement>(null);
  const [canScrollLeft, setCanScrollLeft] = useState(false);
  const [canScrollRight, setCanScrollRight] = useState(true);

  const genres = type === 'movie' 
    ? MOVIE_GENRES 
    : type === 'series' 
      ? SERIES_GENRES 
      : ANIME_GENRES;

  const checkScroll = () => {
    if (!sliderRef.current) return;
    const { scrollLeft, scrollWidth, clientWidth } = sliderRef.current;
    setCanScrollLeft(scrollLeft > 10);
    setCanScrollRight(scrollLeft < scrollWidth - clientWidth - 10);
  };

  useEffect(() => {
    checkScroll();
    window.addEventListener('resize', checkScroll);
    return () => window.removeEventListener('resize', checkScroll);
  }, [genres]);

  const scroll = (direction: 'left' | 'right') => {
    if (!sliderRef.current) return;
    const scrollAmount = direction === 'left' ? -280 : 280;
    sliderRef.current.scrollBy({ left: scrollAmount, behavior: 'smooth' });
    setTimeout(checkScroll, 300);
  };

  return (
    <div className={`relative w-full my-4 sm:my-5 select-none ${className}`}>
      {/* iOS 27 Liquid Dynamic Island Frame */}
      <div className="relative rounded-2xl bg-[#0d0d14]/80 border border-white/10 p-1.5 sm:p-2 backdrop-blur-2xl shadow-[0_8px_32px_rgba(0,0,0,0.5),inset_0_1px_1px_rgba(255,255,255,0.08)] flex items-center">
        
        {/* Left Scroll Trigger Button */}
        {canScrollLeft && (
          <button
            type="button"
            onClick={() => scroll('left')}
            aria-label="Scroll Left"
            className="hidden sm:flex absolute left-2 z-20 w-7 h-7 rounded-full bg-black/70 hover:bg-black/90 text-white items-center justify-center border border-white/15 backdrop-blur-md shadow-lg transition-all active:scale-90 cursor-pointer"
          >
            <ChevronLeft size={16} />
          </button>
        )}

        {/* Horizontal Track */}
        <div
          ref={sliderRef}
          onScroll={checkScroll}
          className="flex items-center gap-1.5 sm:gap-2 overflow-x-auto no-scrollbar scroll-smooth px-1 py-0.5 w-full"
        >
          {genres.map((genre) => {
            const isActive = String(selectedGenreId) === String(genre.id);
            return (
              <button
                key={String(genre.id)}
                type="button"
                onClick={() => onSelectGenre(genre)}
                className={`flex items-center gap-1.5 px-3 sm:px-3.5 py-1.5 rounded-xl text-xs whitespace-nowrap transition-all duration-200 cursor-pointer active:scale-95 shrink-0 select-none ${
                  isActive
                    ? 'bg-gradient-to-r from-red-600 via-rose-600 to-red-600 text-white font-bold shadow-[0_0_15px_rgba(229,9,20,0.5)] border border-red-400/80 scale-[1.02]'
                    : 'bg-white/[0.04] hover:bg-white/[0.09] text-neutral-300 hover:text-white border border-white/10 hover:border-white/20 font-medium'
                }`}
              >
                {genre.icon && <span className="text-xs sm:text-sm">{genre.icon}</span>}
                <span>{genre.name}</span>
              </button>
            );
          })}
        </div>

        {/* Right Scroll Trigger Button */}
        {canScrollRight && (
          <button
            type="button"
            onClick={() => scroll('right')}
            aria-label="Scroll Right"
            className="hidden sm:flex absolute right-2 z-20 w-7 h-7 rounded-full bg-black/70 hover:bg-black/90 text-white items-center justify-center border border-white/15 backdrop-blur-md shadow-lg transition-all active:scale-90 cursor-pointer"
          >
            <ChevronRight size={16} />
          </button>
        )}
      </div>
    </div>
  );
};

export default IOS27GenreSlider;
