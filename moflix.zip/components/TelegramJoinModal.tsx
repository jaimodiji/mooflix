import React, { useState, useEffect } from 'react';
import { Send, X, Sparkles, Film, CheckCircle2 } from 'lucide-react';

const STORAGE_KEY = 'mooflix_telegram_modal_dismissed_time';
const SESSION_KEY = 'mooflix_telegram_modal_session_shown';
const ONE_HOUR_MS = 60 * 60 * 1000;
const TELEGRAM_URL = 'https://t.me/+ziNHhQUYib5mNjk1';

export const TelegramJoinModal: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);

  useEffect(() => {
    try {
      // Check if already shown in this tab session
      const inSession = sessionStorage.getItem(SESSION_KEY);
      if (inSession) return;

      const lastDismissed = localStorage.getItem(STORAGE_KEY);
      if (lastDismissed) {
        const timeElapsed = Date.now() - parseInt(lastDismissed, 10);
        if (timeElapsed < ONE_HOUR_MS) {
          return;
        }
      }

      // Display popup after 2.5 seconds on site
      const timer = setTimeout(() => {
        setIsOpen(true);
        try {
          sessionStorage.setItem(SESSION_KEY, 'true');
        } catch {}
      }, 2500);

      return () => clearTimeout(timer);
    } catch {
      // Safe fallback
    }
  }, []);

  const handleDismiss = () => {
    try {
      localStorage.setItem(STORAGE_KEY, Date.now().toString());
      sessionStorage.setItem(SESSION_KEY, 'true');
    } catch {}
    setIsOpen(false);
  };

  const handleJoin = () => {
    try {
      localStorage.setItem(STORAGE_KEY, Date.now().toString());
      sessionStorage.setItem(SESSION_KEY, 'true');
    } catch {}
    window.open(TELEGRAM_URL, '_blank', 'noopener,noreferrer');
    setIsOpen(false);
  };

  if (!isOpen) return null;

  return (
    <div 
      className="fixed inset-0 z-[800] bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 select-none animate-in fade-in duration-200"
      onClick={handleDismiss}
    >
      <div 
        className="relative w-full max-w-sm sm:max-w-md rounded-3xl bg-[#0c0d14] border border-[#0088cc]/40 p-5 sm:p-7 shadow-[0_25px_80px_rgba(0,0,0,0.95),0_0_50px_rgba(0,136,204,0.3)] text-center overflow-hidden animate-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Ambient Glows */}
        <div className="absolute -top-24 -left-24 w-48 h-48 bg-[#0088cc]/30 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 -right-24 w-48 h-48 bg-red-600/20 rounded-full blur-3xl pointer-events-none" />

        {/* Close Button */}
        <button
          type="button"
          onClick={handleDismiss}
          aria-label="Close"
          className="absolute top-4 right-4 w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 text-neutral-400 hover:text-white flex items-center justify-center transition-colors cursor-pointer"
        >
          <X size={16} />
        </button>

        {/* Telegram Icon Badge */}
        <div className="mx-auto w-16 h-16 rounded-2xl bg-gradient-to-tr from-[#0088cc] via-[#00a8e8] to-[#29b6f6] flex items-center justify-center text-white shadow-xl shadow-[#0088cc]/40 mb-4 border border-white/20">
          <Send size={28} className="-rotate-12 translate-y-[-1px] translate-x-[-1px]" />
        </div>

        {/* Badge */}
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#0088cc]/20 border border-[#0088cc]/40 text-[#29b6f6] text-[11px] font-black uppercase tracking-wider mb-2">
          <Sparkles size={12} />
          <span>Official Community</span>
        </div>

        {/* Title */}
        <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight leading-tight mb-2">
          Join MooFlix on Telegram
        </h2>

        {/* Description */}
        <p className="text-xs sm:text-sm text-neutral-300 leading-relaxed mb-5">
          Get daily alerts for new 4K movie releases, OTT series, Hindi dubbed cinema, and direct request support!
        </p>

        {/* Feature Highlights */}
        <div className="bg-white/[0.03] border border-white/10 rounded-2xl p-3.5 mb-5 text-left space-y-2">
          <div className="flex items-center gap-2 text-xs text-neutral-200">
            <CheckCircle2 size={14} className="text-[#00a8e8] shrink-0" />
            <span>Instant daily release notifications</span>
          </div>
          <div className="flex items-center gap-2 text-xs text-neutral-200">
            <CheckCircle2 size={14} className="text-[#00a8e8] shrink-0" />
            <span>Direct movie & series requests</span>
          </div>
          <div className="flex items-center gap-2 text-xs text-neutral-200">
            <CheckCircle2 size={14} className="text-[#00a8e8] shrink-0" />
            <span>100% Free VIP community access</span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="space-y-2.5">
          <button
            type="button"
            onClick={handleJoin}
            className="w-full py-3.5 px-6 rounded-2xl bg-gradient-to-r from-[#0088cc] to-[#00a8e8] hover:from-[#0077b5] hover:to-[#0096d1] active:scale-95 text-white font-extrabold text-sm sm:text-base transition-all shadow-xl shadow-[#0088cc]/40 flex items-center justify-center gap-2 cursor-pointer border border-white/20"
          >
            <Send size={17} className="-rotate-12" />
            <span>Join Telegram Channel</span>
          </button>

          <button
            type="button"
            onClick={handleDismiss}
            className="w-full py-2.5 px-4 rounded-xl text-neutral-400 hover:text-white text-xs font-semibold transition-colors cursor-pointer"
          >
            Maybe Later
          </button>
        </div>
      </div>
    </div>
  );
};

export default TelegramJoinModal;
