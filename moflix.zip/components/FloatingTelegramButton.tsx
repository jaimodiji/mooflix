import React from 'react';
import { Send } from 'lucide-react';

export const FloatingTelegramButton: React.FC = () => {
  return (
    <aside aria-label="Community Links">
      <a
        href="https://t.me/+ziNHhQUYib5mNjk1"
        target="_blank"
        rel="noopener noreferrer"
        className="fixed bottom-20 right-4 lg:bottom-6 lg:right-6 z-[120] flex items-center gap-2 p-3.5 sm:p-4 rounded-full bg-gradient-to-r from-[#0088cc] to-[#00a8e8] text-white shadow-[0_10px_30px_rgba(0,136,204,0.5)] border border-white/25 active:scale-90 hover:scale-105 transition-all duration-300 group cursor-pointer backdrop-blur-md"
        aria-label="Join Official Telegram Channel"
        title="Join MooFlix on Telegram"
      >
        <Send size={20} className="-rotate-12 translate-y-[-1px] group-hover:translate-x-0.5 transition-transform" />
        <span className="hidden sm:inline font-black text-xs tracking-wide pr-1">Telegram</span>
      </a>
    </aside>
  );
};

export default FloatingTelegramButton;
