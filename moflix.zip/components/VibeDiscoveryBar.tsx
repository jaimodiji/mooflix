import React, { useState } from 'react';
import { Sparkles, Star, Compass, Zap, Flame, Heart, Smile, Moon, Skull, Popcorn, Check } from 'lucide-react';

export interface VibeOption {
  id: string;
  label: string;
  emoji: string;
  genres: (number | string)[];
  description: string;
  minRating?: number;
}

export const VIBE_PRESETS: VibeOption[] = [
  {
    id: 'mind_blowing',
    label: 'Mind-Blowing Thriller',
    emoji: '🤯',
    genres: [878, 53, 9648], // Sci-Fi, Thriller, Mystery
    description: 'Plot twists, suspense & edge-of-the-seat adrenaline',
    minRating: 7.0,
  },
  {
    id: 'feel_good',
    label: 'Feel Good & Chill',
    emoji: '🍿',
    genres: [35, 10751, 16], // Comedy, Family, Animation
    description: 'Heartwarming laughs, comforting vibes & easy watching',
    minRating: 6.5,
  },
  {
    id: 'desi_masala',
    label: 'Desi Masala & Blockbuster',
    emoji: '🔥',
    genres: ['lang_hi', 28, 10749], // Hindi / Bollywood, Action, Romance
    description: 'High octane drama, dialogues, romance & mass moments',
    minRating: 6.0,
  },
  {
    id: 'romantic',
    label: 'Late Night Romance',
    emoji: '💖',
    genres: [10749, 18], // Romance, Drama
    description: 'Passionate chemistry, deep emotions & heartfelt stories',
    minRating: 6.8,
  },
  {
    id: 'spooky',
    label: 'Dark & Spine-Chilling',
    emoji: '👻',
    genres: [27, 9648, 53], // Horror, Mystery, Thriller
    description: 'Paranormal fear, psychological terrors & dark suspense',
    minRating: 6.0,
  },
  {
    id: 'action_packed',
    label: 'Pure Action & Carnage',
    emoji: '💥',
    genres: [28, 12, 80], // Action, Adventure, Crime
    description: 'Fast chases, martial arts, gunfights & epic stunts',
    minRating: 6.5,
  },
  {
    id: 'masterpiece',
    label: 'Critically Acclaimed (8.0+)',
    emoji: '🏆',
    genres: [18, 36, 10752], // Drama, History, War
    description: 'Award-winning cinema with unforgettable storytelling',
    minRating: 8.0,
  },
];

export interface VibeFilterState {
  selectedVibe: string | null;
  minScore: number; // 0 = Any, 6.0, 7.0, 7.5, 8.0, 8.5
  activeMedia: 'all' | 'movie' | 'tv';
}

interface VibeDiscoveryBarProps {
  currentVibe: string | null;
  currentMinScore: number;
  onSelectVibe: (vibeId: string | null, genres: (number | string)[], minRating?: number) => void;
  onSelectMinScore: (score: number) => void;
  totalFilteredCount?: number;
}

export const VibeDiscoveryBar: React.FC<VibeDiscoveryBarProps> = ({
  currentVibe,
  currentMinScore,
  onSelectVibe,
  onSelectMinScore,
  totalFilteredCount,
}) => {
  const [isExpanded, setIsExpanded] = useState(false);

  const scoreOptions = [
    { label: 'All Scores', value: 0 },
    { label: '★ 6.0+ Good', value: 6.0 },
    { label: '★ 7.0+ Popular', value: 7.0 },
    { label: '★ 7.5+ Great', value: 7.5 },
    { label: '★ 8.0+ Top Rated', value: 8.0 },
    { label: '★ 8.5+ Masterpiece', value: 8.5 },
  ];

  return (
    <div className="w-full bg-gradient-to-r from-red-950/40 via-[#111116] to-purple-950/30 border border-white/10 rounded-2xl p-3 sm:p-4 mb-6 shadow-xl backdrop-blur-md">
      {/* Top Header Row with Vibe & Score Buttons */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-red-600 to-amber-500 flex items-center justify-center text-white shadow-md shadow-red-900/40">
            <Sparkles size={16} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-sm font-extrabold text-white tracking-tight flex items-center gap-1.5">
                <span>What's Your Vibe?</span>
                <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-red-600/30 text-red-300 border border-red-500/30">
                  NEW
                </span>
              </h3>
            </div>
            <p className="text-[11px] text-neutral-400">
              Pick your current mood or filter by IMDb/User score
            </p>
          </div>
        </div>

        {/* User Score Filter Dropdown */}
        <div className="flex items-center gap-2">
          <span className="text-xs text-neutral-400 flex items-center gap-1 font-medium">
            <Star size={13} className="text-amber-400 fill-amber-400" />
            <span className="hidden sm:inline">User Score:</span>
          </span>
          <div className="relative">
            <select
              value={currentMinScore}
              onChange={(e) => onSelectMinScore(Number(e.target.value))}
              aria-label="Filter by User Score"
              className="bg-[#18181f] hover:bg-[#22222c] border border-amber-500/30 hover:border-amber-400/60 text-amber-300 text-xs font-bold px-3 py-1.5 rounded-xl cursor-pointer focus:outline-none transition-all shadow-sm"
            >
              {scoreOptions.map((opt) => (
                <option key={opt.value} value={opt.value} className="bg-[#121216] text-white">
                  {opt.label}
                </option>
              ))}
            </select>
          </div>

          {(currentVibe || currentMinScore > 0) && (
            <button
              type="button"
              onClick={() => {
                onSelectVibe(null, []);
                onSelectMinScore(0);
              }}
              className="text-[11px] font-semibold text-neutral-400 hover:text-white px-2 py-1 rounded bg-white/5 hover:bg-white/10 transition-colors cursor-pointer"
            >
              Reset
            </button>
          )}
        </div>
      </div>

      {/* Vibe Selection Pills */}
      <div className="mt-3.5 pt-3 border-t border-white/5">
        <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar">
          <button
            type="button"
            onClick={() => onSelectVibe(null, [])}
            className={`px-3 py-1.5 rounded-full text-xs font-bold transition-all shrink-0 cursor-pointer flex items-center gap-1.5 ${
              !currentVibe
                ? 'bg-white text-black shadow-lg shadow-white/10'
                : 'bg-white/[0.05] hover:bg-white/[0.1] text-neutral-300 border border-white/10'
            }`}
          >
            <span>All Vibes</span>
          </button>

          {VIBE_PRESETS.map((vibe) => {
            const isSelected = currentVibe === vibe.id;
            return (
              <button
                key={vibe.id}
                type="button"
                onClick={() => {
                  if (isSelected) {
                    onSelectVibe(null, []);
                  } else {
                    onSelectVibe(vibe.id, vibe.genres, vibe.minRating);
                  }
                }}
                className={`px-3.5 py-1.5 rounded-full text-xs font-bold transition-all shrink-0 cursor-pointer flex items-center gap-1.5 border select-none active:scale-95 ${
                  isSelected
                    ? 'bg-gradient-to-r from-red-600 to-rose-600 border-red-400 text-white shadow-lg shadow-red-900/50'
                    : 'bg-white/[0.06] hover:bg-white/[0.12] border-white/10 text-neutral-300 hover:text-white'
                }`}
                title={vibe.description}
              >
                <span>{vibe.emoji}</span>
                <span>{vibe.label}</span>
                {isSelected && <Check size={12} className="stroke-[3]" />}
              </button>
            );
          })}
        </div>

        {/* Active Vibe Description Preview */}
        {currentVibe && (
          <div className="mt-2.5 flex items-center justify-between text-[11px] text-neutral-400 px-1">
            <span>
              Showing: <strong className="text-white">{VIBE_PRESETS.find(v => v.id === currentVibe)?.description}</strong>
            </span>
            {typeof totalFilteredCount === 'number' && (
              <span className="font-mono text-red-400 font-semibold">{totalFilteredCount} matching titles</span>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default VibeDiscoveryBar;
