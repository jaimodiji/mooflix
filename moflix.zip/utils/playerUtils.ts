import { PlayConfig, ServerProvider } from '../types';

export type CustomPlayerServerId = '1' | '2' | '3' | '4' | 'modiji' | 'rahulji' | 'cjp' | 'aap';

export interface CustomPlayerServerConfig {
  id: '1' | '2' | '3' | '4';
  name: string;
  tag: string;
  desc: string;
}

export const CUSTOM_PLAYER_SERVERS: CustomPlayerServerConfig[] = [
  {
    id: '1',
    name: 'Server 1',
    tag: 'Server 1',
    desc: 'Fast HD Stream • Zero Ads',
  },
  {
    id: '2',
    name: 'Server 2',
    tag: 'Server 2',
    desc: 'Multi-Audio HD • Zero Ads',
  },
  {
    id: '3',
    name: 'Server 3',
    tag: 'Server 3',
    desc: 'Backup HD Stream • Zero Ads',
  },
  {
    id: '4',
    name: 'Server 4',
    tag: 'Server 4',
    desc: 'Ultra HD Mirror • Zero Ads',
  },
];

export const normalizeServerNo = (provider?: ServerProvider | string | number): '1' | '2' | '3' | '4' => {
  const p = String(provider || '1').toLowerCase().trim();
  if (p === '2' || p === 's2' || p === 'server 2' || p === 'rahulji' || p === 'rahul ji' || p === 'playdrive' || p === 'play4u') return '2';
  if (p === '3' || p === 's3' || p === 'server 3' || p === 'cjp' || p === 'rozgarlelo' || p === 'modiplay') return '3';
  if (p === '4' || p === 's4' || p === 'server 4' || p === 'aap' || p === 'nxsha') return '4';
  return '1';
};

export const getServerDisplayName = (provider?: ServerProvider | string | number): string => {
  const num = normalizeServerNo(provider);
  return `Server ${num}`;
};

export const getServerSlug = (provider?: ServerProvider | string | number): string => {
  return normalizeServerNo(provider);
};

export const padEpisode = (n: number | string): string => String(Math.max(1, Number(n) || 1)).padStart(2, '0');

/**
 * Universal Ad-Free Cinema Player URLs:
 *
 * Server 1 (Clean Proxied Fast Stream + Not-Found Auto-Failover Detection):
 *   Movie:  /api/player/proxy?server=1&type=movie&tmdbId=${tmdb}
 *   TV:     /api/player/proxy?server=1&type=tv&tmdbId=${tmdb}&season=${season}&episode=${episode}
 *
 * Server 2 (Play4U Direct IMDb Stream - Zero Ads):
 *   Movie:  https://play4u.org/${imdb}
 *   TV:     https://play4u.org/series/${imdb}/s-${pad(season)}/ep-${pad(episode)}
 *
 * Server 3 (ModiPlay Backup Stream):
 *   Movie:  https://rozgarlelo.modiplay.xyz/embed/tmdb/movie?id=${tmdb}
 *   TV:     https://rozgarlelo.modiplay.xyz/embed/tmdb/tv?id=${tmdb}&s=${season}&e=${episode}
 *
 * Server 4 (Nxsha Stream - Zero Ads):
 *   Movie:  https://nxsha.space/embed/movie/${tmdb}?disable_ad=true&disable_ads=true&ads=0&no_ads=1
 *   TV:     https://nxsha.space/embed/tv/${tmdb}/${season}/${episode}?disable_ad=true&disable_ads=true&ads=0&no_ads=1
 */
export const getEmbedUrl = (
  provider: ServerProvider | string | number = '1',
  item?: PlayConfig['item'] | null,
  season = 1,
  episode = 1,
  imdbId?: string | null
): string => {
  if (!item) return '';

  const serverNo = normalizeServerNo(provider);
  const isTv = item.type === 'tv' || item.type === 'series';

  const rawTmdb =
    (item as any).tmdbId ||
    (typeof item.id === 'number'
      ? String(item.id)
      : typeof item.id === 'string' && !item.id.startsWith('tt')
        ? item.id
        : '');
  const tmdb = String(rawTmdb || '').trim();

  const rawImdb =
    imdbId ||
    (item as any).imdbId ||
    (typeof item.id === 'string' && item.id.startsWith('tt') ? item.id : '');
  const imdb = rawImdb && String(rawImdb).startsWith('tt') ? String(rawImdb).trim() : '';

  const safeSeason = Math.max(1, Number(season) || 1);
  const safeEpisode = Math.max(1, Number(episode) || 1);

  if (isTv) {
    switch (serverNo) {
      case '1':
        if (!tmdb) return '';
        return `/api/player/proxy?server=1&type=tv&tmdbId=${encodeURIComponent(tmdb)}&season=${safeSeason}&episode=${safeEpisode}`;
      case '2':
        if (!imdb) return '';
        return `https://play4u.org/series/${encodeURIComponent(imdb)}/s-${padEpisode(safeSeason)}/ep-${padEpisode(safeEpisode)}`;
      case '3':
        if (!tmdb) return '';
        return `https://rozgarlelo.modiplay.xyz/embed/tmdb/tv?id=${encodeURIComponent(tmdb)}&s=${safeSeason}&e=${safeEpisode}`;
      case '4':
        if (!tmdb) return '';
        return `https://nxsha.space/embed/tv/${encodeURIComponent(tmdb)}/${safeSeason}/${safeEpisode}?disable_ad=true&disable_ads=true&ads=0&no_ads=1`;
      default:
        if (!tmdb) return '';
        return `/api/player/proxy?server=1&type=tv&tmdbId=${encodeURIComponent(tmdb)}&season=${safeSeason}&episode=${safeEpisode}`;
    }
  } else {
    switch (serverNo) {
      case '1':
        if (!tmdb) return '';
        return `/api/player/proxy?server=1&type=movie&tmdbId=${encodeURIComponent(tmdb)}`;
      case '2':
        if (!imdb) return '';
        return `https://play4u.org/${encodeURIComponent(imdb)}`;
      case '3':
        if (!tmdb) return '';
        return `https://rozgarlelo.modiplay.xyz/embed/tmdb/movie?id=${encodeURIComponent(tmdb)}`;
      case '4':
        if (!tmdb) return '';
        return `https://nxsha.space/embed/movie/${encodeURIComponent(tmdb)}?disable_ad=true&disable_ads=true&ads=0&no_ads=1`;
      default:
        if (!tmdb) return '';
        return `/api/player/proxy?server=1&type=movie&tmdbId=${encodeURIComponent(tmdb)}`;
    }
  }
};

export const getDownloadUrl = (
  item: { id: number | string; type: string; tmdbId?: number | string | null },
  _server: 1 | 2 = 1,
  season = 1,
  episode = 1,
  _imdbId?: string | null
): string => {
  const isMovie = item.type === 'movie';
  const id = item.tmdbId || item.id;

  return isMovie
    ? `https://nxsha.space/dl/movie/${id}?color=%23ffffff&theme=white&disable_ad=true&ads=0`
    : `https://nxsha.space/dl/tv/${id}/${season}/${episode}?color=%23ffffff&theme=white&disable_ad=true&ads=0`;
};
