type LockAction = () => void;

/**
 * Stream Lock completely disabled per user request.
 * Directly executes the requested action without any locked popup modal.
 */
export const executeWithStreamLock = (action: LockAction): void => {
  if (typeof action === 'function') {
    action();
  }
};

export const setStreamUnlockedGracePeriod = (_durationMs = 0): void => {};
export const isStreamPlayerUnlocked = (): boolean => true;
export const openStreamLockModal = (onUnlock?: () => void): void => {
  if (onUnlock) onUnlock();
};
export const unlockStreamPlayerSession = (_durationMinutes = 0): void => {};
