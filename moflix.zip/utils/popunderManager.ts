/**
 * MooFlix Ad-Free Popunder Stub
 * All popunders, redirects, and third-party ad triggers are permanently disabled.
 */
export class PopunderManager {
  public static canTrigger(): boolean {
    return false;
  }

  public static trigger(): boolean {
    return false;
  }

  public static initGlobalListener(_getIsAdsFree?: () => boolean, _getIsPlayerActive?: () => boolean) {
    // No-op: 100% ad-free experience
  }
}
