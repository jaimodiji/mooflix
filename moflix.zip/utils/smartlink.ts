/**
 * MooFlix Ad-Free Mode
 * All external smartlinks and redirect monetization have been permanently removed.
 */
export const SMARTLINK_URL = '';

export const triggerSmartlink = (): void => {
  // No-op: site is 100% ad-free
};
