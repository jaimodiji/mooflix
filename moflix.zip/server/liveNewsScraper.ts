import * as cheerio from 'cheerio';
import crypto from 'node:crypto';
import { type NewsItem, SEED_NEWS_ITEMS } from '../services/newsService.ts';

// In-memory cache for live scraped news
let cachedLiveNews: NewsItem[] = [];
let lastFetchTime = 0;
const CACHE_TTL_MS = 15 * 60 * 1000; // 15 minutes TTL

// High quality thematic backdrop images for auto-categorization
const CATEGORY_IMAGES: Record<string, string[]> = {
  tollywood: [
    'https://images.unsplash.com/photo-1536440136628-849c177e76a1?w=900&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1517604931442-7e0c8ed2963c?w=900&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?w=900&auto=format&fit=crop&q=80',
  ],
  bollywood: [
    'https://images.unsplash.com/photo-1594909122845-11baa439b7bf?w=900&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1578328819058-b69f3a3b0f6b?w=900&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1485846234645-a62644f84728?w=900&auto=format&fit=crop&q=80',
  ],
  hollywood: [
    'https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?w=900&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1478760329108-5c3ed9d495a0?w=900&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1635805737707-575885ab0820?w=900&auto=format&fit=crop&q=80',
  ],
  ott: [
    'https://images.unsplash.com/photo-1574375927938-d5a98e8ffe85?w=900&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1522869635100-9f4c5e86aa37?w=900&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1518133835878-5a93cc3f89e5?w=900&auto=format&fit=crop&q=80',
  ],
  cricket: [
    'https://images.unsplash.com/photo-1540747913346-19e32dc3e97e?w=900&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1531415074968-036ba1b575da?w=900&auto=format&fit=crop&q=80',
  ],
  football: [
    'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=900&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1574629810360-7efbbe195018?w=900&auto=format&fit=crop&q=80',
  ],
  f1: [
    'https://images.unsplash.com/photo-1568605117036-5fe5e7bab0b7?w=900&auto=format&fit=crop&q=80',
  ],
  combat: [
    'https://images.unsplash.com/photo-1517649763962-0c623266ddc0?w=900&auto=format&fit=crop&q=80',
  ]
};

function determineCategory(title: string, desc: string, isSports: boolean): {
  category: NewsItem['category'];
  categoryLabel: string;
} {
  const text = `${title} ${desc}`.toLowerCase();

  if (isSports) {
    if (text.includes('cricket') || text.includes('ipl') || text.includes('bcci') || text.includes('kohli') || text.includes('rohit') || text.includes('dhoni') || text.includes('odi') || text.includes('test match') || text.includes('t20')) {
      return { category: 'cricket', categoryLabel: 'Cricket' };
    }
    if (text.includes('football') || text.includes('soccer') || text.includes('champions league') || text.includes('premier league') || text.includes('messi') || text.includes('ronaldo') || text.includes('real madrid') || text.includes('barcelona') || text.includes('arsenal')) {
      return { category: 'football', categoryLabel: 'Football' };
    }
    if (text.includes('f1') || text.includes('formula 1') || text.includes('grand prix') || text.includes('verstappen') || text.includes('ferrari') || text.includes('racing')) {
      return { category: 'f1', categoryLabel: 'F1 & Racing' };
    }
    if (text.includes('wwe') || text.includes('ufc') || text.includes('mma') || text.includes('boxing') || text.includes('smackdown') || text.includes('raw')) {
      return { category: 'combat', categoryLabel: 'WWE & Combat' };
    }
    return { category: 'cricket', categoryLabel: 'Sports' };
  }

  // Entertainment categorization
  if (text.includes('tollywood') || text.includes('telugu') || text.includes('rajamouli') || text.includes('allu arjun') || text.includes('prabhas') || text.includes('mahesh babu') || text.includes('pushpa') || text.includes('salaar') || text.includes('devara') || text.includes('tamil') || text.includes('kollywood')) {
    return { category: 'tollywood', categoryLabel: 'Tollywood' };
  }
  if (text.includes('netflix') || text.includes('prime video') || text.includes('hotstar') || text.includes('series') || text.includes('season') || text.includes('episode') || text.includes('ott') || text.includes('stream')) {
    return { category: 'ott', categoryLabel: 'OTT & Web Series' };
  }
  if (text.includes('marvel') || text.includes('disney') || text.includes('hollywood') || text.includes('avengers') || text.includes('batman') || text.includes('spiderman') || text.includes('nolan') || text.includes('oscar') || text.includes('warner')) {
    return { category: 'hollywood', categoryLabel: 'Hollywood' };
  }

  return { category: 'bollywood', categoryLabel: 'Bollywood' };
}

function getRandomImage(category: string, index: number): string {
  const images = CATEGORY_IMAGES[category] || CATEGORY_IMAGES.bollywood;
  return images[index % images.length];
}

async function fetchRssFeed(url: string, section: 'entertainment' | 'sports'): Promise<NewsItem[]> {
  try {
    const res = await fetch(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'application/rss+xml, application/xml, text/xml, */*'
      }
    });

    if (!res.ok) return [];
    const xml = await res.text();
    const $ = cheerio.load(xml, { xmlMode: true });
    const items: NewsItem[] = [];

    $('item').each((idx, el) => {
      if (idx >= 15) return; // Keep top 15 from each feed

      const title = $(el).find('title').first().text().trim();
      const link = $(el).find('link').first().text().trim();
      const pubDateRaw = $(el).find('pubDate').first().text().trim();
      const rawDesc = $(el).find('description').first().text().trim();
      const source = $(el).find('source').first().text().trim() || 'News Wire';

      // Clean snippet from raw HTML description
      const $desc = cheerio.load(rawDesc || '');
      const cleanSnippet = $desc.text().replace(/\s+/g, ' ').trim() || title;

      if (!title) return;

      const { category, categoryLabel } = determineCategory(title, cleanSnippet, section === 'sports');
      const pubDate = pubDateRaw ? new Date(pubDateRaw).toISOString() : new Date().toISOString();
      const image = getRandomImage(category, idx);

      const hash = crypto.createHash('sha256').update(`${title}-${link || idx}-${pubDateRaw || idx}`).digest('hex').slice(0, 16);
      const id = `${section}-${category}-${hash}`;

      items.push({
        id,
        title,
        section,
        category,
        categoryLabel,
        source,
        pubDate,
        imageUrl: image,
        snippet: cleanSnippet.length > 220 ? `${cleanSnippet.slice(0, 217)}...` : cleanSnippet,
        fullContent: cleanSnippet,
        originalUrl: link || undefined,
        keywords: [categoryLabel, section === 'entertainment' ? 'Cinema' : 'Sports', source]
      });
    });

    return items;
  } catch (err) {
    console.warn(`Failed to fetch RSS from ${url}:`, err);
    return [];
  }
}

/**
 * Fetches fresh live news automatically from Google News RSS feeds
 * Merges with curated seeds, deduplicates, and sorts strictly Latest First
 */
export async function getLiveNewsArticles(forceRefresh = false): Promise<NewsItem[]> {
  const now = Date.now();
  if (!forceRefresh && cachedLiveNews.length > 0 && (now - lastFetchTime) < CACHE_TTL_MS) {
    return cachedLiveNews;
  }

  try {
    const [entLive, sportsLive] = await Promise.all([
      fetchRssFeed('https://news.google.com/rss/search?q=(Bollywood+OR+Tollywood+OR+Hollywood+OR+"web+series")+movies&hl=en-IN&gl=IN&ceid=IN:en', 'entertainment'),
      fetchRssFeed('https://news.google.com/rss/search?q=(cricket+OR+"India+vs"+OR+football+OR+IPL+OR+sports)&hl=en-IN&gl=IN&ceid=IN:en', 'sports')
    ]);

    const allCombined = [...entLive, ...sportsLive, ...SEED_NEWS_ITEMS];

    // Deduplicate by title similarity or ID
    const seenTitles = new Set<string>();
    const seenIds = new Set<string>();
    const uniqueItems: NewsItem[] = [];

    for (const item of allCombined) {
      const normalizedTitle = item.title.toLowerCase().replace(/[^a-z0-9]/g, '').slice(0, 45);
      if (!seenTitles.has(normalizedTitle) && !seenIds.has(item.id)) {
        seenTitles.add(normalizedTitle);
        seenIds.add(item.id);
        uniqueItems.push(item);
      }
    }

    // Sort strictly descending: Latest timestamp on top
    uniqueItems.sort((a, b) => new Date(b.pubDate).getTime() - new Date(a.pubDate).getTime());

    cachedLiveNews = uniqueItems;
    lastFetchTime = now;
    return uniqueItems;
  } catch (err) {
    console.warn('Error scraping live news, falling back to seed items:', err);
    return [...SEED_NEWS_ITEMS].sort((a, b) => new Date(b.pubDate).getTime() - new Date(a.pubDate).getTime());
  }
}
