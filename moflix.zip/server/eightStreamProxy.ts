import type { Express, Request, Response } from "express";
import https from "node:https";
import http from "node:http";

interface StreamSource {
  quality: string;
  url: string;
  language?: string;
  isM3u8?: boolean;
}

interface EightStreamResponse {
  success: boolean;
  title?: string;
  sources?: StreamSource[];
  m3u8Url?: string;
  defaultAudio?: string;
  audioTracks?: Array<{ id: string; label: string; language: string }>;
  error?: string;
}

// In-memory cache for resolved streams to save bandwidth and speed up requests
const streamCache = new Map<string, { data: EightStreamResponse; expires: number }>();

export function registerEightStreamProxy(app: Express) {
  // 1. Resolve 8StreamApi / m3u8 endpoint
  app.get("/api/stream/8stream/resolve", async (req: Request, res: Response) => {
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Methods", "GET, OPTIONS");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type");

    const id = (req.query.id as string) || "";
    const imdbId = (req.query.imdbId as string) || "";
    const type = (req.query.type as string) || "movie";
    const season = Number(req.query.season) || 1;
    const episode = Number(req.query.episode) || 1;

    const cacheKey = `${id}-${imdbId}-${type}-${season}-${episode}`;
    const cached = streamCache.get(cacheKey);
    if (cached && cached.expires > Date.now()) {
      return res.json(cached.data);
    }

    try {
      const targetImdb = imdbId.startsWith("tt") ? imdbId : null;
      const targetTmdb = id ? String(id) : null;

      // Attempt to resolve streams from public 8Stream instances & multi-audio providers
      const candidates = [
        `https://8stream-api.vercel.app/api/v1/${type === "movie" ? "mediaInfo" : "getSeasonList"}?id=${targetImdb || targetTmdb}`,
        `https://api.consumet.org/movies/flixhq/info?id=${targetImdb || targetTmdb}`,
      ];

      let resolvedM3u8: string | null = null;
      let audioTracks: Array<{ id: string; label: string; language: string }> = [
        { id: "hi", label: "Hindi (Dual Audio)", language: "Hindi" },
        { id: "en", label: "English (Original)", language: "English" },
      ];

      for (const candidate of candidates) {
        try {
          const controller = new AbortController();
          const timeoutId = setTimeout(() => controller.abort(), 3500);
          const response = await fetch(candidate, {
            headers: {
              "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
              "Accept": "application/json",
            },
            signal: controller.signal,
          });
          clearTimeout(timeoutId);

          if (response.ok) {
            const data: any = await response.json();
            if (data?.data?.link && data.data.link.includes(".m3u8")) {
              resolvedM3u8 = data.data.link;
              break;
            } else if (data?.sources?.[0]?.url && data.sources[0].url.includes(".m3u8")) {
              resolvedM3u8 = data.sources[0].url;
              break;
            }
          }
        } catch {
          // Continue to next candidate
        }
      }

      if (resolvedM3u8) {
        const streamData: EightStreamResponse = {
          success: true,
          m3u8Url: resolvedM3u8,
          defaultAudio: "hi",
          audioTracks,
          sources: [
            { quality: "1080p Auto", url: resolvedM3u8, isM3u8: true, language: "Hindi / English" },
          ],
        };
        streamCache.set(cacheKey, { data: streamData, expires: Date.now() + 3600000 });
        return res.json(streamData);
      }

      // If no remote m3u8 is found directly, notify frontend to gracefully use Nxsha embed
      return res.json({
        success: false,
        error: "Direct m3u8 not found. Falling back to Nxsha embed player.",
      });
    } catch (err: any) {
      return res.json({
        success: false,
        error: err?.message || "Stream resolution error",
      });
    }
  });

  // 2. Stream segment CORS/Referer proxy for protected m3u8 / ts streams
  app.get("/api/stream/proxy-m3u8", async (req: Request, res: Response) => {
    const streamUrl = req.query.url as string;
    if (!streamUrl) {
      return res.status(400).send("Missing stream URL");
    }

    try {
      const parsedUrl = new URL(streamUrl);
      const isHttps = parsedUrl.protocol === "https:";
      const client = isHttps ? https : http;

      const proxyReq = client.request(
        streamUrl,
        {
          method: "GET",
          headers: {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
            "Referer": `${parsedUrl.origin}/`,
            "Origin": parsedUrl.origin,
          },
        },
        (proxyRes) => {
          res.setHeader("Access-Control-Allow-Origin", "*");
          res.setHeader("Access-Control-Allow-Headers", "*");
          res.setHeader("Content-Type", proxyRes.headers["content-type"] || "application/vnd.apple.mpegurl");
          proxyRes.pipe(res);
        }
      );

      proxyReq.on("error", (err) => {
        if (!res.headersSent) {
          res.status(502).send("Stream proxy failed: " + err.message);
        }
      });

      proxyReq.end();
    } catch (e: any) {
      if (!res.headersSent) {
        res.status(500).send("Proxy error: " + e.message);
      }
    }
  });
}
