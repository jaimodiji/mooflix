import type { Express, Request, Response } from "express";
import https from "node:https";

const chunkCache = new Map<string, string>();
const anilistCache = new Map<string, number>();

// Query AniList GraphQL API to find official AniList ID for any Anime title
function getAnilistId(title: string): Promise<number | null> {
  if (!title) return Promise.resolve(null);
  const cleanKey = title.trim().toLowerCase();
  if (anilistCache.has(cleanKey)) {
    return Promise.resolve(anilistCache.get(cleanKey)!);
  }

  const query = `
    query ($search: String) {
      Page(page: 1, perPage: 1) {
        media(search: $search, type: ANIME, sort: POPULARITY_DESC) {
          id
        }
      }
    }
  `;

  return new Promise((resolve) => {
    const postData = JSON.stringify({ query, variables: { search: title.trim() } });
    const req = https.request(
      "https://graphql.anilist.co",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
          "User-Agent": "MooFlix-AniList-Client/1.0",
        },
        timeout: 4000,
      },
      (res) => {
        let d = "";
        res.on("data", (c) => (d += c));
        res.on("end", () => {
          try {
            const json = JSON.parse(d);
            const id = json?.data?.Page?.media?.[0]?.id || null;
            if (id) {
              anilistCache.set(cleanKey, id);
            }
            resolve(id);
          } catch {
            resolve(null);
          }
        });
      }
    );
    req.on("error", () => resolve(null));
    req.on("timeout", () => {
      req.destroy();
      resolve(null);
    });
    req.write(postData);
    req.end();
  });
}

function patchVidlyChunk(data: string): string {
  return data
    // 1. Definitively resolve the sandbox detection hook to not sandboxed and not checking
    // This directly fixes the black screen caused by eD.checking remaining true indefinitely
    .replace(/\{sandboxed:t,checking:n\}/g, "{sandboxed:false,checking:false}")
    .replace(/eD\.checking\s*\|\|\s*eD\.sandboxed/g, "false")
    .replace(/eD\.sandboxed\s*&&/g, "false&&")
    .replace(/eD\.sandboxed/g, "false")
    .replace(/eD\.checking/g, "false")
    .replace(/null===\(t=window\.frameElement\)\|\|void 0===t\?void 0:t\.hasAttribute\("sandbox"\)/g, "false")
    .replace(/String\(t\)\.toLowerCase\(\)\.includes\("sandbox"\)&&e\(\)/g, "false")
    // 2. Extra safety fallback: neutralize sandbox warning component
    .replace(/function tZ\(e\)\{/g, "function tZ(e){return null;");
}

export function registerVidlyProxy(app: Express) {
  // 1. Handle all Next.js static assets for Vidly (/_next/*)
  // This guarantees that webpack chunks, CSS, and fonts load with proper MIME types
  // and dynamically patches sandbox detections in JS chunks.
  app.use("/_next", (req: Request, res: Response) => {
    const upstreamUrl = `https://vidly.pro/_next${req.url}`;
    const isJsChunk = req.url.endsWith(".js");

    // Serve cached chunk if already patched
    if (isJsChunk && chunkCache.has(req.url)) {
      res.setHeader("Content-Type", "application/javascript; charset=utf-8");
      res.setHeader("Cache-Control", "public, max-age=86400");
      res.setHeader("Access-Control-Allow-Origin", "*");
      return res.send(chunkCache.get(req.url));
    }

    const options = {
      headers: {
        "User-Agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
        Referer: "https://vidly.pro/",
        Accept: "*/*",
      },
    };

    const proxyReq = https.get(upstreamUrl, options, (upstreamRes) => {
      // If it's a JS chunk, inspect and apply surgical sandbox bypass patch if needed
      if (isJsChunk && upstreamRes.statusCode === 200) {
        let chunkData = "";
        upstreamRes.setEncoding("utf8");
        upstreamRes.on("data", (c) => {
          chunkData += c;
        });
        upstreamRes.on("end", () => {
          const needsPatch =
            chunkData.includes("sandboxed") ||
            chunkData.includes("frameElement") ||
            chunkData.includes("checking");

          const finalData = needsPatch ? patchVidlyChunk(chunkData) : chunkData;
          if (needsPatch) {
            chunkCache.set(req.url, finalData);
          }

          res.setHeader("Content-Type", "application/javascript; charset=utf-8");
          res.setHeader("Cache-Control", "public, max-age=86400");
          res.setHeader("Access-Control-Allow-Origin", "*");
          return res.send(finalData);
        });
        return;
      }

      // For all other static assets (CSS, images, fonts):
      res.writeHead(upstreamRes.statusCode || 200, {
        "Content-Type": upstreamRes.headers["content-type"] || "application/octet-stream",
        "Cache-Control": upstreamRes.headers["cache-control"] || "public, max-age=86400",
        "Access-Control-Allow-Origin": "*",
      });
      upstreamRes.pipe(res);
    });

    proxyReq.on("error", (err) => {
      console.warn(`Upstream static asset fetch error for ${req.url}:`, err.message);
      if (!res.headersSent) {
        res.status(404).send("// Asset not found");
      }
    });
  });

  // 2. Proxy all Vidly dynamic API endpoints (/api/sources, /api/episodes, /api/subtitles, /api/source, etc.)
  // Handles all HTTP methods (GET, POST, OPTIONS) and query parameters transparently
  app.all(["/api/sources", "/api/episodes", "/api/subtitles", "/api/source"], (req: Request, res: Response) => {
    const upstreamApiUrl = `https://vidly.pro${req.originalUrl}`;
    const options = {
      method: req.method,
      headers: {
        "User-Agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
        Referer: "https://vidly.pro/",
        Accept: "*/*",
        "Content-Type": req.headers["content-type"] || "application/json",
      },
    };

    const proxyReq = https.request(upstreamApiUrl, options, (upstreamRes) => {
      res.writeHead(upstreamRes.statusCode || 200, {
        "Content-Type": upstreamRes.headers["content-type"] || "application/json",
        "Access-Control-Allow-Origin": "*",
        "Cache-Control": "no-cache",
      });
      upstreamRes.pipe(res);
    });

    proxyReq.on("error", (err) => {
      console.warn("Vidly API proxy error:", err.message);
      if (!res.headersSent) {
        res.status(500).json({ error: "Source proxy error" });
      }
    });

    if (req.method === "POST" || req.method === "PUT") {
      if (req.body && Object.keys(req.body).length > 0) {
        proxyReq.write(typeof req.body === "string" ? req.body : JSON.stringify(req.body));
      }
    }
    proxyReq.end();
  });

  // 3. Stream Embed Proxy (renders Server 1 player iframe)
  // Server 1
  // Dedicated sandbox-bypass and header stripping.
  app.get("/api/player/vidly", async (req: Request, res: Response) => {
    try {
      const type = (req.query.type as string) || "movie";
      const id = req.query.id as string;
      const title = (req.query.title as string) || "";
      const season = req.query.season ? Number(req.query.season) : 1;
      const episode = req.query.episode ? Number(req.query.episode) : 1;
      const audio = (req.query.audio as string) || "dub";

      if (!id && !title) {
        return res.status(400).send("Content ID or Title required");
      }

      let targetUrl = "";

      if (type === "anime") {
        let anilistId: number | string | null = null;
        if (title) {
          anilistId = await getAnilistId(title);
        }
        if (!anilistId) {
          anilistId = id;
        }
        targetUrl = `https://vidly.pro/anime/${anilistId}/${episode}/${audio}?autoplay=1&audioPicker=1`;
      } else if (type === "tv") {
        targetUrl = `https://vidly.pro/tv/${id}/${season}/${episode}?autoplay=1&audioPicker=1`;
      } else {
        targetUrl = `https://vidly.pro/movie/${id}?autoplay=1&audioPicker=1`;
      }

      https
        .get(
          targetUrl,
          {
            headers: {
              "User-Agent":
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
              Referer: "https://vidly.pro/",
              Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
              "Accept-Language": "en-US,en;q=0.9,hi;q=0.8",
            },
          },
          (upstreamRes) => {
            if (upstreamRes.statusCode !== 200) {
              return res.status(upstreamRes.statusCode || 500).send(
                `<div style="display:flex;align-items:center;justify-content:center;height:100vh;background:#000;color:#fff;font-family:sans-serif;text-align:center;padding:20px;">
                  <div>
                    <h3 style="margin-bottom:8px;">Server 1: Stream Unavailable</h3>
                    <p style="color:#aaa;font-size:14px;">Switching to Server 2...</p>
                  </div>
                </div>`
              );
            }

            let html = "";
            upstreamRes.setEncoding("utf8");
            upstreamRes.on("data", (chunk) => {
              html += chunk;
            });

            upstreamRes.on("end", () => {
              // Global style suppressing any sandbox alert element
              const sandboxOverrideStyle = `
<style>
.vp-sandbox, [class*="sandbox"], [class*="Sandbox"] {
  display: none !important;
  opacity: 0 !important;
  visibility: hidden !important;
  pointer-events: none !important;
  width: 0 !important;
  height: 0 !important;
}
</style>
`;

              // Safe guards for document.domain to suppress SecurityError and prevent frame crashes
              const bypassScript = `
<script>
try {
  var origDomain = document.domain;
  Object.defineProperty(document, 'domain', {
    get: function() { return origDomain || window.location.hostname; },
    set: function() {},
    configurable: true
  });
} catch(e) {}

// Ad Popup Blocker
try {
  window.open = function() { return null; };
  window.alert = function() {};
  window.confirm = function() { return false; };
  window.prompt = function() { return null; };

  // Intercept synthetic click events on ad links
  window.addEventListener('click', function(e) {
    var target = e.target;
    while (target && target !== document.body) {
      if (target.tagName === 'A' && (target.target === '_blank' || target.getAttribute('target') === '_blank')) {
        e.preventDefault();
        e.stopPropagation();
        return false;
      }
      target = target.parentElement;
    }
  }, true);
} catch(e) {}
</script>
`;

              let modifiedHtml = html;

              // Insert sandbox override styles and bypass script into <head>
              if (modifiedHtml.includes("<head>")) {
                modifiedHtml = modifiedHtml.replace(
                  "<head>",
                  `<head>${sandboxOverrideStyle}${bypassScript}`
                );
              } else {
                modifiedHtml = `<head>${sandboxOverrideStyle}${bypassScript}</head>` + modifiedHtml;
              }

              res.removeHeader("X-Frame-Options");
              res.removeHeader("Content-Security-Policy");
              res.setHeader("Content-Type", "text/html; charset=utf-8");
              res.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
              return res.send(modifiedHtml);
            });
          }
        )
        .on("error", (err) => {
          console.error("Vidly proxy error:", err.message);
          return res.status(502).send(
            `<div style="display:flex;align-items:center;justify-content:center;height:100vh;background:#000;color:#fff;font-family:sans-serif;text-align:center;padding:20px;">
              <div>
                <h3 style="margin-bottom:8px;">Server 1: Connection Error</h3>
                <p style="color:#aaa;font-size:14px;">Please switch to Server 2 from the server menu.</p>
              </div>
            </div>`
          );
        });
    } catch (err: any) {
      console.error("Vidly endpoint error:", err?.message || err);
      return res.status(500).send(
        `<div style="display:flex;align-items:center;justify-content:center;height:100vh;background:#000;color:#fff;font-family:sans-serif;text-align:center;padding:20px;">
          <div>
            <h3 style="margin-bottom:8px;">Server 1: Playback Error</h3>
            <p style="color:#aaa;font-size:14px;">Please switch to Server 2 from the server menu.</p>
          </div>
        </div>`
      );
    }
  });
}
