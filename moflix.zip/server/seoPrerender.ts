import fs from 'node:fs';
import path from 'node:path';
import { BLOG_POSTS, BlogPost } from '../services/blogData';

interface MovieSeriesMeta {
  title: string;
  overview: string;
  year: string;
  poster: string;
  rating: number;
}

interface CatalogData {
  movies: Record<string, MovieSeriesMeta>;
  series: Record<string, MovieSeriesMeta>;
}

let cachedCatalog: CatalogData | null = null;

function getCatalog(): CatalogData {
  if (cachedCatalog) return cachedCatalog;
  try {
    const pubCatalog = path.join(process.cwd(), 'public', 'seo-catalog.json');
    const distCatalog = path.join(process.cwd(), 'dist', 'seo-catalog.json');
    const fileToRead = fs.existsSync(distCatalog) ? distCatalog : pubCatalog;
    if (fs.existsSync(fileToRead)) {
      const raw = fs.readFileSync(fileToRead, 'utf-8');
      cachedCatalog = JSON.parse(raw);
      return cachedCatalog!;
    }
  } catch (e) {
    console.warn('Could not load seo-catalog.json:', e);
  }
  return { movies: {}, series: {} };
}

export function renderPageWithSeo(templateHtml: string, reqPath: string): string {
  // Normalize path
  const cleanPath = reqPath.split('?')[0].replace(/\/+$/, '') || '/';
  const canonicalUrl = `https://mooflix.online${cleanPath === '/' ? '/' : cleanPath}`;

  let pageTitle = 'MooFlix — Watch Free Movies, TV Series & Live Sports in HD';
  let metaDescription = 'Stream trending movies, web series, anime, and live sports on MooFlix in Ultra HD 4K with zero ads and automatic multi-server player failover.';
  let ogImage = 'https://mooflix.online/icons/og-image.jpg';
  let jsonLd: any = null;
  let bodyContentHtml = '';

  const catalog = getCatalog();

  // 1. BLOG ARTICLE ROUTE
  if (cleanPath.startsWith('/blog/')) {
    const slug = cleanPath.replace('/blog/', '').trim();
    const post = BLOG_POSTS.find((p) => p.slug === slug || p.id === slug);

    if (post) {
      pageTitle = `${post.title} | MooFlix Cinema Magazine`;
      metaDescription = post.excerpt.slice(0, 158);
      ogImage = post.coverImage || ogImage;

      jsonLd = {
        "@context": "https://schema.org",
        "@type": "Article",
        "headline": post.title,
        "description": post.excerpt,
        "image": post.coverImage,
        "author": {
          "@type": "Organization",
          "name": post.author || "MooFlix Editorial Team",
          "url": "https://mooflix.online/about"
        },
        "publisher": {
          "@type": "Organization",
          "name": "MooFlix",
          "url": "https://mooflix.online",
          "logo": {
            "@type": "ImageObject",
            "url": "https://mooflix.online/icons/icon-512x512.png"
          }
        },
        "datePublished": post.publishedDate || "2026-11-16",
        "dateModified": post.publishedDate || "2026-11-16",
        "mainEntityOfPage": canonicalUrl
      };

      const paragraphsHtml = post.content
        .split('\n\n')
        .filter(p => p.trim())
        .map(p => `<p style="font-size: 16px; line-height: 1.8; color: #d1d5db; margin-bottom: 20px;">${p.trim().replace(/^###?\s*/, '<strong>').replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')}</p>`)
        .join('');

      bodyContentHtml = `
      <article style="max-width: 900px; margin: 0 auto; padding: 40px 20px;">
        <nav style="font-size: 13px; color: #9ca3af; margin-bottom: 24px;">
          <a href="/" style="color: #e50914; text-decoration: none;">Home</a> &gt; 
          <a href="/blogs" style="color: #9ca3af; text-decoration: none;">Blogs &amp; Guides</a> &gt; 
          <span style="color: #ffffff;">${post.title}</span>
        </nav>
        <span style="display: inline-block; background: #e50914; color: #ffffff; font-weight: 800; font-size: 11px; text-transform: uppercase; padding: 4px 10px; border-radius: 6px; margin-bottom: 12px;">${post.category || 'Cinema Guide'}</span>
        <h1 style="font-size: 36px; font-weight: 900; line-height: 1.25; color: #ffffff; margin: 0 0 16px 0;">${post.title}</h1>
        <div style="font-size: 13px; color: #9ca3af; margin-bottom: 24px;">
          By <strong>${post.author}</strong> • Published ${post.publishedDate} • ${post.readTime}
        </div>
        ${post.coverImage ? `<img src="${post.coverImage}" alt="${post.title}" style="width: 100%; max-height: 480px; object-fit: cover; border-radius: 16px; margin-bottom: 32px; border: 1px solid rgba(255,255,255,0.1);" />` : ''}
        <div style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.1); border-radius: 16px; padding: 24px; margin-bottom: 32px;">
          <h2 style="font-size: 18px; color: #ffffff; margin-top: 0;">Quick Summary</h2>
          <p style="font-size: 15px; color: #d1d5db; line-height: 1.6; margin: 0;">${post.excerpt}</p>
        </div>
        <div class="article-body">
          ${paragraphsHtml}
        </div>
        <div style="margin-top: 40px; padding: 24px; background: rgba(229,9,20,0.08); border: 1px solid rgba(229,9,20,0.25); border-radius: 16px; text-align: center;">
          <h3 style="color: #ffffff; font-size: 20px; font-weight: 800; margin-top: 0;">Ready to Watch Movies in Ultra HD 4K?</h3>
          <p style="color: #d1d5db; font-size: 14px; margin-bottom: 16px;">Browse thousands of titles free on MooFlix with zero buffering and no sign-up.</p>
          <a href="/movies" style="display: inline-block; background: #e50914; color: #ffffff; font-weight: 800; padding: 12px 28px; border-radius: 12px; text-decoration: none;">Explore Free Movies &rarr;</a>
        </div>
      </article>`;
    }
  }

  // 2. MOVIE DETAILS ROUTE (/movie/:id)
  else if (cleanPath.startsWith('/movie/')) {
    const movieId = cleanPath.replace('/movie/', '').trim();
    const movieMeta = catalog.movies[movieId];
    const movieTitle = movieMeta?.title || `Blockbuster Movie #${movieId}`;
    const year = movieMeta?.year || '2026';
    const overview = movieMeta?.overview || 'Stream full movie in Ultra HD 4K on MooFlix with zero buffering and multiple servers.';
    const rating = movieMeta?.rating || 7.8;
    const poster = movieMeta?.poster || ogImage;

    pageTitle = `Watch ${movieTitle} (${year}) Free Online HD 4K | MooFlix`;
    metaDescription = `Stream ${movieTitle} (${year}) in Ultra HD 4K with multiple servers and zero buffering on MooFlix. ${overview.slice(0, 120)}`;
    ogImage = poster;

    jsonLd = {
      "@context": "https://schema.org",
      "@type": "Movie",
      "name": movieTitle,
      "dateCreated": `${year}-01-01`,
      "description": overview,
      "image": poster,
      "aggregateRating": {
        "@type": "AggregateRating",
        "ratingValue": rating,
        "bestRating": "10",
        "ratingCount": "1284"
      },
      "offers": {
        "@type": "Offer",
        "price": "0",
        "priceCurrency": "USD",
        "availability": "https://schema.org/InStock"
      }
    };

    bodyContentHtml = `
    <div style="max-width: 1100px; margin: 0 auto; padding: 40px 20px;">
      <nav style="font-size: 13px; color: #9ca3af; margin-bottom: 24px;">
        <a href="/" style="color: #e50914; text-decoration: none;">Home</a> &gt; 
        <a href="/movies" style="color: #9ca3af; text-decoration: none;">Movies</a> &gt; 
        <span style="color: #ffffff;">${movieTitle}</span>
      </nav>
      <div style="display: flex; flex-direction: column; md:flex-row; gap: 32px; align-items: flex-start;">
        ${poster ? `<img src="${poster}" alt="${movieTitle}" style="width: 280px; border-radius: 16px; border: 1px solid rgba(255,255,255,0.1); box-shadow: 0 20px 40px rgba(0,0,0,0.8);" />` : ''}
        <div style="flex: 1;">
          <div style="display: flex; gap: 8px; align-items: center; margin-bottom: 8px;">
            <span style="background: #e50914; color: white; font-weight: 800; font-size: 12px; padding: 2px 8px; border-radius: 4px;">4K ULTRA HD</span>
            <span style="color: #fbbf24; font-weight: 700; font-size: 14px;">★ ${rating}/10</span>
            <span style="color: #9ca3af; font-size: 14px;">• ${year}</span>
          </div>
          <h1 style="font-size: 36px; font-weight: 900; color: #ffffff; margin: 0 0 16px 0;">${movieTitle}</h1>
          <p style="font-size: 16px; line-height: 1.7; color: #d1d5db; margin-bottom: 24px;">${overview}</p>
          <div style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.1); border-radius: 12px; padding: 20px; margin-bottom: 24px;">
            <h3 style="font-size: 15px; color: #ffffff; margin-top: 0; margin-bottom: 8px;">Playback Features:</h3>
            <ul style="color: #9ca3af; font-size: 14px; margin: 0; padding-left: 20px; line-height: 1.8;">
              <li>High-speed adaptive bitrate (1080p / 4K)</li>
              <li>Multi-server failover system</li>
              <li>No subscription or credit card needed</li>
            </ul>
          </div>
          <a href="/movie/${movieId}" style="display: inline-block; background: #e50914; color: #ffffff; font-weight: 800; padding: 14px 32px; border-radius: 12px; text-decoration: none; font-size: 16px; box-shadow: 0 10px 25px rgba(229,9,20,0.5);">▶ Watch ${movieTitle} in HD</a>
        </div>
      </div>
    </div>`;
  }

  // 3. TV SERIES DETAILS ROUTE (/series/:id)
  else if (cleanPath.startsWith('/series/')) {
    const seriesId = cleanPath.replace('/series/', '').trim();
    const seriesMeta = catalog.series[seriesId];
    const seriesTitle = seriesMeta?.title || `Web Series #${seriesId}`;
    const year = seriesMeta?.year || '2026';
    const overview = seriesMeta?.overview || 'Stream all seasons and episodes in Ultra HD on MooFlix with zero buffering.';
    const rating = seriesMeta?.rating || 8.1;
    const poster = seriesMeta?.poster || ogImage;

    pageTitle = `Watch ${seriesTitle} Online Free All Episodes HD | MooFlix`;
    metaDescription = `Stream ${seriesTitle} online free in Ultra HD on MooFlix. Complete seasons, all episodes, zero buffering. ${overview.slice(0, 120)}`;
    ogImage = poster;

    jsonLd = {
      "@context": "https://schema.org",
      "@type": "TVSeries",
      "name": seriesTitle,
      "dateCreated": `${year}-01-01`,
      "description": overview,
      "image": poster,
      "aggregateRating": {
        "@type": "AggregateRating",
        "ratingValue": rating,
        "bestRating": "10",
        "ratingCount": "982"
      }
    };

    bodyContentHtml = `
    <div style="max-width: 1100px; margin: 0 auto; padding: 40px 20px;">
      <nav style="font-size: 13px; color: #9ca3af; margin-bottom: 24px;">
        <a href="/" style="color: #e50914; text-decoration: none;">Home</a> &gt; 
        <a href="/series" style="color: #9ca3af; text-decoration: none;">TV Series</a> &gt; 
        <span style="color: #ffffff;">${seriesTitle}</span>
      </nav>
      <div style="display: flex; flex-direction: column; md:flex-row; gap: 32px; align-items: flex-start;">
        ${poster ? `<img src="${poster}" alt="${seriesTitle}" style="width: 280px; border-radius: 16px; border: 1px solid rgba(255,255,255,0.1); box-shadow: 0 20px 40px rgba(0,0,0,0.8);" />` : ''}
        <div style="flex: 1;">
          <div style="display: flex; gap: 8px; align-items: center; margin-bottom: 8px;">
            <span style="background: #e50914; color: white; font-weight: 800; font-size: 12px; padding: 2px 8px; border-radius: 4px;">TV SERIES</span>
            <span style="color: #fbbf24; font-weight: 700; font-size: 14px;">★ ${rating}/10</span>
            <span style="color: #9ca3af; font-size: 14px;">• ${year}</span>
          </div>
          <h1 style="font-size: 36px; font-weight: 900; color: #ffffff; margin: 0 0 16px 0;">${seriesTitle}</h1>
          <p style="font-size: 16px; line-height: 1.7; color: #d1d5db; margin-bottom: 24px;">${overview}</p>
          <a href="/series/${seriesId}" style="display: inline-block; background: #e50914; color: #ffffff; font-weight: 800; padding: 14px 32px; border-radius: 12px; text-decoration: none; font-size: 16px; box-shadow: 0 10px 25px rgba(229,9,20,0.5);">▶ Stream All Episodes Free</a>
        </div>
      </div>
    </div>`;
  }

  // 5. ABOUT PAGE
  else if (cleanPath === '/about') {
    pageTitle = 'About MooFlix - Editorial Cinema Index & Free Streaming Protocol';
    metaDescription = 'Learn about MooFlix (mooflix.online), the independent digital cinema magazine and metadata index providing free HD/4K movie and web series streaming.';
    bodyContentHtml = `
    <article style="max-width: 900px; margin: 0 auto; padding: 48px 20px;">
      <h1 style="font-size: 36px; font-weight: 900; color: #ffffff; margin-bottom: 16px;">About MooFlix Cinema &amp; Entertainment</h1>
      <p style="font-size: 16px; line-height: 1.8; color: #d1d5db; margin-bottom: 24px;">
        <strong>MooFlix</strong> (accessible at <span style="color: #e50914;">mooflix.online</span>) is an independent digital cinema magazine, entertainment review portal, and metadata index engineered for film enthusiasts, television cinephiles, and anime followers across the globe.
      </p>
      <h2 style="font-size: 22px; color: #ffffff; margin-top: 32px;">Our Editorial Mission</h2>
      <p style="font-size: 15px; line-height: 1.8; color: #9ca3af;">
        The digital entertainment landscape is flooded with paywalls, fragmented licensing, and low-quality scraper sites. MooFlix was built to restore simplicity and joy to cinema discovery. We provide high-speed search, trailers, detailed filmography, genre curation, and insightful commentary covering Hollywood blockbusters, European independent cinema, South Asian cinema, and Japanese animation.
      </p>
      <h2 style="font-size: 22px; color: #ffffff; margin-top: 32px;">Metadata Attribution</h2>
      <p style="font-size: 15px; line-height: 1.8; color: #9ca3af;">
        Movie and television metadata, plot synopses, cast rosters, and poster artwork are retrieved via the official API of <strong>The Movie Database (TMDb)</strong>.
      </p>
    </article>`;
  }

  // 5. ANIME PAGE
  else if (cleanPath === '/anime') {
    pageTitle = 'Watch Anime Online Free Ultra HD | Japanese Sub & Dub | MooFlix';
    metaDescription = 'Stream Japanese anime, popular shonen, isekai hits, and animated films with English subtitles and dubbing online free on MooFlix.';
    bodyContentHtml = `
    <div style="max-width: 1200px; margin: 0 auto; padding: 48px 20px;">
      <h1 style="font-size: 36px; font-weight: 900; color: #ffffff; margin-bottom: 12px;">Anime &amp; Japanese Animation Hub</h1>
      <p style="font-size: 16px; color: #9ca3af; margin-bottom: 32px;">Explore popular Japanese anime series, classic movies, and 3D animated series in English sub and dub.</p>
      <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 16px; margin-bottom: 36px;">
        <div style="padding: 20px; background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.1); border-radius: 12px;">
          <h3 style="color: #ffffff; margin-top: 0;">Shonen Hits</h3>
          <p style="font-size: 13px; color: #9ca3af;">Stream action-packed battles and adventures from top creators.</p>
        </div>
        <div style="padding: 20px; background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.1); border-radius: 12px;">
          <h3 style="color: #ffffff; margin-top: 0;">Isekai &amp; Fantasy</h3>
          <p style="font-size: 13px; color: #9ca3af;">Explore magical realms and reincarnated legends in HD.</p>
        </div>
        <div style="padding: 20px; background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.1); border-radius: 12px;">
          <h3 style="color: #ffffff; margin-top: 0;">Sci-Fi &amp; Cyberpunk</h3>
          <p style="font-size: 13px; color: #9ca3af;">Futuristic dystopias, mecha sagas, and neon aesthetics.</p>
        </div>
      </div>
      <div style="text-align: center; margin-top: 32px;">
        <a href="/blogs" style="color: #e50914; font-weight: 700; text-decoration: none;">&larr; Read Anime Release Guides &amp; Sub vs Dub Reviews</a>
      </div>
    </div>`;
  }

  // 6. MOVIES BROWSE (With crawlable direct links to all catalog movies)
  else if (cleanPath === '/movies') {
    pageTitle = 'Watch Free Movies Online in Ultra HD 4K | MooFlix Official';
    metaDescription = 'Browse thousands of free movies online in Ultra HD 4K. Hollywood, Bollywood, action, thrillers, and classics with zero buffering on MooFlix.';
    
    const movieEntries = Object.entries(catalog.movies);
    const movieCardsHtml = movieEntries.map(([id, m]) => `
      <div style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); border-radius: 12px; padding: 12px; display: flex; flex-direction: column;">
        ${m.poster ? `<img src="${m.poster}" alt="${m.title}" style="width: 100%; aspect-ratio: 2/3; object-fit: cover; border-radius: 8px; margin-bottom: 10px;" loading="lazy" />` : ''}
        <div style="font-size: 11px; color: #fbbf24; font-weight: 700; margin-bottom: 4px;">★ ${m.rating} • ${m.year}</div>
        <h3 style="font-size: 14px; font-weight: 700; color: #ffffff; margin: 0 0 6px 0; line-height: 1.3;">
          <a href="/movie/${id}" style="color: #ffffff; text-decoration: none;">${m.title}</a>
        </h3>
        <p style="font-size: 12px; color: #9ca3af; line-height: 1.4; margin: 0 0 12px 0; flex: 1; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;">${m.overview}</p>
        <a href="/movie/${id}" style="display: block; text-align: center; background: #e50914; color: #ffffff; font-weight: 700; font-size: 12px; padding: 6px 12px; border-radius: 6px; text-decoration: none;">Stream Free</a>
      </div>
    `).join('');

    bodyContentHtml = `
    <div style="max-width: 1400px; margin: 0 auto; padding: 48px 20px;">
      <h1 style="font-size: 36px; font-weight: 900; color: #ffffff; margin-bottom: 12px;">Free Movies Online - Complete Collection</h1>
      <p style="font-size: 16px; color: #9ca3af; margin-bottom: 32px;">Stream thousands of Hollywood, Bollywood, and international cinema blockbusters in Ultra HD 4K without sign-up.</p>
      <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(180px, 1fr)); gap: 16px;">
        ${movieCardsHtml}
      </div>
    </div>`;
  }

  // 7. TV SERIES BROWSE (With crawlable direct links to all catalog series)
  else if (cleanPath === '/series') {
    pageTitle = 'Watch TV Series & Web Series Online Free HD | MooFlix Official';
    metaDescription = 'Stream complete seasons and latest episodes of top TV shows, crime thrillers, and binge-worthy web series online with zero subscription fees on MooFlix.';

    const seriesEntries = Object.entries(catalog.series);
    const seriesCardsHtml = seriesEntries.map(([id, s]) => `
      <div style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); border-radius: 12px; padding: 12px; display: flex; flex-direction: column;">
        ${s.poster ? `<img src="${s.poster}" alt="${s.title}" style="width: 100%; aspect-ratio: 2/3; object-fit: cover; border-radius: 8px; margin-bottom: 10px;" loading="lazy" />` : ''}
        <div style="font-size: 11px; color: #fbbf24; font-weight: 700; margin-bottom: 4px;">★ ${s.rating} • ${s.year}</div>
        <h3 style="font-size: 14px; font-weight: 700; color: #ffffff; margin: 0 0 6px 0; line-height: 1.3;">
          <a href="/series/${id}" style="color: #ffffff; text-decoration: none;">${s.title}</a>
        </h3>
        <p style="font-size: 12px; color: #9ca3af; line-height: 1.4; margin: 0 0 12px 0; flex: 1; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;">${s.overview}</p>
        <a href="/series/${id}" style="display: block; text-align: center; background: #e50914; color: #ffffff; font-weight: 700; font-size: 12px; padding: 6px 12px; border-radius: 6px; text-decoration: none;">All Episodes</a>
      </div>
    `).join('');

    bodyContentHtml = `
    <div style="max-width: 1400px; margin: 0 auto; padding: 48px 20px;">
      <h1 style="font-size: 36px; font-weight: 900; color: #ffffff; margin-bottom: 12px;">TV Series &amp; Web Series Online</h1>
      <p style="font-size: 16px; color: #9ca3af; margin-bottom: 32px;">Binge-watch complete seasons and all episodes of top rated television series in full HD with zero buffering.</p>
      <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(180px, 1fr)); gap: 16px;">
        ${seriesCardsHtml}
      </div>
    </div>`;
  }

  // 8. CINEMA BLOGS HUB (/blogs) - Complete archive of all 66 articles for Googlebot
  else if (cleanPath === '/blogs') {
    pageTitle = 'MooFlix Cinema Magazine & Streaming Guides | 2026 Blog Archive';
    metaDescription = 'Explore in-depth cinema reviews, streaming platform comparisons, anime schedules, Bollywood dual audio guides, and OTT recommendations on MooFlix.';

    const blogCardsHtml = BLOG_POSTS.map(post => `
      <article style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); border-radius: 16px; overflow: hidden; display: flex; flex-direction: column;">
        ${post.coverImage ? `
          <a href="/blog/${post.slug}" style="display: block;">
            <img src="${post.coverImage}" alt="${post.title}" style="width: 100%; aspect-ratio: 16/9; object-fit: cover;" loading="lazy" />
          </a>
        ` : ''}
        <div style="padding: 20px; flex: 1; display: flex; flex-direction: column;">
          <div style="display: flex; gap: 8px; align-items: center; margin-bottom: 8px;">
            <span style="background: rgba(229,9,20,0.15); color: #e50914; font-weight: 700; font-size: 11px; padding: 2px 8px; border-radius: 4px;">${post.category || 'Cinema Guide'}</span>
            <span style="color: #6b7280; font-size: 12px;">• ${post.readTime}</span>
          </div>
          <h2 style="font-size: 18px; font-weight: 800; line-height: 1.35; color: #ffffff; margin: 0 0 10px 0;">
            <a href="/blog/${post.slug}" style="color: #ffffff; text-decoration: none;">${post.title}</a>
          </h2>
          <p style="font-size: 14px; color: #9ca3af; line-height: 1.5; margin: 0 0 16px 0; flex: 1;">${post.excerpt}</p>
          <div style="display: flex; justify-content: space-between; align-items: center; font-size: 12px; color: #6b7280; border-top: 1px solid rgba(255,255,255,0.05); pt: 12px;">
            <span>By ${post.author}</span>
            <a href="/blog/${post.slug}" style="color: #e50914; font-weight: 700; text-decoration: none;">Read Guide &rarr;</a>
          </div>
        </div>
      </article>
    `).join('');

    bodyContentHtml = `
    <div style="max-width: 1300px; margin: 0 auto; padding: 48px 20px;">
      <nav style="font-size: 13px; color: #9ca3af; margin-bottom: 24px;">
        <a href="/" style="color: #e50914; text-decoration: none;">Home</a> &gt; 
        <span style="color: #ffffff;">Cinema Magazine &amp; Guides</span>
      </nav>
      <h1 style="font-size: 38px; font-weight: 900; color: #ffffff; margin: 0 0 12px 0;">Cinema Guides &amp; Streaming Insights</h1>
      <p style="font-size: 16px; color: #9ca3af; margin-bottom: 40px; max-width: 800px;">
        Authoritative editorial analysis, upcoming movie calendars, streaming comparisons, anime dub/sub guides, and 4K playback tutorials written by the MooFlix editorial team.
      </p>
      <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(320px, 1fr)); gap: 24px;">
        ${blogCardsHtml}
      </div>
    </div>`;
  }

  // 9. COMPLETE HTML SITEMAP (/sitemap) - Instant Crawl Bridge for all 372 URLs
  else if (cleanPath === '/sitemap') {
    pageTitle = 'MooFlix HTML Sitemap - Complete Movies, Shows & Cinema Guides Directory';
    metaDescription = 'Comprehensive HTML sitemap indexing all streaming titles, Hollywood movies, TV series, anime hits, and cinema guides available on mooflix.online.';

    const movieLinks = Object.entries(catalog.movies).map(([id, m]) => `
      <li><a href="/movie/${id}" style="color: #d1d5db; text-decoration: none; hover: underline;">${m.title} (${m.year})</a></li>
    `).join('');

    const seriesLinks = Object.entries(catalog.series).map(([id, s]) => `
      <li><a href="/series/${id}" style="color: #d1d5db; text-decoration: none; hover: underline;">${s.title} (${s.year})</a></li>
    `).join('');

    const blogLinks = BLOG_POSTS.map(post => `
      <li><a href="/blog/${post.slug}" style="color: #d1d5db; text-decoration: none; hover: underline;">${post.title}</a> <span style="color: #6b7280; font-size: 12px;">(${post.publishedDate})</span></li>
    `).join('');

    bodyContentHtml = `
    <div style="max-width: 1200px; margin: 0 auto; padding: 48px 20px;">
      <nav style="font-size: 13px; color: #9ca3af; margin-bottom: 24px;">
        <a href="/" style="color: #e50914; text-decoration: none;">Home</a> &gt; 
        <span style="color: #ffffff;">HTML Sitemap</span>
      </nav>
      <h1 style="font-size: 38px; font-weight: 900; color: #ffffff; margin-bottom: 12px;">MooFlix Complete HTML Sitemap</h1>
      <p style="font-size: 15px; color: #9ca3af; margin-bottom: 36px;">
        Direct crawl index connecting every core section, movie detail page, television series, and cinema guide published on <strong>mooflix.online</strong>.
      </p>

      <!-- Core Pages -->
      <section style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); border-radius: 16px; padding: 24px; margin-bottom: 32px;">
        <h2 style="font-size: 22px; color: #ffffff; margin-top: 0; margin-bottom: 16px;">Core Navigation &amp; Legal Protocols</h2>
        <ul style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 12px; list-style: none; padding: 0; margin: 0;">
          <li><a href="/" style="color: #e50914; font-weight: 700; text-decoration: none;">&rarr; Home Showcase</a></li>
          <li><a href="/movies" style="color: #e50914; font-weight: 700; text-decoration: none;">&rarr; Free Movies Catalog</a></li>
          <li><a href="/series" style="color: #e50914; font-weight: 700; text-decoration: none;">&rarr; TV Series Archive</a></li>
          <li><a href="/anime" style="color: #e50914; font-weight: 700; text-decoration: none;">&rarr; Anime Hub</a></li>
          <li><a href="/sports" style="color: #e50914; font-weight: 700; text-decoration: none;">&rarr; Live Sports &amp; Cricket</a></li>
          <li><a href="/blogs" style="color: #e50914; font-weight: 700; text-decoration: none;">&rarr; Cinema Blogs &amp; Guides</a></li>
          <li><a href="/about" style="color: #e50914; font-weight: 700; text-decoration: none;">&rarr; About MooFlix</a></li>
          <li><a href="/dmca" style="color: #e50914; font-weight: 700; text-decoration: none;">&rarr; DMCA Copyright Notice</a></li>
          <li><a href="/privacy" style="color: #e50914; font-weight: 700; text-decoration: none;">&rarr; Privacy Policy</a></li>
          <li><a href="/terms" style="color: #e50914; font-weight: 700; text-decoration: none;">&rarr; Terms of Service</a></li>
          <li><a href="/contact" style="color: #e50914; font-weight: 700; text-decoration: none;">&rarr; Contact Support</a></li>
          <li><a href="/watchlist" style="color: #e50914; font-weight: 700; text-decoration: none;">&rarr; User Saved Watchlist</a></li>
          <li><a href="/sitemap.xml" target="_blank" style="color: #e50914; font-weight: 700; text-decoration: none;">&rarr; Master XML Sitemap</a></li>
        </ul>
      </section>

      <!-- Cinema Guides & Blogs (66 Articles) -->
      <section style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); border-radius: 16px; padding: 24px; margin-bottom: 32px;">
        <h2 style="font-size: 22px; color: #ffffff; margin-top: 0; margin-bottom: 16px;">Cinema Guides &amp; Streaming Articles (${BLOG_POSTS.length})</h2>
        <ul style="display: grid; grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap: 10px; font-size: 14px; line-height: 1.5; padding-left: 20px;">
          ${blogLinks}
        </ul>
      </section>

      <!-- Movies Index (135 Movies) -->
      <section style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); border-radius: 16px; padding: 24px; margin-bottom: 32px;">
        <h2 style="font-size: 22px; color: #ffffff; margin-top: 0; margin-bottom: 16px;">Indexed Feature Films &amp; Blockbusters (${Object.keys(catalog.movies).length})</h2>
        <ul style="display: grid; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); gap: 8px; font-size: 13px; line-height: 1.5; padding-left: 20px;">
          ${movieLinks}
        </ul>
      </section>

      <!-- TV Series Index (154 Series) -->
      <section style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); border-radius: 16px; padding: 24px;">
        <h2 style="font-size: 22px; color: #ffffff; margin-top: 0; margin-bottom: 16px;">Indexed Television &amp; Web Series (${Object.keys(catalog.series).length})</h2>
        <ul style="display: grid; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); gap: 8px; font-size: 13px; line-height: 1.5; padding-left: 20px;">
          ${seriesLinks}
        </ul>
      </section>
    </div>`;
  }

  // 10. DMCA POLICY
  else if (cleanPath === '/dmca') {
    pageTitle = 'DMCA Copyright Compliance & Designated Agent | MooFlix';
    metaDescription = 'Digital Millennium Copyright Act compliance notice, safe harbor disclosures (17 U.S.C. § 512), and designated copyright agent for mooflix.online.';
    bodyContentHtml = `
    <article style="max-width: 900px; margin: 0 auto; padding: 48px 20px;">
      <h1 style="font-size: 36px; font-weight: 900; color: #ffffff; margin-bottom: 16px;">DMCA Copyright Policy</h1>
      <p style="font-size: 15px; line-height: 1.8; color: #d1d5db;">MooFlix respects intellectual property rights and complies with Title 17, United States Code, Section 512 (DMCA). Designated Copyright Agent: legal@mooflix.online.</p>
    </article>`;
  }

  // 12. PRIVACY POLICY
  else if (cleanPath === '/privacy') {
    pageTitle = 'Privacy Policy & GDPR Cookie Disclosures | MooFlix';
    metaDescription = 'MooFlix privacy policy, log files usage, advertising partners, and GDPR/CCPA consumer data protection disclosures for mooflix.online.';
    bodyContentHtml = `
    <article style="max-width: 900px; margin: 0 auto; padding: 48px 20px;">
      <h1 style="font-size: 36px; font-weight: 900; color: #ffffff; margin-bottom: 16px;">Privacy Policy &amp; Cookie Disclosures</h1>
      <p style="font-size: 15px; line-height: 1.8; color: #d1d5db;">Detailed information about user privacy, log file analytics, and European GDPR data protection compliance.</p>
    </article>`;
  }

  // 13. TERMS OF SERVICE
  else if (cleanPath === '/terms') {
    pageTitle = 'Terms of Service & User Usage Agreement | MooFlix';
    metaDescription = 'Terms of service, user agreements, acceptable conduct, and disclaimers for using the mooflix.online streaming protocol.';
    bodyContentHtml = `
    <article style="max-width: 900px; margin: 0 auto; padding: 48px 20px;">
      <h1 style="font-size: 36px; font-weight: 900; color: #ffffff; margin-bottom: 16px;">Terms of Service</h1>
      <p style="font-size: 15px; line-height: 1.8; color: #d1d5db;">User agreement and conditions governing access to MooFlix cinema indexation services.</p>
    </article>`;
  }

  // 14. CONTACT PAGE
  else if (cleanPath === '/contact') {
    pageTitle = 'Contact MooFlix - Editorial & Support Desk | mooflix.online';
    metaDescription = 'Contact the MooFlix editorial team, submit movie review requests, partnership inquiries, or copyright notices.';
    bodyContentHtml = `
    <article style="max-width: 900px; margin: 0 auto; padding: 48px 20px;">
      <h1 style="font-size: 36px; font-weight: 900; color: #ffffff; margin-bottom: 16px;">Contact MooFlix Support &amp; Editorial</h1>
      <p style="font-size: 15px; line-height: 1.8; color: #d1d5db;">Email: contact@mooflix.online | Legal &amp; DMCA: legal@mooflix.online | Telegram: @MooFlixOfficial</p>
    </article>`;
  }

  // 15. LIVE SPORTS
  else if (cleanPath === '/sports' || cleanPath === '/sport' || cleanPath === '/live') {
    pageTitle = 'Watch Live Sports, Cricket & Football Free HD | MooFlix';
    metaDescription = 'Stream live cricket, IPL, football, UFC, Formula 1, and international sports channels on MooFlix in HD with zero ads and automatic server failover.';
    jsonLd = {
      "@context": "https://schema.org",
      "@type": "CollectionPage",
      "name": "MooFlix Live Sports Arena",
      "description": metaDescription,
      "url": canonicalUrl,
      "isPartOf": {
        "@type": "WebSite",
        "name": "MooFlix",
        "url": "https://mooflix.online/"
      }
    };
    bodyContentHtml = `
    <div style="max-width: 1200px; margin: 0 auto; padding: 48px 20px;">
      <h1 style="font-size: 36px; font-weight: 900; color: #ffffff; margin-bottom: 12px;">Live Sports &amp; Match Arena</h1>
      <p style="font-size: 16px; color: #9ca3af; margin-bottom: 32px;">Stream live cricket, football, motorsport, combat sports, and 24/7 sports broadcasters on MooFlix with zero ads and automatic Server 1/2/3 failover.</p>
      <div style="display: flex; gap: 12px; flex-wrap: wrap;">
        <a href="/movies" style="color: #e50914; font-weight: 700; text-decoration: none;">Explore Movies &rarr;</a>
        <a href="/series" style="color: #e50914; font-weight: 700; text-decoration: none;">Explore TV Series &rarr;</a>
      </div>
    </div>`;
  }

  // 16. WATCHLIST
  else if (cleanPath === '/watchlist') {
    pageTitle = 'My Cinema Watchlist & Saved Titles | MooFlix';
    metaDescription = 'Access your personal saved movies and TV shows on MooFlix. Saved locally with instant resume.';
    bodyContentHtml = `
    <div style="max-width: 1200px; margin: 0 auto; padding: 48px 20px;">
      <h1 style="font-size: 36px; font-weight: 900; color: #ffffff; margin-bottom: 16px;">My Watchlist</h1>
      <p style="font-size: 15px; color: #9ca3af;">Your saved movies and web series.</p>
    </div>`;
  }

  // Apply substitutions to template
  let finalHtml = templateHtml;

  // 1. Title
  finalHtml = finalHtml.replace(/<title>.*?<\/title>/i, `<title>${pageTitle}</title>`);

  // 2. Meta description
  finalHtml = finalHtml.replace(/<meta\s+name=["']description["']\s+content=["'].*?["']\s*\/?>/i, `<meta name="description" content="${metaDescription}">`);

  // 3. Canonical URL
  finalHtml = finalHtml.replace(/<link\s+rel=["']canonical["']\s+href=["'].*?["']\s*\/?>/i, `<link rel="canonical" href="${canonicalUrl}">`);

  // 4. OpenGraph tags
  finalHtml = finalHtml.replace(/<meta\s+property=["']og:url["']\s+content=["'].*?["']\s*\/?>/i, `<meta property="og:url" content="${canonicalUrl}">`);
  finalHtml = finalHtml.replace(/<meta\s+property=["']og:title["']\s+content=["'].*?["']\s*\/?>/i, `<meta property="og:title" content="${pageTitle}">`);
  finalHtml = finalHtml.replace(/<meta\s+property=["']og:description["']\s+content=["'].*?["']\s*\/?>/i, `<meta property="og:description" content="${metaDescription}">`);
  if (ogImage) {
    finalHtml = finalHtml.replace(/<meta\s+property=["']og:image["']\s+content=["'].*?["']\s*\/?>/i, `<meta property="og:image" content="${ogImage}">`);
  }

  // 5. Twitter Card tags
  finalHtml = finalHtml.replace(/<meta\s+name=["']twitter:title["']\s+content=["'].*?["']\s*\/?>/i, `<meta name="twitter:title" content="${pageTitle}">`);
  finalHtml = finalHtml.replace(/<meta\s+name=["']twitter:description["']\s+content=["'].*?["']\s*\/?>/i, `<meta name="twitter:description" content="${metaDescription}">`);
  if (ogImage) {
    finalHtml = finalHtml.replace(/<meta\s+name=["']twitter:image["']\s+content=["'].*?["']\s*\/?>/i, `<meta name="twitter:image" content="${ogImage}">`);
  }

  // 6. Inject Schema.org JSON-LD if present
  if (jsonLd) {
    const jsonLdTag = `\n  <script type="application/ld+json">\n${JSON.stringify(jsonLd, null, 2)}\n  </script>`;
    finalHtml = finalHtml.replace('</head>', `${jsonLdTag}\n</head>`);
  }

  // 7. Inject specific body content inside <div id="root"> if we have custom HTML for this route
  if (bodyContentHtml && cleanPath !== '/') {
    const fullBodyHtml = `
  <div id="root">
    <!-- Static Semantic Crawl Payload for Search Engine Indexation -->
    <div style="background-color: #050508; color: #ffffff; min-height: 100vh; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;">
      <header style="border-bottom: 1px solid rgba(255,255,255,0.1); padding: 16px 24px; display: flex; align-items: center; justify-content: space-between; max-width: 1400px; margin: 0 auto;">
        <a href="/" style="color: #e50914; font-weight: 900; font-size: 26px; text-decoration: none;">MOOFLIX</a>
        <nav style="display: flex; gap: 20px; font-size: 14px; font-weight: 600;">
          <a href="/" style="color: #d1d5db; text-decoration: none;">Home</a>
          <a href="/movies" style="color: #d1d5db; text-decoration: none;">Movies</a>
          <a href="/series" style="color: #d1d5db; text-decoration: none;">TV Series</a>
          <a href="/anime" style="color: #d1d5db; text-decoration: none;">Anime</a>
          <a href="/sports" style="color: #d1d5db; text-decoration: none;">Live Sports</a>
          <a href="/blogs" style="color: #d1d5db; text-decoration: none;">Cinema Blogs</a>
          <a href="/sitemap" style="color: #d1d5db; text-decoration: none;">Sitemap</a>
        </nav>
      </header>
      <main>
        ${bodyContentHtml}
      </main>
      <footer style="border-top: 1px solid rgba(255,255,255,0.08); padding: 32px 24px; text-align: center; color: #6b7280; font-size: 13px; margin-top: 60px;">
        <p>&copy; 2026 MooFlix (mooflix.online). All rights reserved.</p>
        <div style="display: flex; justify-content: center; gap: 16px; margin-top: 8px; flex-wrap: wrap;">
          <a href="/about" style="color: #9ca3af; text-decoration: none;">About</a>
          <a href="/dmca" style="color: #9ca3af; text-decoration: none;">DMCA</a>
          <a href="/privacy" style="color: #9ca3af; text-decoration: none;">Privacy Policy</a>
          <a href="/terms" style="color: #9ca3af; text-decoration: none;">Terms of Service</a>
          <a href="/contact" style="color: #9ca3af; text-decoration: none;">Contact</a>
          <a href="/sitemap" style="color: #9ca3af; text-decoration: none;">HTML Sitemap</a>
          <a href="/sitemap.xml" target="_blank" style="color: #9ca3af; text-decoration: none;">Sitemap XML</a>
        </div>
      </footer>
    </div>
  </div>`;

    // Replace the root div
    finalHtml = finalHtml.replace(/<div id=["']root["']>[\s\S]*?<\/div>\s*<script/i, `${fullBodyHtml}\n  <script`);
  }

  return finalHtml;
}
