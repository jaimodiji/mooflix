import { ContentItem, ExtendedDetails, Genre, CastMember, Episode } from '../types';
import { correctSearchSpelling } from './searchSpellCorrection';


const API_KEY = 'f4c3361d4917e9f25f79f339356eb8d9'; 
const BASE_URL = 'https://api.themoviedb.org/3';
const IMAGE_BASE = 'https://image.tmdb.org/t/p';
const LANGUAGE = 'en-US';

export const getTodayDate = (): string => {
  return new Date().toISOString().split('T')[0];
};

export const getDateDaysAgo = (days: number): string => {
  const d = new Date();
  d.setDate(d.getDate() - days);
  return d.toISOString().split('T')[0];
};

const handleResponse = async (response: Response) => {
  if (!response.ok) {
    const errorData = await response.json().catch(() => ({}));
    const message = errorData.status_message || `Request failed with status ${response.status}`;
    throw new Error(message);
  }
  return response.json();
};

// Adaptive Network Quality Detection (2G, 3G, SaveData)
export const isSlowNetwork = (): boolean => {
  if (typeof navigator !== 'undefined' && 'connection' in navigator) {
    const conn = (navigator as any).connection;
    if (conn) {
      if (conn.saveData) return true;
      if (conn.effectiveType === '2g' || conn.effectiveType === 'slow-2g' || conn.effectiveType === '3g') {
        return true;
      }
    }
  }
  return false;
};

// High-Speed Memory & Session Cache (TTL: 10 minutes)
interface CacheEntry {
  data: any;
  timestamp: number;
}
const memoryCache = new Map<string, CacheEntry>();
const CACHE_TTL_MS = 10 * 60 * 1000; // 10 minutes

// Collision-Free Cache Key Generator (combines API path and full-URL hash to prevent collisions)
const getCacheKey = (url: string): string => {
  let hash = 5381;
  for (let i = 0; i < url.length; i++) {
    hash = ((hash << 5) + hash) + url.charCodeAt(i);
  }
  const hashStr = (hash >>> 0).toString(36);
  const pathPart = url.split('?')[0].replace(/https?:\/\/[^/]+/i, '').replace(/[^a-zA-Z0-9]/g, '_').slice(-30);
  return `moo_c4_${pathPart}_${hashStr}`;
};

export const cachedFetch = async (url: string): Promise<any> => {
  const now = Date.now();
  const cached = memoryCache.get(url);
  if (cached && (now - cached.timestamp < CACHE_TTL_MS)) {
    return cached.data;
  }

  const sessionKey = getCacheKey(url);
  try {
    const stored = sessionStorage.getItem(sessionKey);
    if (stored) {
      const parsed = JSON.parse(stored);
      if (parsed && (now - parsed.timestamp < CACHE_TTL_MS)) {
        memoryCache.set(url, parsed);
        return parsed.data;
      }
    }
  } catch {}

  let response = await fetch(url);
  if (!response.ok && (response.status === 429 || response.status === 401)) {
    const backupKeys = ['8265bd1679663a7ea12ac168da84d2e8', '2e11893d5f3089694d21ee6ff8c5120a'];
    for (const bKey of backupKeys) {
      const fallbackUrl = url.replace(/api_key=[^&]+/, `api_key=${bKey}`);
      try {
        const fallbackRes = await fetch(fallbackUrl);
        if (fallbackRes.ok) {
          response = fallbackRes;
          break;
        }
      } catch {}
    }
  }

  const data = await handleResponse(response);
  memoryCache.set(url, { data, timestamp: now });

  try {
    sessionStorage.setItem(sessionKey, JSON.stringify({ data, timestamp: now }));
  } catch {}

  return data;
};

// Comprehensive adult / 18+ content regex filter
const ADULT_REGEX = /(^|\b)(porn|porno|pornography|xxx|hentai|erotica|erotic|sex tape|gangbang|hardcore sex|softcore|camgirl|adult film|playboy|penthouse|brazzers|bangbros|nudity|milf|onlyfans|red light district|adult video|erotic movie|blowjob|deepthroat|cumshot|fetish|bdsm)(\b|$)/i;

export const isItemAdult = (item: any): boolean => {
  if (!item) return false;
  // 1. Explicit TMDB adult flag
  if (item.adult === true) return true;
  
  // 2. Title & Original Title checks
  const title = String(item.title || item.name || '').trim();
  const originalTitle = String(item.original_title || item.original_name || '').trim();
  if (ADULT_REGEX.test(title) || ADULT_REGEX.test(originalTitle)) {
    return true;
  }

  // 3. Overview / Description check for explicit pornography
  const overview = String(item.overview || item.description || '').trim();
  if (ADULT_REGEX.test(overview)) {
    return true;
  }

  return false;
};

export const isItemReleased = (item: any): boolean => {
  if (!item || !item.id) return false;
  // STRICT: Filter out all adult titles
  if (isItemAdult(item)) return false;
  if (!item.title && !item.name) return false;
  if (!item.poster_path && !item.backdrop_path && !item.poster && !item.thumbnail) return false;
  
  const today = getTodayDate();
  const releaseDate = item.release_date || item.first_air_date || item.releaseDateText;

  if (releaseDate && typeof releaseDate === 'string') {
    const dateStr = releaseDate.split('T')[0];
    if (/^\d{4}-\d{2}-\d{2}$/.test(dateStr)) {
      if (dateStr > today) return false;
    } else {
      const parsed = new Date(releaseDate);
      if (!isNaN(parsed.getTime()) && parsed.getTime() > Date.now()) return false;
    }
  } else if (item.year) {
    const currentYear = new Date().getFullYear();
    if (Number(item.year) > currentYear) return false;
  }

  // Filter out unreleased/production statuses
  if (item.status && ['In Production', 'Post Production', 'Planned', 'Announced', 'Upcoming'].includes(item.status)) {
    return false;
  }

  return true;
};

export const isItemUpcoming = (item: any): boolean => {
  if (!item || !item.id) return false;
  if (isItemAdult(item)) return false;
  const today = getTodayDate();
  const releaseDate = item.release_date || item.first_air_date || item.releaseDateText;

  if (releaseDate && typeof releaseDate === 'string') {
    const dateStr = releaseDate.split('T')[0];
    if (/^\d{4}-\d{2}-\d{2}$/.test(dateStr)) {
      if (dateStr > today) return true;
    } else {
      const parsed = new Date(releaseDate);
      if (!isNaN(parsed.getTime()) && parsed.getTime() > Date.now()) return true;
    }
  }

  if (item.year && Number(item.year) > new Date().getFullYear()) {
    return true;
  }

  if (item.status && ['In Production', 'Post Production', 'Planned', 'Announced', 'Upcoming'].includes(item.status)) {
    return true;
  }

  return false;
};

export const isValidSearchItem = (item: any): boolean => {
  if (!item || !item.id) return false;
  // STRICT: Filter out all adult titles
  if (isItemAdult(item)) return false;
  if (!item.title && !item.name) return false;
  return true;
};

// Comprehensive detector for Indian daily broadcast TV serials / saas-bahu soaps / talk shows / reality soaps
// User explicit requirement: "series dikhao na ki serial, serial nhi dikhana h please"
const INDIAN_SERIAL_PATTERNS = [
  /\bc\.?i\.?d\.?\b/i,
  /\btaarak\s*mehta\b/i,
  /\banupama+a?\b/i,
  /\byeh\s*rishta\b/i,
  /\bkundali\s*bhagya\b/i,
  /\bkumkum\s*bhagya\b/i,
  /\bbigg\s*boss\b/i,
  /\bcrime\s*patrol\b/i,
  /\bsavdhaan\b/i,
  /\bsaath\s*nibha+na\b/i,
  /\bkyunki\s*saas\b/i,
  /\bkaha+ni\s*ghar\b/i,
  /\bdiya\s*aur\s*baati\b/i,
  /\bkasautii\b/i,
  /\bbalika\s*vadhu\b/i,
  /\bnaagin\b/i,
  /\bsasural\s*simar\b/i,
  /\budaariya+n\b/i,
  /\bteri\s*meri\s*doriya+n\b/i,
  /\bfaltu\b/i,
  /\bghum\s*hai\b/i,
  /\bimlie\b/i,
  /\bpandya\s*store\b/i,
  /\byeh\s*hai\s*chahatein\b/i,
  /\bbhagya\s*lakshmi\b/i,
  /\bradhakrishn\b/i,
  /\bcomedy\s*nights\b/i,
  /\bkapil\s*sharma\b/i,
  /\blaughter\s*chefs\b/i,
  /\bbharaghar\b/i,
  /\bpaaru\b/i,
  /\bshravani\b/i,
  /\bcharmsukh\b/i,
  /\bpalang\s*tod\b/i,
  /\bboron\b/i,
  /\bsohag\s*chand\b/i,
  /\bgrihoprobesh\b/i,
  /\bkanaa\b/i,
  /\bjhanak\b/i,
  /\bpherari\s*mon\b/i,
  /\bkaala\s*teeka\b/i,
  /\bshagun\b/i,
  /\bkavyanjali\b/i,
  /\bparineetii\b/i,
  /\bjunooniyatt\b/i,
  /\bchoti\s*sarrda+rni\b/i,
  /\bbarrister\s*babu\b/i,
  /\bmolkki\b/i,
  /\bbepannah\b/i,
  /\bishqbaaz\b/i,
  /\buttaran\b/i,
  /\bpavitra\s*rishta\b/i,
  /\bye\s*hai\s*mohabbatein\b/i,
  /\bishq\s*mein\s*marjawan\b/i,
  /\bx\.?x\.?x\b/i,
  /\buncensored\b/i,
  /\bullu\b/i,
  /\bmahabharat\b/i,
  /\bramayan\b/i,
  /\bshaka\s*laka\b/i,
  /\bmotu\s*patlu\b/i,
  /\bhatim\b/i,
  /\bshaktimaan\b/i,
  /\bqubool\s*hai\b/i,
  /\bpunar\s*vivaah\b/i,
  /\bmadhubala\b/i,
  /\bsapne\s*suhane\b/i,
  /\bhitler\s*didi\b/i,
  /\bantarvasna\b/i
];

export const isIndianSerial = (item: any): boolean => {
  if (!item) return false;
  // 1. Check explicit TMDB Soap (10766), Talk (10767), Reality (10764), News (10763), Kids animation (10762)
  const genreIds: number[] = item.genre_ids || (item.genres ? item.genres.map((g: any) => g.id) : []) || [];
  if (genreIds.some(id => [10766, 10767, 10764, 10763, 10762].includes(id))) {
    return true;
  }
  
  // 2. Title & original name pattern match
  const name = String(item.name || item.title || '').trim();
  const originalName = String(item.original_name || item.original_title || '').trim();
  if (INDIAN_SERIAL_PATTERNS.some(p => p.test(name) || p.test(originalName))) {
    return true;
  }

  // 3. Overview keyword check
  const overview = String(item.overview || item.description || '').toLowerCase();
  if (
    overview.includes('daily soap') ||
    overview.includes('television soap opera') ||
    overview.includes('indian soap opera') ||
    overview.includes('daily television series')
  ) {
    return true;
  }

  return false;
};

// Curated canonical top Indian OTT web series IDs for guaranteed prestige list
export const TOP_INDIAN_WEB_SERIES_IDS: number[] = [
  84105,  // Mirzapur
  101352, // Panchayat
  93352,  // The Family Man
  79352,  // Sacred Games
  132117, // Farzi
  100911, // Asur
  111188, // Scam 1992: The Harshad Mehta Story
  103051, // Paatal Lok
  89113,  // Kota Factory
  156714, // Guns & Gulaabs
  87508,  // Delhi Crime
  156716, // Heeramandi: The Diamond Bazaar
  228943, // The Railway Men
  87407,  // Made in Heaven
  120998, // Special OPS
  218768, // Kohrra
  209736  // Taaza Khabar
];

const mapToContentItem = (item: any): ContentItem => {
  const releaseDate = item.release_date || item.first_air_date;
  const isSeries = item.media_type 
    ? (item.media_type === 'tv' || item.media_type === 'series')
    : Boolean(item.first_air_date || (item.name && !item.title));
  let badge = item.badge;
  let badgeType = item.badgeType;
  
  if (!badge && releaseDate) {
    const release = new Date(releaseDate);
    const now = new Date();
    const diffTime = Math.abs(now.getTime() - release.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays <= 14 && release <= now) {
      if (isSeries) {
        badge = 'New Episode Added';
        badgeType = 'new_episode';
      } else {
        badge = 'New Release';
        badgeType = 'new_release';
      }
    }
  }

  const slow = isSlowNetwork();
  const posterSize = slow ? 'w342' : 'w500';
  const backdropSize = slow ? 'w780' : 'w1280';

  const posterUrl = item.poster_path ? `${IMAGE_BASE}/${posterSize}${item.poster_path}` : (item.poster || item.thumbnail || 'https://via.placeholder.com/500x750?text=No+Poster');

  return {
    id: item.id?.toString() || Math.random().toString(36).substr(2, 9),
    tmdbId: item.id || undefined,
    title: item.title || item.name || 'Untitled',
    description: item.overview || 'No description available.',
    thumbnail: posterUrl,
    poster: posterUrl,
    backdrop: item.backdrop_path ? `${IMAGE_BASE}/${backdropSize}${item.backdrop_path}` : (item.poster_path ? `${IMAGE_BASE}/${backdropSize}${item.poster_path}` : (item.poster || 'https://via.placeholder.com/1280x720?text=Moflix')),
    rating: item.vote_average ? item.vote_average.toFixed(1) : (item.rating ? item.rating.toString() : 'N/A'),
    year: new Date(releaseDate || 'N/A').getFullYear() || item.year || 0,
    type: item.type ? item.type : (isSeries ? 'series' : 'movie'),
    badge,
    badgeType,
    releaseDateText: releaseDate,
    imdbId: item.imdb_id || item.external_ids?.imdb_id || item.imdbId || null,
    imdbRating: item.imdbRating || (item.vote_average ? item.vote_average.toFixed(1) : undefined),
    popularity: item.popularity || 0,
    voteCount: item.vote_count || 0
  };
};

export const fetchTrending = async (page = 1): Promise<ContentItem[]> => {
  try {
    const data = await cachedFetch(`${BASE_URL}/trending/all/week?api_key=${API_KEY}&language=${LANGUAGE}&page=${page}`);
    return (data.results || [])
      .filter(isItemReleased)
      .map(mapToContentItem);
  } catch (err) {
    console.error('fetchTrending failed:', err);
    return [];
  }
};

export const fetchTrendingMovies = async (page = 1): Promise<ContentItem[]> => {
  try {
    const data = await cachedFetch(`${BASE_URL}/trending/movie/week?api_key=${API_KEY}&language=${LANGUAGE}&page=${page}`);
    return (data.results || [])
      .filter(isItemReleased)
      .filter((i: any) => !isIndianSerial(i))
      .map((i: any) => ({
        ...mapToContentItem({ ...i, media_type: 'movie', type: 'movie' }),
        type: 'movie' as const
      }))
      .filter(item => item.type === 'movie' && !item.first_air_date);
  } catch (err) {
    console.error('fetchTrendingMovies failed:', err);
    return [];
  }
};

export const fetchTrendingSeries = async (page = 1): Promise<ContentItem[]> => {
  try {
    const data = await cachedFetch(`${BASE_URL}/trending/tv/week?api_key=${API_KEY}&language=${LANGUAGE}&page=${page}`);
    return (data.results || [])
      .filter(isItemReleased)
      .filter(i => !isIndianSerial(i))
      .map((i: any) => ({
        ...mapToContentItem({ ...i, media_type: 'tv', type: 'series' }),
        type: 'series' as const
      }))
      .filter(item => item.type === 'series');
  } catch (err) {
    console.error('fetchTrendingSeries failed:', err);
    return [];
  }
};

export const fetchTop10Movies = async (page = 1): Promise<ContentItem[]> => {
  try {
    const today = getTodayDate();
    const [d1, d2] = await Promise.all([
      cachedFetch(`${BASE_URL}/discover/movie?api_key=${API_KEY}&language=${LANGUAGE}&region=IN&with_origin_country=IN&primary_release_date.lte=${today}&sort_by=popularity.desc&page=${page}&include_adult=false`),
      cachedFetch(`${BASE_URL}/discover/movie?api_key=${API_KEY}&language=${LANGUAGE}&with_original_language=hi|te|ta|ml|kn&primary_release_date.lte=${today}&sort_by=popularity.desc&page=${page}&include_adult=false`)
    ]);

    const seen = new Set<number>();
    const combined: any[] = [];
    const r1 = (d1.results || []).filter(isItemReleased).filter((i: any) => !isIndianSerial(i));
    const r2 = (d2.results || []).filter(isItemReleased).filter((i: any) => !isIndianSerial(i));

    for (let i = 0; i < Math.max(r1.length, r2.length); i++) {
      if (r1[i] && !seen.has(r1[i].id)) {
        seen.add(r1[i].id);
        combined.push(r1[i]);
      }
      if (r2[i] && !seen.has(r2[i].id)) {
        seen.add(r2[i].id);
        combined.push(r2[i]);
      }
    }

    return combined
      .slice(0, page === 1 ? 10 : 20)
      .map((i: any) => ({
        ...mapToContentItem({ ...i, media_type: 'movie', type: 'movie' }),
        type: 'movie' as const
      }))
      .filter(item => item.type === 'movie');
  } catch (err) {
    console.error('fetchTop10Movies failed:', err);
    return [];
  }
};

export const fetchTop10Series = async (page = 1): Promise<ContentItem[]> => {
  try {
    const today = getTodayDate();
    
    // For page 1, fetch top prestige Indian web series (Mirzapur, Panchayat, Sacred Games, The Family Man, Farzi, etc.)
    if (page === 1) {
      const topIdsToFetch = TOP_INDIAN_WEB_SERIES_IDS.slice(0, 10);
      try {
        const curatedPromises = topIdsToFetch.map(id =>
          cachedFetch(`${BASE_URL}/tv/${id}?api_key=${API_KEY}&language=${LANGUAGE}`).catch(() => null)
        );
        const curatedResults = await Promise.all(curatedPromises);
        const validCurated = curatedResults
          .filter(Boolean)
          .filter(isItemReleased)
          .filter(i => !isIndianSerial(i))
          .map((i: any) => ({
            ...mapToContentItem({ ...i, media_type: 'tv', type: 'series' }),
            type: 'series' as const
          }));
        
        if (validCurated.length >= 8) {
          return validCurated.slice(0, 10);
        }
      } catch (err) {
        console.warn('Curated top 10 series fetch warning:', err);
      }
    }

    // Dynamic discovery of Indian Web Series (strictly without daily soaps, talk shows, news, reality)
    const [popData, topData] = await Promise.all([
      cachedFetch(`${BASE_URL}/discover/tv?api_key=${API_KEY}&language=${LANGUAGE}&with_origin_country=IN&without_genres=10766,10767,10764,10763,10762&vote_count.gte=15&vote_average.gte=6.5&sort_by=popularity.desc&page=${page}&include_adult=false`),
      cachedFetch(`${BASE_URL}/discover/tv?api_key=${API_KEY}&language=${LANGUAGE}&with_origin_country=IN&without_genres=10766,10767,10764,10763,10762&vote_count.gte=25&sort_by=vote_count.desc&page=${page}&include_adult=false`)
    ]);

    const seen = new Set<number>();
    const combined: any[] = [];
    const popList = (popData.results || []).filter(isItemReleased).filter((i: any) => !isIndianSerial(i));
    const topList = (topData.results || []).filter(isItemReleased).filter((i: any) => !isIndianSerial(i));

    for (let i = 0; i < Math.max(popList.length, topList.length); i++) {
      if (topList[i] && !seen.has(topList[i].id)) {
        seen.add(topList[i].id);
        combined.push(topList[i]);
      }
      if (popList[i] && !seen.has(popList[i].id)) {
        seen.add(popList[i].id);
        combined.push(popList[i]);
      }
    }

    return combined
      .slice(0, page === 1 ? 10 : 20)
      .map((i: any) => ({
        ...mapToContentItem({ ...i, media_type: 'tv', type: 'series' }),
        type: 'series' as const
      }))
      .filter(item => item.type === 'series' && !isIndianSerial(item));
  } catch (err) {
    console.error('fetchTop10Series failed:', err);
    return [];
  }
};

export const fetchRecentReleases = async (): Promise<ContentItem[]> => {
  const today = getTodayDate();
  const twoWeeksAgo = getDateDaysAgo(14);

  // Discover movies released in last 14 days
  const moviesUrl = `${BASE_URL}/discover/movie?api_key=${API_KEY}&language=${LANGUAGE}&sort_by=popularity.desc&primary_release_date.gte=${twoWeeksAgo}&primary_release_date.lte=${today}&page=1&include_adult=false`;
  
  // Discover TV shows airing in last 14 days (new episodes or series)
  const tvUrl = `${BASE_URL}/discover/tv?api_key=${API_KEY}&language=${LANGUAGE}&sort_by=popularity.desc&air_date.gte=${twoWeeksAgo}&air_date.lte=${today}&page=1&include_adult=false`;

  try {
    const [mRes, tRes] = await Promise.all([
      fetch(moviesUrl),
      fetch(tvUrl)
    ]);

    const [mData, tData] = await Promise.all([
      handleResponse(mRes),
      handleResponse(tRes)
    ]);

    const recentMovies: ContentItem[] = (mData.results || [])
      .filter(isItemReleased)
      .map((item: any) => ({
        ...mapToContentItem({ ...item, media_type: 'movie' }),
        badge: 'New Release',
        badgeType: 'new_release',
        releaseDateText: item.release_date
      }));

    const recentTV: ContentItem[] = (tData.results || [])
      .filter(isItemReleased)
      .map((item: any) => {
        const isBrandNew = item.first_air_date && item.first_air_date >= twoWeeksAgo;
        return {
          ...mapToContentItem({ ...item, media_type: 'tv' }),
          badge: isBrandNew ? 'New Series' : 'New Episode Added',
          badgeType: isBrandNew ? 'new_release' : 'new_episode',
          releaseDateText: item.first_air_date
        };
      });

    const combined: ContentItem[] = [];
    const maxLen = Math.max(recentTV.length, recentMovies.length);
    for (let i = 0; i < maxLen; i++) {
      if (recentTV[i]) combined.push(recentTV[i]);
      if (recentMovies[i]) combined.push(recentMovies[i]);
    }

    return combined.slice(0, 20);
  } catch (err) {
    console.error('Error fetching recent releases:', err);
    return [];
  }
};

export const fetchMovies = async (page = 1, genreId?: number | string): Promise<ContentItem[]> => {
  try {
    const today = getTodayDate();
    let queryParam = '';
    
    if (genreId) {
      if (typeof genreId === 'string' && genreId.startsWith('lang_')) {
        const langCode = genreId.replace('lang_', '');
        if (langCode === 'ta_te') {
          queryParam = `&with_original_language=ta|te|ml|kn`;
        } else {
          queryParam = `&with_original_language=${langCode}`;
        }
      } else {
        queryParam = `&with_genres=${genreId}`;
      }
    }

    const url = `${BASE_URL}/discover/movie?api_key=${API_KEY}&language=${LANGUAGE}&sort_by=popularity.desc&page=${page}&primary_release_date.lte=${today}${queryParam}&include_adult=false`;
    const response = await fetch(url);
    const data = await handleResponse(response);
    return (data.results || [])
      .filter(isItemReleased)
      .map((i: any) => mapToContentItem({ ...i, media_type: 'movie' }));
  } catch (err) {
    console.error('fetchMovies failed:', err);
    return [];
  }
};

export const fetchTVShows = async (page = 1, genreId?: number | string): Promise<ContentItem[]> => {
  try {
    const today = getTodayDate();
    let queryParam = '';
    
    if (genreId) {
      if (typeof genreId === 'string' && genreId.startsWith('lang_')) {
        const langCode = genreId.replace('lang_', '');
        if (langCode === 'ta_te') {
          queryParam = `&with_original_language=ta|te|ml|kn`;
        } else {
          queryParam = `&with_original_language=${langCode}`;
        }
      } else {
        queryParam = `&with_genres=${genreId}`;
      }
    }

    const url = `${BASE_URL}/discover/tv?api_key=${API_KEY}&language=${LANGUAGE}&sort_by=popularity.desc&page=${page}&first_air_date.lte=${today}${queryParam}&include_adult=false`;
    const response = await fetch(url);
    const data = await handleResponse(response);
    return (data.results || [])
      .filter(isItemReleased)
      .map((i: any) => mapToContentItem({ ...i, media_type: 'tv' }));
  } catch (err) {
    console.error('fetchTVShows failed:', err);
    return [];
  }
};

export const fetchAnime = async (page = 1, genreId?: number | string): Promise<ContentItem[]> => {
  try {
    const today = getTodayDate();
    const genreFilter = genreId && genreId !== 'all' ? `,${genreId}` : '';
    // Query Japanese animation strictly so Anime page only contains true Anime, not Western cartoons
    const [tvRes, movieRes] = await Promise.all([
      fetch(`${BASE_URL}/discover/tv?api_key=${API_KEY}&with_genres=16${genreFilter}&with_original_language=ja&language=${LANGUAGE}&sort_by=popularity.desc&page=${page}&first_air_date.lte=${today}&include_adult=false`),
      fetch(`${BASE_URL}/discover/movie?api_key=${API_KEY}&with_genres=16${genreFilter}&with_original_language=ja&language=${LANGUAGE}&sort_by=popularity.desc&page=${page}&primary_release_date.lte=${today}&include_adult=false`)
    ]);

    const [tvData, movieData] = await Promise.all([
      handleResponse(tvRes).catch(() => ({ results: [] })),
      handleResponse(movieRes).catch(() => ({ results: [] }))
    ]);

    const isTrueAnime = (item: any): boolean => {
      if (!item) return false;
      const lang = String(item.original_language || '').toLowerCase();
      const countries: string[] = Array.isArray(item.origin_country) ? item.origin_country : [];
      return lang === 'ja' || countries.includes('JP');
    };

    const combined = [
      ...(tvData.results || []).map((i: any) => ({ ...i, media_type: 'tv' })),
      ...(movieData.results || []).map((i: any) => ({ ...i, media_type: 'movie' }))
    ]
      .filter(isTrueAnime)
      .sort((a, b) => (b.popularity || 0) - (a.popularity || 0));

    return combined
      .filter(isItemReleased)
      .map(mapToContentItem);
  } catch (err) {
    console.error('fetchAnime failed:', err);
    return [];
  }
};

export const fetchSports = async (page = 1, genreId?: number | string): Promise<ContentItem[]> => {
  try {
    const today = getTodayDate();
    const [movieRes, tvRes] = await Promise.all([
      fetch(`${BASE_URL}/discover/movie?api_key=${API_KEY}&with_keywords=6075${genreId && genreId !== 'all' ? `&with_genres=${genreId}` : ''}&language=${LANGUAGE}&sort_by=popularity.desc&page=${page}&primary_release_date.lte=${today}&include_adult=false`),
      fetch(`${BASE_URL}/discover/tv?api_key=${API_KEY}&with_keywords=6075${genreId && genreId !== 'all' ? `&with_genres=${genreId}` : ''}&language=${LANGUAGE}&sort_by=popularity.desc&page=${page}&first_air_date.lte=${today}&include_adult=false`)
    ]);

    const [movieData, tvData] = await Promise.all([
      handleResponse(movieRes).catch(() => ({ results: [] })),
      handleResponse(tvRes).catch(() => ({ results: [] }))
    ]);

    const combined = [
      ...(movieData.results || []).map((i: any) => ({ ...i, media_type: 'movie' })),
      ...(tvData.results || []).map((i: any) => ({ ...i, media_type: 'tv' }))
    ].sort((a, b) => (b.popularity || 0) - (a.popularity || 0));

    return combined
      .filter(isItemReleased)
      .map(mapToContentItem);
  } catch (err) {
    console.error('fetchSports failed:', err);
    return [];
  }
};

const GENRE_NAME_MAP: Record<string | number, string> = {
  28: 'Action',
  12: 'Adventure',
  16: 'Animation',
  35: 'Comedy',
  80: 'Crime',
  18: 'Drama',
  10751: 'Family',
  14: 'Fantasy',
  36: 'History',
  27: 'Horror',
  10402: 'Music',
  9648: 'Mystery',
  10749: 'Romance',
  878: 'Sci-Fi',
  53: 'Thriller',
  10752: 'War',
  37: 'Western',
  99: 'Documentary',
};

export const fetchContentByGenre = async (
  genreId: number | string, 
  page = 1,
  mediaType: 'all' | 'movie' | 'tv' = 'all'
): Promise<ContentItem[]> => {
  try {
    const cleanId = typeof genreId === 'string' && genreId.includes(',') ? genreId.split(',')[0] : genreId;
    const today = getTodayDate();
    
    if (mediaType === 'movie') {
      const res = await fetch(`${BASE_URL}/discover/movie?api_key=${API_KEY}&with_genres=${genreId}&language=${LANGUAGE}&sort_by=popularity.desc&page=${page}&primary_release_date.lte=${today}&include_adult=false`);
      const data = await handleResponse(res);
      return (data.results || []).filter(isItemReleased).map((i: any) => mapToContentItem({ ...i, media_type: 'movie' }));
    }
    
    if (mediaType === 'tv') {
      const res = await fetch(`${BASE_URL}/discover/tv?api_key=${API_KEY}&with_genres=${genreId}&language=${LANGUAGE}&sort_by=popularity.desc&page=${page}&first_air_date.lte=${today}&include_adult=false`);
      const data = await handleResponse(res);
      return (data.results || []).filter(isItemReleased).map((i: any) => mapToContentItem({ ...i, media_type: 'tv' }));
    }

    const [mRes, tRes] = await Promise.all([
      fetch(`${BASE_URL}/discover/movie?api_key=${API_KEY}&with_genres=${genreId}&language=${LANGUAGE}&sort_by=popularity.desc&page=${page}&primary_release_date.lte=${today}&include_adult=false`),
      fetch(`${BASE_URL}/discover/tv?api_key=${API_KEY}&with_genres=${genreId}&language=${LANGUAGE}&sort_by=popularity.desc&page=${page}&first_air_date.lte=${today}&include_adult=false`)
    ]);
    
    const [mData, tData] = await Promise.all([handleResponse(mRes), handleResponse(tRes)]);
    
    const combined = [
      ...(mData.results || []).map((i: any) => ({...i, media_type: 'movie'})),
      ...(tData.results || []).map((i: any) => ({...i, media_type: 'tv'}))
    ].sort((a, b) => b.popularity - a.popularity);

    return combined
      .filter(isItemReleased)
      .map(mapToContentItem);
  } catch (err) {
    console.error(`fetchContentByGenre (${genreId}) failed:`, err);
    return [];
  }
};

export interface PersonResult {
  id: number;
  name: string;
  profilePath: string;
  knownForDepartment: string;
  knownForTitles: string[];
  popularity?: number;
}

export interface SearchResultWithMeta {
  items: ContentItem[];
  people?: PersonResult[];
  metaNotice?: string;
  matchedPerson?: string;
  matchedLanguage?: string;
  suggestionQuery?: string;
}

const LANGUAGE_KEYWORD_MAP: Record<string, { code: string; label: string }> = {
  hindi: { code: 'hi', label: 'Hindi / Bollywood' },
  bollywood: { code: 'hi', label: 'Hindi / Bollywood' },
  desi: { code: 'hi', label: 'Hindi' },
  tamil: { code: 'ta', label: 'Tamil' },
  kollywood: { code: 'ta', label: 'Tamil' },
  telugu: { code: 'te', label: 'Telugu' },
  tollywood: { code: 'te', label: 'Telugu' },
  malayalam: { code: 'ml', label: 'Malayalam' },
  mollywood: { code: 'ml', label: 'Malayalam' },
  kannada: { code: 'kn', label: 'Kannada' },
  sandalwood: { code: 'kn', label: 'Kannada' },
  punjabi: { code: 'pa', label: 'Punjabi' },
  pollywood: { code: 'pa', label: 'Punjabi' },
  bengali: { code: 'bn', label: 'Bengali' },
  marathi: { code: 'mr', label: 'Marathi' },
  korean: { code: 'ko', label: 'Korean / K-Drama' },
  kdrama: { code: 'ko', label: 'Korean Drama' },
  'k-drama': { code: 'ko', label: 'Korean Drama' },
  japanese: { code: 'ja', label: 'Japanese' },
  anime: { code: 'ja', label: 'Anime' },
  spanish: { code: 'es', label: 'Spanish' },
  espanol: { code: 'es', label: 'Spanish' },
  french: { code: 'fr', label: 'French' },
  chinese: { code: 'zh', label: 'Chinese / C-Drama' },
  turkish: { code: 'tr', label: 'Turkish' },
  german: { code: 'de', label: 'German' },
  italian: { code: 'it', label: 'Italian' },
  russian: { code: 'ru', label: 'Russian' },
  english: { code: 'en', label: 'English / Hollywood' },
  hollywood: { code: 'en', label: 'Hollywood' },
};

const TYPO_CORRECTIONS: Record<string, string> = {
  srk: 'Shah Rukh Khan',
  shahrukh: 'Shah Rukh Khan',
  sharukh: 'Shah Rukh Khan',
  sharuk: 'Shah Rukh Khan',
  salmn: 'Salman Khan',
  salman: 'Salman Khan',
  aamir: 'Aamir Khan',
  amirkhan: 'Aamir Khan',
  amir: 'Aamir Khan',
  hritik: 'Hrithik Roshan',
  hrithik: 'Hrithik Roshan',
  deepka: 'Deepika Padukone',
  deepika: 'Deepika Padukone',
  akshay: 'Akshay Kumar',
  alluarjun: 'Allu Arjun',
  'allu arjun': 'Allu Arjun',
  prabhs: 'Prabhas',
  prabhas: 'Prabhas',
  ramcharan: 'Ram Charan',
  'ram charan': 'Ram Charan',
  ntr: 'N.T. Rama Rao Jr.',
  'jr ntr': 'N.T. Rama Rao Jr.',
  thalapathy: 'Vijay',
  vijay: 'Vijay',
  rajini: 'Rajinikanth',
  rajnikanth: 'Rajinikanth',
  yash: 'Yash',
  kalkee: 'Kalki 2898 AD',
  kalki: 'Kalki 2898 AD',
  pushpaa: 'Pushpa',
  puspa: 'Pushpa',
  jawann: 'Jawan',
  avengrs: 'Avengers',
  avenger: 'Avengers',
  avengers: 'Avengers',
  oppenhimr: 'Oppenheimer',
  openheimer: 'Oppenheimer',
  interstelar: 'Interstellar',
  intersteller: 'Interstellar',
  strangerthngs: 'Stranger Things',
  'stranger thngs': 'Stranger Things',
  batmn: 'Batman',
  spidrman: 'Spider-Man',
  spiderman: 'Spider-Man',
  deadpol: 'Deadpool',
  dedpool: 'Deadpool',
  wolvrin: 'Wolverine',
  incepton: 'Inception',
  mcu: 'Marvel',
  marvel: 'Marvel',
  got: 'Game of Thrones',
  hotd: 'House of the Dragon',
  brba: 'Breaking Bad',
  bb: 'Breaking Bad',
  aot: 'Attack on Titan',
  narutoo: 'Naruto',
  naruto: 'Naruto',
  jjk: 'Jujutsu Kaisen',
  demonslayer: 'Demon Slayer',
  'demon slayer': 'Demon Slayer',
  onepice: 'One Piece',
  'one piece': 'One Piece',
  devara: 'Devara',
  stree: 'Stree',
  stree2: 'Stree 2',
  'stree 2': 'Stree 2'
};

export const searchContentDetailed = async (
  query: string,
  page = 1,
  category: 'all' | 'movie' | 'series' | 'star' = 'all'
): Promise<SearchResultWithMeta> => {
  const trimmed = query.trim();
  if (!trimmed) {
    return { items: [] };
  }

  try {
    const lower = trimmed.toLowerCase();
    const spellCheck = correctSearchSpelling(trimmed);
    const correctedQuery = spellCheck.hasCorrection ? spellCheck.correctedQuery : (TYPO_CORRECTIONS[lower] || null);
    const effectiveQuery = correctedQuery || trimmed;

    const yearMatch = trimmed.match(/\b(19\d\d|20\d\d)\b/);
    const detectedYear = yearMatch ? yearMatch[1] : null;
    const cleanTitle = yearMatch ? trimmed.replace(yearMatch[0], '').replace(/\s+/g, ' ').trim() : trimmed;



    // Direct Movie Search if category === 'movie'
    if (category === 'movie') {
      const moviePromises: Promise<any>[] = [
        fetch(`${BASE_URL}/search/movie?api_key=${API_KEY}&query=${encodeURIComponent(effectiveQuery)}&language=${LANGUAGE}&page=${page}&include_adult=false`)
          .then(handleResponse)
          .catch(() => ({ results: [] }))
      ];
      if (detectedYear && cleanTitle) {
        moviePromises.unshift(
          fetch(`${BASE_URL}/search/movie?api_key=${API_KEY}&query=${encodeURIComponent(cleanTitle)}&primary_release_year=${detectedYear}&language=${LANGUAGE}&include_adult=false`)
            .then(handleResponse)
            .catch(() => ({ results: [] }))
        );
      }
      const movieResults = await Promise.all(moviePromises);
      const combined = [
        ...(movieResults[0]?.results || []),
        ...(movieResults[1]?.results || [])
      ];
      const items = combined.filter(isValidSearchItem).map(mapToContentItem);
      const uniqueItems = items.filter((item, index, self) => index === self.findIndex((t) => t.id === item.id));
      return {
        items: uniqueItems,
        metaNotice: correctedQuery ? `Showing results for "${correctedQuery}"` : (detectedYear ? `Movies for "${cleanTitle}" (${detectedYear})` : `Movies matching "${trimmed}"`),
        suggestionQuery: correctedQuery || undefined
      };
    }

    // Direct TV Series Search if category === 'series'
    if (category === 'series') {
      const seriesPromises: Promise<any>[] = [
        fetch(`${BASE_URL}/search/tv?api_key=${API_KEY}&query=${encodeURIComponent(effectiveQuery)}&language=${LANGUAGE}&page=${page}&include_adult=false`)
          .then(handleResponse)
          .catch(() => ({ results: [] }))
      ];
      if (detectedYear && cleanTitle) {
        seriesPromises.unshift(
          fetch(`${BASE_URL}/search/tv?api_key=${API_KEY}&query=${encodeURIComponent(cleanTitle)}&first_air_date_year=${detectedYear}&language=${LANGUAGE}&include_adult=false`)
            .then(handleResponse)
            .catch(() => ({ results: [] }))
        );
      }
      const seriesResults = await Promise.all(seriesPromises);
      const combined = [
        ...(seriesResults[0]?.results || []),
        ...(seriesResults[1]?.results || [])
      ];
      const items = combined.filter(isValidSearchItem).map(mapToContentItem);
      const uniqueItems = items.filter((item, index, self) => index === self.findIndex((t) => t.id === item.id));
      return {
        items: uniqueItems,
        metaNotice: correctedQuery ? `Showing results for "${correctedQuery}"` : (detectedYear ? `Series for "${cleanTitle}" (${detectedYear})` : `Web Series & TV Shows matching "${trimmed}"`),
        suggestionQuery: correctedQuery || undefined
      };
    }

    // 1. Check for Language / Regional Keywords
    let matchedLanguage: string | undefined;
    let languageCode: string | undefined;
    const words = lower.split(/\s+/);
    for (const w of words) {
      if (LANGUAGE_KEYWORD_MAP[w]) {
        matchedLanguage = LANGUAGE_KEYWORD_MAP[w].label;
        languageCode = LANGUAGE_KEYWORD_MAP[w].code;
        break;
      }
    }

    // 2. Parallel fetch: Person search + Multi search + Year specific + (Language discover if matched)
    const promises: Promise<any>[] = [
      fetch(`${BASE_URL}/search/multi?api_key=${API_KEY}&query=${encodeURIComponent(trimmed)}&language=${LANGUAGE}&page=${page}&include_adult=false`)
        .then(handleResponse)
        .catch(() => ({ results: [] })),
      fetch(`${BASE_URL}/search/person?api_key=${API_KEY}&query=${encodeURIComponent(effectiveQuery)}&language=${LANGUAGE}&page=1&include_adult=false`)
        .then(handleResponse)
        .catch(() => ({ results: [] }))
    ];

    if (detectedYear && cleanTitle) {
      promises.push(
        fetch(`${BASE_URL}/search/movie?api_key=${API_KEY}&query=${encodeURIComponent(cleanTitle)}&primary_release_year=${detectedYear}&language=${LANGUAGE}&include_adult=false`)
          .then(handleResponse)
          .catch(() => ({ results: [] })),
        fetch(`${BASE_URL}/search/tv?api_key=${API_KEY}&query=${encodeURIComponent(cleanTitle)}&first_air_date_year=${detectedYear}&language=${LANGUAGE}&include_adult=false`)
          .then(handleResponse)
          .catch(() => ({ results: [] }))
      );
    }

    if (correctedQuery && correctedQuery.toLowerCase() !== trimmed.toLowerCase()) {
      promises.push(
        fetch(`${BASE_URL}/search/multi?api_key=${API_KEY}&query=${encodeURIComponent(correctedQuery)}&language=${LANGUAGE}&page=${page}&include_adult=false`)
          .then(handleResponse)
          .catch(() => ({ results: [] }))
      );
    }

    if (languageCode) {
      promises.push(
        fetch(`${BASE_URL}/discover/movie?api_key=${API_KEY}&with_original_language=${languageCode}&sort_by=popularity.desc&page=${page}&include_adult=false`)
          .then(handleResponse)
          .catch(() => ({ results: [] })),
        fetch(`${BASE_URL}/discover/tv?api_key=${API_KEY}&with_original_language=${languageCode}&sort_by=popularity.desc&page=${page}&include_adult=false`)
          .then(handleResponse)
          .catch(() => ({ results: [] }))
      );
    }

    const fetchedResults = await Promise.all(promises);
    const multiData = fetchedResults[0] || { results: [] };
    const personData = fetchedResults[1] || { results: [] };
    
    let resultIdx = 2;
    let yearMovieData: any = null;
    let yearTvData: any = null;
    if (detectedYear && cleanTitle) {
      yearMovieData = fetchedResults[resultIdx++] || { results: [] };
      yearTvData = fetchedResults[resultIdx++] || { results: [] };
    }

    let correctedMultiData: any = null;
    if (correctedQuery && correctedQuery.toLowerCase() !== trimmed.toLowerCase()) {
      correctedMultiData = fetchedResults[resultIdx++] || { results: [] };
    }

    let langMovieData: any = null;
    let langTvData: any = null;
    if (languageCode) {
      langMovieData = fetchedResults[resultIdx++] || { results: [] };
      langTvData = fetchedResults[resultIdx++] || { results: [] };
    }

    let allItems: ContentItem[] = [];

    // If exact year query matched (e.g. Love 2015, Batman 2022), prioritize them at the very top!
    if (yearMovieData?.results?.length) {
      const yearItems = yearMovieData.results
        .filter(isValidSearchItem)
        .map((i: any) => ({
          ...mapToContentItem(i),
          badge: `${cleanTitle.toUpperCase()} (${detectedYear})`,
          badgeType: 'trending' as any
        }));
      allItems.push(...yearItems);
    }
    if (yearTvData?.results?.length) {
      const yearTvItems = yearTvData.results
        .filter(isValidSearchItem)
        .map((i: any) => ({
          ...mapToContentItem(i),
          badge: `${cleanTitle.toUpperCase()} (${detectedYear})`,
          badgeType: 'trending' as any
        }));
      allItems.push(...yearTvItems);
    }

    // If spell-checked / corrected query matched (e.g. Dilwale Dulhania Le Jayenge), place them at the very top!
    if (correctedMultiData?.results?.length) {
      const cItems = correctedMultiData.results
        .filter(isValidSearchItem)
        .map((i: any) => ({
          ...mapToContentItem(i),
          badge: i.title === correctedQuery || i.name === correctedQuery ? `Exact Match` : `Did you mean: ${correctedQuery}`,
          badgeType: 'trending' as any
        }));
      allItems.unshift(...cItems);
    }
    let matchedPerson: string | undefined;
    let metaNotice: string | undefined;

    // Extract People list
    const peopleList: PersonResult[] = (personData.results || [])
      .filter((p: any) => p && p.id && (p.popularity > 0.5 || p.profile_path))
      .slice(0, 10)
      .map((p: any) => ({
        id: p.id,
        name: p.name,
        profilePath: p.profile_path ? `${IMAGE_BASE}/w185${p.profile_path}` : 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&auto=format&fit=crop&q=80',
        knownForDepartment: p.known_for_department || 'Acting',
        knownForTitles: (p.known_for || []).map((k: any) => k.title || k.name).filter(Boolean).slice(0, 3),
        popularity: p.popularity,
      }));

    // 3. Process Actor / Hero / Heroine credits
    const topPerson = personData.results?.[0];
    if (topPerson && (topPerson.popularity > 1 || topPerson.name.toLowerCase().includes(lower) || lower.includes(topPerson.name.toLowerCase().split(' ')[0]))) {
      matchedPerson = topPerson.name;
      metaNotice = `Featuring titles starring ${topPerson.name}`;

      // Extract known_for movies/shows
      if (topPerson.known_for && Array.isArray(topPerson.known_for)) {
        const knownItems = topPerson.known_for
          .filter(isValidSearchItem)
          .map((i: any) => ({
            ...mapToContentItem(i),
            badge: `Starring: ${topPerson.name}`,
            badgeType: 'starring' as any
          }));
        allItems.push(...knownItems);
      }

      // Fetch extended combined_credits for comprehensive filmography
      try {
        const creditsRes = await fetch(`${BASE_URL}/person/${topPerson.id}/combined_credits?api_key=${API_KEY}&language=${LANGUAGE}`);
        const creditsData = await handleResponse(creditsRes);
        const castCredits = (creditsData.cast || [])
          .filter(isValidSearchItem)
          .sort((a: any, b: any) => (b.popularity || 0) - (a.popularity || 0))
          .slice(0, 30)
          .map((c: any) => ({
            ...mapToContentItem(c),
            badge: `Starring: ${topPerson.name}`,
            badgeType: 'starring' as any
          }));
        allItems.push(...castCredits);
      } catch (e) {
        console.warn('Failed to fetch person combined_credits:', e);
      }
    }

    // 4. Process Multi-search results (unpacking people and movies/series)
    const rawMultiResults = [...(multiData.results || []), ...(correctedMultiData?.results || [])];
    for (const item of rawMultiResults) {
      if (item.media_type === 'person') {
        if (!matchedPerson) {
          matchedPerson = item.name;
          metaNotice = `Featuring titles starring ${item.name}`;
        }
        if (item.known_for && Array.isArray(item.known_for)) {
          const kItems = item.known_for.filter(isValidSearchItem).map((k: any) => ({
            ...mapToContentItem(k),
            badge: `Starring: ${item.name}`,
            badgeType: 'starring' as any
          }));
          allItems.push(...kItems);
        }
      } else if (isValidSearchItem(item)) {
        allItems.push(mapToContentItem(item));
      }
    }

    // 5. Process Language Discover Results
    if (languageCode && (langMovieData || langTvData)) {
      if (!metaNotice) {
        metaNotice = `Popular titles in ${matchedLanguage}`;
      }
      const lMovies = (langMovieData?.results || []).filter(isValidSearchItem).map((i: any) => mapToContentItem({ ...i, media_type: 'movie' }));
      const lTv = (langTvData?.results || []).filter(isValidSearchItem).map((i: any) => mapToContentItem({ ...i, media_type: 'tv' }));
      allItems.push(...lMovies, ...lTv);
    }

    // 6. Typo Notice
    if (correctedQuery && !metaNotice) {
      metaNotice = `Showing related titles for "${correctedQuery}"`;
    }

    // 7. Fallback / Typo Fuzzy Recovery if 0 results
    if (allItems.length === 0) {
      const deDuped = trimmed.replace(/(.)\1+/g, '$1');
      if (deDuped !== trimmed && deDuped.length >= 3) {
        try {
          const fallbackRes = await fetch(`${BASE_URL}/search/multi?api_key=${API_KEY}&query=${encodeURIComponent(deDuped)}&language=${LANGUAGE}&page=1&include_adult=false`);
          const fbData = await handleResponse(fallbackRes);
          const fbItems = (fbData.results || []).filter(isValidSearchItem).map(mapToContentItem);
          if (fbItems.length > 0) {
            allItems.push(...fbItems);
            metaNotice = `Showing closest matches for "${deDuped}"`;
          }
        } catch {
          // ignore fallback error
        }
      }

      if (allItems.length === 0 && words.length > 1) {
        const longestToken = [...words].sort((a, b) => b.length - a.length)[0];
        if (longestToken && longestToken.length >= 4) {
          try {
            const tokenRes = await fetch(`${BASE_URL}/search/multi?api_key=${API_KEY}&query=${encodeURIComponent(longestToken)}&language=${LANGUAGE}&page=1&include_adult=false`);
            const tData = await handleResponse(tokenRes);
            const tItems = (tData.results || []).filter(isValidSearchItem).map(mapToContentItem);
            if (tItems.length > 0) {
              allItems.push(...tItems);
              metaNotice = `Showing related titles matching "${longestToken}"`;
            }
          } catch {
            // ignore
          }
        }
      }
    }

    // 8. Deduplicate items by ID and prioritize Recently Released & Trending
    const seen = new Set<string>();
    const uniqueItems: ContentItem[] = [];
    for (const it of allItems) {
      if (it && it.id && !seen.has(String(it.id))) {
        seen.add(String(it.id));
        uniqueItems.push(it);
      }
    }

    const currentYear = new Date().getFullYear();
    const cleanQ = trimmed.toLowerCase();

    // 4-Tier Search Ranking:
    // 1. Exact Title Match
    // 2. New Releases (Last 1-2 years: 2024-2026)
    // 3. All-time Trending / Blockbuster Popularity
    // 4. Most Loved & Highly Rated (Ratings >= 7.0)
    // 5. Rarely watched / obscure content pushed to bottom
    const computeScore = (item: ContentItem): number => {
      let score = 0;
      const title = (item.title || '').toLowerCase();
      
      if (title === cleanQ) score += 5000;
      else if (title.startsWith(cleanQ)) score += 2000;
      else if (title.includes(cleanQ)) score += 1000;

      const year = item.year || 0;
      const rating = parseFloat(item.rating || '0') || 0;
      const pop = item.popularity || 0;
      const vCount = item.voteCount || 0;

      // Tier 1: New Releases (Recent 1-2 years)
      if (year >= currentYear - 1 && year <= currentYear) {
        score += 850;
      } else if (year >= currentYear - 3) {
        score += 400;
      }

      // Tier 2: All-time Trending / High Popularity
      if (pop > 100) score += 700;
      else if (pop > 40) score += 400;
      else if (pop > 15) score += 200;

      // Tier 3: Most Loved / Highly Rated (People like to watch)
      if (rating >= 8.0 && vCount > 20) score += 500;
      else if (rating >= 7.0 && vCount > 10) score += 300;
      else if (rating >= 6.0) score += 100;
      else if (rating > 0 && rating < 5.0) score -= 300; // Low rated demoted

      // Demote rarely watched / obscure titles
      if (pop < 4 && vCount < 5) score -= 500;
      if (year > currentYear) score -= 1200; // Unreleased future titles to bottom

      return score;
    };

    uniqueItems.sort((a, b) => computeScore(b) - computeScore(a));

    return {
      items: uniqueItems,
      people: peopleList,
      metaNotice,
      matchedPerson,
      matchedLanguage,
      suggestionQuery: correctedQuery || undefined
    };
  } catch (err) {
    console.error('searchContentDetailed failed:', err);
    return { items: [] };
  }
};

export const fetchPersonFilmography = async (personId: number, personName?: string): Promise<ContentItem[]> => {
  try {
    const res = await fetch(`${BASE_URL}/person/${personId}/combined_credits?api_key=${API_KEY}&language=${LANGUAGE}`);
    const data = await handleResponse(res);
    return (data.cast || [])
      .filter(isValidSearchItem)
      .sort((a: any, b: any) => (b.popularity || 0) - (a.popularity || 0))
      .slice(0, 40)
      .map((c: any) => ({
        ...mapToContentItem(c),
        badge: personName ? `Starring: ${personName}` : undefined,
        badgeType: 'starring' as any
      }));
  } catch (e) {
    console.warn('Failed to fetch person filmography:', e);
    return [];
  }
};

export const searchByExactTitleAndYear = async (
  title: string,
  year?: string | null,
  type?: 'movie' | 'series' | 'star' | null
): Promise<ContentItem | null> => {
  if (!title) return null;
  const clean = title.trim();
  const yr = year ? String(year).trim() : undefined;

  try {
    if (type === 'series') {
      let url = `${BASE_URL}/search/tv?api_key=${API_KEY}&query=${encodeURIComponent(clean)}&language=${LANGUAGE}&include_adult=false`;
      if (yr) url += `&first_air_date_year=${yr}`;
      const res = await fetch(url);
      const data = await handleResponse(res);
      const item = data.results?.[0];
      if (item && !isItemAdult(item)) {
        return mapToContentItem(item);
      }
    } else {
      let url = `${BASE_URL}/search/movie?api_key=${API_KEY}&query=${encodeURIComponent(clean)}&language=${LANGUAGE}&include_adult=false`;
      if (yr) url += `&primary_release_year=${yr}`;
      const res = await fetch(url);
      const data = await handleResponse(res);
      const item = data.results?.[0];
      if (item && !isItemAdult(item)) {
        return mapToContentItem(item);
      }
    }

    // Fallback: Multi search
    const multiUrl = `${BASE_URL}/search/multi?api_key=${API_KEY}&query=${encodeURIComponent(clean)}&language=${LANGUAGE}&include_adult=false`;
    const mRes = await fetch(multiUrl);
    const mData = await handleResponse(mRes);
    const valid = (mData.results || []).filter(isValidSearchItem);
    if (yr) {
      const yearMatch = valid.find((r: any) => (r.release_date || r.first_air_date || '').startsWith(yr));
      if (yearMatch && !isItemAdult(yearMatch)) return mapToContentItem(yearMatch);
    }
    if (valid.length > 0 && !isItemAdult(valid[0])) {
      return mapToContentItem(valid[0]);
    }
  } catch (err) {
    console.warn('searchByExactTitleAndYear failed:', err);
  }
  return null;
};

export const searchContent = async (query: string, page = 1): Promise<ContentItem[]> => {
  const res = await searchContentDetailed(query, page);
  return res.items;
};

export const fetchImdbId = async (id: string, type: 'movie' | 'series' | 'anime' | 'tv' | string): Promise<string | null> => {
  if (typeof id === 'string' && id.startsWith('tt')) {
    return id;
  }
  try {
    const mediaType = (type === 'series' || type === 'tv' || type === 'anime') ? 'tv' : 'movie';
    const response = await fetch(`${BASE_URL}/${mediaType}/${id}/external_ids?api_key=${API_KEY}`);
    if (!response.ok) return null;
    const data = await response.json().catch(() => ({}));
    return data.imdb_id || null;
  } catch {
    return null;
  }
};

export const fetchTitleLogo = async (id: string, type: 'movie' | 'series' | 'anime' | 'tv' | string): Promise<string | null> => {
  try {
    const mediaType = (type === 'series' || type === 'tv' || type === 'anime') ? 'tv' : 'movie';
    const response = await fetch(`${BASE_URL}/${mediaType}/${id}/images?api_key=${API_KEY}`);
    if (!response.ok) return null;
    const data = await response.json().catch(() => ({}));
    const logo = data.logos?.find((l: any) => l.iso_639_1 === 'en' && l.file_path) || data.logos?.find((l: any) => l.file_path);
    return logo ? `${IMAGE_BASE}/w500${logo.file_path}` : null;
  } catch {
    return null;
  }
};

export const fetchTrailerKey = async (id: string | number, type: string = 'movie'): Promise<string | null> => {
  try {
    const mediaType = (type === 'series' || type === 'tv' || type === 'anime') ? 'tv' : 'movie';
    const cacheKey = `moflix_trailer_${mediaType}_${id}`;
    const cached = sessionStorage.getItem(cacheKey);
    if (cached) return cached === 'null' ? null : cached;

    const response = await fetch(`${BASE_URL}/${mediaType}/${id}/videos?api_key=${API_KEY}&language=${LANGUAGE}`);
    const data = await handleResponse(response);
    const trailer = data.results?.find((v: any) => v.site === 'YouTube' && (v.type === 'Trailer' || v.type === 'Teaser'))
      || data.results?.find((v: any) => v.site === 'YouTube');
    const key = trailer?.key || null;
    try {
      sessionStorage.setItem(cacheKey, key || 'null');
    } catch {}
    return key;
  } catch {
    return null;
  }
};

export const fetchExtendedDetails = async (id: string, type: 'movie' | 'series' | 'anime' | 'tv' | string): Promise<ExtendedDetails> => {
  try {
    const mediaType = (type === 'series' || type === 'tv' || type === 'anime') ? 'tv' : 'movie';
    const appendToResponse = 'videos,credits,recommendations,similar,external_ids,images';
    const response = await fetch(`${BASE_URL}/${mediaType}/${id}?api_key=${API_KEY}&language=${LANGUAGE}&append_to_response=${appendToResponse}&include_image_language=en,null`);
    const data = await handleResponse(response);
    const today = getTodayDate();

    const trailer = data.videos?.results?.find((v: any) => (v.type === 'Trailer' || v.type === 'Teaser') && v.site === 'YouTube');
    
    const logo = data.images?.logos?.find((l: any) => l.iso_639_1 === 'en' && l.file_path) || data.images?.logos?.find((l: any) => l.file_path);
    const logoUrl = logo ? `${IMAGE_BASE}/w500${logo.file_path}` : null;

    const cast = (data.credits?.cast || []).slice(0, 15).map((c: any): CastMember => ({
      id: c.id,
      name: c.name,
      character: c.character,
      profilePath: c.profile_path ? `${IMAGE_BASE}/w200${c.profile_path}` : '',
    }));

    const directors = data.credits?.crew
      ?.filter((c: any) => c.job === 'Director')
      .map((c: any) => c.name);

    const creators = data.created_by?.map((c: any) => c.name);
    
    const combinedRecs = [
      ...(data.recommendations?.results || []),
      ...(data.similar?.results || [])
    ];
    
    const uniqueRecs = Array.from(new Map(combinedRecs.map(item => [item.id, item])).values());
    const recommendations = uniqueRecs
      .filter(isItemReleased)
      .map((i: any) => ({ ...i, media_type: type === 'series' ? 'tv' : 'movie' }))
      .map(mapToContentItem);

    const screenshots = (data.images?.backdrops || [])
      .filter((b: any) => b && b.file_path)
      .slice(0, 10)
      .map((b: any) => `${IMAGE_BASE}/w780${b.file_path}`);

    return {
      genres: (data.genres || []).map((g: any) => g.name),
      cast,
      trailerKey: trailer?.key || null,
      recommendations,
      runtime: data.runtime || data.episode_run_time?.[0],
      seasons: await (async () => {
        const today = getTodayDate();
        let seasonsList = (data.seasons || [])
          .filter((s: any) => {
            if (!s || s.season_number <= 0) return false;
            if (s.episode_count === 0) return false;
            // Exclude future unreleased seasons
            if (s.air_date && s.air_date > today) return false;
            return true;
          })
          .map((s: any) => ({
            id: s.id,
            name: s.name,
            episodeCount: s.episode_count,
            seasonNumber: s.season_number,
          }));

        // Check for OTT Episode Groups (e.g. Lupin 4 parts, Money Heist 5 parts)
        if (type === 'series' || type === 'tv') {
          try {
            const groupsRes = await fetch(`${BASE_URL}/tv/${id}/episode_groups?api_key=${API_KEY}`);
            if (groupsRes.ok) {
              const groupsData = await groupsRes.json();
              const results = groupsData.results || [];
              // Find an OTT part/season release group if available
              const ottGroup = results.find((g: any) => 
                (g.network?.name === 'Netflix' || g.name?.includes('Part') || g.group_count > seasonsList.length) &&
                g.group_count > seasonsList.length
              ) || (results.length > 0 && results[0].group_count > seasonsList.length ? results[0] : null);

              if (ottGroup) {
                const detailRes = await fetch(`${BASE_URL}/tv/episode_group/${ottGroup.id}?api_key=${API_KEY}`);
                if (detailRes.ok) {
                  const detailData = await detailRes.json();
                  if (detailData.groups && detailData.groups.length > 0) {
                    const sortedGroups = [...detailData.groups].sort((a: any, b: any) => (a.order || 0) - (b.order || 0));
                    episodeGroupCache.set(String(id), { groups: sortedGroups });
                    seasonsList = sortedGroups.map((g: any, idx: number) => ({
                      id: g.id ? String(g.id) : idx + 1,
                      name: g.name || `Part ${idx + 1}`,
                      episodeCount: g.episodes?.length || 0,
                      seasonNumber: idx + 1,
                    }));
                  }
                }
              }
            }
          } catch (e) {
            console.warn('Episode groups check failed:', e);
          }
        }
        return seasonsList;
      })(),
      directors,
      creators,
      status: data.status,
      originalLanguage: data.original_language?.toUpperCase(),
      imdbId: data.external_ids?.imdb_id || data.imdb_id || null,
      logoUrl,
      screenshots
    };
  } catch (err) {
    console.error('fetchExtendedDetails failed:', err);
    return {
      genres: [],
      cast: [],
      trailerKey: null,
      recommendations: [],
      seasons: []
    };
  }
};

// In-memory cache for series with episode groups (e.g. Lupin 4 parts, Money Heist 5 parts)
const episodeGroupCache = new Map<string, { groups: any[] }>();

export const fetchEpisodes = async (seriesId: string, seasonNumber: number): Promise<Episode[]> => {
  try {
    const cleanId = String(seriesId);
    const today = getTodayDate();

    // 1. Check if this series has an active episode group cached
    let cachedGroupData = episodeGroupCache.get(cleanId);

    // If not cached yet, query episode groups dynamically
    if (!cachedGroupData) {
      try {
        const groupsRes = await fetch(`${BASE_URL}/tv/${cleanId}/episode_groups?api_key=${API_KEY}`);
        if (groupsRes.ok) {
          const groupsData = await groupsRes.json();
          const results = groupsData.results || [];
          const ottGroup = results.find((g: any) => 
            (g.network?.name === 'Netflix' || g.name?.includes('Part') || g.group_count > 3) &&
            g.group_count > 3
          ) || (results.length > 0 && results[0].group_count > 3 ? results[0] : null);

          if (ottGroup) {
            const detailRes = await fetch(`${BASE_URL}/tv/episode_group/${ottGroup.id}?api_key=${API_KEY}`);
            if (detailRes.ok) {
              const detailData = await detailRes.json();
              if (detailData.groups && detailData.groups.length > 0) {
                const sortedGroups = [...detailData.groups].sort((a: any, b: any) => (a.order || 0) - (b.order || 0));
                cachedGroupData = { groups: sortedGroups };
                episodeGroupCache.set(cleanId, cachedGroupData);
              }
            }
          }
        }
      } catch {}
    }

    // If episode group is active, return episodes from the requested group (only already aired)
    if (cachedGroupData && cachedGroupData.groups && cachedGroupData.groups.length >= seasonNumber) {
      const targetGroup = cachedGroupData.groups[seasonNumber - 1];
      if (targetGroup && targetGroup.episodes && targetGroup.episodes.length > 0) {
        return targetGroup.episodes
          .filter((ep: any) => {
            if (!ep) return false;
            if (ep.air_date && ep.air_date > today) return false;
            return true;
          })
          .map((ep: any, epIdx: number): Episode => ({
            id: ep.id,
            name: ep.name || `Episode ${epIdx + 1}`,
            overview: ep.overview || '',
            stillPath: ep.still_path ? `${IMAGE_BASE}/w500${ep.still_path}` : '',
            episodeNumber: epIdx + 1,
            runtime: ep.runtime || 0,
            seasonNumber: ep.season_number || seasonNumber,
          }));
      }
    }

    // 2. Standard TMDB season endpoint
    const response = await fetch(`${BASE_URL}/tv/${seriesId}/season/${seasonNumber}?api_key=${API_KEY}&language=${LANGUAGE}`);
    const data = await handleResponse(response);

    return (data.episodes || [])
      .filter((ep: any) => {
        if (!ep || !ep.episode_number) return false;
        // Strictly only show episodes that have already aired! Upcoming episodes belong only in upcoming!
        if (ep.air_date && ep.air_date > today) return false;
        return true;
      })
      .map((ep: any): Episode => ({
        id: ep.id,
        name: ep.name,
        overview: ep.overview,
        stillPath: ep.still_path ? `${IMAGE_BASE}/w500${ep.still_path}` : '',
        episodeNumber: ep.episode_number,
        runtime: ep.runtime || 0,
        seasonNumber: ep.season_number || seasonNumber,
      }));
  } catch (err) {
    console.error(`fetchEpisodes for series ${seriesId} season ${seasonNumber} failed:`, err);
    return [];
  }
};

export const fetchContentRecommendations = async (id: string | number, type: string = 'movie'): Promise<ContentItem[]> => {
  try {
    const mediaType = (type === 'series' || type === 'tv' || type === 'anime') ? 'tv' : 'movie';
    const [recsRes, similarRes] = await Promise.all([
      fetch(`${BASE_URL}/${mediaType}/${id}/recommendations?api_key=${API_KEY}&language=${LANGUAGE}`).then(r => r.ok ? r.json() : { results: [] }).catch(() => ({ results: [] })),
      fetch(`${BASE_URL}/${mediaType}/${id}/similar?api_key=${API_KEY}&language=${LANGUAGE}`).then(r => r.ok ? r.json() : { results: [] }).catch(() => ({ results: [] }))
    ]);

    const combined = [...(recsRes.results || []), ...(similarRes.results || [])];
    const unique = Array.from(new Map(combined.map((item: any) => [item.id, item])).values());
    return unique
      .filter(isItemReleased)
      .slice(0, 12)
      .map((i: any) => ({ ...i, media_type: mediaType }))
      .map(mapToContentItem);
  } catch (err) {
    console.error('fetchContentRecommendations failed:', err);
    return [];
  }
};

export const fetchUpcomingMovies = async (page = 1): Promise<ContentItem[]> => {
  try {
    const response = await fetch(`${BASE_URL}/movie/upcoming?api_key=${API_KEY}&language=${LANGUAGE}&page=${page}`);
    const data = await handleResponse(response);
    return (data.results || [])
      .filter((i: any) => !isItemAdult(i) && (i.poster_path || i.backdrop_path))
      .map((i: any) => {
        const releaseDate = i.release_date;
        const daysRemaining = releaseDate 
          ? Math.ceil((new Date(releaseDate).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24))
          : 0;
        return {
          ...mapToContentItem({ ...i, media_type: 'movie' }),
          badge: daysRemaining > 0 ? `In ${daysRemaining} Days` : 'Coming Soon',
          badgeType: 'new_release' as const,
        };
      });
  } catch (err) {
    console.error('fetchUpcomingMovies failed:', err);
    return [];
  }
};

export const fetchNowPlayingMovies = async (page = 1): Promise<ContentItem[]> => {
  try {
    const response = await fetch(`${BASE_URL}/movie/now_playing?api_key=${API_KEY}&language=${LANGUAGE}&page=${page}`);
    const data = await handleResponse(response);
    return (data.results || [])
      .filter(isItemReleased)
      .map((i: any) => mapToContentItem({ ...i, media_type: 'movie' }));
  } catch (err) {
    console.error('fetchNowPlayingMovies failed:', err);
    return [];
  }
};

export const fetchOnTheAirSeries = async (page = 1): Promise<ContentItem[]> => {
  try {
    const response = await fetch(`${BASE_URL}/tv/on_the_air?api_key=${API_KEY}&language=${LANGUAGE}&page=${page}`);
    const data = await handleResponse(response);
    return (data.results || [])
      .filter((i: any) => !isItemAdult(i) && (i.poster_path || i.backdrop_path))
      .map((i: any) => mapToContentItem({ ...i, media_type: 'tv' }));
  } catch (err) {
    console.error('fetchOnTheAirSeries failed:', err);
    return [];
  }
};

export const fetchContentItemById = async (id: string, type: 'movie' | 'series' | string = 'movie'): Promise<ContentItem | null> => {
  try {
    const isTv = type === 'series' || type === 'tv' || type === 'shows';
    const primaryType = isTv ? 'tv' : 'movie';
    const fallbackType = isTv ? 'movie' : 'tv';

    let data: any = null;
    let resolvedMediaType: 'tv' | 'movie' = primaryType;

    try {
      const response = await fetch(`${BASE_URL}/${primaryType}/${id}?api_key=${API_KEY}&language=${LANGUAGE}`);
      if (response.ok) {
        data = await handleResponse(response);
      }
    } catch {
      // primary fetch failed, try fallback
    }

    if (!data || !data.id) {
      try {
        const fallbackRes = await fetch(`${BASE_URL}/${fallbackType}/${id}?api_key=${API_KEY}&language=${LANGUAGE}`);
        if (fallbackRes.ok) {
          data = await handleResponse(fallbackRes);
          resolvedMediaType = fallbackType;
        }
      } catch {
        // fallback failed
      }
    }

    if (!data || !data.id || isItemAdult(data)) return null;
    return mapToContentItem({ ...data, media_type: resolvedMediaType });
  } catch (err) {
    console.error(`fetchContentItemById for ${id} failed:`, err);
    return null;
  }
};

export const resolveTmdbId = async (externalId: string): Promise<number | null> => {
  if (!externalId) return null;
  if (!isNaN(Number(externalId))) return Number(externalId);
  try {
    const res = await fetch(`${BASE_URL}/find/${externalId}?api_key=${API_KEY}&external_source=imdb_id`);
    if (!res.ok) return null;
    const data = await res.json();
    const match = data.movie_results?.[0] || data.tv_results?.[0];
    return match ? match.id : null;
  } catch {
    return null;
  }
};


