import { ContentItem, ExtendedDetails, Episode, CastMember } from '../types';

const CINEMETA_CATALOG_BASE = 'https://cinemeta-catalogs.strem.io/top/catalog';
const CINEMETA_META_BASE = 'https://v3-cinemeta.strem.io';
const TMDB_API_KEY = 'f4c3361d4917e9f25f79f339356eb8d9';

const imdbMemoryCache = new Map<string, { timestamp: number; data: any }>();
const tmdbIdCache = new Map<string, string | number>();
const CACHE_TTL_MS = 15 * 60 * 1000; // 15 minutes

async function imdbFetch<T>(url: string): Promise<T | null> {
  const cached = imdbMemoryCache.get(url);
  const now = Date.now();
  if (cached && now - cached.timestamp < CACHE_TTL_MS) {
    return cached.data;
  }

  try {
    const res = await fetch(url, {
      headers: {
        Accept: 'application/json',
      },
    });
    if (!res.ok) return null;
    const data = await res.json();
    imdbMemoryCache.set(url, { timestamp: now, data });
    return data;
  } catch (err) {
    console.warn(`[IMDb API Error] ${url}:`, err);
    return null;
  }
}

// Strictly filter out all unreleased titles (shows only in upcoming)
export function isImdbItemReleased(m: any): boolean {
  if (!m) return false;
  const now = new Date();
  const todayStr = now.toISOString().split('T')[0];
  const currentYear = now.getFullYear();

  // If exact release date is available
  if (m.released) {
    const relStr = String(m.released).split('T')[0];
    if (relStr > todayStr) {
      return false; // Future date -> unreleased!
    }
  }

  // If year is in future
  if (m.year) {
    const y = parseInt(String(m.year).slice(0, 4), 10);
    if (!isNaN(y) && y > currentYear) {
      return false; // Future year -> unreleased!
    }
  }

  return true;
}

export function mapCinemetaToContentItem(m: any, defaultType?: 'movie' | 'series'): ContentItem {
  const isMovie = m.type === 'movie' || defaultType === 'movie';
  const imdbId = m.id || m.imdb_id || (m.slug ? m.slug.split('-').pop() : undefined);
  const tmdbId = m.moviedb_id || null;
  const title = m.name || m.title || 'Untitled';
  const desc = m.description || m.overview || 'No description available.';
  const poster = m.poster || (imdbId ? `https://images.metahub.space/poster/medium/${imdbId}/img` : '');
  const backdrop = m.background || m.logo || (imdbId ? `https://images.metahub.space/background/medium/${imdbId}/img` : poster);

  let yearNum = 2024;
  if (m.year) {
    yearNum = parseInt(String(m.year).slice(0, 4), 10) || 2024;
  } else if (m.releaseInfo) {
    yearNum = parseInt(String(m.releaseInfo).slice(0, 4), 10) || 2024;
  } else if (m.released) {
    yearNum = new Date(m.released).getFullYear() || 2024;
  }

  if (imdbId && tmdbId) {
    tmdbIdCache.set(imdbId, tmdbId);
  }

  const rawRating = m.imdbRating || '7.8';

  return {
    id: imdbId || String(Math.random()),
    tmdbId: tmdbId || null,
    title,
    description: desc,
    thumbnail: poster,
    backdrop,
    rating: '',
    year: yearNum,
    type: isMovie ? 'movie' : 'series',
    imdbId: imdbId || null,
    badge: undefined,
    badgeType: undefined,
  };
}

// Resolve TMDB ID from IMDb ID for Player and Download links
export async function resolveTmdbId(imdbId: string): Promise<string | number | null> {
  if (!imdbId) return null;
  if (!imdbId.startsWith('tt')) return imdbId;

  if (tmdbIdCache.has(imdbId)) {
    return tmdbIdCache.get(imdbId)!;
  }

  try {
    const res = await fetch(`https://api.themoviedb.org/3/find/${imdbId}?api_key=${TMDB_API_KEY}&external_source=imdb_id`);
    if (!res.ok) return imdbId;
    const data = await res.json();
    const match = data.movie_results?.[0] || data.tv_results?.[0] || data.tv_episode_results?.[0];
    const tmdbId = match?.id || imdbId;
    tmdbIdCache.set(imdbId, tmdbId);
    return tmdbId;
  } catch {
    return imdbId;
  }
}

// 1. Fetch Top IMDb Movies (Released only)
export async function getImdbMovies(skip = 0): Promise<ContentItem[]> {
  const url = `${CINEMETA_CATALOG_BASE}/movie/top${skip > 0 ? `/skip=${skip}` : ''}.json`;
  const res = await imdbFetch<{ metas: any[] }>(url);
  if (!res || !Array.isArray(res.metas)) return [];
  return res.metas
    .filter(isImdbItemReleased)
    .map((m) => mapCinemetaToContentItem(m, 'movie'));
}

// 2. Fetch Top IMDb Series (Released only)
export async function getImdbSeries(skip = 0): Promise<ContentItem[]> {
  const url = `${CINEMETA_CATALOG_BASE}/series/top${skip > 0 ? `/skip=${skip}` : ''}.json`;
  const res = await imdbFetch<{ metas: any[] }>(url);
  if (!res || !Array.isArray(res.metas)) return [];
  return res.metas
    .filter(isImdbItemReleased)
    .map((m) => mapCinemetaToContentItem(m, 'series'));
}

// 3. Fetch Top 10 IMDb Movies
export async function getImdbTop10Movies(): Promise<ContentItem[]> {
  const movies = await getImdbMovies(0);
  return movies.slice(0, 10);
}

// 4. Fetch Top 10 IMDb Series
export async function getImdbTop10Series(): Promise<ContentItem[]> {
  const series = await getImdbSeries(0);
  return series.slice(0, 10);
}

// 5. Fetch Top IMDb Anime / Animation
export async function getImdbAnime(skip = 0): Promise<ContentItem[]> {
  const url = `${CINEMETA_CATALOG_BASE}/series/top/genre=Animation${skip > 0 ? `/skip=${skip}` : ''}.json`;
  const res = await imdbFetch<{ metas: any[] }>(url);
  if (!res || !Array.isArray(res.metas)) return [];
  return res.metas
    .filter(isImdbItemReleased)
    .map((m) => ({
      ...mapCinemetaToContentItem(m, 'series'),
      type: 'anime',
    }));
}

// 6. Fetch IMDb Content by Genre
export async function getImdbByGenre(genreName: string, skip = 0): Promise<ContentItem[]> {
  const url = `${CINEMETA_CATALOG_BASE}/movie/top/genre=${encodeURIComponent(genreName)}${skip > 0 ? `/skip=${skip}` : ''}.json`;
  const res = await imdbFetch<{ metas: any[] }>(url);
  if (!res || !Array.isArray(res.metas)) return [];
  return res.metas
    .filter(isImdbItemReleased)
    .map((m) => mapCinemetaToContentItem(m, 'movie'));
}

// 7. Fetch Full IMDb Metadata & Details (With Related Recommendations!)
export async function getImdbExtendedDetails(
  imdbId: string,
  type: 'movie' | 'series' | 'anime' | 'tv' | string
): Promise<ExtendedDetails | null> {
  const mediaType = type === 'series' || type === 'tv' || type === 'anime' ? 'series' : 'movie';
  const url = `${CINEMETA_META_BASE}/meta/${mediaType}/${imdbId}.json`;
  const res = await imdbFetch<{ meta: any }>(url);
  if (!res || !res.meta) return null;

  const m = res.meta;
  if (m.moviedb_id) {
    tmdbIdCache.set(imdbId, m.moviedb_id);
  }

  const cast: CastMember[] = (m.cast || []).map((name: string, idx: number) => ({
    id: idx + 1,
    name,
    character: 'Starring',
    profilePath: '',
  }));

  const genres: string[] = m.genres || m.genre || [];
  const trailerKey = m.trailers?.[0]?.source || null;

  let seasons: { name: string; episodeCount: number; seasonNumber: number; id: number }[] = [];
  if (Array.isArray(m.videos) && m.videos.length > 0) {
    const seasonCounts = new Map<number, number>();
    for (const v of m.videos) {
      if (typeof v.season === 'number' && v.season > 0) {
        seasonCounts.set(v.season, (seasonCounts.get(v.season) || 0) + 1);
      }
    }
    seasons = Array.from(seasonCounts.entries())
      .sort((a, b) => a[0] - b[0])
      .map(([seasonNum, count]) => ({
        id: seasonNum,
        name: `Season ${seasonNum}`,
        episodeCount: count,
        seasonNumber: seasonNum,
      }));
  }

  // Related Movies/Series for "More Like This"
  let recommendations: ContentItem[] = [];
  try {
    const primaryGenre = genres[0] || (mediaType === 'series' ? 'Drama' : 'Action');
    const relatedCatalog = mediaType === 'series' 
      ? await getImdbSeries(0)
      : await getImdbByGenre(primaryGenre, 0);
    recommendations = relatedCatalog
      .filter((item) => item.id !== imdbId && item.imdbId !== imdbId)
      .slice(0, 12);
  } catch (err) {
    console.warn('[Failed to fetch related items]:', err);
  }

  return {
    genres,
    cast,
    trailerKey,
    recommendations,
    runtime: parseInt(m.runtime, 10) || undefined,
    seasons: seasons.length > 0 ? seasons : undefined,
    directors: m.director || (m.directors ? m.directors : []),
    creators: m.writer ? [m.writer] : [],
    status: m.status || 'Released',
    originalLanguage: m.country || 'EN',
    imdbId: m.imdb_id || m.id || imdbId,
    logoUrl: m.logo || null,
    screenshots: m.background ? [m.background] : [],
  };
}

// 8. Fetch IMDb Episodes for Series
export async function getImdbEpisodes(imdbId: string, seasonNumber: number): Promise<Episode[]> {
  const url = `${CINEMETA_META_BASE}/meta/series/${imdbId}.json`;
  const res = await imdbFetch<{ meta: any }>(url);
  if (!res || !res.meta || !Array.isArray(res.meta.videos)) return [];

  return res.meta.videos
    .filter((v: any) => v.season === seasonNumber)
    .sort((a: any, b: any) => (a.episode || 0) - (b.episode || 0))
    .map((v: any, idx: number): Episode => ({
      id: idx + 1,
      name: v.title || v.name || `Episode ${v.episode}`,
      overview: v.overview || v.description || 'Watch episode in Ultra HD.',
      stillPath: v.thumbnail || '',
      episodeNumber: v.episode || idx + 1,
      runtime: 45,
    }));
}

// 9. Search IMDb Catalog
export async function searchImdb(query: string): Promise<ContentItem[]> {
  if (!query || query.trim().length === 0) return [];

  const cleanQuery = query.trim().toLowerCase();
  const searchUrl = `${CINEMETA_META_BASE}/catalog/movie/top/search=${encodeURIComponent(cleanQuery)}.json`;
  const seriesSearchUrl = `${CINEMETA_META_BASE}/catalog/series/top/search=${encodeURIComponent(cleanQuery)}.json`;

  const [movieRes, seriesRes] = await Promise.all([
    imdbFetch<{ metas: any[] }>(searchUrl),
    imdbFetch<{ metas: any[] }>(seriesSearchUrl),
  ]);

  const results: ContentItem[] = [];
  const seenIds = new Set<string>();

  if (movieRes && Array.isArray(movieRes.metas)) {
    for (const m of movieRes.metas) {
      if (m && m.id && !seenIds.has(m.id)) {
        seenIds.add(m.id);
        results.push(mapCinemetaToContentItem(m, 'movie'));
      }
    }
  }

  if (seriesRes && Array.isArray(seriesRes.metas)) {
    for (const s of seriesRes.metas) {
      if (s && s.id && !seenIds.has(s.id)) {
        seenIds.add(s.id);
        results.push(mapCinemetaToContentItem(s, 'series'));
      }
    }
  }

  // Prioritize Recently Released and Trending Titles at the Top
  const currentYear = new Date().getFullYear();
  return results.sort((a, b) => {
    const aTitle = (a.title || '').toLowerCase();
    const bTitle = (b.title || '').toLowerCase();

    // Query inclusion
    const aIncludes = aTitle.includes(cleanQuery);
    const bIncludes = bTitle.includes(cleanQuery);
    if (aIncludes && !bIncludes) return -1;
    if (!aIncludes && bIncludes) return 1;

    const aYear = a.year || 0;
    const bYear = b.year || 0;

    // Filter unreleased future items to the bottom (> currentYear)
    const aFuture = aYear > currentYear;
    const bFuture = bYear > currentYear;
    if (aFuture && !bFuture) return 1;
    if (!aFuture && bFuture) return -1;

    // Trending bonus
    const aTrend = (a.badgeType === 'trending' || a.badgeType === 'popular') ? 10 : 0;
    const bTrend = (b.badgeType === 'trending' || b.badgeType === 'popular') ? 10 : 0;

    // Recency score (Higher recent year = Higher ranking up to current year)
    const aRecency = Math.min(aYear, currentYear);
    const bRecency = Math.min(bYear, currentYear);

    const aExact = aTitle === cleanQuery ? 2 : 0;
    const bExact = bTitle === cleanQuery ? 2 : 0;

    return (bRecency + bTrend + bExact) - (aRecency + aTrend + aExact);
  });
}
