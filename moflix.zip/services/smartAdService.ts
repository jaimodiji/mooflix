/**
 * MooFlix Ad-Free Mode: Interstitials permanently disabled.
 */
export const canShowSmartInterstitial = (_isAdBlockOn?: boolean): boolean => false;
export const markSmartInterstitialShown = () => {};
