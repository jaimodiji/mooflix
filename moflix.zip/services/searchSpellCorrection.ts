import Fuse from 'fuse.js';

/**
 * Advanced Fuzzy String Matching & Spell Correction powered by Fuse.js
 * Optimized for Romanized Hindi / Bollywood transliterations,
 * common phonetic typos, and Hollywood blockbuster titles.
 */

export interface CatalogTitleItem {
  title: string;
  aliases: string[];
  year?: number;
  type?: 'movie' | 'series';
}

// Canonical title database for fuzzy string matching via Fuse.js
export const TITLE_CATALOG: CatalogTitleItem[] = [
  // Bollywood Classics & Mega Hits
  {
    title: 'Dilwale Dulhania Le Jayenge',
    aliases: [
      'dil wale dulaniya le jaynge',
      'dilwale dulhaniya le jayenge',
      'dil wale dulhania le jayenge',
      'dil wale dulaniya',
      'dilwale dulhaniya',
      'dilwale dulhania',
      'ddlj',
      'shah rukh khan ddlj',
      'raj and simran',
    ],
    year: 1995,
    type: 'movie',
  },
  {
    title: 'Kabhi Khushi Kabhie Gham',
    aliases: ['k3g', 'kabhi khushi kabhi gham', 'kabhie khushi kabhie gham', 'kabhi kushi kabhi gam'],
    year: 2001,
    type: 'movie',
  },
  {
    title: 'Kuch Kuch Hota Hai',
    aliases: ['kkhh', 'kuch kuchh hota hai', 'kuch kuch hota h', 'kuchh kuchh hota hai'],
    year: 1998,
    type: 'movie',
  },
  {
    title: 'Hum Aapke Hain Koun..!',
    aliases: ['hum aapke hain koun', 'hum aapke hain kaun', 'hakhk'],
    year: 1994,
    type: 'movie',
  },
  {
    title: 'Yeh Jawaani Hai Deewani',
    aliases: ['yjhd', 'yeh jawani hai diwani', 'ye jawani hai deewani', 'ranbir kapoor yjhd'],
    year: 2013,
    type: 'movie',
  },
  {
    title: 'Zindagi Na Milegi Dobara',
    aliases: ['znmd', 'zindagi na milegi dobara', 'jindagi na milegi dobara'],
    year: 2011,
    type: 'movie',
  },
  {
    title: '3 Idiots',
    aliases: ['three idiots', '3 idiot', '3 idiots aamir khan', 'all is well'],
    year: 2009,
    type: 'movie',
  },
  {
    title: 'Taare Zameen Par',
    aliases: ['tare zameen par', 'taare zamen par', 'tare jameen par'],
    year: 2007,
    type: 'movie',
  },
  {
    title: 'Sholay',
    aliases: ['sholey', 'gabbar singh sholay', 'jai veeru'],
    year: 1975,
    type: 'movie',
  },
  {
    title: 'Gangs of Wasseypur',
    aliases: ['gow', 'gangs of wasseypur part 1', 'gang of wasseypur'],
    year: 2012,
    type: 'movie',
  },
  {
    title: 'Bajrangi Bhaijaan',
    aliases: ['bajrangi bhai jan', 'salman khan bajrangi bhaijaan'],
    year: 2015,
    type: 'movie',
  },
  {
    title: 'Om Shanti Om',
    aliases: ['oso', 'om santi om', 'srk om shanti om'],
    year: 2007,
    type: 'movie',
  },
  {
    title: 'Dangal',
    aliases: ['dangle', 'aamir khan dangal'],
    year: 2016,
    type: 'movie',
  },

  // Modern Pan-India & Bollywood Releases
  {
    title: 'Pushpa: The Rise',
    aliases: ['pushpa', 'puspa', 'pushpa 1', 'allu arjun pushpa the rise'],
    year: 2021,
    type: 'movie',
  },
  {
    title: 'Pushpa 2: The Rule',
    aliases: ['pushpa 2', 'puspa 2', 'pushpa the rule', 'pushpa part 2'],
    year: 2024,
    type: 'movie',
  },
  {
    title: 'Kalki 2898 AD',
    aliases: ['kalki', 'kalkee', 'kalki 2898', 'prabhas kalki 2898 ad'],
    year: 2024,
    type: 'movie',
  },
  {
    title: 'Stree 2',
    aliases: ['stree2', 'stri 2', 'stree sarkate ka aatank', 'shraddha kapoor stree 2'],
    year: 2024,
    type: 'movie',
  },
  {
    title: 'Devara: Part 1',
    aliases: ['devara', 'dewara', 'jr ntr devara', 'devara part 1'],
    year: 2024,
    type: 'movie',
  },
  {
    title: 'Salaar: Part 1 - Ceasefire',
    aliases: ['salaar', 'salar', 'salaar ceasefire', 'prabhas salaar'],
    year: 2023,
    type: 'movie',
  },
  {
    title: 'Baahubali: The Beginning',
    aliases: ['bahubali', 'baahubali 1', 'bahubali the beginning'],
    year: 2015,
    type: 'movie',
  },
  {
    title: 'Baahubali 2: The Conclusion',
    aliases: ['bahubali 2', 'baahubali 2', 'bahubali the conclusion'],
    year: 2017,
    type: 'movie',
  },
  {
    title: 'RRR',
    aliases: ['rrr movie', 'ss rajamouli rrr'],
    year: 2022,
    type: 'movie',
  },
  {
    title: 'Jawan',
    aliases: ['jawaan', 'srk jawan', 'shah rukh khan jawan'],
    year: 2023,
    type: 'movie',
  },
  {
    title: 'Pathaan',
    aliases: ['pathan', 'srk pathan', 'shah rukh khan pathaan'],
    year: 2023,
    type: 'movie',
  },
  {
    title: 'Animal',
    aliases: ['ranbir kapoor animal', 'animal movie ranbir'],
    year: 2023,
    type: 'movie',
  },
  {
    title: 'Kantara',
    aliases: ['kantara chapter 1', 'rishab shetty kantara'],
    year: 2022,
    type: 'movie',
  },
  {
    title: 'K.G.F: Chapter 1',
    aliases: ['kgf', 'kgf 1', 'yash kgf'],
    year: 2018,
    type: 'movie',
  },
  {
    title: 'K.G.F: Chapter 2',
    aliases: ['kgf 2', 'kgf chapter 2'],
    year: 2022,
    type: 'movie',
  },

  // Hollywood Blockbusters
  {
    title: 'Deadpool & Wolverine',
    aliases: ['deadpool 3', 'deadpol and wolverin', 'deadpool and wolverine', 'deadpool wolverine'],
    year: 2024,
    type: 'movie',
  },
  {
    title: 'Interstellar',
    aliases: ['interstelar', 'interstaler', 'christopher nolan interstellar'],
    year: 2014,
    type: 'movie',
  },
  {
    title: 'Inception',
    aliases: ['inceptoin', 'leonardo dicaprio inception'],
    year: 2010,
    type: 'movie',
  },
  {
    title: 'Oppenheimer',
    aliases: ['oppenhiemer', 'openheimer', 'cillian murphy oppenheimer'],
    year: 2023,
    type: 'movie',
  },
  {
    title: 'Avengers: Endgame',
    aliases: ['avangers endgame', 'avengers end game', 'marvel endgame'],
    year: 2019,
    type: 'movie',
  },
  {
    title: 'Spider-Man: No Way Home',
    aliases: ['spiderman no way home', 'spider man no way home', 'no way home'],
    year: 2021,
    type: 'movie',
  },
  {
    title: 'The Dark Knight',
    aliases: ['dark knight', 'batman the dark knight', 'joker dark knight'],
    year: 2008,
    type: 'movie',
  },
  {
    title: 'Breaking Bad',
    aliases: ['brba', 'walter white breaking bad', 'heisenberg'],
    year: 2008,
    type: 'series',
  },
  {
    title: 'Game of Thrones',
    aliases: ['got', 'game of throne', 'winter is coming'],
    year: 2011,
    type: 'series',
  },
  {
    title: 'Stranger Things',
    aliases: ['stranger thing', 'eleven stranger things', 'netflix stranger things', 'netflix original'],
    year: 2016,
    type: 'series',
  },
  {
    title: 'Dilwale Dulhania Le Jayenge',
    aliases: ['bollyflix ddlj', 'moviesflix ddlj', 'mojflix ddlj'],
    year: 1995,
    type: 'movie',
  },
];

// Initialize Fuse.js for Title Catalog with optimal fuzzy configuration
export const titleFuse = new Fuse(TITLE_CATALOG, {
  keys: [
    { name: 'title', weight: 0.6 },
    { name: 'aliases', weight: 0.9 },
  ],
  includeScore: true,
  threshold: 0.55, // Generous threshold to catch heavily misspelled titles like 'dil wale dulaniya le jaynge'
  distance: 120,
  ignoreLocation: true,
  minMatchCharLength: 3,
});

export interface FuzzyMatchResult {
  matchedTitle: string;
  confidenceScore: number;
  year?: number;
  type?: 'movie' | 'series';
}

/**
 * Searches the canonical title database using Fuse.js fuzzy string matching.
 */
export function fuseFuzzyMatchTitle(input: string): FuzzyMatchResult | null {
  const trimmed = input.trim();
  if (trimmed.length < 3) return null;

  const results = titleFuse.search(trimmed);
  if (results && results.length > 0) {
    const top = results[0];
    if (top.score !== undefined && top.score <= 0.6) {
      return {
        matchedTitle: top.item.title,
        confidenceScore: top.score,
        year: top.item.year,
        type: top.item.type,
      };
    }
  }
  return null;
}

export interface SpellCheckResult {
  originalQuery: string;
  correctedQuery: string;
  hasCorrection: boolean;
  confidence: 'fuse' | 'exact' | 'none';
  year?: number;
  type?: 'movie' | 'series';
}

/**
 * Corrects spelling mistakes and Romanized Hindi typos using Fuse.js fuzzy matching.
 */
export function correctSearchSpelling(input: string): SpellCheckResult {
  const trimmed = input.trim();
  if (!trimmed) {
    return {
      originalQuery: input,
      correctedQuery: input,
      hasCorrection: false,
      confidence: 'none',
    };
  }

  // 1. Fuse.js Fuzzy String Matching (Primary Engine)
  const fuseMatch = fuseFuzzyMatchTitle(trimmed);
  if (fuseMatch) {
    const hasCorrection = fuseMatch.matchedTitle.toLowerCase() !== trimmed.toLowerCase();
    return {
      originalQuery: trimmed,
      correctedQuery: fuseMatch.matchedTitle,
      hasCorrection,
      confidence: 'fuse',
      year: fuseMatch.year,
      type: fuseMatch.type,
    };
  }

  return {
    originalQuery: trimmed,
    correctedQuery: trimmed,
    hasCorrection: false,
    confidence: 'none',
  };
}
