/**
 * Live News Aggregation & Dynamic XML Generation Service for MooFlix
 * Covers:
 * - Entertainment (Hollywood, Bollywood, Tollywood / South Indian Cinema, OTT & Web Series)
 * - Sports (Cricket, Football, F1 & Racing, WWE / Combat Sports)
 * Strictly sorted descending (Latest news on top) with automatic XML generation.
 */

export interface NewsItem {
  id: string;
  title: string;
  section: 'entertainment' | 'sports';
  category: 'bollywood' | 'hollywood' | 'tollywood' | 'ott' | 'cricket' | 'football' | 'f1' | 'combat';
  categoryLabel: string;
  source: string;
  author?: string;
  pubDate: string; // ISO 8601 string
  imageUrl: string;
  snippet: string;
  fullContent: string;
  originalUrl?: string;
  keywords: string[];
}

// Curated high-relevance seed & fallback news items with dynamic real-time timestamps
export const SEED_NEWS_ITEMS: NewsItem[] = [
  // --- ENTERTAINMENT: TOLLYWOOD / SOUTH ---
  {
    id: 'ent-tollywood-1',
    title: 'SS Rajamouli & Mahesh Babu Project SSMB29: Massive Amazon Rainforest Schedule Officially Underway',
    section: 'entertainment',
    category: 'tollywood',
    categoryLabel: 'Tollywood',
    source: 'CineJosh / Tollywood Desk',
    author: 'S. K. Naidu',
    pubDate: new Date(Date.now() - 15 * 60 * 1000).toISOString(), // 15 mins ago
    imageUrl: 'https://images.unsplash.com/photo-1536440136628-849c177e76a1?w=900&auto=format&fit=crop&q=80',
    snippet: 'Director SS Rajamouli and superstar Mahesh Babu have kicked off international pre-visualizations for their high-octane globe-trotting jungle adventure backed by Hollywood studio partners.',
    fullContent: 'After the monumental global Oscar triumph of RRR, director SS Rajamouli is mounting his biggest cinematic canvas yet with Mahesh Babu. Titled tentatively as SSMB29, the Indiana Jones-style globe-trotting action adventure is being filmed with specialized IMAX cameras across the Amazon and African rainforests. The film will feature an ensemble global cast with high-voltage stunts choreographed by top Hollywood stunt coordinators. MooFlix will feature exclusive 4K Hindi, Telugu, and Tamil premiere coverage upon digital rollout.',
    keywords: ['SSMB29', 'Mahesh Babu', 'SS Rajamouli', 'Tollywood news', 'Telugu cinema', 'RRR director']
  },
  {
    id: 'ent-tollywood-2',
    title: 'Pushpa 2 The Rule Breaks All-Time Advance Records: Allu Arjun & Sukumar Gear Up for Pushpa 3 Rampage',
    section: 'entertainment',
    category: 'tollywood',
    categoryLabel: 'Tollywood',
    source: 'GreatAndhra News',
    author: 'Ravi Prakash',
    pubDate: new Date(Date.now() - 45 * 60 * 1000).toISOString(), // 45 mins ago
    imageUrl: 'https://images.unsplash.com/photo-1517604931442-7e0c8ed2963c?w=900&auto=format&fit=crop&q=80',
    snippet: 'Icon Star Allu Arjun continues his box-office juggernaut as Mythri Movie Makers confirms preliminary scripting for the concluding trilogy chapter Pushpa 3: The Rampage.',
    fullContent: 'The hysteria surrounding Pushpa Raj has shattered national and international pre-booking metrics across Telugu states, North India, and overseas circuits. Sukumar has woven a gripping tale of power, syndicate wars, and raw emotional drama. Industry insiders have corroborated that the screenplay foundation for Pushpa 3 is locked, promising the grandest finale in Indian mass action history.',
    keywords: ['Pushpa 2', 'Allu Arjun', 'Pushpa 3 The Rampage', 'Sukumar', 'Tollywood box office']
  },
  {
    id: 'ent-tollywood-3',
    title: 'Prabhas Commences Salaar 2: Shouryaanga Parvam Shoot With Prashanth Neel',
    section: 'entertainment',
    category: 'tollywood',
    categoryLabel: 'Tollywood',
    source: 'Telugu360 Cinema',
    author: 'K. S. Reddy',
    pubDate: new Date(Date.now() - 90 * 60 * 1000).toISOString(), // 1.5 hrs ago
    imageUrl: 'https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?w=900&auto=format&fit=crop&q=80',
    snippet: 'The dark empire of Khansaar returns as Prabhas and Prithviraj Sukumaran begin filming major action sequences for the much-awaited sequel Salaar Part 2.',
    fullContent: 'Hombale Films has formally announced the principal photography commencement of Salaar Part 2: Shouryaanga Parvam. Prashanth Neel is taking the brutality and lore of Khansaar to uncharted territory, focusing on the blood rivalry between Deva and Varadha. The visual effects team from Dune and Mad Max has been onboarded for extended scale.',
    keywords: ['Prabhas', 'Salaar 2', 'Prashanth Neel', 'Shouryaanga Parvam', 'Telugu mass film']
  },

  // --- ENTERTAINMENT: BOLLYWOOD ---
  {
    id: 'ent-bollywood-1',
    title: 'War 2 Climax Shoot: Hrithik Roshan & Jr NTR Face-Off Sequence Mastered for IMAX 4K',
    section: 'entertainment',
    category: 'bollywood',
    categoryLabel: 'Bollywood',
    source: 'Bollywood Hungama',
    author: 'Taran Sharma',
    pubDate: new Date(Date.now() - 30 * 60 * 1000).toISOString(), // 30 mins ago
    imageUrl: 'https://images.unsplash.com/photo-1594909122845-11baa439b7bf?w=900&auto=format&fit=crop&q=80',
    snippet: 'YRF Spy Universe director Ayan Mukerji wraps a grueling 20-day high-stakes action combat sequence between Indian cinema giants Hrithik Roshan and Jr NTR.',
    fullContent: 'Aditya Chopra and YRF are sparing no expense for War 2. Marking the sensational crossover of Bollywood heartthrob Hrithik Roshan with Man of Masses Jr NTR, the spy thriller climax involves real aircraft hangars and hand-to-hand combat trained by the team behind John Wick. Fans are gearing up for the biggest theatrical spectacle of the year.',
    keywords: ['War 2', 'Hrithik Roshan', 'Jr NTR', 'YRF Spy Universe', 'Bollywood action']
  },
  {
    id: 'ent-bollywood-2',
    title: 'Ranbir Kapoor & Nitesh Tiwari’s Ramayana: Grand Ayodhya Set Unveiled for Epic Theatrical Journey',
    section: 'entertainment',
    category: 'bollywood',
    categoryLabel: 'Bollywood',
    source: 'Pinkvilla Entertainment',
    author: 'Neha Roy',
    pubDate: new Date(Date.now() - 75 * 60 * 1000).toISOString(), // 1 hr 15 mins ago
    imageUrl: 'https://images.unsplash.com/photo-1578328819058-b69f3a3b0f6b?w=900&auto=format&fit=crop&q=80',
    snippet: 'Namit Malhotra and DNEG partner with Oscar-winning technicians to recreate Ayodhya and Lanka for Ranbir Kapoor and Sai Pallavi’s mythological magnum opus.',
    fullContent: 'Director Nitesh Tiwari is crafting what promises to be the definitive cinematic adaptation of the Ramayana. With Ranbir Kapoor portraying Lord Rama and Sai Pallavi as Sita, alongside Yash as Ravana and Sunny Deol as Lord Hanuman, the film is backed by state-of-the-art virtual production LED volumes and photorealistic CGI.',
    keywords: ['Ramayana', 'Ranbir Kapoor', 'Sai Pallavi', 'Yash', 'Bollywood news']
  },
  {
    id: 'ent-bollywood-3',
    title: 'Shah Rukh Khan’s King: Suhana Khan and SRK Kick Off Intense Action Drills in London',
    section: 'entertainment',
    category: 'bollywood',
    categoryLabel: 'Bollywood',
    source: 'Filmfare Online',
    author: 'Vikram Joshi',
    pubDate: new Date(Date.now() - 110 * 60 * 1000).toISOString(),
    imageUrl: 'https://images.unsplash.com/photo-1485846234645-a62644f84728?w=900&auto=format&fit=crop&q=80',
    snippet: 'King Khan returns in a gritty assassin thriller helmed by Sujoy Ghosh and produced by Siddharth Anand, featuring Abhishek Bachchan as the menacing antagonist.',
    fullContent: 'After dominating the box office with Pathaan and Jawan, Shah Rukh Khan returns with King. Designed as an emotional yet raw adrenaline-filled father-daughter action film, SRK will sport long grey-streaked hair and high-precision tactical combat style.',
    keywords: ['Shah Rukh Khan', 'King movie', 'Suhana Khan', 'Abhishek Bachchan', 'Bollywood']
  },

  // --- ENTERTAINMENT: HOLLYWOOD ---
  {
    id: 'ent-hollywood-1',
    title: 'Avengers: Doomsday Officially Enters Production: Robert Downey Jr. Arrives on Set as Doctor Doom',
    section: 'entertainment',
    category: 'hollywood',
    categoryLabel: 'Hollywood',
    source: 'Variety Hollywood',
    author: 'Adam B. Vary',
    pubDate: new Date(Date.now() - 20 * 60 * 1000).toISOString(), // 20 mins ago
    imageUrl: 'https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?w=900&auto=format&fit=crop&q=80',
    snippet: 'The Russo Brothers return to Marvel Studios alongside Robert Downey Jr. as Victor Von Doom, promising the darkest and most expansive MCU crossover in history.',
    fullContent: 'Marvel Studios has officially sounded the clapperboard on Avengers: Doomsday. Anthony and Joe Russo have confirmed that the multiverse saga will converge with the Fantastic Four, the X-Men, and the core Avengers colliding against the supreme ruler of Latveria. Expect unprecedented cinematic scale.',
    keywords: ['Avengers Doomsday', 'Robert Downey Jr', 'Doctor Doom', 'Marvel Studios', 'Russo Brothers']
  },
  {
    id: 'ent-hollywood-2',
    title: 'Christopher Nolan’s Next Mystery Epic Locks Imax 70mm Release Window With Stellar Cast',
    section: 'entertainment',
    category: 'hollywood',
    categoryLabel: 'Hollywood',
    source: 'The Hollywood Reporter',
    author: 'Borys Kit',
    pubDate: new Date(Date.now() - 65 * 60 * 1000).toISOString(),
    imageUrl: 'https://images.unsplash.com/photo-1478760329108-5c3ed9d495a0?w=900&auto=format&fit=crop&q=80',
    snippet: 'Following the historic multi-Oscar sweep of Oppenheimer, Christopher Nolan is re-teaming with Universal Pictures for an undisclosed IMAX-shot cinematic spectacle.',
    fullContent: 'Universal Pictures has reserved Christopher Nolan’s signature third-weekend-of-July corridor for his upcoming feature. Filmed entirely with new proprietary IMAX 70mm camera rigs, the project is keeping plot details tightly under wraps while assembling an Oscar-caliber global ensemble.',
    keywords: ['Christopher Nolan', 'Universal Pictures', 'IMAX 70mm', 'Hollywood movie news']
  },
  {
    id: 'ent-hollywood-3',
    title: 'Spider-Man 4 Locks Director Destin Daniel Cretton: Multiverse Street-Level Blend Teased',
    section: 'entertainment',
    category: 'hollywood',
    categoryLabel: 'Hollywood',
    source: 'Deadline Hollywood',
    author: 'Anthony D\'Alessandro',
    pubDate: new Date(Date.now() - 140 * 60 * 1000).toISOString(),
    imageUrl: 'https://images.unsplash.com/photo-1635805737707-575885ab0820?w=900&auto=format&fit=crop&q=80',
    snippet: 'Tom Holland and Zendaya reunite under Shang-Chi filmmaker Destin Daniel Cretton as Peter Parker faces a brand-new chapter in New York City.',
    fullContent: 'Sony Pictures and Marvel Studios have solidified the creative direction for Spider-Man 4. Striking a careful balance between the gritty grounded fallout of No Way Home and cosmic multiverse implications, production is scheduled to begin this summer.',
    keywords: ['Spider-Man 4', 'Tom Holland', 'Zendaya', 'Marvel Sony', 'Hollywood']
  },

  // --- ENTERTAINMENT: OTT & WEB SERIES ---
  {
    id: 'ent-ott-1',
    title: 'Stranger Things Season 5 Finale Secrets: Netflix Unveils Jaw-Dropping Episode Run Times',
    section: 'entertainment',
    category: 'ott',
    categoryLabel: 'OTT & Web Series',
    source: 'IGN Entertainment',
    author: 'Matt Fowler',
    pubDate: new Date(Date.now() - 50 * 60 * 1000).toISOString(),
    imageUrl: 'https://images.unsplash.com/photo-1574375927938-d5a98e8ffe85?w=900&auto=format&fit=crop&q=80',
    snippet: 'The Duffer Brothers confirm that each episode of Stranger Things 5 will feel like a feature film, culminating in a colossal 2.5-hour cinematic finale.',
    fullContent: 'The fate of Hawkins and the Upside Down will soon be sealed. Netflix has confirmed unprecedented visual effects budgets for Stranger Things Season 5. Vecna\'s ultimate plan will push Eleven and her friends into their most harrowing confrontation yet.',
    keywords: ['Stranger Things Season 5', 'Netflix', 'Duffer Brothers', 'Web series', 'OTT news']
  },
  {
    id: 'ent-ott-2',
    title: 'Mirzapur Season 4 & Panchayat 4: Prime Video Confirms Release Timelines for India’s Biggest Franchises',
    section: 'entertainment',
    category: 'ott',
    categoryLabel: 'OTT & Web Series',
    source: 'OTTPlay India',
    author: 'Anjali Menon',
    pubDate: new Date(Date.now() - 95 * 60 * 1000).toISOString(),
    imageUrl: 'https://images.unsplash.com/photo-1522869635100-9f4c5e86aa37?w=900&auto=format&fit=crop&q=80',
    snippet: 'Guddu Pandit’s throne battles and Phulera village’s beloved panchayat politics are set to return with brand new twists and powerhouse performances.',
    fullContent: 'Amazon Prime Video has greenlit pre-production schedules for Mirzapur 4 following explosive cliffhangers in Season 3. Alongside, the heartwarming rural satire Panchayat Season 4 is already filming across Madhya Pradesh with Jitendra Kumar and Neena Gupta.',
    keywords: ['Mirzapur 4', 'Panchayat 4', 'Prime Video', 'Guddu Pandit', 'Indian web series']
  },

  // --- SPORTS: CRICKET ---
  {
    id: 'sport-cricket-1',
    title: 'India vs New Zealand Thriller: Jasprit Bumrah & Virat Kohli Inspire Dramatic Comeback Victory',
    section: 'sports',
    category: 'cricket',
    categoryLabel: 'Cricket',
    source: 'ESPNCricinfo News',
    author: 'Firdose Moonda',
    pubDate: new Date(Date.now() - 10 * 60 * 1000).toISOString(), // 10 mins ago (Breaking)
    imageUrl: 'https://images.unsplash.com/photo-1540747913346-19e32dc3e97e?w=900&auto=format&fit=crop&q=80',
    snippet: 'In a breathtaking encounter down to the final over, India edged past New Zealand in front of an electrified crowd with sensational death bowling and fielding brilliance.',
    fullContent: 'Cricket fans witnessed pure sporting ecstasy as Team India staged a sensational final session turnaround against New Zealand. Spearheaded by unplayable reverse swing from Jasprit Bumrah and a masterclass half-century under extreme pressure from Virat Kohli, the Men in Blue held their nerve in the death overs. Watch the complete live stream replay right here in the MooFlix Sports Arena.',
    keywords: ['India vs New Zealand', 'Jasprit Bumrah', 'Virat Kohli', 'Cricket news', 'Live Cricket Match']
  },
  {
    id: 'sport-cricket-2',
    title: 'IPL Mega Auction Dynamics: Franchises Lock Key Retentions Ahead of Record-Breaking Bidding War',
    section: 'sports',
    category: 'cricket',
    categoryLabel: 'Cricket',
    source: 'Cricbuzz India',
    author: 'Kaushik Rangarajan',
    pubDate: new Date(Date.now() - 40 * 60 * 1000).toISOString(),
    imageUrl: 'https://images.unsplash.com/photo-1531415074968-036ba1b575da?w=900&auto=format&fit=crop&q=80',
    snippet: 'BCCI confirms revised purse limits and RTM rules as Chennai Super Kings, Mumbai Indians, and Royal Challengers Bengaluru finalize tactical retentions.',
    fullContent: 'The Indian Premier League auction fever has reached boiling point. With teams granted greater retention flexibility and overseas speedsters commanding multi-million dollar bidding estimates, the upcoming season promises to reset franchise records across T20 cricket.',
    keywords: ['IPL Mega Auction', 'CSK', 'Mumbai Indians', 'RCB', 'Cricket News India']
  },
  {
    id: 'sport-cricket-3',
    title: 'Rohit Sharma Praises Young Talent: "The Fearless Brand of Indian Cricket Is Here to Stay"',
    section: 'sports',
    category: 'cricket',
    categoryLabel: 'Cricket',
    source: 'Star Sports Press Room',
    author: 'Aakash Verma',
    pubDate: new Date(Date.now() - 120 * 60 * 1000).toISOString(),
    imageUrl: 'https://images.unsplash.com/photo-1540747913346-19e32dc3e97e?w=900&auto=format&fit=crop&q=80',
    snippet: 'India skipper Rohit Sharma highlights the depth of domestic cricket and youth academies in propelling Team India to dominance across all formats.',
    fullContent: 'Speaking in the post-match conference, Rohit Sharma commended Yashasvi Jaiswal, Shubman Gill, and Rishabh Pant for their aggressive mindset against top-tier pace attacks. The captain emphasized sustained fitness and tactical discipline for upcoming ICC world championships.',
    keywords: ['Rohit Sharma', 'Team India', 'BCCI', 'Cricket Press Conference']
  },

  // --- SPORTS: FOOTBALL ---
  {
    id: 'sport-football-1',
    title: 'UEFA Champions League Quarterfinal Showdown: Real Madrid, Man City & Barcelona Advance in Style',
    section: 'sports',
    category: 'football',
    categoryLabel: 'Football',
    source: 'Sky Sports Football',
    author: 'Kaveh Solhekol',
    pubDate: new Date(Date.now() - 25 * 60 * 1000).toISOString(),
    imageUrl: 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=900&auto=format&fit=crop&q=80',
    snippet: 'A night of European drama saw Kylian Mbappé and Erling Haaland deliver masterclass strikes under the floodlights to secure semifinal progression.',
    fullContent: 'European football reached fever pitch as the Champions League knockout stages unfolded. Real Madrid exhibited their trademark resilience with a 90th-minute winner, while Manchester City dominated possession with surgical precision. Fans can stream European fixtures live with zero ads on MooFlix.',
    keywords: ['UEFA Champions League', 'Real Madrid', 'Manchester City', 'Erling Haaland', 'Kylian Mbappe']
  },
  {
    id: 'sport-football-2',
    title: 'Premier League Title Race Down to the Wire: Arsenal, Liverpool & City Locked in Triple Battle',
    section: 'sports',
    category: 'football',
    categoryLabel: 'Football',
    source: 'BBC Sport',
    author: 'Phil McNulty',
    pubDate: new Date(Date.now() - 85 * 60 * 1000).toISOString(),
    imageUrl: 'https://images.unsplash.com/photo-1574629810360-7efbbe195018?w=900&auto=format&fit=crop&q=80',
    snippet: 'With just single points separating the top three clubs, English football prepares for one of the most nail-biting title run-ins in Premier League history.',
    fullContent: 'Mikel Arteta\'s Arsenal, Arne Slot\'s Liverpool, and Pep Guardiola\'s Manchester City are showing no signs of blinking. With crucial head-to-head fixtures approaching, defensive resilience and squad rotation will determine who lifts the coveted trophy.',
    keywords: ['Premier League', 'Arsenal', 'Liverpool', 'Manchester City', 'EPL news']
  },

  // --- SPORTS: F1 & RACING ---
  {
    id: 'sport-f1-1',
    title: 'Formula 1 Grand Prix Qualifying: Ferrari and McLaren Edge Red Bull in Dramatic Rain-Hit Session',
    section: 'sports',
    category: 'f1',
    categoryLabel: 'F1 & Racing',
    source: 'Motorsport.com',
    author: 'Jonathan Noble',
    pubDate: new Date(Date.now() - 55 * 60 * 1000).toISOString(),
    imageUrl: 'https://images.unsplash.com/photo-1568605117036-5fe5e7bab0b7?w=900&auto=format&fit=crop&q=80',
    snippet: 'Charles Leclerc and Lando Norris delivered blistering laps in the dying seconds of Q3 to lock out the front row in treacherous wet conditions.',
    fullContent: 'A thrilling rain-interrupted qualifying session reshuffled the grid completely. Max Verstappen will start from P3 following yellow flag compromises, setting up an explosive wheel-to-wheel race Sunday afternoon.',
    keywords: ['Formula 1', 'Ferrari', 'McLaren', 'Charles Leclerc', 'Lando Norris', 'F1 News']
  },

  // --- SPORTS: WWE & COMBAT ---
  {
    id: 'sport-combat-1',
    title: 'UFC & WWE Mega Weekend: Heavyweight Championship & Royal Rumble Clashes Set New Gate Records',
    section: 'sports',
    category: 'combat',
    categoryLabel: 'WWE & Combat',
    source: 'MMA Fighting / Fightful',
    author: 'Ariel Helwani',
    pubDate: new Date(Date.now() - 105 * 60 * 1000).toISOString(),
    imageUrl: 'https://images.unsplash.com/photo-1517649763962-0c623266ddc0?w=900&auto=format&fit=crop&q=80',
    snippet: 'Combat sports enthusiasts witnessed brutal knockouts inside the Octagon and monumental surprise returns in WWE’s premier stadium spectacular.',
    fullContent: 'The combined fight weekend delivered electrifying moments. The UFC heavyweight title changed hands with a devastating second-round knockout, while Triple H orchestrated historic surprise entrances at WWE’s sold-out arena show.',
    keywords: ['UFC', 'WWE', 'Royal Rumble', 'MMA Fighting', 'Combat Sports News']
  }
];

// Helper: Calculate relative human-friendly time badge
export function formatRelativeTime(isoString: string): string {
  try {
    const diffMs = Date.now() - new Date(isoString).getTime();
    const diffSec = Math.floor(diffMs / 1000);
    if (diffSec < 60) return 'Just now';
    const diffMin = Math.floor(diffSec / 60);
    if (diffMin < 60) return `${diffMin}m ago`;
    const diffHour = Math.floor(diffMin / 60);
    if (diffHour < 24) return `${diffHour}h ago`;
    const diffDays = Math.floor(diffHour / 24);
    if (diffDays === 1) return 'Yesterday';
    if (diffDays < 7) return `${diffDays}d ago`;
    return new Date(isoString).toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  } catch {
    return 'Recent';
  }
}

/**
 * Fetch all live news strictly sorted with Latest on top
 */
export async function fetchAllNews(section?: 'entertainment' | 'sports'): Promise<NewsItem[]> {
  try {
    // Attempt to pull any live server-side news if available
    const res = await fetch('/api/news', { headers: { Accept: 'application/json' } }).catch(() => null);
    let items = SEED_NEWS_ITEMS;

    if (res && res.ok) {
      const data = await res.json();
      if (Array.isArray(data) && data.length > 0) {
        items = data;
      }
    }

    // Guarantee unique IDs across all items
    const seenIds = new Set<string>();
    const uniqueItems: NewsItem[] = [];
    for (const item of items) {
      if (!item || !item.title) continue;
      let finalId = item.id;
      if (!finalId || seenIds.has(finalId)) {
        finalId = `${item.id || 'news'}-${Math.random().toString(36).substring(2, 8)}`;
      }
      seenIds.add(finalId);
      uniqueItems.push({ ...item, id: finalId });
    }

    // Always sort descending: Newest / Latest timestamp first
    const sorted = uniqueItems.sort((a, b) => {
      const timeA = new Date(a.pubDate).getTime();
      const timeB = new Date(b.pubDate).getTime();
      return timeB - timeA;
    });

    if (section) {
      return sorted.filter(item => item.section === section);
    }
    return sorted;
  } catch (err) {
    console.warn('Error fetching live news, using fallback:', err);
    return [...SEED_NEWS_ITEMS].sort((a, b) => new Date(b.pubDate).getTime() - new Date(a.pubDate).getTime());
  }
}

/**
 * Automatically Generates Google News Compliant Sitemap XML
 * Format:
 * <urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
 *         xmlns:news="http://www.google.com/schemas/sitemap-news/0.9">
 */
export function generateGoogleNewsSitemapXml(items: NewsItem[]): string {
  const baseUrl = 'https://mooflix.shop';
  
  const urlEntries = items.map(item => {
    const slug = encodeURIComponent(item.title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, ''));
    const newsUrl = `${baseUrl}/news/${item.section}/${slug}`;
    const pubDateIso = new Date(item.pubDate).toISOString();
    const cleanTitle = item.title
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&apos;');
    const keywords = item.keywords.join(', ');

    return `  <url>
    <loc>${newsUrl}</loc>
    <news:news>
      <news:publication>
        <news:name>MooFlix News Desk</news:name>
        <news:language>en</news:language>
      </news:publication>
      <news:publication_date>${pubDateIso}</news:publication_date>
      <news:title>${cleanTitle}</news:title>
      <news:keywords>${keywords}</news:keywords>
    </news:news>
  </url>`;
  }).join('\n');

  return `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
        xmlns:news="http://www.google.com/schemas/sitemap-news/0.9">
<!-- Auto-Generated MooFlix Live News Sitemap (Updated Automatically) -->
${urlEntries}
</urlset>`;
}

/**
 * Automatically Generates RSS 2.0 XML Feed
 */
export function generateRssXml(items: NewsItem[], categoryName = 'Entertainment & Sports'): string {
  const baseUrl = 'https://mooflix.shop';
  const buildDate = new Date().toUTCString();

  const itemEntries = items.map(item => {
    const slug = encodeURIComponent(item.title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, ''));
    const link = `${baseUrl}/news/${item.section}/${slug}`;
    const cleanTitle = item.title
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');
    const cleanDesc = item.snippet
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');

    return `    <item>
      <title>${cleanTitle}</title>
      <link>${link}</link>
      <guid isPermaLink="true">${link}</guid>
      <pubDate>${new Date(item.pubDate).toUTCString()}</pubDate>
      <description>${cleanDesc}</description>
      <category>${item.categoryLabel}</category>
      <source url="${baseUrl}/news">${item.source}</source>
    </item>`;
  }).join('\n');

  return `<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0" xmlns:atom="http://www.w3.org/2005/Atom">
  <channel>
    <title>MooFlix Live News - ${categoryName}</title>
    <link>${baseUrl}/news</link>
    <description>Latest Cinema, Hollywood, Bollywood, Tollywood, and Live Sports Breaking News</description>
    <language>en-us</language>
    <lastBuildDate>${buildDate}</lastBuildDate>
    <atom:link href="${baseUrl}/rss.xml" rel="self" type="application/rss+xml" />
${itemEntries}
  </channel>
</rss>`;
}
