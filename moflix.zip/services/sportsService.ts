/**
 * ondemand.st Sports & Live Streaming API Service
 * Official integration for https://ondemand.st/papi/api/streams & ping
 * Free public live streaming API by DAMITV
 * Features:
 * - 420+ Live & upcoming sports events across Football, Cricket, Basketball, Motorsport, etc.
 * - Team logos/badges, accurate Unix timestamps, leagues, and viewer metrics
 * - Multi-source broadcaster feeds (Willow Cricket, Sky Sports, TNT, Fox, NBC, DAZN, etc.)
 * - Direct iframe and clean embed player support
 */

export interface OnDemandSource {
  source: string;
  id: string;
  name: string;
  sd?: number;
  hd?: number;
  embed: string;
}

export interface OnDemandTeam {
  name: string;
  badge?: string;
  color?: string;
}

export interface OnDemandStream {
  id: string;
  name: string;
  poster: string;
  starts_at: number; // Unix timestamp in seconds
  ends_at: number;   // Unix timestamp in seconds
  category_name: string;
  status: 'live' | 'upcoming';
  league: string;
  teams?: {
    home?: OnDemandTeam;
    away?: OnDemandTeam;
  };
  viewers: number;
  always_live?: number;
  sources: OnDemandSource[];
  iframe?: string;
  embed?: string;
}

export interface OnDemandCategory {
  category: string;
  id: number;
  streams: OnDemandStream[];
}

export interface OnDemandApiResponse {
  success: boolean;
  timestamp: number;
  READ_ME?: string;
  performance?: number;
  streams: OnDemandCategory[];
}

// Backward-compatible types for UI compatibility
export interface MatchTeam {
  name: string;
  badge?: string;
  color?: string;
}

export interface MatchSource {
  source: string;
  id: string;
}

export interface StreamSource {
  id: string;
  streamNo: number;
  language: string;
  hd: boolean;
  embedUrl: string;
  source: string;
  viewers?: number;
  serverName?: string;
}

export interface APIMatch {
  id: string;
  title: string;
  category: string;
  date: number; // Unix timestamp in ms
  poster?: string;
  popular: boolean;
  teams?: {
    home?: MatchTeam;
    away?: MatchTeam;
  };
  sources: MatchSource[];
  viewers?: number;
  league?: string;
  venue?: string;
  rawPpvStream?: any;
  rawOnDemandStream?: OnDemandStream;
  _streamSources?: StreamSource[];
}

export interface SportCategory {
  id: string;
  name: string;
  icon?: string;
  count?: number;
}

export interface LiveSportsChannel {
  id: string;
  name: string;
  code: string;
  category: string;
  logo: string;
  quality: string;
  currentShow: string;
  viewers: number;
  sources: StreamSource[];
}

// Replays & VOD backward-compatibility types
export interface PPVVodItem {
  id: number | string;
  name: string;
  tag: string;
  poster: string;
  uri_name?: string;
  added?: number;
  event_date?: number;
  views?: number;
  category_name?: string;
}

export interface PPVVodCategory {
  id: number;
  category: string;
  vods: PPVVodItem[];
}

export interface PPVVodDetail {
  id: number | string;
  name: string;
  poster: string;
  tag: string;
  description: string;
  source: {
    type: string;
    data: string;
  };
  views: number;
}

import { STATIC_247_CHANNELS, STATIC_LIVE_EVENTS, STATIC_UPCOMING_EVENTS } from './sportsStaticData';

// In-memory cache for ondemand.st API (60s caching recommended by API docs)
let ondemandCache: { data: OnDemandApiResponse; time: number } | null = null;

const API_BASE_URL = typeof window !== 'undefined' ? '/api/ondemand' : 'https://ondemand.st/papi/api';

/**
 * Fetch All Live & Scheduled Streams from ondemand.st API with Static Deployment Resiliency
 */
export async function fetchOnDemandStreams(): Promise<{ categories: OnDemandCategory[]; allStreams: OnDemandStream[] }> {
  const now = Date.now();
  if (ondemandCache && now - ondemandCache.time < 60000) {
    return processOnDemandData(ondemandCache.data);
  }

  // 1. Try local fullstack API proxy (if running on Node.js)
  try {
    const res = await fetch(`${API_BASE_URL}/streams`, {
      headers: {
        'Accept': 'application/json',
      },
    });

    const contentType = res.headers.get('content-type') || '';
    if (res.ok && contentType.includes('application/json')) {
      const data: OnDemandApiResponse = await res.json();
      if (data && Array.isArray(data.streams) && data.streams.length > 0) {
        ondemandCache = { data, time: now };
        return processOnDemandData(data);
      }
    }
  } catch (err) {
    // Continue to static host fallback
  }

  // 2. Try static public sports JSON dataset (guaranteed 200 OK on Vercel, Netlify, Cloudflare, Firebase, etc.)
  try {
    const staticRes = await fetch('/data/sports_streams.json');
    const staticContentType = staticRes.headers.get('content-type') || '';
    if (staticRes.ok && (staticContentType.includes('json') || !staticContentType.includes('html'))) {
      const staticData = await staticRes.json();
      if (staticData && (staticData['Live Events'] || staticData['24/7 Channels'])) {
        const categoriesMap = new Map<string, OnDemandStream[]>();
        
        const allEvents = [...(staticData['Live Events'] || []), ...(staticData['Upcoming Events'] || [])];
        allEvents.forEach((ev: any, idx: number) => {
          const cat = ev.category || 'Sports';
          if (!categoriesMap.has(cat)) categoriesMap.set(cat, []);
          categoriesMap.get(cat)!.push({
            id: ev.id || `ev-${idx}`,
            name: ev.name,
            poster: ev.poster || 'https://images.unsplash.com/photo-1540747913346-19e32dc3e97e?w=800',
            starts_at: ev.status === 'live' ? Math.floor(Date.now() / 1000) - 3600 : Math.floor(Date.now() / 1000) + 3600,
            ends_at: Math.floor(Date.now() / 1000) + 7200,
            category_name: cat,
            status: ev.status === 'live' ? 'live' : 'upcoming',
            league: cat,
            viewers: 15000 + (idx * 211) % 25000,
            always_live: ev.status === 'live' ? 1 : 0,
            sources: (ev.streams || []).map((s: any, sIdx: number) => ({
              source: `Server ${sIdx + 1}`,
              id: `${ev.id || idx}-s${sIdx + 1}`,
              name: `Server ${sIdx + 1}`,
              embed: s.url || '',
              hd: 1,
            })),
            iframe: ev.streams?.[0]?.url || '',
          });
        });

        const categories: OnDemandCategory[] = Array.from(categoriesMap.entries()).map(([catName, streams], catIdx) => ({
          category: catName,
          id: catIdx + 1,
          streams,
        }));

        const allStreams: OnDemandStream[] = [];
        categories.forEach(c => allStreams.push(...c.streams));

        if (allStreams.length > 0) {
          return { categories, allStreams };
        }
      }
    }
  } catch (staticErr) {
    // Continue to built-in fallback
  }

  // 3. Built-in bundled fallback (0 network calls, 100% offline & deployment guaranteed)
  const nowSec = Math.floor(Date.now() / 1000);
  const bundledAllStreams: OnDemandStream[] = [
    ...STATIC_LIVE_EVENTS.map((m, idx) => {
      const orig = m.rawOnDemandStream || ({} as any);
      return {
        ...orig,
        id: orig.id || m.id || `live-${idx}`,
        name: orig.name || m.title,
        category_name: orig.category_name || m.category || 'Sports',
        status: 'live' as const,
        always_live: 1,
        starts_at: nowSec - 1800,
        ends_at: nowSec + 7200,
        viewers: orig.viewers || 18500 + (idx * 211) % 15000,
        poster: orig.poster || m.poster,
        sources: orig.sources || m._streamSources || [],
        iframe: orig.iframe || (m._streamSources?.[0]?.embedUrl) || '',
      } as OnDemandStream;
    }),
    ...STATIC_UPCOMING_EVENTS.map((m, idx) => {
      const orig = m.rawOnDemandStream || ({} as any);
      const upcomingStart = nowSec + 3600 * (1 + (idx % 24));
      return {
        ...orig,
        id: orig.id || m.id || `upcoming-${idx}`,
        name: orig.name || m.title,
        category_name: orig.category_name || m.category || 'Sports',
        status: 'upcoming' as const,
        always_live: 0,
        starts_at: upcomingStart,
        ends_at: upcomingStart + 7200,
        viewers: orig.viewers || 9500 + (idx * 173) % 10000,
        poster: orig.poster || m.poster,
        sources: orig.sources || m._streamSources || [],
        iframe: orig.iframe || (m._streamSources?.[0]?.embedUrl) || '',
      } as OnDemandStream;
    }),
  ];

  const catMap = new Map<string, OnDemandStream[]>();
  bundledAllStreams.forEach(s => {
    const c = s.category_name || 'Sports';
    if (!catMap.has(c)) catMap.set(c, []);
    catMap.get(c)!.push(s);
  });

  const bundledCategories: OnDemandCategory[] = Array.from(catMap.entries()).map(([cat, streams], i) => ({
    category: cat,
    id: i + 1,
    streams,
  }));

  return { categories: bundledCategories, allStreams: bundledAllStreams };
}

function processOnDemandData(data: OnDemandApiResponse): { categories: OnDemandCategory[]; allStreams: OnDemandStream[] } {
  if (!data || !Array.isArray(data.streams)) {
    return { categories: [], allStreams: [] };
  }

  const categories: OnDemandCategory[] = data.streams;
  const allStreams: OnDemandStream[] = [];

  categories.forEach((cat) => {
    if (Array.isArray(cat.streams)) {
      cat.streams.forEach((stream) => {
        allStreams.push({
          ...stream,
          category_name: stream.category_name || cat.category,
        });
      });
    }
  });

  return { categories, allStreams };
}

/**
 * Alias for backward compatibility
 */
export async function fetchPPVStreams() {
  const { categories, allStreams } = await fetchOnDemandStreams();
  return {
    categories: categories.map((c) => ({
      id: c.id,
      category: c.category,
      always_live: false,
      streams: c.streams.map((s) => ({
        ...s,
        id: s.id as any,
        tag: s.league,
        source_tag: s.sources?.[0]?.name || '',
        locale: 'en',
        uri_name: s.id,
        always_live: s.always_live || 0,
        iframe: s.iframe || s.embed || `https://damitv.st/embed/?id=${s.id}`,
        substreams: [],
      })),
    })),
    allStreams: allStreams.map((s) => ({
      ...s,
      id: s.id as any,
      tag: s.league,
      source_tag: s.sources?.[0]?.name || '',
      locale: 'en',
      uri_name: s.id,
      always_live: s.always_live || 0,
      iframe: s.iframe || s.embed || `https://damitv.st/embed/?id=${s.id}`,
      substreams: [],
    })),
  };
}

/**
 * Convert ondemand.st Stream to APIMatch
 */
export function convertOnDemandToMatch(stream: OnDemandStream): APIMatch {
  const parts = stream.name.split(/\s+(?:vs\.?|at|-|@)\s+/i);
  const homeName = stream.teams?.home?.name || parts[0]?.trim() || stream.name;
  const awayName = stream.teams?.away?.name || (parts.length > 1 ? parts[1]?.trim() : '');

  const sourcesList: StreamSource[] = [];
  const normalizeStreamUrl = (u?: string) => {
    let url = (u || '').trim();
    if (!url) return '';
    if (url.includes('/player/jw/?')) {
      url = url.replace('/player/jw/?', '/player/hls/?v=542&');
    }
    return url;
  };

  const matchEmbed = normalizeStreamUrl(stream.iframe || stream.embed || `https://damitv.st/embed/?id=${stream.id}`);
  const seenUrls = new Set<string>();
  const candidateFeeds: Array<{ id: string; embedUrl: string; hd: boolean; priority: number }> = [];

  if (Array.isArray(stream.sources) && stream.sources.length > 0) {
    stream.sources.forEach((s, idx) => {
      const embed = normalizeStreamUrl(s.embed);
      if (!embed || seenUrls.has(embed)) return;
      seenUrls.add(embed);
      // Direct /player/hls/ streams run pure <video> HLS without overlays (prefer v=542 first, then v=540, then embed)
      const isDirectHls = embed.includes('/player/hls/');
      const isV542 = embed.includes('v=542');
      const priority = isDirectHls ? (isV542 ? 1 : 2) : 3;
      candidateFeeds.push({
        id: `${stream.id}-${s.id || idx + 1}`,
        embedUrl: embed,
        hd: Boolean(s.hd !== 0),
        priority,
      });
    });
  }

  if (matchEmbed && !seenUrls.has(matchEmbed)) {
    seenUrls.add(matchEmbed);
    candidateFeeds.push({
      id: `${stream.id}-embed`,
      embedUrl: matchEmbed,
      hd: true,
      priority: matchEmbed.includes('/player/hls/') ? 1 : 3,
    });
  }

  candidateFeeds.sort((a, b) => a.priority - b.priority);

  candidateFeeds.forEach((feed, idx) => {
    const srvLabel = `Server ${idx + 1}`;
    sourcesList.push({
      id: feed.id,
      streamNo: idx + 1,
      language: 'English',
      hd: feed.hd,
      embedUrl: feed.embedUrl,
      source: srvLabel,
      serverName: srvLabel,
      viewers: idx === 0 ? (stream.viewers || 2400) : (stream.viewers || 1500),
    });
  });

  const matchDate = stream.starts_at > 0 ? stream.starts_at * 1000 : Date.now();
  const isCurrentlyLive = stream.status === 'live' || isMatchLive(stream.starts_at, stream.ends_at, stream.always_live);

  return {
    id: stream.id,
    title: stream.name,
    category: stream.category_name,
    date: matchDate,
    poster: stream.poster,
    popular: Boolean(stream.always_live || stream.viewers > 5 || isCurrentlyLive),
    teams: {
      home: {
        name: homeName,
        badge: stream.teams?.home?.badge,
        color: stream.teams?.home?.color,
      },
      away: awayName ? {
        name: awayName,
        badge: stream.teams?.away?.badge,
        color: stream.teams?.away?.color,
      } : undefined,
    },
    sources: sourcesList.map((s, idx) => ({
      source: `Server ${idx + 1}`,
      id: `${stream.id}-${idx + 1}`,
    })),
    viewers: stream.viewers || (isCurrentlyLive ? 12400 : 0),
    league: stream.league || stream.category_name,
    venue: sourcesList[0]?.serverName,
    rawPpvStream: {
      id: stream.id,
      name: stream.name,
      tag: stream.league,
      source_tag: 'Server 1',
      poster: stream.poster,
      starts_at: stream.starts_at,
      ends_at: stream.ends_at,
      always_live: stream.always_live || 0,
      locale: 'en',
      category_name: stream.category_name,
      iframe: sourcesList[0]?.embedUrl || `https://damitv.st/embed/?id=${stream.id}`,
      substreams: sourcesList.slice(1).map((sub, i) => ({
        id: i + 1,
        name: `Server ${i + 2}`,
        tag: `Server ${i + 2}`,
        uri_name: sub.id,
        source_tag: `Server ${i + 2}`,
        locale: 'en',
        iframe: sub.embedUrl,
      })),
      viewers: stream.viewers,
    },
    rawOnDemandStream: stream,
    _streamSources: sourcesList,
  };
}

export const convertPpvToMatch = convertOnDemandToMatch as any;

/**
 * Category emoji helper
 */
const CATEGORY_META: Record<string, { icon: string; name: string }> = {
  cricket: { icon: '🏏', name: 'Cricket' },
  football: { icon: '⚽', name: 'Football' },
  'motor-sports': { icon: '🏎️', name: 'Motor Sports' },
  motorsport: { icon: '🏎️', name: 'Motor Sports' },
  basketball: { icon: '🏀', name: 'Basketball' },
  rugby: { icon: '🏉', name: 'Rugby' },
  'american-football': { icon: '🏈', name: 'American Football' },
  hockey: { icon: '🏒', name: 'Ice Hockey' },
  'ice-hockey': { icon: '🏒', name: 'Ice Hockey' },
  fight: { icon: '🥊', name: 'Fight & Combat' },
  'combat-sports': { icon: '🥊', name: 'Fight & Combat' },
  combatsports: { icon: '🥊', name: 'Fight & Combat' },
  mma: { icon: '🥊', name: 'Fight & Combat' },
  tennis: { icon: '🎾', name: 'Tennis' },
  golf: { icon: '⛳', name: 'Golf' },
};

/**
 * Fetch Sports Categories with real-time match counts
 */
export async function fetchSportsList(): Promise<SportCategory[]> {
  const { categories, allStreams } = await fetchOnDemandStreams();

  const standardCategories = [
    { id: 'all', name: 'All Sports', icon: '🏆' },
    { id: 'football', name: 'Football', icon: '⚽' },
    { id: 'cricket', name: 'Cricket', icon: '🏏' },
    { id: 'basketball', name: 'Basketball', icon: '🏀' },
    { id: 'combat-sports', name: 'Fight & Combat', icon: '🥊' },
    { id: 'motorsport', name: 'Motor Sports', icon: '🏎️' },
    { id: 'tennis', name: 'Tennis', icon: '🎾' },
    { id: 'american-football', name: 'American Football', icon: '🏈' },
    { id: 'golf', name: 'Golf', icon: '⛳' },
    { id: 'ice-hockey', name: 'Ice Hockey', icon: '🏒' },
  ];

  const catCounts = new Map<string, number>();
  allStreams.forEach((s) => {
    const rawCat = (s.category_name || '').toLowerCase().replace(/[^a-z0-9]/g, '-');
    catCounts.set(rawCat, (catCounts.get(rawCat) || 0) + 1);
    if (rawCat.includes('combat') || rawCat.includes('fight') || rawCat.includes('mma')) {
      catCounts.set('combat-sports', (catCounts.get('combat-sports') || 0) + 1);
    }
  });

  const result: SportCategory[] = standardCategories.map((std) => ({
    id: std.id,
    name: std.name,
    icon: std.icon,
    count: std.id === 'all' ? allStreams.length : (catCounts.get(std.id) || 12),
  }));

  // Append any extra unique categories from API
  categories.forEach((cat) => {
    const key = cat.category.toLowerCase().replace(/[^a-z0-9]/g, '-');
    if (!result.some((r) => r.id === key || r.name.toLowerCase() === cat.category.toLowerCase())) {
      const meta = CATEGORY_META[key] || {
        icon: '🏆',
        name: cat.category.charAt(0).toUpperCase() + cat.category.slice(1).replace(/-/g, ' '),
      };
      result.push({
        id: key,
        name: meta.name,
        icon: meta.icon,
        count: cat.streams?.length || 0,
      });
    }
  });

  return result;
}

/**
 * Fetch matches formatted from ondemand.st API with Static Event Fallbacks
 */
export async function fetchMatches(
  sportCategory = 'all',
  filter: 'all' | 'live' | 'upcoming' | 'channels' | 'vods' = 'all'
): Promise<APIMatch[]> {
  const { allStreams } = await fetchOnDemandStreams();
  let matches = allStreams.map(convertOnDemandToMatch);

  // If ondemand.st API returned 0 streams, use bundled static events with active timestamps
  if (matches.length === 0) {
    const nowSec = Math.floor(Date.now() / 1000);
    matches = [...STATIC_LIVE_EVENTS, ...STATIC_UPCOMING_EVENTS].map((m, idx) => {
      const isLive = idx < STATIC_LIVE_EVENTS.length;
      const sAt = isLive ? nowSec - 1800 : nowSec + 3600 * (1 + (idx % 24));
      return {
        ...m,
        date: sAt * 1000,
        rawPpvStream: {
          ...(m.rawPpvStream || {}),
          starts_at: sAt,
          ends_at: sAt + 7200,
          status: isLive ? 'live' : 'upcoming',
          always_live: isLive ? 1 : 0,
        },
        rawOnDemandStream: {
          ...(m.rawOnDemandStream || {}),
          starts_at: sAt,
          ends_at: sAt + 7200,
          status: isLive ? 'live' : 'upcoming',
          always_live: isLive ? 1 : 0,
        } as any,
      };
    });
  }

  // Filter by category
  if (sportCategory && sportCategory !== 'all') {
    const norm = sportCategory.toLowerCase().replace(/[^a-z0-9]/g, '');
    matches = matches.filter((m) => {
      const cNorm = (m.category || '').toLowerCase().replace(/[^a-z0-9]/g, '');
      return cNorm === norm || cNorm.includes(norm) || norm.includes(cNorm);
    });
  }

  // Filter by status (live vs upcoming vs channels)
  const nowSec = Math.floor(Date.now() / 1000);
  if (filter === 'live') {
    matches = matches.filter((m) => {
      const s = m.rawOnDemandStream;
      if (!s) return false;
      return s.status === 'live' || isMatchLive(s.starts_at, s.ends_at, s.always_live);
    });
  } else if (filter === 'upcoming') {
    matches = matches.filter((m) => {
      const s = m.rawOnDemandStream;
      if (!s) return false;
      return s.status === 'upcoming' || (s.starts_at > nowSec && !s.always_live);
    });
  } else if (filter === 'channels') {
    matches = matches.filter((m) => Boolean(m.rawOnDemandStream?.always_live) || m.league?.toLowerCase().includes('channel'));
  }

  // Sort: Marquee featured matches (e.g. India vs New Zealand) first, then Live matches, then chronological
  matches.sort((a, b) => {
    const aTitle = (a.title || '').toLowerCase();
    const bTitle = (b.title || '').toLowerCase();
    const isMarquee = (t: string) => (t.includes('india') || t.includes('ind')) && (t.includes('zealand') || t.includes('nz'));
    const aMarquee = isMarquee(aTitle);
    const bMarquee = isMarquee(bTitle);
    if (aMarquee && !bMarquee) return -1;
    if (!aMarquee && bMarquee) return 1;

    const aLive = a.rawOnDemandStream?.status === 'live' || isMatchLive(a.rawOnDemandStream?.starts_at, a.rawOnDemandStream?.ends_at, a.rawOnDemandStream?.always_live);
    const bLive = b.rawOnDemandStream?.status === 'live' || isMatchLive(b.rawOnDemandStream?.starts_at, b.rawOnDemandStream?.ends_at, b.rawOnDemandStream?.always_live);
    if (aLive && !bLive) return -1;
    if (!aLive && bLive) return 1;
    return a.date - b.date;
  });

  return matches;
}

/**
 * Fetch Live Matches only
 */
export async function fetchLiveMatches(): Promise<APIMatch[]> {
  return fetchMatches('all', 'live');
}

/**
 * Fetch Live Sports TV Channels
 * Guaranteed 219+ live broadcaster channels across Sky Sports, Willow, TNT, Fox, NBC, ESPN, etc.
 */
export async function fetchLiveSportsChannels(): Promise<LiveSportsChannel[]> {
  const channelMap = new Map<string, LiveSportsChannel>();
  const channelUrlSets = new Map<string, Set<string>>();

  const addSourceToChannel = (chId: string, embedUrl: string, hd = true) => {
    const ch = channelMap.get(chId);
    if (!ch || !embedUrl) return;
    let normalized = embedUrl.trim();
    if (normalized.includes('/player/jw/?')) {
      normalized = normalized.replace('/player/jw/?', '/player/hls/?v=542&');
    }
    let seen = channelUrlSets.get(chId);
    if (!seen) {
      seen = new Set<string>();
      channelUrlSets.set(chId, seen);
    }
    if (seen.has(normalized)) return;
    seen.add(normalized);
    const nextIdx = ch.sources.length + 1;
    ch.sources.push({
      id: `${chId}-s${nextIdx}`,
      streamNo: nextIdx,
      language: 'English',
      hd,
      embedUrl: normalized,
      source: `Server ${nextIdx}`,
      serverName: `Server ${nextIdx}`,
      viewers: ch.viewers || 18000,
    });
  };

  try {
    const { allStreams } = await fetchOnDemandStreams();

    // 1. Prioritize live 24/7-streams category and always_live channels from ondemand.st
    allStreams.forEach((stream) => {
      const is247 = Boolean(stream.always_live) || (stream.category_name || '').toLowerCase().includes('24/7');
      if (!is247) return;

      const chName = (stream.name || '').trim();
      if (!chName) return;
      const chId = `channel-${chName.toLowerCase().replace(/[^a-z0-9]/g, '-')}`;

      if (!channelMap.has(chId)) {
        channelMap.set(chId, {
          id: chId,
          name: chName,
          code: chName.slice(0, 8).toUpperCase(),
          category: inferChannelCategory(chName),
          logo: stream.poster || 'https://images.unsplash.com/photo-1540747913346-19e32dc3e97e?w=800',
          quality: '1080p 60fps HD',
          currentShow: `${chName} — Live 24/7 Stream`,
          viewers: Math.max(14500, (stream.viewers || 12) * 420),
          sources: [],
        });
      }

      const rawSources = [...(stream.sources || [])].sort((a, b) => {
        const ae = a.embed || '';
        const be = b.embed || '';
        const ap = ae.includes('/player/hls/') ? (ae.includes('v=542') ? 1 : 2) : 3;
        const bp = be.includes('/player/hls/') ? (be.includes('v=542') ? 1 : 2) : 3;
        return ap - bp;
      });

      rawSources.forEach((src) => {
        if (src.embed) addSourceToChannel(chId, src.embed, src.hd !== 0);
      });
      const fallbackEmbed = stream.iframe || stream.embed || `https://damitv.st/embed/?id=${stream.id}`;
      addSourceToChannel(chId, fallbackEmbed, true);
    });

    // 2. Extract all unique live sports broadcaster feeds (Willow Cricket, Sky Sports, TNT Sports, SuperSport, Fox, etc.)
    allStreams.forEach((stream) => {
      const sortedSources = [...(stream.sources || [])].sort((a, b) => {
        const ae = a.embed || '';
        const be = b.embed || '';
        const ap = ae.includes('/player/hls/') ? (ae.includes('v=542') ? 1 : 2) : 3;
        const bp = be.includes('/player/hls/') ? (be.includes('v=542') ? 1 : 2) : 3;
        return ap - bp;
      });

      sortedSources.forEach((src) => {
        if (!src.name || src.name.startsWith('Server ')) return;
        const chName = src.name.trim();
        const chId = `channel-${chName.toLowerCase().replace(/[^a-z0-9]/g, '-')}`;

        if (!channelMap.has(chId)) {
          channelMap.set(chId, {
            id: chId,
            name: chName,
            code: chName.slice(0, 8).toUpperCase(),
            category: inferChannelCategory(chName),
            logo: stream.poster || 'https://images.unsplash.com/photo-1540747913346-19e32dc3e97e?w=800',
            quality: src.hd ? '1080p 60fps HD' : '720p HD',
            currentShow: `${stream.name} (${stream.league || 'Live Event'})`,
            viewers: Math.max(16200, (stream.viewers || 18) * 380),
            sources: [],
          });
        }

        addSourceToChannel(chId, src.embed || `https://damitv.st/embed/?id=${stream.id}`, src.hd !== 0);
      });
    });
  } catch {
    // Continue to static channels fallback if live feed unavailable
  }

  // 3. Append static channels after live channels (or add their sources as backup servers to matching channels)
  STATIC_247_CHANNELS.forEach((ch) => {
    const existing = channelMap.get(ch.id);
    if (existing) {
      (ch.sources || []).forEach((src) => {
        if (src.embedUrl) addSourceToChannel(ch.id, src.embedUrl, src.hd);
      });
    } else {
      channelMap.set(ch.id, {
        ...ch,
        sources: (ch.sources || []).map((src, idx) => ({
          ...src,
          streamNo: idx + 1,
          source: `Server ${idx + 1}`,
          serverName: `Server ${idx + 1}`,
        })),
      });
    }
  });

  return Array.from(channelMap.values());
}

export function inferChannelCategory(name: string): string {
  const n = name.toLowerCase();
  if (n.includes('cricket') || n.includes('willow') || n.includes('501') || n.includes('astro cricket')) return 'Cricket';
  if (n.includes('football') || n.includes('footy') || n.includes('bundesliga') || n.includes('calcio') || n.includes('laliga') || n.includes('premier league') || n.includes('tnt sports') || n.includes('ziggo')) return 'Football';
  if (n.includes('f1') || n.includes('motogp') || n.includes('racing') || n.includes('dirtvision') || n.includes('formula')) return 'Motorsport';
  if (n.includes('nba') || n.includes('basketball')) return 'Basketball';
  if (n.includes('nfl') || n.includes('american football') || n.includes('cfb') || n.includes('acc network') || n.includes('sec network') || n.includes('fox sports') || n.includes('nbc') || n.includes('usa network') || n.includes('espn')) return 'American Football';
  if (n.includes('nhl') || n.includes('hockey')) return 'Ice Hockey';
  if (n.includes('tennis')) return 'Tennis';
  if (n.includes('golf')) return 'Golf';
  if (n.includes('fight') || n.includes('ufc') || n.includes('mma') || n.includes('wrestling') || n.includes('dazn')) return 'Combat Sports';
  return 'Sports';
}

/**
 * Synchronous complete 219+ channel suite
 */
export function getLiveSportsChannels(): LiveSportsChannel[] {
  return STATIC_247_CHANNELS.map((ch) => ({
    ...ch,
    sources: (ch.sources || []).map((src, idx) => ({
      ...src,
      streamNo: idx + 1,
      source: `Server ${idx + 1}`,
      serverName: `Server ${idx + 1}`,
    })),
  }));
}

/**
 * Fetch all available stream feeds for a match (strictly labeled Server 1, Server 2, Server 3...)
 */
export async function fetchAllStreamsForMatch(match: APIMatch): Promise<StreamSource[]> {
  if (match._streamSources && match._streamSources.length > 0) {
    const seen = new Set<string>();
    const deduped: StreamSource[] = [];
    match._streamSources.forEach((src) => {
      const url = (src.embedUrl || '').trim();
      if (!url || seen.has(url)) return;
      seen.add(url);
      const n = deduped.length + 1;
      deduped.push({
        ...src,
        streamNo: n,
        source: `Server ${n}`,
        serverName: `Server ${n}`,
      });
    });
    if (deduped.length > 0) return deduped;
  }

  const s = match.rawOnDemandStream;
  if (s && Array.isArray(s.sources) && s.sources.length > 0) {
    const seen = new Set<string>();
    const list: StreamSource[] = [];
    const sorted = [...s.sources].sort((a, b) => {
      const ae = a.embed || '';
      const be = b.embed || '';
      const ap = ae.includes('/player/hls/') ? (ae.includes('v=542') ? 1 : 2) : 3;
      const bp = be.includes('/player/hls/') ? (be.includes('v=542') ? 1 : 2) : 3;
      return ap - bp;
    });
    sorted.forEach((src, idx) => {
      const url = (src.embed || s.iframe || s.embed || `https://damitv.st/embed/?id=${match.id}`).trim();
      if (!url || seen.has(url)) return;
      seen.add(url);
      const n = list.length + 1;
      list.push({
        id: `${match.id}-${src.id || idx + 1}`,
        streamNo: n,
        language: 'English',
        hd: Boolean(src.hd !== 0),
        embedUrl: url,
        source: `Server ${n}`,
        serverName: `Server ${n}`,
        viewers: match.viewers,
      });
    });
    if (list.length > 0) return list;
  }

  return [
    {
      id: `${match.id}-default`,
      streamNo: 1,
      language: 'English',
      hd: true,
      embedUrl: `https://damitv.st/embed/?id=${match.id}`,
      source: 'Server 1',
      serverName: 'Server 1',
      viewers: match.viewers,
    },
  ];
}

/**
 * Match live status calculation
 */
export function isMatchLive(startsAtSec?: number, endsAtSec?: number, alwaysLive?: number | boolean): boolean {
  if (alwaysLive) return true;
  if (!startsAtSec || startsAtSec === 0) return true;

  const nowSec = Math.floor(Date.now() / 1000);
  const endSec = endsAtSec && endsAtSec > startsAtSec ? endsAtSec : startsAtSec + 3.5 * 3600;

  return nowSec >= startsAtSec - 15 * 60 && nowSec <= endSec;
}

/**
 * Format match time with IST & countdown
 */
export function formatMatchTime(matchTimestampMs: number, startsAtSec?: number): {
  formattedDate: string;
  formattedTime: string;
  istTime: string;
  status: 'live' | 'upcoming' | 'ended';
  countdown: string;
} {
  const now = Date.now();
  const ts = startsAtSec && startsAtSec > 0 ? startsAtSec * 1000 : matchTimestampMs;
  const dateObj = new Date(ts);

  let status: 'live' | 'upcoming' | 'ended' = 'upcoming';
  if (!startsAtSec || startsAtSec === 0) {
    status = 'live';
  } else {
    const nowSec = Math.floor(now / 1000);
    const estimatedEndSec = startsAtSec + 3.5 * 3600;
    if (nowSec >= startsAtSec && nowSec <= estimatedEndSec) {
      status = 'live';
    } else if (nowSec > estimatedEndSec) {
      status = 'ended';
    } else {
      status = 'upcoming';
    }
  }

  const formattedDate = dateObj.toLocaleDateString(undefined, {
    month: 'short',
    day: 'numeric',
    weekday: 'short',
  });

  const formattedTime = dateObj.toLocaleTimeString(undefined, {
    hour: '2-digit',
    minute: '2-digit',
  });

  const istTime = dateObj.toLocaleTimeString('en-IN', {
    timeZone: 'Asia/Kolkata',
    hour: '2-digit',
    minute: '2-digit',
    hour12: true,
  });

  let countdown = '';
  if (status === 'live') {
    countdown = 'LIVE NOW';
  } else if (status === 'upcoming') {
    const diffMs = ts - now;
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
    const diffMins = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));

    if (diffHours > 24) {
      const days = Math.floor(diffHours / 24);
      countdown = `In ${days}d ${diffHours % 24}h`;
    } else if (diffHours > 0) {
      countdown = `Starts in ${diffHours}h ${diffMins}m`;
    } else {
      countdown = `Starts in ${Math.max(1, diffMins)}m`;
    }
  } else {
    countdown = 'Match Ended';
  }

  return {
    formattedDate,
    formattedTime,
    istTime: `${istTime} IST`,
    status,
    countdown,
  };
}

/**
 * Poster fallback utility
 */
export const SPORT_DEFAULT_IMAGES: Record<string, string> = {
  football: 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=800&auto=format&fit=crop&q=80',
  'american-football': 'https://images.unsplash.com/photo-1566577739112-5180d4bf9390?w=800&auto=format&fit=crop&q=80',
  basketball: 'https://images.unsplash.com/photo-1546519638-68e109498ffc?w=800&auto=format&fit=crop&q=80',
  cricket: 'https://images.unsplash.com/photo-1540747913346-19e32dc3e97e?w=800&auto=format&fit=crop&q=80',
  'motor-sports': 'https://images.unsplash.com/photo-1568605117036-5fe5e7bab0b7?w=800&auto=format&fit=crop&q=80',
  motorsport: 'https://images.unsplash.com/photo-1568605117036-5fe5e7bab0b7?w=800&auto=format&fit=crop&q=80',
  'ice-hockey': 'https://images.unsplash.com/photo-1580748141549-71748dbe0bdc?w=800&auto=format&fit=crop&q=80',
  hockey: 'https://images.unsplash.com/photo-1580748141549-71748dbe0bdc?w=800&auto=format&fit=crop&q=80',
  wrestling: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?w=800&auto=format&fit=crop&q=80',
  fight: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?w=800&auto=format&fit=crop&q=80',
  golf: 'https://images.unsplash.com/photo-1535131749006-b7f58c99034b?w=800&auto=format&fit=crop&q=80',
  rugby: 'https://images.unsplash.com/photo-1529900245534-47fbf822156a?w=800&auto=format&fit=crop&q=80',
  default: 'https://images.unsplash.com/photo-1461896836934-ffe607ba8211?w=800&auto=format&fit=crop&q=80',
};

export function getSportPosterUrl(posterUrl?: string, category = 'default'): string {
  if (posterUrl && posterUrl.startsWith('http')) return posterUrl;
  const key = category.toLowerCase().replace(/[^a-z0-9]/g, '-');
  return SPORT_DEFAULT_IMAGES[key] || SPORT_DEFAULT_IMAGES.default;
}

export function getTeamBadgeUrl(badge?: string): string {
  return badge || '';
}

// PPV VOD backward-compatibility fallbacks
export async function fetchPPVVods(): Promise<PPVVodCategory[]> {
  return [];
}

export async function fetchPPVVodById(_id: number | string): Promise<PPVVodDetail | null> {
  return null;
}
