import { useState, useEffect } from 'react';

/**
 * Custom React hook that detects when a player or document enters fullscreen mode
 * on mobile devices and automatically forces screen orientation to landscape
 * using `screen.orientation.lock("landscape")`.
 *
 * When fullscreen exits, it unlocks orientation.
 */
export function useFullscreenLandscape() {
  const [isFullscreen, setIsFullscreen] = useState<boolean>(() => {
    if (typeof document === 'undefined') return false;
    return Boolean(
      document.fullscreenElement ||
      (document as any).webkitFullscreenElement ||
      (document as any).mozFullScreenElement ||
      (document as any).msFullscreenElement
    );
  });

  useEffect(() => {
    const handleFullscreenChange = async () => {
      const isFs = Boolean(
        document.fullscreenElement ||
        (document as any).webkitFullscreenElement ||
        (document as any).mozFullScreenElement ||
        (document as any).msFullscreenElement
      );

      setIsFullscreen(isFs);

      if (isFs) {
        // Automatically lock orientation to landscape when in fullscreen mode
        try {
          if (window.screen?.orientation && 'lock' in window.screen.orientation) {
            await (window.screen.orientation as any).lock('landscape');
          } else if ((window.screen as any)?.lockOrientation) {
            (window.screen as any).lockOrientation('landscape');
          } else if ((window.screen as any)?.mozLockOrientation) {
            (window.screen as any).mozLockOrientation('landscape');
          } else if ((window.screen as any)?.msLockOrientation) {
            (window.screen as any).msLockOrientation('landscape');
          }
        } catch (error) {
          // Screen orientation lock might be rejected or unsupported on some desktop browsers or secure contexts
          console.debug('Orientation lock to landscape skipped or unsupported:', error);
        }
      } else {
        // Unlock orientation on exit
        try {
          if (window.screen?.orientation && 'unlock' in window.screen.orientation) {
            (window.screen.orientation as any).unlock?.();
          } else if ((window.screen as any)?.unlockOrientation) {
            (window.screen as any).unlockOrientation();
          } else if ((window.screen as any)?.mozUnlockOrientation) {
            (window.screen as any).mozUnlockOrientation();
          } else if ((window.screen as any)?.msUnlockOrientation) {
            (window.screen as any).msUnlockOrientation();
          }
        } catch (error) {
          console.debug('Orientation unlock skipped:', error);
        }
      }
    };

    document.addEventListener('fullscreenchange', handleFullscreenChange);
    document.addEventListener('webkitfullscreenchange', handleFullscreenChange);
    document.addEventListener('mozfullscreenchange', handleFullscreenChange);
    document.addEventListener('MSFullscreenChange', handleFullscreenChange);

    return () => {
      document.removeEventListener('fullscreenchange', handleFullscreenChange);
      document.removeEventListener('webkitfullscreenchange', handleFullscreenChange);
      document.removeEventListener('mozfullscreenchange', handleFullscreenChange);
      document.removeEventListener('MSFullscreenChange', handleFullscreenChange);

      try {
        if (window.screen?.orientation && 'unlock' in window.screen.orientation) {
          (window.screen.orientation as any).unlock?.();
        }
      } catch {
        // Ignore
      }
    };
  }, []);

  return { isFullscreen };
}

export default useFullscreenLandscape;
